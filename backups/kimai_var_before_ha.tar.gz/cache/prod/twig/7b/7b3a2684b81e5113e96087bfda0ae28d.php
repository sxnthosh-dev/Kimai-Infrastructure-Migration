<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_user_list_export.html.twig */
class __TwigTemplate_2a695224e8c2b9e15cb839c14caa2aaf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("reporting/report_user_list_export.html.twig", 1, 1)->unwrap()->yield(CoreExtension::toArray(["avatar" => false, "showAccountNumber" => true, "stats" => ($context["stats"] ?? null), "dataType" => ($context["dataType"] ?? null), "period_attribute" => ($context["period_attribute"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_export.html.twig", "/opt/kimai/templates/reporting/report_user_list_export.html.twig");
    }
}


/* reporting/report_user_list_export.html.twig */
class __TwigTemplate_2a695224e8c2b9e15cb839c14caa2aaf___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user_column' => [$this, 'block_user_column'],
            'duration' => [$this, 'block_duration'],
            'total_duration' => [$this, 'block_total_duration'],
            'total_duration_user' => [$this, 'block_total_duration_user'],
            'total_duration_period' => [$this, 'block_total_duration_period'],
            'rate' => [$this, 'block_rate'],
            'total_rate' => [$this, 'block_total_rate'],
            'total_rate_user' => [$this, 'block_total_rate_user'],
            'total_rate_period' => [$this, 'block_total_rate_period'],
            'internal_rate' => [$this, 'block_internal_rate'],
            'total_internal_rate' => [$this, 'block_total_internal_rate'],
            'total_internal_rate_user' => [$this, 'block_total_internal_rate_user'],
            'total_internal_rate_period' => [$this, 'block_total_internal_rate_period'],
            'period_name' => [$this, 'block_period_name'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "reporting/user_list_period_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/user_list_period_data.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_column(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(App\Utils\StringHelper::sanitizeDDE(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 3), "displayName", [], "any", false, false, false, 3)), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalDuration", [], "any", false, false, false, 6), true), "html", null, true);
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["absoluteDuration"] ?? null), true), "html", null, true);
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["usersTotalDuration"] ?? null), true), "html", null, true);
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["total"] ?? null), true), "html", null, true);
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalRate", [], "any", false, false, false, 18), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["absoluteRate"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["usersTotalRate"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalInternalRate", [], "any", false, false, false, 30), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 33
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["absoluteInternalRate"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["usersTotalInternalRate"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["total"] ?? null), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "        <th class=\"text-center text-nowrap\">
            ";
        // line 43
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["column"] ?? null)), "html", null, true);
        yield "
        </th>
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  317 => 43,  314 => 42,  307 => 41,  299 => 39,  292 => 38,  284 => 36,  277 => 35,  269 => 33,  262 => 32,  254 => 30,  247 => 29,  239 => 27,  232 => 26,  224 => 24,  217 => 23,  209 => 21,  202 => 20,  194 => 18,  187 => 17,  182 => 15,  175 => 14,  170 => 12,  163 => 11,  158 => 9,  151 => 8,  146 => 6,  139 => 5,  131 => 3,  124 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_export.html.twig", "/opt/kimai/templates/reporting/report_user_list_export.html.twig");
    }
}
