<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/buttons.html.twig */
class __TwigTemplate_4f7f1bc816f3933428135f2d0b1cedfb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "
";
        // line 9
        yield "
";
        // line 25
        yield "
";
        // line 40
        yield "
";
        // line 57
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_action_cardtoolbutton($icon = null, $attrs = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "icon" => $icon,
            "attrs" => $attrs,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 3, $this->getSourceContext())->macro_button(...[($context["icon"] ?? null), ($context["attrs"] ?? null)]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 6
    public function macro_action_collapsebutton($label = null, $target = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "label" => $label,
            "target" => $target,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 7
            yield (string) $this->getTemplateForMacro("macro_action_cardtoolbutton", $context, 7, $this->getSourceContext())->macro_action_cardtoolbutton(...["collapse", ["collapse" => ($context["target"] ?? null), "title" => ((array_key_exists("label", $context)) ? (Twig\Extension\CoreExtension::default(($context["label"] ?? null), "")) : (""))]]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 10
    public function macro_link_button($label = null, $href = null, $icon = null, $type = null, $size = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "label" => $label,
            "href" => $href,
            "icon" => $icon,
            "type" => $type,
            "size" => $size,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 11
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 11)->unwrap();
            // line 12
            yield "
    ";
            // line 13
            $context["_href"] = (((array_key_exists("href", $context) &&  !(null === $context["href"]))) ? ($context["href"]) : ("#"));
            // line 14
            yield "    ";
            $context["_icon"] = (((array_key_exists("icon", $context) &&  !(null === $context["icon"]))) ? ($context["icon"]) : (false));
            // line 15
            yield "    ";
            $context["_type"] = (((array_key_exists("type", $context) &&  !(null === $context["type"]))) ? ($context["type"]) : ("primary"));
            // line 16
            yield "    ";
            $context["_size"] = (((array_key_exists("size", $context) &&  !(null === $context["size"]))) ? ($context["size"]) : (null));
            // line 17
            yield "
    ";
            // line 18
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 18, $this->getSourceContext())->macro_button(...[($context["_icon"] ?? null), ["title" =>             // line 19
($context["label"] ?? null), "combined" => true, "href" =>             // line 21
($context["_href"] ?? null), "class" => (((($tmp =             // line 22
($context["_size"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("btn-" . ($context["_size"] ?? null))) : (""))],             // line 23
($context["_type"] ?? null)]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 26
    public function macro_action_button($label = null, $action = null, $icon = null, $type = null, $size = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "label" => $label,
            "action" => $action,
            "icon" => $icon,
            "type" => $type,
            "size" => $size,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 27
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 27)->unwrap();
            // line 28
            yield "
    ";
            // line 29
            $context["_icon"] = (((array_key_exists("icon", $context) &&  !(null === $context["icon"]))) ? ($context["icon"]) : (false));
            // line 30
            yield "    ";
            $context["_type"] = (((array_key_exists("type", $context) &&  !(null === $context["type"]))) ? ($context["type"]) : ("primary"));
            // line 31
            yield "    ";
            $context["_size"] = (((array_key_exists("size", $context) &&  !(null === $context["size"]))) ? ($context["size"]) : (null));
            // line 32
            yield "
    ";
            // line 33
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 33, $this->getSourceContext())->macro_button(...[($context["_icon"] ?? null), ["title" =>             // line 34
($context["label"] ?? null), "class" => (((($tmp =             // line 35
($context["_size"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (("btn-" . ($context["_size"] ?? null))) : ("")), "buttonType" => "button", "attr" => ["data-action" =>             // line 37
($context["action"] ?? null)]],             // line 38
($context["_type"] ?? null)]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 41
    public function macro_submit_button($icon = null, $user_values = null, $type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "icon" => $icon,
            "user_values" => $user_values,
            "type" => $type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 42
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 42)->unwrap();
            // line 43
            yield "
    ";
            // line 44
            $context["default_values"] = ["combined" => true, "attr" => ["type" => "submit"], "disabled" => false, "buttonType" => "submit"];
            // line 50
            yield "
    ";
            // line 51
            $context["values_attr"] = Twig\Extension\CoreExtension::merge(CoreExtension::getAttribute($this->env, $this->source, ($context["default_values"] ?? null), "attr", [], "any", false, false, false, 51), ((CoreExtension::getAttribute($this->env, $this->source, ($context["user_values"] ?? null), "attr", [], "any", true, true, false, 51)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["user_values"] ?? null), "attr", [], "any", false, false, false, 51), [])) : ([])));
            // line 52
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge(($context["default_values"] ?? null), ((array_key_exists("user_values", $context)) ? (Twig\Extension\CoreExtension::default(($context["user_values"] ?? null), [])) : ([])));
            // line 53
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge(($context["values"] ?? null), ["attr" => ($context["values_attr"] ?? null)]);
            // line 54
            yield "
    ";
            // line 55
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 55, $this->getSourceContext())->macro_button(...[($context["icon"] ?? null), ($context["values"] ?? null), ($context["type"] ?? null)]);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 58
    public function macro_dropdown_button($button = null, $actions = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "button" => $button,
            "actions" => $actions,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 59
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 59)->unwrap();
            // line 60
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 60)->unwrap();
            // line 61
            yield "
    ";
            // line 62
            $context["button_default"] = ["buttonType" => "button", "class" => "", "combined" => true, "attr" => ["data-bs-toggle" => "dropdown"]];
            // line 70
            yield "
    ";
            // line 71
            $context["options"] = Twig\Extension\CoreExtension::merge(((array_key_exists("options", $context)) ? (Twig\Extension\CoreExtension::default(($context["options"] ?? null), [])) : ([])), ["icon_class" => "me-2 text-center"]);
            // line 72
            yield "    ";
            $context["values_attr"] = Twig\Extension\CoreExtension::merge(CoreExtension::getAttribute($this->env, $this->source, ($context["button_default"] ?? null), "attr", [], "any", false, false, false, 72), ((CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "attr", [], "any", true, true, false, 72)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "attr", [], "any", false, false, false, 72), [])) : ([])));
            // line 73
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge(($context["button_default"] ?? null), ((array_key_exists("button", $context)) ? (Twig\Extension\CoreExtension::default(($context["button"] ?? null), [])) : ([])));
            // line 74
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge(($context["values"] ?? null), ["attr" => ($context["values_attr"] ?? null)]);
            // line 75
            yield "
    <div class=\"dropdown\">
        ";
            // line 77
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 77, $this->getSourceContext())->macro_button(...[(((CoreExtension::getAttribute($this->env, $this->source,             // line 78
($context["button"] ?? null), "icon", [], "any", true, true, false, 78) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "icon", [], "any", false, false, false, 78)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "icon", [], "any", false, false, false, 78)) : (false)), Twig\Extension\CoreExtension::merge(            // line 79
($context["values"] ?? null), ["class" => (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "class", [], "any", false, false, false, 79) . " dropdown-toggle")]), (((CoreExtension::getAttribute($this->env, $this->source,             // line 80
($context["button"] ?? null), "type", [], "any", true, true, false, 80) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "type", [], "any", false, false, false, 80)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["button"] ?? null), "type", [], "any", false, false, false, 80)) : (null))]);
            // line 81
            yield "

        ";
            // line 83
            if ((is_iterable(($context["actions"] ?? null)) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["actions"] ?? null)) > 0))) {
                // line 84
                yield "            <div class=\"dropdown-menu\">
                ";
                // line 85
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["actions"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["action"]) {
                    // line 86
                    yield "                    ";
                    $context["_title"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["action"], "title", [], "any", true, true, false, 86) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["action"], "title", [], "any", false, false, false, 86)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "title", [], "any", false, false, false, 86)) : (null));
                    // line 87
                    yield "                    ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "url", [], "any", true, true, false, 87)) {
                        // line 88
                        yield "                        ";
                        $context["_href"] = CoreExtension::getAttribute($this->env, $this->source, $context["action"], "url", [], "any", false, false, false, 88);
                        // line 89
                        yield "                    ";
                    } else {
                        // line 90
                        yield "                        ";
                        $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["action"], "href", [], "any", true, true, false, 90) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["action"], "href", [], "any", false, false, false, 90)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "href", [], "any", false, false, false, 90)) : ("#"));
                        // line 91
                        yield "                    ";
                    }
                    // line 92
                    yield "                    ";
                    $context["_icon"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["action"], "icon", [], "any", true, true, false, 92) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["action"], "icon", [], "any", false, false, false, 92)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "icon", [], "any", false, false, false, 92)) : (false));
                    // line 93
                    yield "                    ";
                    $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["action"], "attr", [], "any", true, true, false, 93) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["action"], "attr", [], "any", false, false, false, 93)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "attr", [], "any", false, false, false, 93)) : ([]));
                    // line 94
                    yield "                    ";
                    $context["_class"] = ("dropdown-item " . (((CoreExtension::getAttribute($this->env, $this->source, $context["action"], "class", [], "any", true, true, false, 94) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["action"], "class", [], "any", false, false, false, 94)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["action"], "class", [], "any", false, false, false, 94)) : ("")));
                    // line 95
                    yield "
                    <a class=\"";
                    // line 96
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_class"] ?? null), "html", null, true);
                    yield "\" href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
                    yield "\" ";
                    yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 96, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                    yield ">";
                    // line 97
                    if ( !(($context["_icon"] ?? null) === false)) {
                        // line 98
                        yield "<span class=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon_class", [], "any", false, false, false, 98), "html", null, true);
                        yield "\">";
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["_icon"] ?? null), false);
                        yield "</span>
                        ";
                    }
                    // line 100
                    if ( !(null === ($context["_title"] ?? null))) {
                        // line 101
                        yield (string) ($context["_title"] ?? null);
                        yield "
                        ";
                    }
                    // line 103
                    yield "                    </a>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['action'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 105
                yield "            </div>
        ";
            }
            // line 107
            yield "    </div>";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/buttons.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  356 => 107,  352 => 105,  344 => 103,  339 => 101,  337 => 100,  329 => 98,  327 => 97,  320 => 96,  317 => 95,  314 => 94,  311 => 93,  308 => 92,  305 => 91,  302 => 90,  299 => 89,  296 => 88,  293 => 87,  290 => 86,  286 => 85,  283 => 84,  281 => 83,  277 => 81,  275 => 80,  274 => 79,  273 => 78,  272 => 77,  268 => 75,  265 => 74,  262 => 73,  259 => 72,  257 => 71,  254 => 70,  252 => 62,  249 => 61,  246 => 60,  244 => 59,  230 => 58,  224 => 55,  221 => 54,  218 => 53,  215 => 52,  213 => 51,  210 => 50,  208 => 44,  205 => 43,  203 => 42,  189 => 41,  183 => 38,  182 => 37,  181 => 35,  180 => 34,  179 => 33,  176 => 32,  173 => 31,  170 => 30,  168 => 29,  165 => 28,  163 => 27,  147 => 26,  141 => 23,  140 => 22,  139 => 21,  138 => 19,  137 => 18,  134 => 17,  131 => 16,  128 => 15,  125 => 14,  123 => 13,  120 => 12,  118 => 11,  102 => 10,  96 => 7,  83 => 6,  76 => 3,  74 => 2,  61 => 1,  55 => 57,  52 => 40,  49 => 25,  46 => 9,  43 => 5,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/buttons.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/buttons.html.twig");
    }
}
