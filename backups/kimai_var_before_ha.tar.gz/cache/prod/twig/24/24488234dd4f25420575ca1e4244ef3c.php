<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/index.html.twig */
class __TwigTemplate_93ef1348cdb355d598ea8d1ceae3fd50 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["actions"] = $this->macros["actions"] = $this->load("project/actions.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 5, $this->getSourceContext())->macro_project_row_attr(...[($context["entry"] ?? null), ($context["now"] ?? null)]);
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 9
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_name", $context, 9, $this->getSourceContext())->macro_label_name(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 9), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9))]);
            yield "
    ";
        } elseif ((        // line 10
($context["column"] ?? null) == "customer")) {
            // line 11
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 11, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "customer", [], "any", false, false, false, 11)]);
            yield "
    ";
        } elseif ((        // line 12
($context["column"] ?? null) == "comment")) {
            // line 13
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentOneLiner($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "comment", [], "any", false, false, false, 13), "html", null, true));
            yield "
    ";
        } elseif ((        // line 14
($context["column"] ?? null) == "orderNumber")) {
            // line 15
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "orderNumber", [], "any", false, false, false, 15), "html", null, true);
            yield "
    ";
        } elseif ((        // line 16
($context["column"] ?? null) == "number")) {
            // line 17
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "number", [], "any", false, false, false, 17), "html", null, true);
            yield "
    ";
        } elseif ((        // line 18
($context["column"] ?? null) == "orderDate")) {
            // line 19
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "orderDate", [], "any", false, false, false, 19))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "orderDate", [], "any", false, false, false, 19)), "html", null, true);
            }
            // line 20
            yield "    ";
        } elseif ((($context["column"] ?? null) == "project_start")) {
            // line 21
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "start", [], "any", false, false, false, 21))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "start", [], "any", false, false, false, 21)), "html", null, true);
            }
            // line 22
            yield "    ";
        } elseif ((($context["column"] ?? null) == "project_end")) {
            // line 23
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 23))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 23)), "html", null, true);
            }
            // line 24
            yield "    ";
        } elseif ((($context["column"] ?? null) == "lockedUntil")) {
            // line 25
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "lockedUntil", [], "any", false, false, false, 25))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "lockedUntil", [], "any", false, false, false, 25)), "html", null, true);
            }
            // line 26
            yield "    ";
        } elseif ((($context["column"] ?? null) == "budget")) {
            // line 27
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasBudget", [], "method", false, false, false, 27)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 28
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "budget", [], "any", false, false, false, 28), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "customer", [], "any", false, false, false, 28), "currency", [], "any", false, false, false, 28)), "html", null, true);
                yield "
        ";
            } else {
                // line 30
                yield "            &ndash;
        ";
            }
            // line 32
            yield "    ";
        } elseif ((($context["column"] ?? null) == "timeBudget")) {
            // line 33
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasTimeBudget", [], "method", false, false, false, 33)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 34
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "timeBudget", [], "any", false, false, false, 34)), "html", null, true);
                yield "
        ";
            } else {
                // line 36
                yield "            &ndash;
        ";
            }
            // line 38
            yield "    ";
        } elseif ((($context["column"] ?? null) == "billable")) {
            // line 39
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 39, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "billable", [], "any", false, false, false, 39)]);
            yield "
    ";
        } elseif ((        // line 40
($context["column"] ?? null) == "team")) {
            // line 41
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 41, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "teams", [], "any", false, false, false, 41)]);
            yield "
    ";
        } elseif ((        // line 42
($context["column"] ?? null) == "visible")) {
            // line 43
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 43, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "visible", [], "any", false, false, false, 43)]);
            yield "
    ";
        } elseif ((        // line 44
($context["column"] ?? null) == "actions")) {
            // line 45
            yield "        ";
            yield (string) $macros["actions"]->getTemplateForMacro("macro_project", $context, 45, $this->getSourceContext())->macro_project(...[($context["entry"] ?? null), "index"]);
            yield "
    ";
        } elseif ((is_string($_v0 =         // line 46
($context["column"] ?? null)) && is_string($_v1 = "mf_") && str_starts_with($_v0, $_v1))) {
            // line 47
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_meta_field_value", $context, 47, $this->getSourceContext())->macro_meta_field_value(...[($context["entry"] ?? null), ($context["data"] ?? null)]);
            yield "
    ";
        }
        yield from [];
    }

    // line 51
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 52
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 53
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "project/duplicate-redirect.html.twig");
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  229 => 53,  224 => 52,  217 => 51,  208 => 47,  206 => 46,  201 => 45,  199 => 44,  194 => 43,  192 => 42,  187 => 41,  185 => 40,  180 => 39,  177 => 38,  173 => 36,  167 => 34,  164 => 33,  161 => 32,  157 => 30,  151 => 28,  148 => 27,  145 => 26,  140 => 25,  137 => 24,  132 => 23,  129 => 22,  124 => 21,  121 => 20,  116 => 19,  114 => 18,  109 => 17,  107 => 16,  102 => 15,  100 => 14,  95 => 13,  93 => 12,  88 => 11,  86 => 10,  81 => 9,  78 => 8,  71 => 7,  59 => 5,  54 => 1,  52 => 3,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/index.html.twig", "/opt/kimai/templates/project/index.html.twig");
    }
}
