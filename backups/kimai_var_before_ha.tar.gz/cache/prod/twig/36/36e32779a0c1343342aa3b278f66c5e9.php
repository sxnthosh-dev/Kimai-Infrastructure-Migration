<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/customer/monthly_projects_data.html.twig */
class __TwigTemplate_fcf4669118cb7a18791a31c3c7b7b8f3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'user_activity' => [$this, 'block_user_activity'],
            'project_activity' => [$this, 'block_project_activity'],
            'project_total' => [$this, 'block_project_total'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["absoluteDuration"] = 0;
        // line 2
        $context["absoluteInternalRate"] = 0;
        // line 3
        $context["absoluteRate"] = 0;
        // line 4
        $context["totalsDuration"] = [];
        // line 5
        $context["totalsInternalRate"] = [];
        // line 6
        $context["totalsRate"] = [];
        // line 7
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 8
            yield "    ";
            $context["dataTypeTitle"] = "stats.amountTotal";
        } elseif ((        // line 9
($context["dataType"] ?? null) == "internalRate")) {
            // line 10
            yield "    ";
            $context["dataTypeTitle"] = "internalRate";
        } else {
            // line 12
            yield "    ";
            $context["dataTypeTitle"] = "stats.durationTotal";
        }
        // line 14
        yield "<table class=\"table table-bordered dataTable\">
    <thead>
        <tr>
            <th rowspan=\"2\" style=\"";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspanStyle"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
        yield "</th>
            ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "activities", [], "any", false, false, false, 18));
        foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
            // line 19
            yield "                <th colspan=\"3\" class=\"text-center\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "name", [], "any", false, false, false, 19), "html", null, true);
            yield "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['activity'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 21
        yield "            <th rowspan=\"2\" style=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspanStyle"] ?? null), "html", null, true);
        yield "\" class=\"text-center\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
        yield "</th>
        </tr>
        <tr>
            ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "activities", [], "any", false, false, false, 24));
        foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
            // line 25
            yield "                <th class=\"text-center\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
            yield "</th>
                <th class=\"text-center\">";
            // line 26
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
            yield "</th>
                <th class=\"text-center\">";
            // line 27
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
            yield "</th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['activity'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 29
        yield "        </tr>
    </thead>
    ";
        // line 31
        $context["customer"] = null;
        // line 32
        yield "    ";
        $context["maxLength"] = ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "activities", [], "any", false, false, false, 32)) * 3) + 2);
        // line 33
        yield "    <tbody>
    ";
        // line 34
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "stats", [], "any", false, false, false, 34), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (((CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer", [], "any", false, false, false, 34) . "_") . CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer_id", [], "any", false, false, false, 34)) <=> ((CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer", [], "any", false, false, false, 34) . "_") . CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer_id", [], "any", false, false, false, 34))); }));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["project"]) {
            // line 35
            yield "        ";
            $context["activityId"] = null;
            // line 36
            yield "        ";
            $context["rowspan"] = (($_v0 = $context["project"]) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["max_users"] ?? null) : null);
            // line 37
            yield "        ";
            $context["currency"] = (($_v1 = (($_v2 = CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "projects", [], "any", false, false, false, 37)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "id", [], "any", false, false, false, 37)) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["currency"] ?? null) : null);
            // line 38
            yield "        ";
            if ((($context["customer"] ?? null) != (($_v4 = (($_v5 = CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "projects", [], "any", false, false, false, 38)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[(($_v6 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "id", [], "any", false, false, false, 38)) instanceof \Stringable ? (string) $_v6 : $_v6)] ?? null) : null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["customer_id"] ?? null) : null))) {
                // line 39
                yield "            <tr class=\"summary\">
                <td colspan=\"";
                // line 40
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["maxLength"] ?? null), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v7 = (($_v8 = CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "projects", [], "any", false, false, false, 40)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[(($_v9 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "id", [], "any", false, false, false, 40)) instanceof \Stringable ? (string) $_v9 : $_v9)] ?? null) : null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["customer"] ?? null) : null), "html", null, true);
                yield "</td>
            </tr>
            ";
                // line 42
                $context["customer"] = (($_v10 = (($_v11 = CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "projects", [], "any", false, false, false, 42)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[(($_v12 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "id", [], "any", false, false, false, 42)) instanceof \Stringable ? (string) $_v12 : $_v12)] ?? null) : null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["customer_id"] ?? null) : null);
                // line 43
                yield "        ";
            }
            // line 44
            yield "
        ";
            // line 45
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(range(1, ($context["rowspan"] ?? null)));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["i"]) {
                // line 46
                yield "            <tr>
                ";
                // line 47
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 47)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 48
                    yield "                    <th";
                    if ((($context["rowspan"] ?? null) > 1)) {
                        yield " rowspan=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspan"] ?? null), "html", null, true);
                        yield "\" style=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspanStyle"] ?? null), "html", null, true);
                        yield "\"";
                    }
                    yield ">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "name", [], "any", false, false, false, 48), "html", null, true);
                    yield "</th>
                ";
                }
                // line 50
                yield "                ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "activities", [], "any", false, false, false, 50));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
                    // line 51
                    yield "                    ";
                    if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["project"], "activities", [], "any", false, true, false, 51), CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "id", [], "any", false, false, false, 51), [], "array", true, true, false, 51) && ($context["i"] <= Twig\Extension\CoreExtension::length($this->env->getCharset(), (($_v13 = (($_v14 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "activities", [], "any", false, false, false, 51)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[(($_v15 = CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "id", [], "any", false, false, false, 51)) instanceof \Stringable ? (string) $_v15 : $_v15)] ?? null) : null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["users"] ?? null) : null))))) {
                        // line 52
                        yield "                        ";
                        $context["user"] = Twig\Extension\CoreExtension::slice($this->env->getCharset(), (($_v16 = (($_v17 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "activities", [], "any", false, false, false, 52)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[(($_v18 = CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "id", [], "any", false, false, false, 52)) instanceof \Stringable ? (string) $_v18 : $_v18)] ?? null) : null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["users"] ?? null) : null),  -$context["i"]);
                        // line 53
                        yield "                        <td>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), 0, [], "any", false, false, false, 53), "name", [], "any", false, false, false, 53), "html", null, true);
                        yield "</td>
                        <td class=\"text-center\">
                            ";
                        // line 55
                        $context["value"] = (($_v19 = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), 0, [], "any", false, false, false, 55)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19[(($_v20 = ($context["dataType"] ?? null)) instanceof \Stringable ? (string) $_v20 : $_v20)] ?? null) : null);
                        // line 56
                        yield "                            ";
                        yield from $this->unwrap()->yieldBlock('user_activity', $context, $blocks);
                        // line 63
                        yield "                        </td>
                        ";
                        // line 64
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "parent", [], "any", false, false, false, 64), "loop", [], "any", false, false, false, 64), "first", [], "any", false, false, false, 64)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 65
                            yield "                            <td";
                            if ((($context["rowspan"] ?? null) > 1)) {
                                yield " rowspan=\"";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspan"] ?? null), "html", null, true);
                                yield "\"";
                            }
                            yield " class=\"text-center text-nowrap\">
                                ";
                            // line 66
                            $context["value"] = (($_v21 = (($_v22 = CoreExtension::getAttribute($this->env, $this->source, $context["project"], "activities", [], "any", false, false, false, 66)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22[(($_v23 = CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "id", [], "any", false, false, false, 66)) instanceof \Stringable ? (string) $_v23 : $_v23)] ?? null) : null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21[(($_v24 = ($context["dataType"] ?? null)) instanceof \Stringable ? (string) $_v24 : $_v24)] ?? null) : null);
                            // line 67
                            yield "                                ";
                            yield from $this->unwrap()->yieldBlock('project_activity', $context, $blocks);
                            // line 74
                            yield "                            </td>
                        ";
                        }
                        // line 76
                        yield "                    ";
                    } else {
                        // line 77
                        yield "                        <td class=\"text-center\"></td>
                        <td class=\"text-center\"></td>
                        ";
                        // line 79
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "parent", [], "any", false, false, false, 79), "loop", [], "any", false, false, false, 79), "first", [], "any", false, false, false, 79)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 80
                            yield "                            <td";
                            if ((($context["rowspan"] ?? null) > 1)) {
                                yield " rowspan=\"";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspan"] ?? null), "html", null, true);
                                yield "\"";
                            }
                            yield "></td>
                        ";
                        }
                        // line 82
                        yield "                    ";
                    }
                    // line 83
                    yield "                ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['activity'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 84
                yield "                ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 84)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 85
                    yield "                    <th";
                    if ((($context["rowspan"] ?? null) > 1)) {
                        yield " rowspan=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspan"] ?? null), "html", null, true);
                        yield "\" style=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["rowspanStyle"] ?? null), "html", null, true);
                        yield "\"";
                    }
                    yield " class=\"text-center text-nowrap\">
                        ";
                    // line 86
                    $context["value"] = (($_v25 = $context["project"]) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25[(($_v26 = ($context["dataType"] ?? null)) instanceof \Stringable ? (string) $_v26 : $_v26)] ?? null) : null);
                    // line 87
                    yield "                        ";
                    yield from $this->unwrap()->yieldBlock('project_total', $context, $blocks);
                    // line 94
                    yield "                    </th>
                ";
                }
                // line 96
                yield "            </tr>
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['i'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 98
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['project'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 99
        yield "    </tbody>
</table>
";
        yield from [];
    }

    // line 56
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 57
        yield "                                ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 58
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
                                ";
        } else {
            // line 60
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                                ";
        }
        // line 62
        yield "                            ";
        yield from [];
    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_project_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "                                    ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 69
            yield "                                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
                                    ";
        } else {
            // line 71
            yield "                                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                                    ";
        }
        // line 73
        yield "                                ";
        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_project_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 88
        yield "                            ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 89
            yield "                                ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
                            ";
        } else {
            // line 91
            yield "                                ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                            ";
        }
        // line 93
        yield "                        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects_data.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  456 => 93,  450 => 91,  444 => 89,  441 => 88,  434 => 87,  429 => 73,  423 => 71,  417 => 69,  414 => 68,  407 => 67,  402 => 62,  396 => 60,  390 => 58,  387 => 57,  380 => 56,  373 => 99,  358 => 98,  342 => 96,  338 => 94,  335 => 87,  333 => 86,  322 => 85,  319 => 84,  304 => 83,  301 => 82,  291 => 80,  289 => 79,  285 => 77,  282 => 76,  278 => 74,  275 => 67,  273 => 66,  264 => 65,  262 => 64,  259 => 63,  256 => 56,  254 => 55,  248 => 53,  245 => 52,  242 => 51,  224 => 50,  210 => 48,  208 => 47,  205 => 46,  188 => 45,  185 => 44,  182 => 43,  180 => 42,  173 => 40,  170 => 39,  167 => 38,  164 => 37,  161 => 36,  158 => 35,  141 => 34,  138 => 33,  135 => 32,  133 => 31,  129 => 29,  120 => 27,  116 => 26,  111 => 25,  107 => 24,  98 => 21,  88 => 19,  84 => 18,  78 => 17,  73 => 14,  69 => 12,  65 => 10,  63 => 9,  60 => 8,  58 => 7,  56 => 6,  54 => 5,  52 => 4,  50 => 3,  48 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects_data.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects_data.html.twig");
    }
}
