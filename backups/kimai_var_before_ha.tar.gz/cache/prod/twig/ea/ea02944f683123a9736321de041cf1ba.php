<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/actions.html.twig */
class __TwigTemplate_f0f3e37623e42bfdaecbb01750e84d36 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_project($project = null, $view = null, $isTable = null, $params = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "view" => $view,
            "isTable" => $isTable,
            "params" => $params,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 3), "project", ($context["view"] ?? null), Twig\Extension\CoreExtension::merge(((array_key_exists("params", $context)) ? (Twig\Extension\CoreExtension::default(($context["params"] ?? null), [])) : ([])), ["project" => ($context["project"] ?? null)]));
            // line 4
            yield "    ";
            if ((((($context["view"] ?? null) == "index") || (($context["view"] ?? null) == "custom")) ||  !(null === ($context["isTable"] ?? null)))) {
                // line 5
                yield "        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 5, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 5)]);
                yield "
    ";
            } else {
                // line 7
                yield "        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_page_actions", $context, 7, $this->getSourceContext())->macro_page_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 7)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/actions.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  76 => 7,  70 => 5,  67 => 4,  64 => 3,  61 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/actions.html.twig", "/opt/kimai/templates/project/actions.html.twig");
    }
}
