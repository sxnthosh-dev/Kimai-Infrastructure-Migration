<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* timesheet/multi-update.html.twig */
class __TwigTemplate_45423cdfb98a1a368bc716d24098d7fd extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = "default/_form.html.twig";
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(        // line 8
($context["back"] ?? null))];
        // line 10
        yield "    ";
        yield from $this->load("timesheet/multi-update.html.twig", 10, 1)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    // line 78
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 79
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        window.addEventListener(\x27load\x27, function() {
            ";
        // line 82
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "recalculateRates", [], "any", true, true, false, 82)) {
            // line 83
            yield "            document.getElementById(\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "recalculateRates", [], "any", false, false, false, 83), "vars", [], "any", false, false, false, 83), "id", [], "any", false, false, false, 83), "html", null, true);
            yield "\x27).onchange = function() {
                if (this.checked) {
                    document.getElementById(\x27";
            // line 85
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", false, false, false, 85), "vars", [], "any", false, false, false, 85), "id", [], "any", false, false, false, 85), "html", null, true);
            yield "\x27).setAttribute(\x27disabled\x27, \x27disabled\x27);
                    document.getElementById(\x27";
            // line 86
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", false, false, false, 86), "vars", [], "any", false, false, false, 86), "id", [], "any", false, false, false, 86), "html", null, true);
            yield "\x27).setAttribute(\x27disabled\x27, \x27disabled\x27);
                } else {
                    document.getElementById(\x27";
            // line 88
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", false, false, false, 88), "vars", [], "any", false, false, false, 88), "id", [], "any", false, false, false, 88), "html", null, true);
            yield "\x27).removeAttribute(\x27disabled\x27);
                    document.getElementById(\x27";
            // line 89
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", false, false, false, 89), "vars", [], "any", false, false, false, 89), "id", [], "any", false, false, false, 89), "html", null, true);
            yield "\x27).removeAttribute(\x27disabled\x27);
                }
            };
            ";
        }
        // line 93
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", true, true, false, 93)) {
            // line 94
            yield "            let allElements = document.getElementsByName(\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 94), "name", [], "any", false, false, false, 94), "html", null, true);
            yield "\x27)[0].elements;
            for (let i = 0; i < allElements.length; ++i) {
                let el = allElements[i];
                let elAttr = el.getAttribute(\x27name\x27);
                if (elAttr === null) {
                    continue;
                }
                if (elAttr.indexOf(\x27";
            // line 101
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 101), "vars", [], "any", false, false, false, 101), "full_name", [], "any", false, false, false, 101), "html", null, true);
            yield "\x27) !== -1) {
                    ";
            // line 103
            yield "                    el.setAttribute(\x27disabled\x27, \x27disabled\x27);
                    if (el.tomselect !== undefined) {
                        el.tomselect.disable();
                    }
                } else if (elAttr.indexOf(\x27";
            // line 107
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "updateMeta", [], "any", false, false, false, 107), "vars", [], "any", false, false, false, 107), "full_name", [], "any", false, false, false, 107), "html", null, true);
            yield "\x27) !== -1) {
                    el.checked = false;
                    el.onclick = function() {
                        let searchElements = document.getElementsByName(\x27";
            // line 110
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 110), "name", [], "any", false, false, false, 110), "html", null, true);
            yield "\x27)[0].elements;
                        let metaCheckbox = this;
                        let metaName = metaCheckbox.value;
                        for (let s = 0; s < searchElements.length; ++s) {
                            let current = searchElements[s];
                            let currentAttr = current.getAttribute(\x27name\x27);
                            if (currentAttr === null) {
                                continue;
                            }
                            if (currentAttr.indexOf(\x27";
            // line 119
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 119), "vars", [], "any", false, false, false, 119), "full_name", [], "any", false, false, false, 119), "html", null, true);
            yield "\x27) === -1) {
                                continue;
                            }
                            if (current.dataset.name === undefined || current.dataset.name !== metaName) {
                                continue;
                            }
                            if (metaCheckbox.checked) {
                                current.removeAttribute(\x27disabled\x27);
                                if (current.tomselect !== undefined) {
                                    current.tomselect.enable();
                                }
                            } else {
                                current.setAttribute(\x27disabled\x27, \x27disabled\x27);
                                if (current.tomselect !== undefined) {
                                    current.tomselect.disable();
                                }
                            }
                        }
                    };
                }
            }
            ";
        }
        // line 141
        yield "        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/multi-update.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  183 => 141,  158 => 119,  146 => 110,  140 => 107,  134 => 103,  130 => 101,  119 => 94,  116 => 93,  109 => 89,  105 => 88,  100 => 86,  96 => 85,  90 => 83,  88 => 82,  81 => 79,  74 => 78,  68 => 10,  66 => 8,  65 => 7,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/multi-update.html.twig", "/opt/kimai/templates/timesheet/multi-update.html.twig");
    }
}


/* timesheet/multi-update.html.twig */
class __TwigTemplate_45423cdfb98a1a368bc716d24098d7fd___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 10
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "            <fieldset class=\"form-fieldset pb-0\">
                <div class=\"row\">
                    <div class=\"col-md-4\">
                        ";
        // line 15
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 15), 'row');
        yield "
                    </div>
                    <div class=\"col-md-4\">
                        ";
        // line 18
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 18), 'row');
        yield "
                    </div>
                    <div class=\"col-md-4\">
                        ";
        // line 21
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activity", [], "any", false, false, false, 21), 'row');
        yield "
                    </div>
                </div>
            </fieldset>
            <fieldset class=\"form-fieldset pb-0 h-100\">
                ";
        // line 26
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "replaceDescription", [], "any", false, false, false, 26), 'row');
        yield "
                ";
        // line 27
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", false, false, false, 27), 'row');
        yield "
            </fieldset>
            <fieldset class=\"form-fieldset pb-0 h-100\">
                ";
        // line 30
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "replaceTags", [], "any", false, false, false, 30), 'row');
        yield "
                ";
        // line 31
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", false, false, false, 31), 'row');
        yield "
            </fieldset>
            ";
        // line 33
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", true, true, false, 33)) {
            // line 34
            yield "                <fieldset class=\"form-fieldset pb-0\">
                    ";
            // line 35
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 35), 'row');
            yield "
                </fieldset>
            ";
        }
        // line 38
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", true, true, false, 38)) {
            // line 39
            yield "                <fieldset class=\"form-fieldset pb-0\">
                    ";
            // line 40
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 40), 'row');
            yield "
                </fieldset>
            ";
        }
        // line 43
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", true, true, false, 43)) {
            // line 44
            yield "                <fieldset class=\"form-fieldset pb-0\">
                    ";
            // line 45
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 45), 'row');
            yield "
                </fieldset>
            ";
        }
        // line 48
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "recalculateRates", [], "any", true, true, false, 48)) {
            // line 49
            yield "                <fieldset class=\"form-fieldset pb-0\">
                    ";
            // line 50
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "recalculateRates", [], "any", false, false, false, 50), 'row');
            yield "
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
            // line 53
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", false, false, false, 53), 'row');
            yield "
                        </div>
                        <div class=\"col-md-6\">
                            ";
            // line 56
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", false, false, false, 56), 'row');
            yield "
                        </div>
                    </div>
                </fieldset>
            ";
        }
        // line 61
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", true, true, false, 61)) {
            // line 62
            yield "                <fieldset class=\"form-fieldset pb-0\">
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
            // line 65
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "updateMeta", [], "any", false, false, false, 65), 'row');
            yield "
                        </div>
                        <div class=\"col-md-6\">
                            ";
            // line 68
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 68), 'row');
            yield "
                        </div>
                    </div>
                </fieldset>
            ";
        }
        // line 73
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/multi-update.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  387 => 73,  379 => 68,  373 => 65,  368 => 62,  365 => 61,  357 => 56,  351 => 53,  345 => 50,  342 => 49,  339 => 48,  333 => 45,  330 => 44,  327 => 43,  321 => 40,  318 => 39,  315 => 38,  309 => 35,  306 => 34,  304 => 33,  299 => 31,  295 => 30,  289 => 27,  285 => 26,  277 => 21,  271 => 18,  265 => 15,  260 => 12,  253 => 11,  243 => 10,  183 => 141,  158 => 119,  146 => 110,  140 => 107,  134 => 103,  130 => 101,  119 => 94,  116 => 93,  109 => 89,  105 => 88,  100 => 86,  96 => 85,  90 => 83,  88 => 82,  81 => 79,  74 => 78,  68 => 10,  66 => 8,  65 => 7,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/multi-update.html.twig", "/opt/kimai/templates/timesheet/multi-update.html.twig");
    }
}
