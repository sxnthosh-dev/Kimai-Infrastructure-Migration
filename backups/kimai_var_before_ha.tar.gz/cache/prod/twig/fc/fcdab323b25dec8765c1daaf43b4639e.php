<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_by_user_layout.html.twig */
class __TwigTemplate_2b4b8a8bd0a2859ee920e49bc2323955 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 5), 'widget');
        yield "
    ";
        // line 6
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", true, true, false, 6)) {
            // line 7
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 7), 'widget', ["label" => false]);
            yield "
    ";
        } elseif ((CoreExtension::getAttribute($this->env, $this->source,         // line 8
($context["app"] ?? null), "user", [], "any", false, false, false, 8) != ($context["user"] ?? null))) {
            // line 9
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_username", $context, 9, $this->getSourceContext())->macro_username(...[($context["user"] ?? null)]);
            yield "
    ";
        }
        // line 11
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "sumType", [], "any", false, false, false, 11), 'widget');
        yield "
    ";
        // line 12
        $macros["_v0"] = $this->load("@theme/components/buttons.html.twig", 12)->unwrap();
        // line 13
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_submit_button", $context, 13, $this->getSourceContext())->macro_submit_button(...["download", ["attr" => ["formaction" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["export_route"] ?? null))], "icon" => "download", "combined" => false]]);
        yield "
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "    ";
        yield from $this->load("reporting/report_by_user_layout.html.twig", 17, 1)->unwrap()->yield(CoreExtension::toArray(["report_content" =>         $this->unwrap()->renderBlock("report_content", $context, $blocks), "box_id" => ($context["box_id"] ?? null), "fullsize" => true]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_by_user_layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  105 => 17,  98 => 16,  90 => 13,  88 => 12,  83 => 11,  77 => 9,  75 => 8,  70 => 7,  68 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_by_user_layout.html.twig", "/opt/kimai/templates/reporting/report_by_user_layout.html.twig");
    }
}


/* reporting/report_by_user_layout.html.twig */
class __TwigTemplate_2b4b8a8bd0a2859ee920e49bc2323955___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 18)->unwrap();
        // line 17
        $this->parent = $this->load("@theme/embeds/card.html.twig", 17);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["box_id"] ?? null), "html", null, true);
        yield " table-responsive m-0";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "            ";
        yield (string) ($context["report_content"] ?? null);
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_by_user_layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 21,  190 => 20,  178 => 19,  173 => 17,  171 => 18,  105 => 17,  98 => 16,  90 => 13,  88 => 12,  83 => 11,  77 => 9,  75 => 8,  70 => 7,  68 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_by_user_layout.html.twig", "/opt/kimai/templates/reporting/report_by_user_layout.html.twig");
    }
}
