<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/card_nav.html.twig */
class __TwigTemplate_40d42c32e77e4bb93c24917de15de050 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'card_before' => [$this, 'block_card_before'],
            'card_class' => [$this, 'block_card_class'],
            'card_content_before' => [$this, 'block_card_content_before'],
            'card_content_class' => [$this, 'block_card_content_class'],
            'card_content_after' => [$this, 'block_card_content_after'],
            'card_after' => [$this, 'block_card_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["_tabs"] = (((array_key_exists("tabs", $context) &&  !(null === $context["tabs"]))) ? ($context["tabs"]) : (false));
        // line 3
        $context["_bottom"] = ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = (((array_key_exists("bottom", $context) &&  !(null === $context["bottom"]))) ? ($context["bottom"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 4
        $context["_pills"] = (((array_key_exists("pills", $context) &&  !(null === $context["pills"]))) ? ($context["pills"]) : (false));
        // line 5
        yield "
";
        // line 7
        $context["card_nav_before"] = ((        $this->unwrap()->hasBlock("card_nav_before", $context, $blocks)) ? (        $this->unwrap()->renderBlock("card_nav_before", $context, $blocks)) : (""));
        // line 8
        $context["card_header_class"] = ((        $this->unwrap()->hasBlock("card_header_class", $context, $blocks)) ? (        $this->unwrap()->renderBlock("card_header_class", $context, $blocks)) : (""));
        // line 9
        $context["card_nav_after"] = ((        $this->unwrap()->hasBlock("card_nav_after", $context, $blocks)) ? (        $this->unwrap()->renderBlock("card_nav_after", $context, $blocks)) : (""));
        // line 10
        $context["_manualContent"] =         $this->unwrap()->hasBlock("card_content", $context, $blocks);
        // line 11
        yield "
";
        // line 13
        $context["_items"] = [];
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((((array_key_exists("items", $context) &&  !(null === $context["items"]))) ? ($context["items"]) : ([])));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 15
            yield "    ";
            if ( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", true, true, false, 15)) {
                // line 16
                yield "        ";
                // line 17
                yield "        ";
                $context["item"] = Twig\Extension\CoreExtension::merge($context["item"], ["id" => $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->uniqueId()]);
                // line 18
                yield "    ";
            }
            // line 19
            yield "
    ";
            // line 20
            $context["_items"] = Twig\Extension\CoreExtension::merge(($context["_items"] ?? null), [ (string)$context["key"] => $context["item"]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 22
        yield "
";
        // line 23
        $context["_navType"] = ((((($tmp = ($context["_pills"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) ? ("pills") : ("tabs"));
        // line 25
        yield "
";
        // line 26
        yield from $this->unwrap()->yieldBlock('card_before', $context, $blocks);
        // line 27
        yield "<div class=\"";
        if ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "card-tabs";
        } else {
            yield "card";
        }
        yield " ";
        yield from $this->unwrap()->yieldBlock('card_class', $context, $blocks);
        yield "\">

    ";
        // line 29
        if ( !(($tmp = ($context["_bottom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 30
            yield "        ";
            yield from $this->load("@Tabler/embeds/card_nav.html.twig", 30, 1)->unwrap()->yield(CoreExtension::merge($context, ["tabs" => ($context["_tabs"] ?? null), "navType" => ($context["_navType"] ?? null), "bottom" => ($context["_bottom"] ?? null), "manualContent" => ($context["_manualContent"] ?? null)]));
            // line 35
            yield "    ";
        }
        // line 36
        yield "
    ";
        // line 38
        yield "    ";
        yield from $this->unwrap()->yieldBlock('card_content_before', $context, $blocks);
        // line 39
        yield "    <div class=\"";
        yield from $this->unwrap()->yieldBlock('card_content_class', $context, $blocks);
        yield "\">
        ";
        // line 40
        if (        $this->unwrap()->hasBlock("card_content", $context, $blocks)) {
            // line 41
            yield "            ";
            yield from             $this->unwrap()->yieldBlock("card_content", $context, $blocks);
            yield "
        ";
        } else {
            // line 43
            yield "            <div class=\"tab-content\">
                ";
            // line 44
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["_items"] ?? null));
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 45
                yield "
                    ";
                // line 47
                yield "                    ";
                $context["_id"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 47);
                // line 48
                yield "                    ";
                $context["_content"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", true, true, false, 48) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", false, false, false, 48)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", false, false, false, 48)) : (""));
                // line 49
                yield "
                    ";
                // line 51
                yield "                    ";
                $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", true, true, false, 51) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 51)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 51)) : (false));
                // line 52
                yield "                    ";
                $context["_raw"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", true, true, false, 52) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 52)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 52)) : (false));
                // line 53
                yield "
                    ";
                // line 54
                if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", true, true, false, 54)) {
                    // line 55
                    yield "                        <div class=\"";
                    if ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield "card";
                    }
                    yield " tab-pane ";
                    if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield "active show";
                    }
                    yield "\"
                             id=\"tabs-";
                    // line 56
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                    yield "\"
                             ";
                    // line 58
                    yield "                             ";
                    if (( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 58) &&  !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 58))) {
                        yield "role=\"tabpanel\"";
                    }
                    // line 59
                    yield "                        >
                            ";
                    // line 60
                    if ( !(($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 61
                        yield "                                <div class=\"card-body\">
                                    ";
                        // line 62
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_content"] ?? null), "html", null, true);
                        yield "
                                </div>
                            ";
                    } else {
                        // line 65
                        yield "                                ";
                        yield (string) ($context["_content"] ?? null);
                        yield "
                            ";
                    }
                    // line 67
                    yield "                        </div>
                    ";
                }
                // line 69
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 70
            yield "            </div>
        ";
        }
        // line 72
        yield "    </div>
    ";
        // line 73
        yield from $this->unwrap()->yieldBlock('card_content_after', $context, $blocks);
        // line 74
        yield "
    ";
        // line 75
        if ((($tmp = ($context["_bottom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 76
            yield "        ";
            yield from $this->load("@Tabler/embeds/card_nav.html.twig", 76, 2)->unwrap()->yield(CoreExtension::merge($context, ["tabs" => ($context["_tabs"] ?? null), "navType" => ($context["_navType"] ?? null), "bottom" => ($context["_bottom"] ?? null), "manualContent" => ($context["_manualContent"] ?? null)]));
            // line 81
            yield "    ";
        }
        // line 82
        yield "</div>
";
        // line 83
        yield from $this->unwrap()->yieldBlock('card_after', $context, $blocks);
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "mb-3";
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_content_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 73
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 83
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card_nav.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  305 => 83,  295 => 73,  285 => 39,  275 => 38,  264 => 27,  254 => 26,  249 => 83,  246 => 82,  243 => 81,  240 => 76,  238 => 75,  235 => 74,  233 => 73,  230 => 72,  226 => 70,  219 => 69,  215 => 67,  209 => 65,  203 => 62,  200 => 61,  198 => 60,  195 => 59,  190 => 58,  186 => 56,  175 => 55,  173 => 54,  170 => 53,  167 => 52,  164 => 51,  161 => 49,  158 => 48,  155 => 47,  152 => 45,  148 => 44,  145 => 43,  139 => 41,  137 => 40,  132 => 39,  129 => 38,  126 => 36,  123 => 35,  120 => 30,  118 => 29,  106 => 27,  104 => 26,  101 => 25,  99 => 23,  96 => 22,  89 => 20,  86 => 19,  83 => 18,  80 => 17,  78 => 16,  75 => 15,  71 => 14,  69 => 13,  66 => 11,  64 => 10,  62 => 9,  60 => 8,  58 => 7,  55 => 5,  53 => 4,  51 => 3,  49 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card_nav.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card_nav.html.twig");
    }
}


/* @Tabler/embeds/card_nav.html.twig */
class __TwigTemplate_40d42c32e77e4bb93c24917de15de050___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'card_nav_before' => [$this, 'block_card_nav_before'],
            'card_header_class' => [$this, 'block_card_header_class'],
            'card_nav_after' => [$this, 'block_card_nav_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 30
        return "@Tabler/embeds/card_nav_header.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@Tabler/embeds/card_nav_header.html.twig", 30);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) ($context["card_nav_before"] ?? null);
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["card_header_class"] ?? null), "html", null, true);
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) ($context["card_nav_after"] ?? null);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card_nav.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  403 => 33,  392 => 32,  381 => 31,  370 => 30,  305 => 83,  295 => 73,  285 => 39,  275 => 38,  264 => 27,  254 => 26,  249 => 83,  246 => 82,  243 => 81,  240 => 76,  238 => 75,  235 => 74,  233 => 73,  230 => 72,  226 => 70,  219 => 69,  215 => 67,  209 => 65,  203 => 62,  200 => 61,  198 => 60,  195 => 59,  190 => 58,  186 => 56,  175 => 55,  173 => 54,  170 => 53,  167 => 52,  164 => 51,  161 => 49,  158 => 48,  155 => 47,  152 => 45,  148 => 44,  145 => 43,  139 => 41,  137 => 40,  132 => 39,  129 => 38,  126 => 36,  123 => 35,  120 => 30,  118 => 29,  106 => 27,  104 => 26,  101 => 25,  99 => 23,  96 => 22,  89 => 20,  86 => 19,  83 => 18,  80 => 17,  78 => 16,  75 => 15,  71 => 14,  69 => 13,  66 => 11,  64 => 10,  62 => 9,  60 => 8,  58 => 7,  55 => 5,  53 => 4,  51 => 3,  49 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card_nav.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card_nav.html.twig");
    }
}


/* @Tabler/embeds/card_nav.html.twig */
class __TwigTemplate_40d42c32e77e4bb93c24917de15de050___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'card_nav_before' => [$this, 'block_card_nav_before'],
            'card_header_class' => [$this, 'block_card_header_class'],
            'card_nav_after' => [$this, 'block_card_nav_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 76
        return "@Tabler/embeds/card_nav_header.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@Tabler/embeds/card_nav_header.html.twig", 76);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 77
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) ($context["card_nav_before"] ?? null);
        yield from [];
    }

    // line 78
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["card_header_class"] ?? null), "html", null, true);
        yield from [];
    }

    // line 79
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) ($context["card_nav_after"] ?? null);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card_nav.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  502 => 79,  491 => 78,  480 => 77,  469 => 76,  403 => 33,  392 => 32,  381 => 31,  370 => 30,  305 => 83,  295 => 73,  285 => 39,  275 => 38,  264 => 27,  254 => 26,  249 => 83,  246 => 82,  243 => 81,  240 => 76,  238 => 75,  235 => 74,  233 => 73,  230 => 72,  226 => 70,  219 => 69,  215 => 67,  209 => 65,  203 => 62,  200 => 61,  198 => 60,  195 => 59,  190 => 58,  186 => 56,  175 => 55,  173 => 54,  170 => 53,  167 => 52,  164 => 51,  161 => 49,  158 => 48,  155 => 47,  152 => 45,  148 => 44,  145 => 43,  139 => 41,  137 => 40,  132 => 39,  129 => 38,  126 => 36,  123 => 35,  120 => 30,  118 => 29,  106 => 27,  104 => 26,  101 => 25,  99 => 23,  96 => 22,  89 => 20,  86 => 19,  83 => 18,  80 => 17,  78 => 16,  75 => 15,  71 => 14,  69 => 13,  66 => 11,  64 => 10,  62 => 9,  60 => 8,  58 => 7,  55 => 5,  53 => 4,  51 => 3,  49 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card_nav.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card_nav.html.twig");
    }
}
