<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* timesheet/edit.html.twig */
class __TwigTemplate_2b5aaa246aa4c6c3164caf793a379019 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["timesheet"] ?? null), "exported", [], "any", false, false, false, 5)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 6
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 6, $this->getSourceContext())->macro_alert(...["warning", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timesheet.locked.warning", [], "flashmessages"), null, "warning"]);
            yield "
    ";
        }
        // line 8
        yield "    ";
        $context["formOptions"] = ["template" => (((($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 9
($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig")), "title" => (((($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 10
($context["timesheet"] ?? null), "id", [], "any", false, false, false, 10)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timesheet.edit")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create"))), "form" =>         // line 11
($context["form"] ?? null)];
        // line 13
        yield "    ";
        if ((array_key_exists("route_back", $context) &&  !(null === ($context["route_back"] ?? null)))) {
            // line 14
            yield "        ";
            $context["formOptions"] = Twig\Extension\CoreExtension::merge(($context["formOptions"] ?? null), ["back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route_back"] ?? null))]);
            // line 15
            yield "    ";
        }
        // line 16
        yield "    ";
        if ( !array_key_exists("template", $context)) {
            // line 17
            yield "        ";
            $context["template"] = "timesheet/edit-default.html.twig";
            // line 18
            yield "    ";
        }
        // line 19
        yield "    ";
        yield from $this->load(($context["template"] ?? null), 19)->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  94 => 19,  91 => 18,  88 => 17,  85 => 16,  82 => 15,  79 => 14,  76 => 13,  74 => 11,  73 => 10,  72 => 9,  70 => 8,  64 => 6,  61 => 5,  54 => 4,  50 => 1,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/edit.html.twig", "/opt/kimai/templates/timesheet/edit.html.twig");
    }
}
