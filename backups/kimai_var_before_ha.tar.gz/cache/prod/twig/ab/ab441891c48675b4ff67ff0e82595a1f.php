<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* timesheet/export.html.twig */
class __TwigTemplate_2d4c84d47e7c2edcd88cf7eddcbca73d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
";
        // line 2
        $context["showUserColumn"] = true;
        // line 3
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "user", [], "any", false, false, false, 3)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 4
            yield "    ";
            $context["showUserColumn"] = false;
        }
        // line 6
        yield "<html lang=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 6), "html", null, true);
        yield "\">
<head>
    <meta charset=\"utf-8\">
    <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
    <title>";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export"), "html", null, true);
        yield "</title>
    <style type=\"text/css\">
        ";
        // line 12
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("invoice");
        yield "
    </style>
</head>
<body class=\"invoice_print\">
<div class=\"wrapper\">
    <section class=\"invoice\">

        <div class=\"row\">
            <div class=\"col-xs-12\">
                <h2 class=\"page-header\">
                    ";
        // line 22
        if ( !(($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 23
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "user", [], "any", false, false, false, 23), "displayName", [], "any", false, false, false, 23), "html", null, true);
            yield ":
                    ";
        }
        // line 25
        yield "                    ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "begin", [], "any", false, false, false, 25))) {
            // line 26
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "begin", [], "any", false, false, false, 26)), "html", null, true);
            yield "
                    ";
        } else {
            // line 28
            yield "                        ";
            $context["last"] = Twig\Extension\CoreExtension::last($this->env->getCharset(), ($context["entries"] ?? null));
            // line 29
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["last"] ?? null), "begin", [], "any", false, false, false, 29)), "html", null, true);
            yield "
                    ";
        }
        // line 31
        yield "                    &ndash;
                    ";
        // line 32
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "end", [], "any", false, false, false, 32))) {
            // line 33
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "end", [], "any", false, false, false, 33)), "html", null, true);
            yield "
                    ";
        } else {
            // line 35
            yield "                        ";
            $context["first"] = Twig\Extension\CoreExtension::first($this->env->getCharset(), ($context["entries"] ?? null));
            // line 36
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["first"] ?? null), "end", [], "any", false, false, false, 36)), "html", null, true);
            yield "
                    ";
        }
        // line 38
        yield "                </h2>
            </div>
        </div>

        <div class=\"row\">
            <div class=\"col-xs-12 table-responsive\">
                <table class=\"table\">
                    <thead>
                    <tr>
                        <th>";
        // line 47
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</th>
                        ";
        // line 48
        if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 49
            yield "                            <th>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("username"), "html", null, true);
            yield "</th>
                        ";
        }
        // line 51
        yield "                        <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("description"), "html", null, true);
        yield "</th>
                        ";
        // line 52
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["timesheetMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 53
            yield "                            <th class=\"text-nowrap\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 53)), "html", null, true);
            yield "</th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 55
        yield "                        <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hours"), "html", null, true);
        yield "</th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 59
        $context["timeWorked"] = 0;
        // line 60
        yield "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 61
            yield "                        ";
            $context["timeWorked"] = (($context["timeWorked"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 61));
            // line 62
            yield "                        <tr>
                            <td class=\"text-nowrap\">";
            // line 63
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 63)), "html", null, true);
            yield "</td>
                            ";
            // line 64
            if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 65
                yield "                                <td>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 65), "displayName", [], "any", false, false, false, 65), "html", null, true);
                yield "</td>
                            ";
            }
            // line 67
            yield "                            <td>
                                ";
            // line 68
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 68))) {
                // line 69
                yield "                                    <div>
                                        ";
                // line 70
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 70));
                yield "
                                    </div>
                                ";
            }
            // line 73
            yield "                                <span class=\"small\">
                                ";
            // line 74
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 74))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
                yield ": ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 74), "name", [], "any", false, false, false, 74), "html", null, true);
                yield " |";
            }
            // line 75
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 75), "name", [], "any", false, false, false, 75), "html", null, true);
            yield " |
                                ";
            // line 76
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 76), "customer", [], "any", false, false, false, 76), "name", [], "any", false, false, false, 76), "html", null, true);
            yield "
                            </span>
                            </td>
                            ";
            // line 79
            $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/meta_fields.html.twig", 79)->unwrap();
            // line 80
            yield "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["timesheetMetaFields"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 81
                yield "                                <td>";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 81, $this->getSourceContext())->macro_meta_field_value(...[$context["entry"], $context["field"]]);
                yield "</td>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 83
            yield "                            <td class=\"text-nowrap\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 83)), "html", null, true);
            yield "</td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 86
        yield "                    </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        ";
        // line 90
        if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 91
            yield "                            <th></th>
                        ";
        }
        // line 93
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["timesheetMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 94
            yield "                            <th></th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 96
        yield "                        <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.total_working_time"), "html", null, true);
        yield "</th>
                        <th class=\"text-nowrap\">";
        // line 97
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["timeWorked"] ?? null)), "html", null, true);
        yield "</th>
                    </tr>
                    </tfoot>
                </table>
            </div>
        </div>

    </section>
</div>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  298 => 97,  293 => 96,  285 => 94,  280 => 93,  276 => 91,  274 => 90,  268 => 86,  257 => 83,  247 => 81,  242 => 80,  240 => 79,  232 => 76,  225 => 75,  218 => 74,  215 => 73,  209 => 70,  206 => 69,  204 => 68,  201 => 67,  195 => 65,  193 => 64,  189 => 63,  186 => 62,  183 => 61,  178 => 60,  176 => 59,  168 => 55,  158 => 53,  154 => 52,  149 => 51,  143 => 49,  141 => 48,  137 => 47,  126 => 38,  120 => 36,  117 => 35,  111 => 33,  109 => 32,  106 => 31,  100 => 29,  97 => 28,  91 => 26,  88 => 25,  82 => 23,  80 => 22,  67 => 12,  62 => 10,  54 => 6,  50 => 4,  48 => 3,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/export.html.twig", "/opt/kimai/templates/timesheet/export.html.twig");
    }
}
