<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/layout_horizontal.html.twig */
class __TwigTemplate_47980b57a11d0a0f1d2f290183d69e67 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'html_start' => [$this, 'block_html_start'],
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body_start' => [$this, 'block_body_start'],
            'body_class' => [$this, 'block_body_class'],
            'after_body_start' => [$this, 'block_after_body_start'],
            'header' => [$this, 'block_header'],
            'header_id' => [$this, 'block_header_id'],
            'header_class' => [$this, 'block_header_class'],
            'app_logo' => [$this, 'block_app_logo'],
            'navbar_brand_classes' => [$this, 'block_navbar_brand_classes'],
            'navbar_brand_class' => [$this, 'block_navbar_brand_class'],
            'navbar_start' => [$this, 'block_navbar_start'],
            'navbar_notifications' => [$this, 'block_navbar_notifications'],
            'navbar_user' => [$this, 'block_navbar_user'],
            'navbar_end' => [$this, 'block_navbar_end'],
            'navbar_menu_condensed' => [$this, 'block_navbar_menu_condensed'],
            'navbar' => [$this, 'block_navbar'],
            'navbar_id' => [$this, 'block_navbar_id'],
            'navbar_menu' => [$this, 'block_navbar_menu'],
            'navbar_search' => [$this, 'block_navbar_search'],
            'page_wrapper' => [$this, 'block_page_wrapper'],
            'page_wrapper_id' => [$this, 'block_page_wrapper_id'],
            'page_wrapper_class' => [$this, 'block_page_wrapper_class'],
            'page_header' => [$this, 'block_page_header'],
            'page_header_id' => [$this, 'block_page_header_id'],
            'page_header_class' => [$this, 'block_page_header_class'],
            'page_intro' => [$this, 'block_page_intro'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'page_pretitle' => [$this, 'block_page_pretitle'],
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'page_actions_class' => [$this, 'block_page_actions_class'],
            'page_actions' => [$this, 'block_page_actions'],
            'page_body' => [$this, 'block_page_body'],
            'page_content_before' => [$this, 'block_page_content_before'],
            'page_content_start' => [$this, 'block_page_content_start'],
            'page_content' => [$this, 'block_page_content'],
            'page_content_end' => [$this, 'block_page_content_end'],
            'page_content_after' => [$this, 'block_page_content_after'],
            'footer' => [$this, 'block_footer'],
            'footer_id' => [$this, 'block_footer_id'],
            'footer_class' => [$this, 'block_footer_class'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "<!doctype html";
        yield from $this->unwrap()->yieldBlock('html_start', $context, $blocks);
        yield ">
<html lang=\"";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 10), "html", null, true);
        yield "\"";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 10)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " dir=\"rtl\"";
        }
        yield " data-bs-theme=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->theme(), "html", null, true);
        yield "\" data-bs-theme-base=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeBase", [], "method", false, false, false, 10), "html", null, true);
        yield "\" data-bs-theme-radius=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeRadius", [], "method", false, false, false, 10), "html", null, true);
        yield "\" data-bs-theme-primary=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemePrimary", [], "method", false, false, false, 10), "html", null, true);
        yield "\">
<head>
    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 15
        yield "    <title>";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>
    ";
        // line 16
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 23
        yield "</head>
<body";
        // line 24
        yield from $this->unwrap()->yieldBlock('body_start', $context, $blocks);
        yield " class=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->bodyClass("antialiased"), "html", null, true);
        yield " ";
        yield from $this->unwrap()->yieldBlock('body_class', $context, $blocks);
        yield "\">
";
        // line 25
        yield from $this->unwrap()->yieldBlock('after_body_start', $context, $blocks);
        // line 26
        yield "<div class=\"page\">

    ";
        // line 29
        yield "    ";
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 62
        yield "
    ";
        // line 63
        yield from $this->unwrap()->yieldBlock('navbar', $context, $blocks);
        // line 81
        yield "    ";
        // line 82
        yield "
    ";
        // line 83
        yield from $this->unwrap()->yieldBlock('page_wrapper', $context, $blocks);
        // line 144
        yield "</div>

";
        // line 146
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 149
        yield "</body>
</html>
";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_html_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "        ";
        yield from $this->load("@Tabler/includes/html_head.html.twig", 13)->unwrap()->yield($context);
        // line 14
        yield "    ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from         $this->unwrap()->yieldBlock("page_title", $context, $blocks);
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "        ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 17)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 18
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler-rtl.css"), "html", null, true);
            yield "\">
        ";
        } else {
            // line 20
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.css"), "html", null, true);
            yield "\">
        ";
        }
        // line 22
        yield "    ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "        <header id=\"";
        yield from $this->unwrap()->yieldBlock('header_id', $context, $blocks);
        yield "\" class=\"navbar navbar-expand-md";
        yield from $this->unwrap()->yieldBlock('header_class', $context, $blocks);
        yield " d-print-none\"";
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isNavbarOverlapping", [], "method", false, false, false, 30)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isHeaderDark", [], "method", false, false, false, 30)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            yield " data-bs-theme=\"dark\"";
        }
        yield ">
            <div class=\"";
        // line 31
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbar-menu\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                ";
        // line 35
        yield from $this->unwrap()->yieldBlock('app_logo', $context, $blocks);
        // line 40
        yield "                <div class=\"navbar-nav flex-row order-md-last\">
                    ";
        // line 41
        yield from $this->unwrap()->yieldBlock('navbar_start', $context, $blocks);
        // line 42
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('navbar_notifications', $context, $blocks);
        // line 45
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('navbar_user', $context, $blocks);
        // line 48
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('navbar_end', $context, $blocks);
        // line 49
        yield "                </div>
                ";
        // line 50
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isCondensedNavbar", [], "method", false, false, false, 50)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 51
            yield "                    <div class=\"collapse navbar-collapse\" id=\"navbar-menu\">
                        <div class=\"d-flex flex-column flex-md-row flex-fill align-items-stretch align-items-md-center\">
                            ";
            // line 53
            yield from $this->unwrap()->yieldBlock('navbar_menu_condensed', $context, $blocks);
            // line 56
            yield "                        </div>
                    </div>
                ";
        }
        // line 59
        yield "            </div>
        </header>
    ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isNavbarOverlapping", [], "method", false, false, false, 30)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "navbar-overlap";
        }
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_app_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "                    <h1 class=\"";
        yield from $this->unwrap()->yieldBlock('navbar_brand_classes', $context, $blocks);
        yield "\">
                        ";
        // line 37
        yield from $this->load("@Tabler/includes/logo.html.twig", 37)->unwrap()->yield($context);
        // line 38
        yield "                    </h1>
                ";
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand d-none-navbar-horizontal pe-0 pe-md-3 ";
        yield from $this->unwrap()->yieldBlock('navbar_brand_class', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand-autodark";
        yield from [];
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_notifications(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "                        ";
        yield from $this->load("@Tabler/includes/navbar_notifications.html.twig", 43)->unwrap()->yield($context);
        // line 44
        yield "                    ";
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        yield "                        ";
        yield from $this->load("@Tabler/includes/navbar_user.html.twig", 46)->unwrap()->yield($context);
        // line 47
        yield "                    ";
        yield from [];
    }

    // line 48
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 53
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu_condensed(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 54
        yield "                                ";
        yield from $this->load("@Tabler/includes/menu.html.twig", 54)->unwrap()->yield($context);
        // line 55
        yield "                            ";
        yield from [];
    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 64
        yield "        ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isCondensedNavbar", [], "method", false, false, false, 64)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 65
            yield "            <div id=\"";
            yield from $this->unwrap()->yieldBlock('navbar_id', $context, $blocks);
            yield "\" class=\"navbar-expand-md\">
                <div class=\"collapse navbar-collapse\" id=\"navbar-menu\">
                    <div class=\"navbar\"";
            // line 67
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isNavbarDark", [], "method", false, false, false, 67)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " data-bs-theme=\"dark\"";
            }
            yield ">
                        <div class=\"";
            // line 68
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
            yield "\">
                            ";
            // line 69
            yield from $this->unwrap()->yieldBlock('navbar_menu', $context, $blocks);
            // line 72
            yield "                            ";
            yield from $this->unwrap()->yieldBlock('navbar_search', $context, $blocks);
            // line 75
            yield "                        </div>
                    </div>
                </div>
            </div>
        ";
        }
        // line 80
        yield "    ";
        yield from [];
    }

    // line 65
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 70
        yield "                                ";
        yield from $this->load("@Tabler/includes/menu.html.twig", 70)->unwrap()->yield($context);
        // line 71
        yield "                            ";
        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_search(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        yield "                                ";
        yield from $this->load("@Tabler/includes/navbar_search.html.twig", 73)->unwrap()->yield($context);
        // line 74
        yield "                            ";
        yield from [];
    }

    // line 83
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 84
        yield "        <div id=\"";
        yield from $this->unwrap()->yieldBlock('page_wrapper_id', $context, $blocks);
        yield "\" class=\"page-wrapper ";
        yield from $this->unwrap()->yieldBlock('page_wrapper_class', $context, $blocks);
        yield "\">
            ";
        // line 85
        yield from $this->unwrap()->yieldBlock('page_header', $context, $blocks);
        // line 122
        yield "
            ";
        // line 123
        yield from $this->unwrap()->yieldBlock('page_body', $context, $blocks);
        // line 134
        yield "
            ";
        // line 135
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 142
        yield "        </div>
    ";
        yield from [];
    }

    // line 84
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 86
        yield "                <div id=\"";
        yield from $this->unwrap()->yieldBlock('page_header_id', $context, $blocks);
        yield "\" class=\"page-header d-print-none ";
        yield from $this->unwrap()->yieldBlock('page_header_class', $context, $blocks);
        yield "\">
                    <div class=\"";
        // line 87
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        <div class=\"row align-items-center\">
                            <div class=\"col\">
                                ";
        // line 90
        yield from $this->unwrap()->yieldBlock('page_intro', $context, $blocks);
        // line 105
        yield "                            </div>
                            <div class=\"";
        // line 106
        yield from $this->unwrap()->yieldBlock('page_actions_class', $context, $blocks);
        yield "\">
                                ";
        // line 107
        yield from $this->unwrap()->yieldBlock('page_actions', $context, $blocks);
        // line 117
        yield "                            </div>
                        </div>
                    </div>
                </div>
            ";
        yield from [];
    }

    // line 86
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 90
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_intro(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 91
        yield "                                    ";
        yield from $this->unwrap()->yieldBlock('breadcrumb', $context, $blocks);
        // line 96
        yield "                                    <h2 class=\"page-title\">
                                        ";
        // line 97
        yield from $this->unwrap()->yieldBlock('page_title', $context, $blocks);
        // line 98
        yield "                                    </h2>
                                    ";
        // line 99
        yield from $this->unwrap()->yieldBlock('page_subtitle', $context, $blocks);
        // line 104
        yield "                                ";
        yield from [];
    }

    // line 91
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_breadcrumb(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 92
        yield "                                        <div class=\"page-pretitle\">
                                            ";
        // line 93
        yield from $this->unwrap()->yieldBlock('page_pretitle', $context, $blocks);
        // line 94
        yield "                                        </div>
                                    ";
        yield from [];
    }

    // line 93
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_pretitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Overview";
        yield from [];
    }

    // line 97
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Dashboard";
        yield from [];
    }

    // line 99
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_subtitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 100
        yield "                                        <div class=\"text-body-secondary mt-1\">
                                            1-10 of 100
                                        </div>
                                    ";
        yield from [];
    }

    // line 106
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "col-auto ms-auto d-print-none";
        yield from [];
    }

    // line 107
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 108
        yield "                                    <div class=\"btn-list\">
                                        <a href=\"#\" class=\"btn btn-white\">
                                            New view
                                        </a>
                                        <a href=\"#\" class=\"btn btn-primary d-none d-sm-inline-block\">
                                            Create new report
                                        </a>
                                    </div>
                                ";
        yield from [];
    }

    // line 123
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 124
        yield "                <div class=\"page-body\">
                    <div class=\"";
        // line 125
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        ";
        // line 126
        yield from $this->unwrap()->yieldBlock('page_content_before', $context, $blocks);
        // line 127
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_start', $context, $blocks);
        // line 128
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content', $context, $blocks);
        // line 129
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_end', $context, $blocks);
        // line 130
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_after', $context, $blocks);
        // line 131
        yield "                    </div>
                </div>
            ";
        yield from [];
    }

    // line 126
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 127
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "@Tabler/includes/flash_messages.html.twig");
        yield from [];
    }

    // line 128
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 129
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 130
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 135
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 136
        yield "                <footer id=\"";
        yield from $this->unwrap()->yieldBlock('footer_id', $context, $blocks);
        yield "\" class=\"footer footer-transparent d-print-none ";
        yield from $this->unwrap()->yieldBlock('footer_class', $context, $blocks);
        yield "\">
                    <div class=\"";
        // line 137
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        ";
        // line 138
        yield from $this->load("@Tabler/includes/footer.html.twig", 138)->unwrap()->yield($context);
        // line 139
        yield "                    </div>
                </footer>
            ";
        yield from [];
    }

    // line 136
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 146
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 147
        yield "    <script src=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.js"), "html", null, true);
        yield "\"></script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/layout_horizontal.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  893 => 147,  886 => 146,  867 => 136,  860 => 139,  858 => 138,  854 => 137,  847 => 136,  840 => 135,  830 => 130,  820 => 129,  810 => 128,  799 => 127,  789 => 126,  782 => 131,  779 => 130,  776 => 129,  773 => 128,  770 => 127,  768 => 126,  764 => 125,  761 => 124,  754 => 123,  741 => 108,  734 => 107,  723 => 106,  715 => 100,  708 => 99,  697 => 97,  686 => 93,  680 => 94,  678 => 93,  675 => 92,  668 => 91,  663 => 104,  661 => 99,  658 => 98,  656 => 97,  653 => 96,  650 => 91,  643 => 90,  624 => 86,  615 => 117,  613 => 107,  609 => 106,  606 => 105,  604 => 90,  598 => 87,  591 => 86,  584 => 85,  565 => 84,  559 => 142,  557 => 135,  554 => 134,  552 => 123,  549 => 122,  547 => 85,  540 => 84,  533 => 83,  528 => 74,  525 => 73,  518 => 72,  513 => 71,  510 => 70,  503 => 69,  493 => 65,  488 => 80,  481 => 75,  478 => 72,  476 => 69,  472 => 68,  466 => 67,  460 => 65,  457 => 64,  450 => 63,  445 => 55,  442 => 54,  435 => 53,  425 => 48,  420 => 47,  417 => 46,  410 => 45,  405 => 44,  402 => 43,  395 => 42,  385 => 41,  363 => 36,  357 => 38,  355 => 37,  350 => 36,  343 => 35,  320 => 30,  313 => 59,  308 => 56,  306 => 53,  302 => 51,  300 => 50,  297 => 49,  294 => 48,  291 => 45,  288 => 42,  286 => 41,  283 => 40,  281 => 35,  274 => 31,  263 => 30,  256 => 29,  246 => 25,  227 => 24,  222 => 22,  216 => 20,  210 => 18,  207 => 17,  200 => 16,  189 => 15,  184 => 14,  181 => 13,  174 => 12,  164 => 9,  157 => 149,  155 => 146,  151 => 144,  149 => 83,  146 => 82,  144 => 81,  142 => 63,  139 => 62,  136 => 29,  132 => 26,  130 => 25,  122 => 24,  119 => 23,  117 => 16,  112 => 15,  110 => 12,  93 => 10,  88 => 9,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/layout_horizontal.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/layout_horizontal.html.twig");
    }
}
