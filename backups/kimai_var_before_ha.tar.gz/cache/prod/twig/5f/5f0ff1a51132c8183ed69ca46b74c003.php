<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/actions.html.twig */
class __TwigTemplate_0c5c76436428ce0f14bab8c0b0871c08 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        // line 7
        yield "
";
        // line 13
        yield "
";
        yield from [];
    }

    // line 2
    public function macro_invoice($invoice = null, $view = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "invoice" => $invoice,
            "view" => $view,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
            // line 4
            yield "    ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 4), "invoice", ($context["view"] ?? null), ["invoice" => ($context["invoice"] ?? null)]);
            // line 5
            yield "    ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 5, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 5)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 8
    public function macro_invoice_template($template = null, $view = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "template" => $template,
            "view" => $view,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 9
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 9)->unwrap();
            // line 10
            yield "    ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 10), "invoice_template", ($context["view"] ?? null), ["template" => ($context["template"] ?? null)]);
            // line 11
            yield "    ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 11, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 11)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 14
    public function macro_invoice_document($document = null, $inUse = null, $view = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "document" => $document,
            "inUse" => $inUse,
            "view" => $view,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 15
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 15)->unwrap();
            // line 16
            yield "    ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 16), "invoice_document", ($context["view"] ?? null), ["document" => ($context["document"] ?? null), "in_use" => ($context["inUse"] ?? null)]);
            // line 17
            yield "    ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 17, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 17)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/actions.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  131 => 17,  128 => 16,  125 => 15,  111 => 14,  102 => 11,  99 => 10,  96 => 9,  83 => 8,  74 => 5,  71 => 4,  68 => 3,  55 => 2,  49 => 13,  46 => 7,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/actions.html.twig", "/opt/kimai/templates/invoice/actions.html.twig");
    }
}
