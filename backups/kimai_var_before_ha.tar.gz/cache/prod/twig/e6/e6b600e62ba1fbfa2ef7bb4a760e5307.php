<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/breadcrumb.html.twig */
class __TwigTemplate_6ce828fd1b8461491ffce4ea98f04acf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_breadcrumb($breadcrumbs = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "breadcrumbs" => $breadcrumbs,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["_v0"] = $this->load("@theme/components/breadcrumb.html.twig", 2)->unwrap();
            // line 3
            yield "    <div class=\"btn-list\">
    ";
            // line 4
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_breadcrumb", $context, 4, $this->getSourceContext())->macro_breadcrumb(...[($context["breadcrumbs"] ?? null), "arrows"]);
            yield "
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/breadcrumb.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  64 => 4,  61 => 3,  58 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/breadcrumb.html.twig", "/opt/kimai/templates/macros/breadcrumb.html.twig");
    }
}
