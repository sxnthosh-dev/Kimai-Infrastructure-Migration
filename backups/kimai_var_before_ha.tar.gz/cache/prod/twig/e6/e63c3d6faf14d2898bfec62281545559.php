<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/layout.html.twig */
class __TwigTemplate_5635e535722dfe50c492c16f6dd3ea55 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'main' => [$this, 'block_main'],
            'report_form' => [$this, 'block_report_form'],
            'report_form_container_class' => [$this, 'block_report_form_container_class'],
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("menu.reporting"), "html", null, true);
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_breadcrumb(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    ";
        $macros["_v0"] = $this->load("macros/breadcrumb.html.twig", 7)->unwrap();
        // line 8
        yield "    ";
        if (array_key_exists("page_setup", $context)) {
            // line 9
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_breadcrumb", $context, 9, $this->getSourceContext())->macro_breadcrumb(...[[ (string)$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("menu.reporting") => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("reporting"),  (string)$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source,             // line 11
($context["page_setup"] ?? null), "title", [], "any", false, false, false, 11), [], CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "translationDomain", [], "any", false, false, false, 11)) => "#"]]);
            // line 12
            yield "
    ";
        } else {
            // line 14
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_breadcrumb", $context, 14, $this->getSourceContext())->macro_breadcrumb(...[[ (string)$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("menu.reporting") => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("reporting"),  (string)$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(            // line 16
($context["report_title"] ?? null), [], "reporting") => "#"]]);
            // line 17
            yield "
    ";
        }
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 22
        yield "    ";
        if (array_key_exists("form", $context)) {
            // line 23
            yield "    <div class=\"mb-3\">
        ";
            // line 24
            yield from $this->unwrap()->yieldBlock('report_form', $context, $blocks);
            // line 31
            yield "    </div>
    ";
        }
        // line 33
        yield "
    <div class=\"row\">
        <div class=\"col-md-12\" id=\"reporting-content\">
            ";
        // line 36
        yield from $this->unwrap()->yieldBlock('report', $context, $blocks);
        // line 37
        yield "        </div>
    </div>
";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "            ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["class" => "form-reporting", "id" => "report-form"]]);
        yield "
            <div class=\"";
        // line 26
        yield from $this->unwrap()->yieldBlock('report_form_container_class', $context, $blocks);
        yield "\">
                ";
        // line 27
        yield from $this->unwrap()->yieldBlock('report_form_layout', $context, $blocks);
        // line 28
        yield "            </div>
            ";
        // line 29
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
        ";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_container_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "btn-list w-100";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        const reportForm = document.getElementById(\x27report-form\x27);
        if (reportForm !== null) {
            reportForm.addEventListener(\x27change\x27, (event) => {
                reportForm.submit();
            });
        }
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  205 => 42,  198 => 41,  188 => 36,  177 => 27,  166 => 26,  159 => 29,  156 => 28,  154 => 27,  150 => 26,  145 => 25,  138 => 24,  131 => 37,  129 => 36,  124 => 33,  120 => 31,  118 => 24,  115 => 23,  112 => 22,  105 => 21,  98 => 17,  96 => 16,  94 => 14,  90 => 12,  88 => 11,  86 => 9,  83 => 8,  80 => 7,  73 => 6,  62 => 4,  57 => 1,  55 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/layout.html.twig", "/opt/kimai/templates/reporting/layout.html.twig");
    }
}
