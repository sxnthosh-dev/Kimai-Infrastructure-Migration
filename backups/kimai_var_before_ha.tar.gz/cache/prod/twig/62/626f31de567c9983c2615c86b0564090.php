<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/stats.html.twig */
class __TwigTemplate_45eb427e220ea1139e7013bea136b97a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'profile_content' => [$this, 'block_profile_content'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["charts"] = $this->macros["charts"] = $this->load("macros/charts.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("user/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    ";
        yield from $this->yieldParentBlock("stylesheets", $context, $blocks);
        yield "
    ";
        // line 7
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("chart");
        yield "
";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "    ";
        yield from $this->yieldParentBlock("head", $context, $blocks);
        yield "
    ";
        // line 12
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("chart");
        yield "
";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_profile_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "    ";
        $context["datagrid"] = ["username" => CoreExtension::getAttribute($this->env, $this->source,         // line 17
($context["user"] ?? null), "userIdentifier", [], "any", false, false, false, 17)];
        // line 19
        yield "    ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "accountNumber", [], "any", false, false, false, 19))) {
            // line 20
            yield "        ";
            $context["datagrid"] = Twig\Extension\CoreExtension::merge(($context["datagrid"] ?? null), ["account_number" => (((CoreExtension::getAttribute($this->env, $this->source,             // line 21
($context["user"] ?? null), "accountNumber", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "accountNumber", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "accountNumber", [], "any", false, false, false, 21)) : ("–"))]);
            // line 23
            yield "    ";
        }
        // line 24
        yield "    ";
        $context["datagrid"] = Twig\Extension\CoreExtension::merge(($context["datagrid"] ?? null), ["profile.first_entry" => (( !(null ===         // line 25
($context["workingSince"] ?? null))) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["workingSince"] ?? null))) : ("–")), "profile.registration_date" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source,         // line 26
($context["user"] ?? null), "registeredAt", [], "any", false, false, false, 26))]);
        // line 28
        yield "    ";
        $context["seeOwnRate"] = false;
        // line 29
        yield "    ";
        if ( !(null === ($context["stats"] ?? null))) {
            // line 30
            yield "        ";
            $context["seeOwnRate"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_rate_own_timesheet");
            // line 31
            yield "        ";
            $context["datagrid"] = Twig\Extension\CoreExtension::merge(($context["datagrid"] ?? null), ["stats.durationTotal" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source,             // line 32
($context["stats"] ?? null), "durationTotal", [], "any", false, false, false, 32)), "stats.durationMonth" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source,             // line 33
($context["stats"] ?? null), "durationThisMonth", [], "any", false, false, false, 33))]);
            // line 35
            yield "    ";
        }
        // line 36
        yield "    ";
        if ((( !(($tmp = ($context["seeOwnRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("hourly-rate", ($context["user"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "preferenceValue", ["hourly_rate"], "method", false, false, false, 36)))) {
            // line 37
            yield "        ";
            $context["datagrid"] = Twig\Extension\CoreExtension::merge(($context["datagrid"] ?? null), ["hourlyRate" => CoreExtension::getAttribute($this->env, $this->source,             // line 38
($context["user"] ?? null), "preferenceValue", ["hourly_rate"], "method", false, false, false, 38), "internalRate" => CoreExtension::getAttribute($this->env, $this->source,             // line 39
($context["user"] ?? null), "preferenceValue", ["internal_rate"], "method", false, false, false, 39)]);
            // line 41
            yield "    ";
        }
        // line 42
        yield "
    <div class=\"card mb-3\">
        <div class=\"card-body\">
            <div class=\"datagrid\">
                ";
        // line 46
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["datagrid"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 47
            yield "                    <div class=\"datagrid-item\">
                        <div class=\"datagrid-title\">";
            // line 48
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["name"]), "html", null, true);
            yield "</div>
                        <div class=\"datagrid-content\">";
            // line 49
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
            yield "</div>
                    </div>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 52
        yield "            </div>
        </div>
    </div>

    ";
        // line 56
        $context["monthRoute"] = null;
        // line 57
        yield "    ";
        $context["canSeeOwnReport"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 57), "id", [], "any", false, false, false, 57) == CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 57)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("report:user")) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 58
        yield "    ";
        $context["canSeeOtherReport"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 58), "id", [], "any", false, false, false, 58) != CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 58)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("report:other")) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 59
        yield "    ";
        $context["canSeeReport"] = ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "enabled", [], "any", false, false, false, 59)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && ((($tmp = ($context["canSeeOwnReport"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["canSeeOtherReport"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)));
        // line 61
        if ((($tmp = ($context["canSeeReport"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 62
            $context["monthRoute"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_month", ["user" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 62), "date" => "__MONTH__"]);
            // line 63
            yield "    ";
        }
        // line 64
        yield "
    ";
        // line 65
        yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_javascript", $context, 65, $this->getSourceContext())->macro_bar_javascript(...[["legend" => ["display" => false], "footer" => "footer", "label" => "tooltip", "onclick" => ["url" => ($context["monthRoute"] ?? null), "replacer" => ["__MONTH__" => "month"]]]]);
        yield "

    ";
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::reverse($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["workMonths"] ?? null), "years", [], "any", false, false, false, 67)));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["year"]) {
            // line 68
            yield "        ";
            $context["totalDuration"] = 0;
            // line 69
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["workMonths"] ?? null), "year", [$context["year"]], "method", false, false, false, 69));
            foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                // line 70
                yield "            ";
                $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["month"], "duration", [], "any", false, false, false, 70));
                // line 71
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 72
            yield "        ";
            yield from $this->load("user/stats.html.twig", 72, 1)->unwrap()->yield($context);
            // line 94
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['year'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 95
        yield "
    ";
        // line 96
        if (( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "teams", [], "any", false, false, false, 96)) && ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("teams", ($context["user"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_team_member", ($context["user"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)))) {
            // line 97
            yield "        ";
            yield from $this->load("user/stats.html.twig", 97, 2)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
            // line 104
            yield "    ";
        }
        // line 105
        yield "
";
        yield from [];
    }

    // line 108
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 109
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 110
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_page_reloader", $context, 110, $this->getSourceContext())->macro_page_reloader(...["kimai.teamUpdate", true]);
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/stats.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  293 => 110,  288 => 109,  281 => 108,  275 => 105,  272 => 104,  269 => 97,  267 => 96,  264 => 95,  249 => 94,  246 => 72,  239 => 71,  236 => 70,  231 => 69,  228 => 68,  211 => 67,  206 => 65,  203 => 64,  200 => 63,  198 => 62,  196 => 61,  193 => 59,  190 => 58,  187 => 57,  185 => 56,  179 => 52,  169 => 49,  165 => 48,  162 => 47,  158 => 46,  152 => 42,  149 => 41,  147 => 39,  146 => 38,  144 => 37,  141 => 36,  138 => 35,  136 => 33,  135 => 32,  133 => 31,  130 => 30,  127 => 29,  124 => 28,  122 => 26,  121 => 25,  119 => 24,  116 => 23,  114 => 21,  112 => 20,  109 => 19,  107 => 17,  105 => 16,  98 => 15,  91 => 12,  86 => 11,  79 => 10,  72 => 7,  67 => 6,  60 => 5,  55 => 1,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/stats.html.twig", "/opt/kimai/templates/user/stats.html.twig");
    }
}


/* user/stats.html.twig */
class __TwigTemplate_45eb427e220ea1139e7013bea136b97a___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 72
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        $macros["charts"] = $this->macros["charts"] = $this->load("macros/charts.html.twig", 73)->unwrap();
        // line 74
        $macros["͜macros"] = $this->macros["͜macros"] = $this->load("macros/widgets.html.twig", 74)->unwrap();
        // line 75
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/status.html.twig", 75)->unwrap();
        // line 72
        $this->parent = $this->load("@theme/embeds/card.html.twig", 72);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 76
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 77
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["year"] ?? null), "html", null, true);
        yield "
                ";
        // line 78
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_status_duration", $context, 78, $this->getSourceContext())->macro_status_duration(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null))]);
        yield from [];
    }

    // line 80
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 81
        if ((($tmp = ($context["canSeeReport"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 82
            yield (string) $macros["͜macros"]->getTemplateForMacro("macro_card_tool_button", $context, 82, $this->getSourceContext())->macro_card_tool_button(...["reporting", ["url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_year", ["user" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 82), "date" => (($context["year"] ?? null) . "-01-01")])]]);
            yield "
                ";
        }
        // line 84
        yield "            ";
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 86
        yield "                ";
        $context["dataset"] = [];
        // line 87
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["workMonths"] ?? null), "year", [($context["year"] ?? null)], "method", false, false, false, 87));
        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
            // line 88
            yield "                    ";
            $context["monthDate"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate((((($context["year"] ?? null) . "-") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["month"], "date", [], "any", false, false, false, 88), "format", ["m"], "method", false, false, false, 88)) . "-01"));
            // line 89
            yield "                    ";
            $context["dataset"] = Twig\Extension\CoreExtension::merge(($context["dataset"] ?? null), [["value" => $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "duration", [], "any", false, false, false, 89)), "tooltip" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "duration", [], "any", false, false, false, 89)), "footer" => (($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable") . ": ") . $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "billableDuration", [], "any", false, false, false, 89))), "month" => $this->extensions['App\Twig\Extensions']->formatReportDate(($context["monthDate"] ?? null))]]);
            // line 90
            yield "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 91
        yield "                ";
        yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_chart", $context, 91, $this->getSourceContext())->macro_bar_chart(...[("userProfileChart" . ($context["year"] ?? null)), $this->extensions['App\Twig\LocaleFormatExtensions']->getMonthNames(), [($context["dataset"] ?? null)]]);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/stats.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  436 => 91,  429 => 90,  426 => 89,  423 => 88,  418 => 87,  415 => 86,  408 => 85,  403 => 84,  398 => 82,  396 => 81,  389 => 80,  384 => 78,  380 => 77,  373 => 76,  368 => 72,  366 => 75,  364 => 74,  362 => 73,  355 => 72,  293 => 110,  288 => 109,  281 => 108,  275 => 105,  272 => 104,  269 => 97,  267 => 96,  264 => 95,  249 => 94,  246 => 72,  239 => 71,  236 => 70,  231 => 69,  228 => 68,  211 => 67,  206 => 65,  203 => 64,  200 => 63,  198 => 62,  196 => 61,  193 => 59,  190 => 58,  187 => 57,  185 => 56,  179 => 52,  169 => 49,  165 => 48,  162 => 47,  158 => 46,  152 => 42,  149 => 41,  147 => 39,  146 => 38,  144 => 37,  141 => 36,  138 => 35,  136 => 33,  135 => 32,  133 => 31,  130 => 30,  127 => 29,  124 => 28,  122 => 26,  121 => 25,  119 => 24,  116 => 23,  114 => 21,  112 => 20,  109 => 19,  107 => 17,  105 => 16,  98 => 15,  91 => 12,  86 => 11,  79 => 10,  72 => 7,  67 => 6,  60 => 5,  55 => 1,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/stats.html.twig", "/opt/kimai/templates/user/stats.html.twig");
    }
}


/* user/stats.html.twig */
class __TwigTemplate_45eb427e220ea1139e7013bea136b97a___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 97
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 98
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 98)->unwrap();
        // line 97
        $this->parent = $this->load("@theme/embeds/card.html.twig", 97);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 99
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("my_teams"), "html", null, true);
        yield from [];
    }

    // line 100
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 101
        yield "                ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_team_list", $context, 101, $this->getSourceContext())->macro_team_list(...[CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "teams", [], "any", false, false, false, 101), ["collapse" => 22]]);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/stats.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  530 => 101,  523 => 100,  512 => 99,  507 => 97,  505 => 98,  498 => 97,  436 => 91,  429 => 90,  426 => 89,  423 => 88,  418 => 87,  415 => 86,  408 => 85,  403 => 84,  398 => 82,  396 => 81,  389 => 80,  384 => 78,  380 => 77,  373 => 76,  368 => 72,  366 => 75,  364 => 74,  362 => 73,  355 => 72,  293 => 110,  288 => 109,  281 => 108,  275 => 105,  272 => 104,  269 => 97,  267 => 96,  264 => 95,  249 => 94,  246 => 72,  239 => 71,  236 => 70,  231 => 69,  228 => 68,  211 => 67,  206 => 65,  203 => 64,  200 => 63,  198 => 62,  196 => 61,  193 => 59,  190 => 58,  187 => 57,  185 => 56,  179 => 52,  169 => 49,  165 => 48,  162 => 47,  158 => 46,  152 => 42,  149 => 41,  147 => 39,  146 => 38,  144 => 37,  141 => 36,  138 => 35,  136 => 33,  135 => 32,  133 => 31,  130 => 30,  127 => 29,  124 => 28,  122 => 26,  121 => 25,  119 => 24,  116 => 23,  114 => 21,  112 => 20,  109 => 19,  107 => 17,  105 => 16,  98 => 15,  91 => 12,  86 => 11,  79 => 10,  72 => 7,  67 => 6,  60 => 5,  55 => 1,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/stats.html.twig", "/opt/kimai/templates/user/stats.html.twig");
    }
}
