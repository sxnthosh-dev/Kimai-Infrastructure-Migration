<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* form/blocks.html.twig */
class __TwigTemplate_f2d4901a338eb1dbf90644b312fdd726 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'choice_widget_expanded' => [$this, 'block_choice_widget_expanded'],
            '_quick_entry_form_rows_entry_timesheets_entry_widget' => [$this, 'block__quick_entry_form_rows_entry_timesheets_entry_widget'],
            '_quick_entry_form_rows_entry_metaFields_entry_widget' => [$this, 'block__quick_entry_form_rows_entry_metaFields_entry_widget'],
            'quick_entry_week_row' => [$this, 'block_quick_entry_week_row'],
            '_team_edit_form_members_entry_user_widget' => [$this, 'block__team_edit_form_members_entry_user_widget'],
            '_team_edit_form_members_entry_teamlead_widget' => [$this, 'block__team_edit_form_members_entry_teamlead_widget'],
            '_team_edit_form_members_widget' => [$this, 'block__team_edit_form_members_widget'],
            'team_member_row' => [$this, 'block_team_member_row'],
            'team_member_widget' => [$this, 'block_team_member_widget'],
            'date_widget' => [$this, 'block_date_widget'],
            'day_widget' => [$this, 'block_day_widget'],
            'time_widget' => [$this, 'block_time_widget'],
            'daterange_widget' => [$this, 'block_daterange_widget'],
            'duration_widget' => [$this, 'block_duration_widget'],
            'date_time_widget' => [$this, 'block_date_time_widget'],
            'text_widget' => [$this, 'block_text_widget'],
            'mail_widget' => [$this, 'block_mail_widget'],
            'secret_widget' => [$this, 'block_secret_widget'],
            'yearpicker_widget' => [$this, 'block_yearpicker_widget'],
            'monthpicker_widget' => [$this, 'block_monthpicker_widget'],
            'weekpicker_widget' => [$this, 'block_weekpicker_widget'],
            'tags_widget' => [$this, 'block_tags_widget'],
            'report_sum_widget' => [$this, 'block_report_sum_widget'],
            'phone_widget' => [$this, 'block_phone_widget'],
            'money_widget' => [$this, 'block_money_widget'],
            'homepage_widget' => [$this, 'block_homepage_widget'],
            'form_errors' => [$this, 'block_form_errors'],
            'meta_fields_collection_row' => [$this, 'block_meta_fields_collection_row'],
            'meta_fields_collection_widget' => [$this, 'block_meta_fields_collection_widget'],
            'form_help_content' => [$this, 'block_form_help_content'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        yield from $this->unwrap()->yieldBlock('choice_widget_expanded', $context, $blocks);
        // line 33
        yield "
";
        // line 34
        yield from $this->unwrap()->yieldBlock('_quick_entry_form_rows_entry_timesheets_entry_widget', $context, $blocks);
        // line 37
        yield "
";
        // line 38
        yield from $this->unwrap()->yieldBlock('_quick_entry_form_rows_entry_metaFields_entry_widget', $context, $blocks);
        // line 41
        yield "
";
        // line 42
        yield from $this->unwrap()->yieldBlock('quick_entry_week_row', $context, $blocks);
        // line 63
        yield "
";
        // line 64
        yield from $this->unwrap()->yieldBlock('_team_edit_form_members_entry_user_widget', $context, $blocks);
        // line 69
        yield "
";
        // line 70
        yield from $this->unwrap()->yieldBlock('_team_edit_form_members_entry_teamlead_widget', $context, $blocks);
        // line 74
        yield "
";
        // line 75
        yield from $this->unwrap()->yieldBlock('_team_edit_form_members_widget', $context, $blocks);
        // line 79
        yield "
";
        // line 80
        yield from $this->unwrap()->yieldBlock('team_member_row', $context, $blocks);
        // line 83
        yield "
";
        // line 84
        yield from $this->unwrap()->yieldBlock('team_member_widget', $context, $blocks);
        // line 133
        yield "
";
        // line 134
        yield from $this->unwrap()->yieldBlock('date_widget', $context, $blocks);
        // line 148
        yield "
";
        // line 150
        yield from $this->unwrap()->yieldBlock('day_widget', $context, $blocks);
        // line 164
        yield "
";
        // line 165
        yield from $this->unwrap()->yieldBlock('time_widget', $context, $blocks);
        // line 190
        yield "
";
        // line 191
        yield from $this->unwrap()->yieldBlock('daterange_widget', $context, $blocks);
        // line 210
        yield "
";
        // line 211
        yield from $this->unwrap()->yieldBlock('duration_widget', $context, $blocks);
        // line 254
        yield "
";
        // line 255
        yield from $this->unwrap()->yieldBlock('date_time_widget', $context, $blocks);
        // line 269
        yield "
";
        // line 270
        yield from $this->unwrap()->yieldBlock('text_widget', $context, $blocks);
        // line 282
        yield "
";
        // line 283
        yield from $this->unwrap()->yieldBlock('mail_widget', $context, $blocks);
        // line 291
        yield "
";
        // line 293
        yield from $this->unwrap()->yieldBlock('secret_widget', $context, $blocks);
        // line 301
        yield "
";
        // line 302
        yield from $this->unwrap()->yieldBlock('yearpicker_widget', $context, $blocks);
        // line 331
        yield "
";
        // line 332
        yield from $this->unwrap()->yieldBlock('monthpicker_widget', $context, $blocks);
        // line 360
        yield "
";
        // line 361
        yield from $this->unwrap()->yieldBlock('weekpicker_widget', $context, $blocks);
        // line 399
        yield "
";
        // line 400
        yield from $this->unwrap()->yieldBlock('tags_widget', $context, $blocks);
        // line 407
        yield "
";
        // line 408
        yield from $this->unwrap()->yieldBlock('report_sum_widget', $context, $blocks);
        // line 422
        yield "
";
        // line 424
        yield from $this->unwrap()->yieldBlock('phone_widget', $context, $blocks);
        // line 432
        yield "
";
        // line 433
        yield from $this->unwrap()->yieldBlock('money_widget', $context, $blocks);
        // line 450
        yield "
";
        // line 452
        yield from $this->unwrap()->yieldBlock('homepage_widget', $context, $blocks);
        // line 461
        yield from $this->unwrap()->yieldBlock('form_errors', $context, $blocks);
        // line 469
        yield from $this->unwrap()->yieldBlock('meta_fields_collection_row', $context, $blocks);
        // line 475
        yield from $this->unwrap()->yieldBlock('meta_fields_collection_widget', $context, $blocks);
        // line 482
        yield "
";
        // line 483
        yield from $this->unwrap()->yieldBlock('form_help_content', $context, $blocks);
        yield from [];
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_choice_widget_expanded(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        if (CoreExtension::inFilter("-inline", ((CoreExtension::getAttribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", true, true, false, 3)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 3), "")) : ("")))) {
            // line 4
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["form"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                // line 5
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', ["parent_label_class" => ((CoreExtension::getAttribute($this->env, $this->source,                 // line 6
($context["label_attr"] ?? null), "class", [], "any", true, true, false, 6)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 6), "")) : ("")), "translation_domain" =>                 // line 7
($context["choice_translation_domain"] ?? null)]);
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
        } else {
            // line 11
            yield "<div ";
            yield from             $this->unwrap()->yieldBlock("widget_container_attributes", $context, $blocks);
            yield ">
            ";
            // line 12
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 12), "choices", [], "any", false, false, false, 12)) != Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 12)))) {
                // line 13
                yield "                ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 13), "choices", [], "any", false, false, false, 13));
                foreach ($context['_seq'] as $context["name"] => $context["choices"]) {
                    // line 14
                    yield "                    <fieldset class=\"form-fieldset\">
                        <legend>";
                    // line 15
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
                    yield "</legend>
                    ";
                    // line 16
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable($context["choices"]);
                    foreach ($context['_seq'] as $context["key"] => $context["choice"]) {
                        // line 17
                        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((($_v0 = ($context["form"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = $context["key"]) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null), 'widget');
                        // line 18
                        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((($_v2 = ($context["form"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = $context["key"]) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null), 'label');
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['key'], $context['choice'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 20
                    yield "                    </fieldset>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['name'], $context['choices'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 22
                yield "            ";
            } else {
                // line 23
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["form"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 24
                    yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["child"], 'widget', ["parent_label_class" => ((CoreExtension::getAttribute($this->env, $this->source,                     // line 25
($context["label_attr"] ?? null), "class", [], "any", true, true, false, 25)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["label_attr"] ?? null), "class", [], "any", false, false, false, 25), "")) : ("")), "translation_domain" =>                     // line 26
($context["choice_translation_domain"] ?? null)]);
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['child'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
            }
            // line 30
            yield "        </div>";
        }
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block__quick_entry_form_rows_entry_timesheets_entry_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", false, false, false, 35), 'row', ["row_attr" => ["class" => "p-0"]]);
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block__quick_entry_form_rows_entry_metaFields_entry_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'row', ["row_attr" => ["class" => "p-0"]]);
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_quick_entry_week_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "    <tr";
        $_v4 = $context;
        $_v5 = ["attr" => Twig\Extension\CoreExtension::merge(($context["row_attr"] ?? null), ["class" => Twig\Extension\CoreExtension::trim(((((CoreExtension::getAttribute($this->env, $this->source, ($context["row_attr"] ?? null), "class", [], "any", true, true, false, 43)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["row_attr"] ?? null), "class", [], "any", false, false, false, 43), "")) : ("")) . " form-group qe-entry-week-row") . (( !(($tmp = ($context["valid"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" is-invalid") : (""))))])];
        if (!is_iterable($_v5)) {
            throw new RuntimeError('Variables passed to the "with" tag must be a mapping.', 43, $this->getSourceContext());
        }
        $_v5 = CoreExtension::toArray($_v5);
        $context = $_v5 + $context + $this->env->getGlobals();
        yield from         $this->unwrap()->yieldBlock("attributes", $context, $blocks);
        $context = $_v4;
        yield ">
        <td>
            ";
        // line 45
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 45), 'row', ["row_attr" => ["class" => "p-0"]]);
        yield "
        </td>
        <td>
            ";
        // line 48
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activity", [], "any", false, false, false, 48), 'row', ["row_attr" => ["class" => "p-0"]]);
        yield "
        </td>
        ";
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 50), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "vars", [], "any", false, false, false, 50), "data", [], "any", false, false, false, 50), "order", [], "any", false, false, false, 50) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "vars", [], "any", false, false, false, 50), "data", [], "any", false, false, false, 50), "order", [], "any", false, false, false, 50)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["meta"]) {
            // line 51
            yield "            <td>
                ";
            // line 52
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "value", [], "any", false, false, false, 52), 'row', ["label" => false]);
            yield "
            </td>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['meta'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 55
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timesheets", [], "any", false, false, false, 55));
        foreach ($context['_seq'] as $context["_key"] => $context["timesheet"]) {
            // line 56
            yield "            <td class=\"text-center";
            if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["timesheet"], "vars", [], "any", false, false, false, 56), "data", [], "any", false, false, false, 56), "begin", [], "any", false, false, false, 56))) {
                yield " weekend";
            }
            if ($this->env->getTest('today')->getCallable()(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["timesheet"], "vars", [], "any", false, false, false, 56), "data", [], "any", false, false, false, 56), "begin", [], "any", false, false, false, 56))) {
                yield " today";
            }
            yield "\">
                ";
            // line 57
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["timesheet"], 'widget');
            yield "
            </td>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['timesheet'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 60
        yield "        <td class=\"text-nowrap text-center total qe-totals-row\"></td>
    </tr>
";
        yield from [];
    }

    // line 64
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block__team_edit_form_members_entry_user_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 65
        yield "    ";
        // line 66
        $context["type"] = "hidden";
        // line 67
        yield from         $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        yield "
";
        yield from [];
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block__team_edit_form_members_entry_teamlead_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 71
        yield "    ";
        $context["attr"] = Twig\Extension\CoreExtension::merge(($context["attr"] ?? null), ["class" => "form-selectgroup-input "]);
        // line 72
        yield "    <input type=\"checkbox\" ";
        yield from         $this->unwrap()->yieldBlock("widget_attributes", $context, $blocks);
        if (array_key_exists("value", $context)) {
            yield " value=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
            yield "\"";
        }
        if ((($tmp = ($context["checked"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " checked=\"checked\"";
        }
        yield " />
";
        yield from [];
    }

    // line 75
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block__team_edit_form_members_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 76
        yield "    <p>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team.configure_teamlead.help"), "html", null, true);
        yield "</p>
    ";
        // line 77
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget', ["row_attr" => ["class" => "mb-1"]]);
        yield "
";
        yield from [];
    }

    // line 80
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_team_member_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 81
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        yield "
";
        yield from [];
    }

    // line 84
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_team_member_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 85
        yield "    ";
        $macros["widgets"] = $this->load("macros/widgets.html.twig", 85)->unwrap();
        // line 86
        yield "    ";
        $context["data"] = [];
        // line 87
        yield "    ";
        $context["user"] = null;
        // line 88
        yield "    ";
        if (( !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 88), "data", [], "any", false, false, false, 88)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 88), "data", [], "any", false, false, false, 88), "user", [], "any", false, false, false, 88)))) {
            // line 89
            yield "        ";
            $context["user"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 89), "data", [], "any", false, false, false, 89), "user", [], "any", false, false, false, 89);
            // line 90
            yield "        ";
            $context["data"] = ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 90), "color" => $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 90), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 90)), "title" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "title", [], "any", false, false, false, 90), "username" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "userIdentifier", [], "any", false, false, false, 90), "alias" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "alias", [], "any", false, false, false, 90), "initials" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "initials", [], "any", false, false, false, 90), "accountnumber" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "accountNumber", [], "any", false, false, false, 90), "display" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 90)];
            // line 91
            yield "    ";
        }
        // line 92
        yield "    <div class=\"row mb-1\"";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["value"]) {
            yield " data-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["key"], "html", null, true);
            yield "=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
            yield "\"";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        yield ">
        <div class=\"col-xs-12\">
            <label class=\"form-selectgroup-item flex-fill\">
                ";
        // line 95
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teamlead", [], "any", false, false, false, 95), 'widget');
        yield "
                <div class=\"form-selectgroup-label d-flex align-items-center p-3\">
                    <div class=\"me-3\">
                        <span class=\"form-selectgroup-check\"></span>
                    </div>
                    <div class=\"form-selectgroup-label-content d-flex align-items-center me-2\">
                        ";
        // line 101
        if ( !(null === ($context["user"] ?? null))) {
            // line 102
            yield "                            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 102, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 102), "data", [], "any", false, false, false, 102), "user", [], "any", false, false, false, 102)]);
            yield "
                        ";
        } else {
            // line 104
            yield "                            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_avatar", $context, 104, $this->getSourceContext())->macro_avatar(...["__INITIALS__", "__COLOR__", "__DISPLAY__"]);
            yield "
                        ";
        }
        // line 106
        yield "                    </div>
                    <div class=\"form-selectgroup-label-content d-flex align-items-center\">
                        <div class=\"text-start\">
                            <div class=\"font-weight-medium\">
                                ";
        // line 110
        if ( !(null === ($context["user"] ?? null))) {
            // line 111
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 111), "data", [], "any", false, false, false, 111), "user", [], "any", false, false, false, 111), "displayName", [], "any", false, false, false, 111), "html", null, true);
            yield "
                                ";
        } else {
            // line 113
            yield "                                    __DISPLAY__
                                ";
        }
        // line 115
        yield "                                ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 115), 'widget');
        yield "
                                ";
        // line 116
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 116), 'errors');
        yield "
                            </div>
                            ";
        // line 118
        if ( !(null === ($context["user"] ?? null))) {
            // line 119
            yield "                                <div class=\"text-body-secondary\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 119), "data", [], "any", false, false, false, 119), "user", [], "any", false, false, false, 119), "title", [], "any", false, false, false, 119), "html", null, true);
            yield "</div>
                            ";
        } else {
            // line 121
            yield "                                <div class=\"text-body-secondary\">__TITLE__</div>
                            ";
        }
        // line 123
        yield "                        </div>
                    </div>
                    <div class=\"ms-auto\">
                        <a href=\"#\" class=\"btn btn-icon remove-member\">";
        // line 126
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("trash", true);
        yield "</a>
                    </div>
                </div>
            </label>
        </div>
    </div>
";
        yield from [];
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_date_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 135
        $context["format"] = $this->extensions['App\Twig\LocaleFormatExtensions']->getLocaleFormat("date");
        // line 136
        yield "    ";
        $context["jsFormat"] = $this->extensions['App\Twig\LocaleFormatExtensions']->convertJavascriptFormat(($context["format"] ?? null));
        // line 137
        yield "    ";
        $context["attr"] = Twig\Extension\CoreExtension::merge(($context["attr"] ?? null), ["pattern" => $this->extensions['App\Twig\LocaleFormatExtensions']->convertHtmlPattern(($context["format"] ?? null)), "autocomplete" => "off", "data-datepicker" => "on", "data-format" => ($context["jsFormat"] ?? null), "placeholder" => ($context["jsFormat"] ?? null)]);
        // line 138
        yield "<div class=\"input-group\">
        <a class=\"btn\" href=\"#\" data-form-widget=\"date-now\" data-format=\"";
        // line 139
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["jsFormat"] ?? null), "html", null, true);
        yield "\" data-target=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("calendar");
        yield "</a>";
        // line 140
        yield from         $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        // line 141
        if ( !(($tmp = ($context["required"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 142
            yield "        <a href=\"javascript: void(0)\" class=\"btn link-secondary fs-5\" onclick=\"document.getElementById(\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\x27).value = \x27\x27\">
            ";
            // line 143
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("cancel");
            yield "
        </a>
        ";
        }
        // line 146
        yield "    </div>";
        yield from [];
    }

    // line 150
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_day_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 151
        $context["format"] = "y-MM-D";
        // line 152
        yield "    ";
        $context["jsFormat"] = $this->extensions['App\Twig\LocaleFormatExtensions']->convertJavascriptFormat(($context["format"] ?? null));
        // line 153
        yield "    ";
        $context["attr"] = Twig\Extension\CoreExtension::merge(($context["attr"] ?? null), ["pattern" => $this->extensions['App\Twig\LocaleFormatExtensions']->convertHtmlPattern(($context["format"] ?? null)), "autocomplete" => "off", "data-format" => ($context["jsFormat"] ?? null)]);
        // line 154
        yield "<div class=\"input-group\">
        <a class=\"btn\" href=\"#\" data-form-widget=\"date-now\" data-format=\"";
        // line 155
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["jsFormat"] ?? null), "html", null, true);
        yield "\" data-target=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("calendar");
        yield "</a>";
        // line 156
        yield from         $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        // line 157
        if ( !(($tmp = ($context["required"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 158
            yield "        <a href=\"javascript: void(0)\" class=\"btn link-secondary fs-5\" onclick=\"document.getElementById(\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\x27).value = \x27\x27\">
            ";
            // line 159
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("cancel");
            yield "
        </a>
        ";
        }
        // line 162
        yield "    </div>";
        yield from [];
    }

    // line 165
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_time_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 166
        $context["attr"] = Twig\Extension\CoreExtension::merge(($context["attr"] ?? null), ["pattern" => $this->extensions['App\Twig\LocaleFormatExtensions']->convertHtmlPattern(($context["time_format"] ?? null)), "autocomplete" => "off", "data-timepicker" => "on", "data-format" => ($context["js_format"] ?? null), "placeholder" => ($context["time_format"] ?? null)]);
        // line 167
        yield "<div class=\"input-group\">
        <a class=\"btn\" href=\"#\" data-form-widget=\"date-now\" data-format=\"";
        // line 168
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["js_format"] ?? null), "html", null, true);
        yield "\" data-target=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("clock");
        yield "</a>
        ";
        // line 169
        yield from         $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        yield "
        ";
        // line 170
        $context["time_presets"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->getTimePresets(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 170), "timezone", [], "any", false, false, false, 170));
        // line 171
        yield "        ";
        if (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["time_presets"] ?? null)) > 0) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 171), "disabled", [], "any", false, false, false, 171) === false))) {
            // line 172
            yield "        <button type=\"button\" class=\"btn dropdown-toggle dropdown-toggle-split btn-duration-preset\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"></button>
        <div class=\"dropdown-menu dropdown-menu-end pre-scrollable\">
            <div class=\"dropdown-menu-columns\">
                ";
            // line 175
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable([0, 1, 2, 3]);
            foreach ($context['_seq'] as $context["_key"] => $context["index"]) {
                // line 176
                yield "                    <div class=\"dropdown-menu-column\" style=\"min-width: 4rem\">
                        ";
                // line 177
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["time_presets"] ?? null));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["value"]) {
                    // line 178
                    yield "                            ";
                    $context["value"] = $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["value"], ($context["format"] ?? null));
                    // line 179
                    yield "                            ";
                    if (((CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 179) % 4) == $context["index"])) {
                        // line 180
                        yield "                                <a class=\"dropdown-item justify-content-center\" href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 180), "id", [], "any", false, false, false, 180), "html", null, true);
                        yield "\" data-value=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                        yield "\" data-event=\"change\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                        yield "</a>
                            ";
                    }
                    // line 182
                    yield "                        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['value'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 183
                yield "                    </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['index'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 185
            yield "            </div>
        </div>
        ";
        }
        // line 188
        yield "    </div>";
        yield from [];
    }

    // line 191
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_daterange_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 192
        yield "    ";
        $context["format"] = $this->extensions['App\Twig\LocaleFormatExtensions']->convertJavascriptFormat($this->extensions['App\Twig\LocaleFormatExtensions']->getLocaleFormat("date"));
        // line 193
        yield "    ";
        $context["attr"] = Twig\Extension\CoreExtension::merge(($context["attr"] ?? null), ["data-daterangepicker" => "on", "autocomplete" => "off", "data-format" => ($context["format"] ?? null), "placeholder" => ((($context["format"] ?? null) . (($_v6 = ($context["attr"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["data-separator"] ?? null) : null)) . ($context["format"] ?? null))]);
        // line 194
        yield "<div class=\"input-group\">
        ";
        // line 195
        if (array_key_exists("ranges", $context)) {
            // line 196
            yield "        <button type=\"button\" class=\"btn dropdown-toggle dropdown-toggle-split btn-duration-preset\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"></button>
        <div class=\"dropdown-menu dropdown-menu-start pre-scrollable\">
            ";
            // line 198
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["ranges"] ?? null));
            foreach ($context['_seq'] as $context["title"] => $context["range"]) {
                // line 199
                yield "                ";
                if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), $context["range"]) == 0)) {
                    // line 200
                    yield "                    <hr class=\"dropdown-divider\">
                ";
                } else {
                    // line 202
                    yield "                    <a class=\"dropdown-item\" href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 202), "id", [], "any", false, false, false, 202), "html", null, true);
                    yield "\" data-value=\"";
                    if ( !(null === (($_v7 = $context["range"]) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[0] ?? null) : null))) {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->formatDate($this->env, (($_v8 = $context["range"]) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[0] ?? null) : null), "short", ($context["rangeFormat"] ?? null)), "html", null, true);
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v9 = ($context["attr"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["data-separator"] ?? null) : null), "html", null, true);
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->formatDate($this->env, (($_v10 = $context["range"]) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[1] ?? null) : null), "short", ($context["rangeFormat"] ?? null)), "html", null, true);
                    }
                    yield "\" data-event=\"change keyup\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["title"], [], "daterangepicker"), "html", null, true);
                    yield "</a>
                ";
                }
                // line 204
                yield "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['title'], $context['range'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 205
            yield "        </div>
        ";
        }
        // line 207
        yield "        ";
        yield from         $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        yield "
    </div>
";
        yield from [];
    }

    // line 211
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_duration_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 212
        yield "    <div class=\"duration-widget\">
        <div class=\"input-group\">
        ";
        // line 214
        if (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 214), "duration_presets", [], "any", true, true, false, 214) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 214), "duration_presets", [], "any", false, false, false, 214))) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 214), "disabled", [], "any", false, false, false, 214) === false))) {
            // line 215
            yield "            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 215), "icon", [], "any", true, true, false, 215) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 215), "icon", [], "any", false, false, false, 215)))) {
                // line 216
                yield "            <div class=\"input-group-text\">
                ";
                // line 217
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 217), "icon", [], "any", false, false, false, 217));
                yield "
            </div>
            ";
            }
            // line 220
            yield "            ";
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
            yield "
            ";
            // line 221
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 221), "toggle", [], "any", true, true, false, 221) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 221), "toggle", [], "any", false, false, false, 221)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 222
                yield "                ";
                // line 223
                yield "                <div class=\"input-group-text\">
                    <a href=\"#\" id=\"";
                // line 224
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 224), "id", [], "any", false, false, false, 224), "html", null, true);
                yield "_toggle\" class=\"text-success\">";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("link");
                yield "</a>
                </div>
            ";
            }
            // line 227
            yield "            <button type=\"button\" class=\"btn dropdown-toggle dropdown-toggle-split btn-duration-preset\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\"></button>
            <div class=\"dropdown-menu dropdown-menu-end pre-scrollable\">
                <div class=\"dropdown-menu-columns\">
                    ";
            // line 230
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable([0, 1, 2, 3]);
            foreach ($context['_seq'] as $context["_key"] => $context["index"]) {
                // line 231
                yield "                        <div class=\"dropdown-menu-column\" style=\"min-width: 4rem\">
                            ";
                // line 232
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 232), "duration_presets", [], "any", false, false, false, 232));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["value"]) {
                    // line 233
                    yield "                                ";
                    if (((CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 233) % 4) == $context["index"])) {
                        // line 234
                        yield "                                    <a class=\"dropdown-item justify-content-center\" href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 234), "id", [], "any", false, false, false, 234), "html", null, true);
                        yield "\" data-value=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                        yield "\" data-event=\"change\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                        yield "</a>
                                ";
                    }
                    // line 236
                    yield "                            ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['value'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 237
                yield "                        </div>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['index'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 239
            yield "                </div>
            </div>
        ";
        } else {
            // line 242
            yield "            ";
            if ((array_key_exists("icon", $context) &&  !Twig\Extension\CoreExtension::testEmpty(($context["icon"] ?? null)))) {
                // line 243
                yield "                <div class=\"input-group-text\">
                    ";
                // line 244
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["icon"] ?? null));
                yield "
                </div>
                ";
                // line 246
                yield from                 $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
                yield "
            ";
            } else {
                // line 248
                yield "                ";
                yield from                 $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
                yield "
            ";
            }
            // line 250
            yield "        ";
        }
        // line 251
        yield "        </div>
    </div>
";
        yield from [];
    }

    // line 255
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_date_time_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 256
        yield "<div ";
        yield from         $this->unwrap()->yieldBlock("widget_container_attributes", $context, $blocks);
        yield ">
        <div class=\"row\">
            <div class=\"col-sm-6\">";
        // line 259
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 259), 'widget', ["datetime" => true]);
        // line 260
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 260), 'errors');
        // line 261
        yield "</div>
            <div class=\"col-sm-6\">";
        // line 263
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "time", [], "any", false, false, false, 263), 'widget', ["datetime" => true]);
        // line 264
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "time", [], "any", false, false, false, 264), 'errors');
        // line 265
        yield "</div>
        </div>
    </div>";
        yield from [];
    }

    // line 270
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_text_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 271
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["icon"] ?? null))) {
            // line 272
            yield "        <div class=\"input-group\">
            <div class=\"input-group-text\">
                ";
            // line 274
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["icon"] ?? null));
            yield "
            </div>
            ";
            // line 276
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
            yield "
        </div>
    ";
        } else {
            // line 279
            yield "        ";
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 283
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_mail_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 284
        yield "<div class=\"input-group\">
        <div class=\"input-group-text\">
            ";
        // line 286
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("mail");
        yield "
        </div>
        ";
        // line 288
        yield from         $this->unwrap()->yieldBlock("email_widget", $context, $blocks);
        yield "
    </div>";
        yield from [];
    }

    // line 293
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_secret_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 294
        yield "<div class=\"input-group\">
        <div class=\"input-group-text\">
            ";
        // line 296
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("password");
        yield "
        </div>
        ";
        // line 298
        yield from         $this->unwrap()->yieldBlock("password_widget", $context, $blocks);
        yield "
    </div>";
        yield from [];
    }

    // line 302
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_yearpicker_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 303
        $context["yearInt"] = $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["year"] ?? null), "Y");
        // line 304
        yield "    <div class=\"btn-group\">
        <a class=\"btn btn-left btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        // line 305
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["previousYear"] ?? null)), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 306
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 306), "id", [], "any", false, false, false, 306), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["previousYear"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 307
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("left");
        yield "
        </a>
        ";
        // line 309
        if ((( !array_key_exists("range", $context) ||  !is_iterable(($context["range"] ?? null))) || Twig\Extension\CoreExtension::testEmpty(($context["range"] ?? null)))) {
            // line 310
            yield "            <a class=\"btn\" href=\"#\" onclick=\"return false;\">
                <span id=\"";
            // line 311
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 311), "id", [], "any", false, false, false, 311), "html", null, true);
            yield "_month_name\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["year"] ?? null)), "html", null, true);
            yield " &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["nextYear"] ?? null)), "html", null, true);
            yield "</span>
            </a>
        ";
        } else {
            // line 314
            yield "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                ";
            // line 315
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["yearInt"] ?? null), "html", null, true);
            yield "
            </button>
            <ul class=\"dropdown-menu dropdown-menu-start pre-scrollable\" style=\"z-index: 1021\">
                ";
            // line 318
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["range"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["rangeDate"]) {
                // line 319
                yield "                    <li><a href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 319), "id", [], "any", false, false, false, 319), "html", null, true);
                yield "\" data-value=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate($context["rangeDate"]), "html", null, true);
                yield "\" data-event=\"change\" class=\"dropdown-item ";
                if (($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["rangeDate"], "Y") == ($context["yearInt"] ?? null))) {
                    yield "active";
                }
                yield "\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort($context["rangeDate"]), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["rangeDate"], "Y"), "html", null, true);
                yield "</a></li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['rangeDate'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 321
            yield "            </ul>
        ";
        }
        // line 323
        yield "        <a class=\"btn btn-right btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["nextYear"] ?? null)), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 324
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 324), "id", [], "any", false, false, false, 324), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["nextYear"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 325
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("right");
        yield "
        </a>
    </div>";
        // line 328
        $context["required"] = false;
        // line 329
        yield "<input type=\"hidden\" ";
        yield from         $this->unwrap()->yieldBlock("widget_attributes", $context, $blocks);
        yield " value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
        yield "\" />";
        yield from [];
    }

    // line 332
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_monthpicker_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 333
        yield "<div class=\"btn-group\">
        <a class=\"btn btn-left btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        // line 334
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["previousMonth"] ?? null), true), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 335
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 335), "id", [], "any", false, false, false, 335), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["previousMonth"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 336
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("left");
        yield "
        </a>
        ";
        // line 338
        if ((( !array_key_exists("range", $context) ||  !is_iterable(($context["range"] ?? null))) || Twig\Extension\CoreExtension::testEmpty(($context["range"] ?? null)))) {
            // line 339
            yield "            <a class=\"btn\" href=\"#\" onclick=\"return false;\">
                <span id=\"";
            // line 340
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 340), "id", [], "any", false, false, false, 340), "html", null, true);
            yield "_month_name\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["month"] ?? null), true), "html", null, true);
            yield "</span>
            </a>
        ";
        } else {
            // line 343
            yield "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                ";
            // line 344
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["month"] ?? null), true), "html", null, true);
            yield "
            </button>
            <ul class=\"dropdown-menu dropdown-menu-start pre-scrollable\" style=\"z-index: 1021\">
                ";
            // line 347
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["range"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["rangeDate"]) {
                // line 348
                yield "                    <li><a href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 348), "id", [], "any", false, false, false, 348), "html", null, true);
                yield "\" data-value=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate($context["rangeDate"]), "html", null, true);
                yield "\" data-event=\"change\" class=\"dropdown-item ";
                if (($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["rangeDate"], "Y-m") == $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["month"] ?? null), "Y-m"))) {
                    yield "active";
                }
                yield "\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort($context["rangeDate"]), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName($context["rangeDate"], true), "html", null, true);
                yield "</a></li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['rangeDate'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 350
            yield "            </ul>
        ";
        }
        // line 352
        yield "        <a class=\"btn btn-right btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["nextMonth"] ?? null), true), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 353
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 353), "id", [], "any", false, false, false, 353), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["nextMonth"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 354
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("right");
        yield "
        </a>
    </div>";
        // line 357
        $context["required"] = false;
        // line 358
        yield "<input type=\"hidden\" ";
        yield from         $this->unwrap()->yieldBlock("widget_attributes", $context, $blocks);
        yield " value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
        yield "\" />";
        yield from [];
    }

    // line 361
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_weekpicker_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 362
        yield "<div class=\"btn-group week-picker-btn-group ";
        yield (string) (((CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", true, true, false, 362) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 362)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "class", [], "any", false, false, false, 362), "html", null, true)) : (""));
        yield "\">
        <a class=\"btn btn-left btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        // line 363
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeek", ["%week%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["previousWeek"] ?? null), "W")]), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 364
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 364), "id", [], "any", false, false, false, 364), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["previousWeek"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 365
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("left");
        yield "
        </a>
        ";
        // line 367
        if ((( !array_key_exists("range", $context) ||  !is_iterable(($context["range"] ?? null))) || Twig\Extension\CoreExtension::testEmpty(($context["range"] ?? null)))) {
            // line 368
            yield "            <a class=\"btn btn-default\" href=\"#\" onclick=\"return false;\">
            <span id=\"";
            // line 369
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 369), "id", [], "any", false, false, false, 369), "html", null, true);
            yield "_week_number\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeek", ["%week%" => ($context["weekNumber"] ?? null)]), "html", null, true);
            yield "\">
                ";
            // line 370
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["week"] ?? null), true), "html", null, true);
            yield "
                &ndash;
                ";
            // line 372
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeekShort", ["%week%" => ($context["weekNumber"] ?? null)]), "html", null, true);
            yield "
            </span>
            </a>
        ";
        } else {
            // line 376
            yield "            <button type=\"button\" class=\"btn btn-default dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                ";
            // line 377
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["week"] ?? null), true), "html", null, true);
            yield "
                &ndash;
                ";
            // line 379
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeekShort", ["%week%" => ($context["weekNumber"] ?? null)]), "html", null, true);
            yield "
            </button>
            <ul class=\"dropdown-menu dropdown-menu-start pre-scrollable\" style=\"z-index: 1021\">
                ";
            // line 382
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["range"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["rangeDate"]) {
                // line 383
                yield "                    <li><a href=\"#\" data-form-widget=\"copy-data\" data-target=\"#";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 383), "id", [], "any", false, false, false, 383), "html", null, true);
                yield "\" data-value=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate($context["rangeDate"]), "html", null, true);
                yield "\" data-event=\"change\" class=\"dropdown-item ";
                if (($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["rangeDate"], "Y-m-W") == $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["week"] ?? null), "Y-m-W"))) {
                    yield "active";
                }
                yield "\">
                        ";
                // line 384
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName($context["rangeDate"], true), "html", null, true);
                yield "
                        &ndash;
                        ";
                // line 386
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeekShort", ["%week%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat($context["rangeDate"], "W")]), "html", null, true);
                yield "
                    </a></li>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['rangeDate'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 389
            yield "            </ul>
        ";
        }
        // line 391
        yield "        <a class=\"btn btn-right btn-icon\" href=\"#\" data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeek", ["%week%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["nextWeek"] ?? null), "W")]), "html", null, true);
        yield "\"
           data-form-widget=\"copy-data\" data-target=\"#";
        // line 392
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 392), "id", [], "any", false, false, false, 392), "html", null, true);
        yield "\" data-value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["nextWeek"] ?? null)), "html", null, true);
        yield "\" data-event=\"change\">
            ";
        // line 393
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("right");
        yield "
        </a>
    </div>";
        // line 396
        $context["required"] = false;
        // line 397
        yield "<input type=\"hidden\" ";
        yield from         $this->unwrap()->yieldBlock("widget_attributes", $context, $blocks);
        yield " value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
        yield "\" />";
        yield from [];
    }

    // line 400
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_tags_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 401
        yield "    ";
        if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 401), "choices", [], "any", true, true, false, 401)) {
            // line 402
            yield "        ";
            yield from             $this->unwrap()->yieldBlock("choice_widget_collapsed", $context, $blocks);
            yield "
    ";
        } else {
            // line 404
            yield "        ";
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 408
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_sum_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 409
        yield "    <div class=\"dropdown\"";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 409), "choices", [], "any", false, false, false, 409)) <= 1)) {
            yield " style=\"display: none\"";
        }
        yield ">
        <button type=\"button\" class=\"btn dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
            ";
        // line 411
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("display", true);
        yield "
        </button>
        <ul class=\"dropdown-menu checkbox-menu\">
            ";
        // line 414
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 414));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 415
            yield "                <li class=\"dropdown-item\">
                    ";
            // line 416
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["option"], 'widget');
            yield "
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['option'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 419
        yield "        </ul>
    </div>
";
        yield from [];
    }

    // line 424
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_phone_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 425
        yield "<div class=\"input-group\">
        <div class=\"input-group-text\">
            ";
        // line 427
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon((((CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "icon", [], "any", true, true, false, 427) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "icon", [], "any", false, false, false, 427)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["attr"] ?? null), "icon", [], "any", false, false, false, 427)) : ("phone")));
        yield "
        </div>
        ";
        // line 429
        yield from         $this->unwrap()->yieldBlock("tel_widget", $context, $blocks);
        yield "
    </div>";
        yield from [];
    }

    // line 433
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_money_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 434
        $context["prepend"] =  !(is_string($_v11 = ($context["money_pattern"] ?? null)) && is_string($_v12 = "{{") && str_starts_with($_v11, $_v12));
        // line 435
        $context["append"] =  !(is_string($_v13 = ($context["money_pattern"] ?? null)) && is_string($_v14 = "}}") && str_ends_with($_v13, $_v14));
        // line 436
        if (((($tmp = ($context["prepend"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["append"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 437
            yield "<div class=\"input-group\">";
            // line 438
            if ((($tmp = ($context["prepend"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 439
                yield "<div class=\"input-group-text\">";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->encodeCurrency($this->env, ($context["money_pattern"] ?? null));
                yield "</div>";
            }
            // line 441
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
            // line 442
            if ((($tmp = ($context["append"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 443
                yield "<div class=\"input-group-text\">";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->encodeCurrency($this->env, ($context["money_pattern"] ?? null));
                yield "</div>";
            }
            // line 445
            yield "</div>";
        } else {
            // line 447
            yield from             $this->unwrap()->yieldBlock("form_widget_simple", $context, $blocks);
        }
        yield from [];
    }

    // line 452
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_homepage_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 453
        yield "<div class=\"input-group\">
        ";
        // line 454
        if (!CoreExtension::inFilter("://", ($context["value"] ?? null))) {
            // line 455
            yield "            <div class=\"input-group-text\">https://</div>
        ";
        }
        // line 457
        yield "        ";
        yield from         $this->unwrap()->yieldBlock("url_widget", $context, $blocks);
        yield "
    </div>";
        yield from [];
    }

    // line 461
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_errors(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 462
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["errors"] ?? null)) > 0)) {
            // line 463
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["errors"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                // line 464
                yield "<div class=\"invalid-feedback d-block";
                if ((Symfony\Bridge\Twig\Extension\twig_is_root_form(($context["form"] ?? null)) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 464)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    yield " mb-3";
                }
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 464), "html", null, true);
                yield "</div>";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
        }
        yield from [];
    }

    // line 469
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_meta_fields_collection_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 470
        yield "<div";
        $_v15 = $context;
        $_v16 = ["attr" => Twig\Extension\CoreExtension::merge(($context["row_attr"] ?? null), ["class" => Twig\Extension\CoreExtension::trim(((CoreExtension::getAttribute($this->env, $this->source, ($context["row_attr"] ?? null), "class", [], "any", true, true, false, 470)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["row_attr"] ?? null), "class", [], "any", false, false, false, 470), ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "parent", [], "any", false, false, false, 470), "vars", [], "any", false, false, false, 470), "name", [], "any", false, false, false, 470) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 470), "name", [], "any", false, false, false, 470)))) : (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "parent", [], "any", false, false, false, 470), "vars", [], "any", false, false, false, 470), "name", [], "any", false, false, false, 470) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 470), "name", [], "any", false, false, false, 470)))))])];
        if (!is_iterable($_v16)) {
            throw new RuntimeError('Variables passed to the "with" tag must be a mapping.', 470, $this->getSourceContext());
        }
        $_v16 = CoreExtension::toArray($_v16);
        $context = $_v16 + $context + $this->env->getGlobals();
        yield from         $this->unwrap()->yieldBlock("attributes", $context, $blocks);
        $context = $_v15;
        yield ">";
        // line 471
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        // line 472
        yield "</div>";
        yield from [];
    }

    // line 475
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_meta_fields_collection_widget(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 476
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["form"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "vars", [], "any", false, false, false, 476), "data", [], "any", false, false, false, 476), "order", [], "any", false, false, false, 476) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "vars", [], "any", false, false, false, 476), "data", [], "any", false, false, false, 476), "order", [], "any", false, false, false, 476)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["meta"]) {
            // line 477
            yield "        ";
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "rendered", [], "any", false, false, false, 477)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 478
                yield "            ";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "value", [], "any", false, false, false, 478), 'row', ["row_attr" => ["class" => ((((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "parent", [], "any", false, false, false, 478), "vars", [], "any", false, false, false, 478), "name", [], "any", false, false, false, 478)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 478), "name", [], "any", false, false, false, 478)) . "_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "vars", [], "any", false, false, false, 478), "name", [], "any", false, false, false, 478))]]);
                yield "
        ";
            }
            // line 480
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['meta'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        yield from [];
    }

    // line 483
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_help_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 484
        if ((array_key_exists("help_translation_domain", $context) &&  !(null === ($context["help_translation_domain"] ?? null)))) {
            // line 485
            $context["translation_domain"] = ($context["help_translation_domain"] ?? null);
        }
        // line 488
        if ((($context["translation_domain"] ?? null) === false)) {
            // line 489
            if ((($context["help_html"] ?? null) === false)) {
                // line 490
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["help"] ?? null), "html", null, true);
            } else {
                // line 492
                yield (string) ($context["help"] ?? null);
            }
        } else {
            // line 495
            if ((($context["help_html"] ?? null) === false)) {
                // line 496
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["help"] ?? null), ($context["help_translation_parameters"] ?? null), ($context["translation_domain"] ?? null)), "html", null, true);
            } else {
                // line 498
                yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["help"] ?? null), ($context["help_translation_parameters"] ?? null), ($context["translation_domain"] ?? null));
            }
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "form/blocks.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1758 => 498,  1755 => 496,  1753 => 495,  1749 => 492,  1746 => 490,  1744 => 489,  1742 => 488,  1739 => 485,  1737 => 484,  1730 => 483,  1720 => 480,  1714 => 478,  1711 => 477,  1707 => 476,  1700 => 475,  1695 => 472,  1693 => 471,  1681 => 470,  1674 => 469,  1649 => 464,  1632 => 463,  1630 => 462,  1623 => 461,  1615 => 457,  1611 => 455,  1609 => 454,  1606 => 453,  1599 => 452,  1593 => 447,  1590 => 445,  1585 => 443,  1583 => 442,  1581 => 441,  1576 => 439,  1574 => 438,  1572 => 437,  1570 => 436,  1568 => 435,  1566 => 434,  1559 => 433,  1552 => 429,  1547 => 427,  1543 => 425,  1536 => 424,  1529 => 419,  1519 => 416,  1516 => 415,  1512 => 414,  1506 => 411,  1498 => 409,  1491 => 408,  1482 => 404,  1476 => 402,  1473 => 401,  1466 => 400,  1457 => 397,  1455 => 396,  1450 => 393,  1444 => 392,  1439 => 391,  1435 => 389,  1425 => 386,  1420 => 384,  1409 => 383,  1405 => 382,  1399 => 379,  1394 => 377,  1391 => 376,  1384 => 372,  1379 => 370,  1373 => 369,  1370 => 368,  1368 => 367,  1363 => 365,  1357 => 364,  1353 => 363,  1348 => 362,  1341 => 361,  1332 => 358,  1330 => 357,  1325 => 354,  1319 => 353,  1314 => 352,  1310 => 350,  1290 => 348,  1286 => 347,  1280 => 344,  1277 => 343,  1269 => 340,  1266 => 339,  1264 => 338,  1259 => 336,  1253 => 335,  1249 => 334,  1246 => 333,  1239 => 332,  1230 => 329,  1228 => 328,  1223 => 325,  1217 => 324,  1212 => 323,  1208 => 321,  1188 => 319,  1184 => 318,  1178 => 315,  1175 => 314,  1165 => 311,  1162 => 310,  1160 => 309,  1155 => 307,  1149 => 306,  1145 => 305,  1142 => 304,  1140 => 303,  1133 => 302,  1126 => 298,  1121 => 296,  1117 => 294,  1110 => 293,  1103 => 288,  1098 => 286,  1094 => 284,  1087 => 283,  1078 => 279,  1072 => 276,  1067 => 274,  1063 => 272,  1061 => 271,  1054 => 270,  1047 => 265,  1045 => 264,  1043 => 263,  1040 => 261,  1038 => 260,  1036 => 259,  1030 => 256,  1023 => 255,  1016 => 251,  1013 => 250,  1007 => 248,  1002 => 246,  997 => 244,  994 => 243,  991 => 242,  986 => 239,  978 => 237,  963 => 236,  953 => 234,  950 => 233,  933 => 232,  930 => 231,  926 => 230,  921 => 227,  913 => 224,  910 => 223,  908 => 222,  906 => 221,  901 => 220,  895 => 217,  892 => 216,  889 => 215,  887 => 214,  883 => 212,  876 => 211,  867 => 207,  863 => 205,  856 => 204,  842 => 202,  838 => 200,  835 => 199,  831 => 198,  827 => 196,  825 => 195,  822 => 194,  819 => 193,  816 => 192,  809 => 191,  804 => 188,  799 => 185,  791 => 183,  776 => 182,  766 => 180,  763 => 179,  760 => 178,  743 => 177,  740 => 176,  736 => 175,  731 => 172,  728 => 171,  726 => 170,  722 => 169,  714 => 168,  711 => 167,  709 => 166,  702 => 165,  697 => 162,  691 => 159,  686 => 158,  684 => 157,  682 => 156,  675 => 155,  672 => 154,  669 => 153,  666 => 152,  664 => 151,  657 => 150,  652 => 146,  646 => 143,  641 => 142,  639 => 141,  637 => 140,  630 => 139,  627 => 138,  624 => 137,  621 => 136,  619 => 135,  612 => 134,  600 => 126,  595 => 123,  591 => 121,  585 => 119,  583 => 118,  578 => 116,  573 => 115,  569 => 113,  563 => 111,  561 => 110,  555 => 106,  549 => 104,  543 => 102,  541 => 101,  532 => 95,  513 => 92,  510 => 91,  507 => 90,  504 => 89,  501 => 88,  498 => 87,  495 => 86,  492 => 85,  485 => 84,  477 => 81,  470 => 80,  463 => 77,  458 => 76,  451 => 75,  435 => 72,  432 => 71,  425 => 70,  418 => 67,  416 => 66,  414 => 65,  407 => 64,  400 => 60,  390 => 57,  380 => 56,  375 => 55,  365 => 52,  362 => 51,  358 => 50,  353 => 48,  347 => 45,  333 => 43,  326 => 42,  320 => 39,  313 => 38,  307 => 35,  300 => 34,  294 => 30,  286 => 26,  285 => 25,  284 => 24,  280 => 23,  277 => 22,  269 => 20,  262 => 18,  260 => 17,  256 => 16,  252 => 15,  249 => 14,  244 => 13,  242 => 12,  237 => 11,  229 => 7,  228 => 6,  227 => 5,  223 => 4,  221 => 3,  214 => 2,  209 => 483,  206 => 482,  204 => 475,  202 => 469,  200 => 461,  198 => 452,  195 => 450,  193 => 433,  190 => 432,  188 => 424,  185 => 422,  183 => 408,  180 => 407,  178 => 400,  175 => 399,  173 => 361,  170 => 360,  168 => 332,  165 => 331,  163 => 302,  160 => 301,  158 => 293,  155 => 291,  153 => 283,  150 => 282,  148 => 270,  145 => 269,  143 => 255,  140 => 254,  138 => 211,  135 => 210,  133 => 191,  130 => 190,  128 => 165,  125 => 164,  123 => 150,  120 => 148,  118 => 134,  115 => 133,  113 => 84,  110 => 83,  108 => 80,  105 => 79,  103 => 75,  100 => 74,  98 => 70,  95 => 69,  93 => 64,  90 => 63,  88 => 42,  85 => 41,  83 => 38,  80 => 37,  78 => 34,  75 => 33,  73 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "form/blocks.html.twig", "/opt/kimai/templates/form/blocks.html.twig");
    }
}
