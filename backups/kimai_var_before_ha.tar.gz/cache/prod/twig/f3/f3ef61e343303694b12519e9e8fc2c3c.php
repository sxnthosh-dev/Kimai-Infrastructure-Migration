<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* embeds/datatable.html.twig */
class __TwigTemplate_5052b9c5aa378c9bf866fadf5a544960 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'datatable_header' => [$this, 'block_datatable_header'],
            'datatable_before' => [$this, 'block_datatable_before'],
            'datatable_outer' => [$this, 'block_datatable_outer'],
            'datatable_row' => [$this, 'block_datatable_row'],
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column' => [$this, 'block_datatable_column'],
            'datatable_column_attr' => [$this, 'block_datatable_column_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
            'datatable_after' => [$this, 'block_datatable_after'],
            'datatable_footer' => [$this, 'block_datatable_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 1)->unwrap();
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        yield "
";
        // line 4
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "hasResults", [], "method", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 5
            yield "    ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_nothing_found", $context, 5, $this->getSourceContext())->macro_nothing_found(...[CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getReloadEvents", [], "method", false, false, false, 5)]);
            yield "
";
        } else {
            // line 7
            yield "    ";
            yield from $this->unwrap()->yieldBlock('datatable_header', $context, $blocks);
            // line 10
            yield "
    ";
            // line 11
            yield from $this->unwrap()->yieldBlock('datatable_before', $context, $blocks);
            // line 12
            yield "
    ";
            // line 13
            $context["sortedColumns"] = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "sortedColumnNames", [], "any", false, false, false, 13);
            // line 14
            yield "    ";
            yield from $this->unwrap()->yieldBlock('datatable_outer', $context, $blocks);
            // line 29
            yield "
    ";
            // line 30
            yield from $this->unwrap()->yieldBlock('datatable_after', $context, $blocks);
            // line 31
            yield "
    ";
            // line 32
            yield from $this->unwrap()->yieldBlock('datatable_footer', $context, $blocks);
        }
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "        ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_header", $context, 8, $this->getSourceContext())->macro_header(...[($context["dataTable"] ?? null)]);
        yield "
    ";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_outer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["dataTable"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 16
            yield "            ";
            yield from $this->unwrap()->yieldBlock('datatable_row', $context, $blocks);
            // line 27
            yield "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 28
        yield "    ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "                <tr";
        yield from $this->unwrap()->yieldBlock('datatable_row_attr', $context, $blocks);
        yield ">
                    ";
        // line 18
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sortedColumns"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["column"] => $context["data"]) {
            // line 19
            yield "                        ";
            yield from $this->unwrap()->yieldBlock('datatable_column', $context, $blocks);
            // line 24
            yield "                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['column'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 25
        yield "                </tr>
            ";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "                            <td class=\"";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 20, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), ($context["column"] ?? null)]);
        yield "\"";
        yield from $this->unwrap()->yieldBlock('datatable_column_attr', $context, $blocks);
        yield ">
                                ";
        // line 21
        yield from $this->unwrap()->yieldBlock('datatable_column_value', $context, $blocks);
        // line 22
        yield "                            </td>
                        ";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["column"] ?? null), "html", null, true);
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 33
        yield "        ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_footer", $context, 33, $this->getSourceContext())->macro_footer(...[($context["dataTable"] ?? null)]);
        yield "
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/datatable.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  294 => 33,  287 => 32,  277 => 30,  266 => 21,  256 => 20,  250 => 22,  248 => 21,  241 => 20,  234 => 19,  224 => 17,  218 => 25,  203 => 24,  200 => 19,  183 => 18,  178 => 17,  171 => 16,  166 => 28,  151 => 27,  148 => 16,  130 => 15,  123 => 14,  113 => 11,  105 => 8,  98 => 7,  92 => 32,  89 => 31,  87 => 30,  84 => 29,  81 => 14,  79 => 13,  76 => 12,  74 => 11,  71 => 10,  68 => 7,  62 => 5,  60 => 4,  57 => 3,  55 => 2,  53 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/datatable.html.twig", "/opt/kimai/templates/embeds/datatable.html.twig");
    }
}
