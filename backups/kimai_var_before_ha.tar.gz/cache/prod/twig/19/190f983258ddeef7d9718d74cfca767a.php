<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/footer.html.twig */
class __TwigTemplate_7f7dee2947113b482eab02e06a94f878 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.show_about")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 2
            yield "<div class=\"row text-center align-items-center flex-row\">
    <div class=\"col-12 col-lg-auto mt-3 mt-lg-0\">
        <ul class=\"list-inline list-inline-dots mb-0\">
            <li class=\"list-inline-item\">
                Copyright &copy; <a href=\"https://www.kevinpapst.de/\" target=\"_blank\" class=\"link-secondary\">Kevin Papst</a>
            </li>
            <li class=\"list-inline-item\">
                <a class=\"link-secondary\" href=\"";
            // line 9
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
            yield "\">
                    ";
            // line 10
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("about.title"), "html", null, true);
            yield "
                </a>
            </li>
        </ul>
    </div>
</div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/footer.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  58 => 10,  54 => 9,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/footer.html.twig", "/opt/kimai/templates/bundles/TablerBundle/includes/footer.html.twig");
    }
}
