<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/navbar_notifications.html.twig */
class __TwigTemplate_e3bd677df01d1784cba7dec2c6fc6e4e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["notificationEvent"] = $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getNotifications();
        // line 3
        yield "
";
        // line 4
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "visible", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 5
            yield "    <div class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "containerClass", [], "any", false, false, false, 5), "html", null, true);
            yield "\">
        ";
            // line 7
            yield "        <a class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "buttonClass", [], "any", false, false, false, 7), "html", null, true);
            yield "\" href=\"#\" data-bs-toggle=\"dropdown\" tabindex=\"-1\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Show notifications", [], "TablerBundle"), "html", null, true);
            yield "\">
            <i class=\"";
            // line 8
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "icon", [], "any", false, false, false, 8)), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "iconClass", [], "any", false, false, false, 8), "html", null, true);
            yield "\"></i>
            ";
            // line 9
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "showBadge", [], "any", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 9) > 0))) {
                // line 10
                yield "<span class=\"badge bg-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "badgeColor", [], "any", false, false, false, 10), "html", null, true);
                yield " text-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "badgeColor", [], "any", false, false, false, 10), "html", null, true);
                yield "-fg\">";
                // line 11
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "showBadgeTotal", [], "any", false, false, false, 11)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 12
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 12), "html", null, true);
                }
                // line 14
                yield "</span>";
            }
            // line 16
            yield "        </a>

        ";
            // line 19
            yield "        <div class=\"dropdown-menu ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "withArrow", [], "any", false, false, false, 19)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "dropdown-menu-arrow";
            }
            yield " dropdown-menu-end dropdown-menu-card\">
            <div class=\"card\">
                ";
            // line 22
            yield "                ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "titleHtml", [], "any", false, false, false, 22)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 23
                yield "                    ";
                yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "titleHtml", [], "any", false, false, false, 23);
                yield "
                ";
            } else {
                // line 25
                yield "                    <div class=\"card-header\">
                        <div class=\"card-title text-truncate\">
                            ";
                // line 27
                if ((CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 27) > 0)) {
                    // line 28
                    yield "                                ";
                    yield (string) (((CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "title", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "title", [], "any", false, false, false, 28)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "title", [], "any", false, false, false, 28), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("You have %count% notifications", ["%count%" => CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 28)], "TablerBundle"), "html", null, true)));
                    yield "
                            ";
                } else {
                    // line 30
                    yield "                                ";
                    yield (string) (((CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "titleEmpty", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "titleEmpty", [], "any", false, false, false, 30)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "titleEmpty", [], "any", false, false, false, 30), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("You have no notification", [], "TablerBundle"), "html", null, true)));
                    yield "
                            ";
                }
                // line 32
                yield "                        </div>
                    </div>
                ";
            }
            // line 35
            yield "
                ";
            // line 37
            yield "                ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 37) > 0)) {
                // line 38
                yield "                    <div class=\"list-group list-group-flush list-group-hoverable\">
                        ";
                // line 39
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "notifications", [], "any", false, false, false, 39));
                foreach ($context['_seq'] as $context["_key"] => $context["notification"]) {
                    // line 40
                    yield "                            ";
                    if ((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "html", [], "any", true, true, false, 40) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "html", [], "any", false, false, false, 40)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "html", [], "any", false, false, false, 40)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 41
                        yield "                                ";
                        yield (string) CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "message", [], "any", false, false, false, 41);
                        yield "
                            ";
                    } else {
                        // line 43
                        yield "                                <div
                                    class=\"list-group-item ";
                        // line 44
                        if ((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "active", [], "any", true, true, false, 44) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "active", [], "any", false, false, false, 44)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "active", [], "any", false, false, false, 44)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            yield "active";
                        }
                        yield " ";
                        if ((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "disabled", [], "any", true, true, false, 44) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "disabled", [], "any", false, false, false, 44)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "disabled", [], "any", false, false, false, 44)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            yield "disabled";
                        }
                        yield "\"
                                >
                                    <div class=\"row align-items-center\">
                                        ";
                        // line 47
                        if ((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "withBadge", [], "any", true, true, false, 47) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "withBadge", [], "any", false, false, false, 47)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "withBadge", [], "any", false, false, false, 47)) : (true))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 48
                            yield "                                            <div class=\x27col-auto\x27>
                                                <div class=\"col-auto\">
                                                    <span
                                                        class=\"status-dot ";
                            // line 51
                            if ((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "badgeAnimated", [], "any", true, true, false, 51) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "badgeAnimated", [], "any", false, false, false, 51)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "badgeAnimated", [], "any", false, false, false, 51)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                yield "status-dot-animated";
                            }
                            yield " ";
                            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "type", [], "any", false, false, false, 51))) {
                                yield "bg-";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "type", [], "any", false, false, false, 51), "html", null, true);
                            }
                            yield " d-block\"
                                                    ></span>
                                                </div>
                                            </div>
                                        ";
                        }
                        // line 56
                        yield "                                        <div class=\"col text-truncate\">
                                            <a class=\x27text-muted text-truncate\x27
                                               href=\"";
                        // line 58
                        yield (string) (((CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "url", [], "any", true, true, false, 58) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "url", [], "any", false, false, false, 58)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "url", [], "any", false, false, false, 58), "html", null, true)) : ("#"));
                        yield "\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["notification"], "message", [], "any", false, false, false, 58), "html", null, true);
                        yield "</a>
                                        </div>
                                    </div>
                                </div>
                            ";
                    }
                    // line 63
                    yield "                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['notification'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 64
                yield "
                        ";
                // line 66
                yield "                        ";
                if ((CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 66) > CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "maxDisplay", [], "any", false, false, false, 66))) {
                    // line 67
                    yield "                            <li class=\"list-group-item disabled\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("And %count% more…", ["%count%" => (CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "total", [], "any", false, false, false, 67) - CoreExtension::getAttribute($this->env, $this->source, ($context["notificationEvent"] ?? null), "maxDisplay", [], "any", false, false, false, 67))], "TablerBundle"), "html", null, true);
                    yield "</li>
                        ";
                }
                // line 69
                yield "                    </div>
                ";
            }
            // line 71
            yield "            </div>
        </div>
    </div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/navbar_notifications.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  224 => 71,  220 => 69,  214 => 67,  211 => 66,  208 => 64,  201 => 63,  191 => 58,  187 => 56,  172 => 51,  167 => 48,  165 => 47,  153 => 44,  150 => 43,  144 => 41,  141 => 40,  137 => 39,  134 => 38,  131 => 37,  128 => 35,  123 => 32,  117 => 30,  111 => 28,  109 => 27,  105 => 25,  99 => 23,  96 => 22,  88 => 19,  84 => 16,  81 => 14,  78 => 12,  76 => 11,  70 => 10,  68 => 9,  62 => 8,  55 => 7,  50 => 5,  48 => 4,  45 => 3,  43 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/navbar_notifications.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/navbar_notifications.html.twig");
    }
}
