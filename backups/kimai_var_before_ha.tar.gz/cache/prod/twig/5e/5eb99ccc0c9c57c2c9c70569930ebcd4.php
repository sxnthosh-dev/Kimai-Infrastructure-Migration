<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* security/2fa.html.twig */
class __TwigTemplate_b145565446adb6b816393cb2b5fc0b7c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'login_box_msg' => [$this, 'block_login_box_msg'],
            'unlock_title' => [$this, 'block_unlock_title'],
            'unlock_form' => [$this, 'block_unlock_form'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "security/unlock.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("security/unlock.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box_msg(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profile.2fa", ["%provider%" => ($context["twoFactorProvider"] ?? null)]), "html", null, true);
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_unlock_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("login.2fa_intro"), "html", null, true);
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_unlock_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "
    ";
        // line 9
        yield "    ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["availableTwoFactorProviders"] ?? null)) > 1)) {
            // line 10
            yield "        <p>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("choose_provider", [], "SchebTwoFactorBundle"), "html", null, true);
            yield ":
            ";
            // line 11
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["availableTwoFactorProviders"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["provider"]) {
                // line 12
                yield "                <a href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("2fa_login", ["preferProvider" => $context["provider"]]), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["provider"], "html", null, true);
                yield "</a>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['provider'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 14
            yield "        </p>
    ";
        }
        // line 16
        yield "
    <form class=\"form\" action=\"";
        // line 17
        yield (string) (((($tmp = ($context["checkPathUrl"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["checkPathUrl"] ?? null), "html", null, true)) : ($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["checkPathRoute"] ?? null))));
        yield "\" method=\"post\">
        <div class=\"mb-3\">
                <div class=\"mb-3\">
                    <label for=\"_auth_code\" class=\"form-label\">";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("login.2fa_label"), "html", null, true);
        yield "</label>
                    <input id=\"_auth_code\" type=\"text\" name=\"";
        // line 21
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["authCodeParameterName"] ?? null), "html", null, true);
        yield "\" autocomplete=\"one-time-code\" autofocus class=\"form-control";
        if ((($tmp = ($context["authenticationError"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " is-invalid";
        }
        yield "\" placeholder=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("login.2fa_label"), "html", null, true);
        yield "\" />
                    ";
        // line 22
        if ((($tmp = ($context["authenticationError"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 23
            yield "                        <div class=\"invalid-feedback d-block\">
                            ";
            // line 24
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["authenticationError"] ?? null), ($context["authenticationErrorData"] ?? null), "SchebTwoFactorBundle"), "html", null, true);
            yield "
                        </div>
                    ";
        }
        // line 27
        yield "                </div>

                ";
        // line 34
        yield "        </div>

        ";
        // line 36
        if ((($tmp = ($context["displayTrustedOption"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 37
            yield "            <p class=\"widget\"><label for=\"_trusted\"><input id=\"_trusted\" type=\"checkbox\" name=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["trustedParameterName"] ?? null), "html", null, true);
            yield "\" /> ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("trusted", [], "SchebTwoFactorBundle"), "html", null, true);
            yield "</label></p>
        ";
        }
        // line 39
        yield "        <input type=\"hidden\" name=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["csrfParameterName"] ?? null), "html", null, true);
        yield "\" value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken(($context["csrfTokenId"] ?? null)), "html", null, true);
        yield "\">
        <div class=\"form-footer\">
            <button type=\"submit\" tabindex=\"40\" class=\"btn btn-primary w-100\">
                ";
        // line 42
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Sign In", [], "TablerBundle"), "html", null, true);
        yield "
            </button>
        </div>
    </form>

    <div class=\"hr-text\">";
        // line 47
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("or", [], "TablerBundle"), "html", null, true);
        yield "</div>

    <div class=\"row\">
        <div class=\"col text-center\">
            ";
        // line 52
        yield "            <a class=\"btn\" href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["logoutPath"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("cancel"), "html", null, true);
        yield "</a>
        </div>
    </div>

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "security/2fa.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  190 => 52,  183 => 47,  175 => 42,  166 => 39,  158 => 37,  156 => 36,  152 => 34,  148 => 27,  142 => 24,  139 => 23,  137 => 22,  127 => 21,  123 => 20,  117 => 17,  114 => 16,  110 => 14,  98 => 12,  94 => 11,  89 => 10,  86 => 9,  83 => 7,  76 => 6,  65 => 4,  54 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "security/2fa.html.twig", "/opt/kimai/templates/security/2fa.html.twig");
    }
}
