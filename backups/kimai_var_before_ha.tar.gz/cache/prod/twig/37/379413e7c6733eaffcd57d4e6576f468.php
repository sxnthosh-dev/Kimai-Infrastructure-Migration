<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/charts.html.twig */
class __TwigTemplate_3f9556a6fbe84a55238e1e5441576b4c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 3
    public function macro_project_budget($project = null, $details = null, $prefix = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "details" => $details,
            "prefix" => $prefix,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 4
            yield "    ";
            $context["chartPrefix"] = ((((null === ($context["prefix"] ?? null))) ? (Twig\Extension\CoreExtension::random($this->env->getCharset())) : (($context["prefix"] ?? null))) . "Budget");
            // line 5
            yield "    ";
            $context["chart"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null));
            // line 6
            yield "    ";
            $context["showMoneyBudget"] = ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 6)) && $tmp instanceof Markup ? (string) $tmp : $tmp));
            // line 7
            yield "    ";
            $context["showTimeBudget"] = ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 7)) && $tmp instanceof Markup ? (string) $tmp : $tmp));
            // line 8
            yield "    ";
            if (((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 9
                yield "        ";
                $macros["_v0"] = $this->load("macros/charts.html.twig", 9)->unwrap();
                // line 10
                yield "        ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 10), "currency", [], "any", false, false, false, 10);
                // line 11
                yield "        ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 11)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 12
                    yield "            <h4>";
                    // line 13
                    if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
                    } else {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
                    }
                    // line 14
                    yield ": ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
                    yield "
            </h4>
            ";
                    // line 16
                    $context["chartData"] = [];
                    // line 17
                    yield "            ";
                    $context["chartLabels"] = [];
                    // line 18
                    yield "            ";
                    // line 19
                    yield "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["details"] ?? null), "years", [], "any", false, false, false, 19));
                    foreach ($context['_seq'] as $context["_key"] => $context["year"]) {
                        // line 20
                        yield "                ";
                        // line 21
                        yield "                ";
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "months", [], "any", false, false, false, 21));
                        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                            // line 22
                            yield "                    ";
                            $context["monthDate"] = $this->extensions['Twig\Extension\CoreExtension']->convertDate((((CoreExtension::getAttribute($this->env, $this->source, $context["year"], "year", [], "any", false, false, false, 22) . "-") . CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 22)) . "-01 00:00:00"));
                            // line 23
                            yield "                    ";
                            if (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 23)) || (($context["monthDate"] ?? null) < CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 23)))) {
                                // line 24
                                yield "                        ";
                                $context["totalBudget"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getTimeBudget", [], "method", false, false, false, 24) - CoreExtension::getAttribute($this->env, $this->source, $context["month"], "billableDuration", [], "any", false, false, false, 24));
                                // line 25
                                yield "                        ";
                                $context["projectBudget"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getTimeBudget", [], "method", false, false, false, 25);
                                // line 26
                                yield "                        ";
                                if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 27
                                    yield "                            ";
                                    $context["totalBudget"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getBudget", [], "method", false, false, false, 27) - CoreExtension::getAttribute($this->env, $this->source, $context["month"], "billableRate", [], "any", false, false, false, 27));
                                    // line 28
                                    yield "                            ";
                                    $context["projectBudget"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getBudget", [], "method", false, false, false, 28);
                                    // line 29
                                    yield "                        ";
                                }
                                // line 30
                                yield "                        ";
                                $context["chartLabels"] = Twig\Extension\CoreExtension::merge(($context["chartLabels"] ?? null), [(($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["monthDate"] ?? null)) . " ") . CoreExtension::getAttribute($this->env, $this->source, $context["year"], "year", [], "any", false, false, false, 30))]);
                                // line 31
                                yield "                        ";
                                $context["chartValue"] = ["label" => (((($tmp =                                 // line 32
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalBudget"] ?? null), ($context["currency"] ?? null))) : ($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalBudget"] ?? null)))), "value" => ("" . (((($tmp =                                 // line 33
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->moneyChart(($context["totalBudget"] ?? null))) : ($this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(($context["totalBudget"] ?? null)))))];
                                // line 35
                                yield "                        ";
                                if ((($context["totalBudget"] ?? null) < 0)) {
                                    // line 36
                                    yield "                            ";
                                    $context["chartValue"] = Twig\Extension\CoreExtension::merge(($context["chartValue"] ?? null), ["color" => "red"]);
                                    // line 37
                                    yield "                        ";
                                }
                                // line 38
                                yield "                        ";
                                if ((($context["totalBudget"] ?? null) == ($context["projectBudget"] ?? null))) {
                                    // line 39
                                    yield "                            ";
                                    $context["chartValue"] = Twig\Extension\CoreExtension::merge(($context["chartValue"] ?? null), ["color" => "green"]);
                                    // line 40
                                    yield "                        ";
                                }
                                // line 41
                                yield "                        ";
                                $context["chartData"] = Twig\Extension\CoreExtension::merge(($context["chartData"] ?? null), [($context["chartValue"] ?? null)]);
                                // line 42
                                yield "                    ";
                            }
                            // line 43
                            yield "                ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent);
                        $context += $_parent;
                        // line 44
                        yield "            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['year'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 45
                    yield "            ";
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_bar_chart", $context, 45, $this->getSourceContext())->macro_bar_chart(...[($context["chartPrefix"] ?? null), ($context["chartLabels"] ?? null), [($context["chartData"] ?? null)], ["height" => "300px", "renderEvent" => ("render." . ($context["chartPrefix"] ?? null))]]);
                    yield "
        ";
                } else {
                    // line 47
                    yield "            <h4>";
                    // line 48
                    if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
                    } else {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
                    }
                    // line 49
                    yield "</h4>
            ";
                    // line 50
                    $context["chartData"] = [];
                    // line 51
                    yield "            ";
                    $context["chartLabels"] = [];
                    // line 52
                    yield "            ";
                    if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 53
                        yield "                ";
                        $context["totalBudget"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getBudget", [], "method", false, false, false, 53);
                        // line 54
                        yield "            ";
                    } else {
                        // line 55
                        yield "                ";
                        $context["totalBudget"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getTimeBudget", [], "method", false, false, false, 55);
                        // line 56
                        yield "            ";
                    }
                    // line 57
                    yield "            ";
                    // line 58
                    yield "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["details"] ?? null), "years", [], "any", false, false, false, 58));
                    foreach ($context['_seq'] as $context["_key"] => $context["year"]) {
                        // line 59
                        yield "                ";
                        // line 60
                        yield "                ";
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "months", [], "any", false, false, false, 60));
                        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                            // line 61
                            yield "                    ";
                            $context["monthDate"] = $this->extensions['Twig\Extension\CoreExtension']->convertDate((((CoreExtension::getAttribute($this->env, $this->source, $context["year"], "year", [], "any", false, false, false, 61) . "-") . CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 61)) . "-01"));
                            // line 62
                            yield "                    ";
                            if (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 62)) || (($context["monthDate"] ?? null) < CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 62)))) {
                                // line 63
                                yield "                        ";
                                if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 64
                                    yield "                            ";
                                    $context["totalBudget"] = (($context["totalBudget"] ?? null) - CoreExtension::getAttribute($this->env, $this->source, $context["month"], "billableRate", [], "any", false, false, false, 64));
                                    // line 65
                                    yield "                        ";
                                } else {
                                    // line 66
                                    yield "                            ";
                                    $context["totalBudget"] = (($context["totalBudget"] ?? null) - CoreExtension::getAttribute($this->env, $this->source, $context["month"], "billableDuration", [], "any", false, false, false, 66));
                                    // line 67
                                    yield "                        ";
                                }
                                // line 68
                                yield "                        ";
                                $context["chartLabels"] = Twig\Extension\CoreExtension::merge(($context["chartLabels"] ?? null), [(($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["monthDate"] ?? null)) . " ") . CoreExtension::getAttribute($this->env, $this->source, $context["year"], "year", [], "any", false, false, false, 68))]);
                                // line 69
                                yield "                        ";
                                $context["chartValue"] = ["label" => (((($tmp =                                 // line 70
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalBudget"] ?? null), ($context["currency"] ?? null))) : ($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalBudget"] ?? null)))), "value" => (((($tmp =                                 // line 71
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->moneyChart(($context["totalBudget"] ?? null))) : ($this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(($context["totalBudget"] ?? null))))];
                                // line 73
                                yield "                        ";
                                if ((($context["totalBudget"] ?? null) < 0)) {
                                    // line 74
                                    yield "                            ";
                                    $context["chartValue"] = Twig\Extension\CoreExtension::merge(($context["chartValue"] ?? null), ["color" => "red"]);
                                    // line 75
                                    yield "                        ";
                                }
                                // line 76
                                yield "                        ";
                                $context["chartData"] = Twig\Extension\CoreExtension::merge(($context["chartData"] ?? null), [($context["chartValue"] ?? null)]);
                                // line 77
                                yield "                    ";
                            }
                            // line 78
                            yield "                ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent);
                        $context += $_parent;
                        // line 79
                        yield "            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['year'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 80
                    yield "            ";
                    $context["last"] = Twig\Extension\CoreExtension::last($this->env->getCharset(), ($context["chartData"] ?? null));
                    // line 81
                    yield "            ";
                    if (( !Twig\Extension\CoreExtension::testEmpty(($context["last"] ?? null)) && (CoreExtension::getAttribute($this->env, $this->source, ($context["last"] ?? null), "value", [], "any", false, false, false, 81) > 0))) {
                        // line 82
                        yield "                ";
                        $context["chartValueZero"] = ["label" => (((($tmp =                         // line 83
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->money(0, ($context["currency"] ?? null))) : ($this->extensions['App\Twig\LocaleFormatExtensions']->duration(0))), "value" => (((($tmp =                         // line 84
($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->moneyChart(0)) : ($this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(0)))];
                        // line 86
                        yield "                ";
                        $context["chartData"] = Twig\Extension\CoreExtension::merge(($context["chartData"] ?? null), [($context["chartValueZero"] ?? null)]);
                        // line 87
                        yield "            ";
                    }
                    // line 88
                    yield "            ";
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_bar_chart", $context, 88, $this->getSourceContext())->macro_bar_chart(...[($context["chartPrefix"] ?? null), ($context["chartLabels"] ?? null), [($context["chartData"] ?? null)], ["height" => "300px", "renderEvent" => ("render." . ($context["chartPrefix"] ?? null)), "type" => "line"]]);
                    yield "
        ";
                }
                // line 90
                yield "    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/charts.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  319 => 90,  313 => 88,  310 => 87,  307 => 86,  305 => 84,  304 => 83,  302 => 82,  299 => 81,  296 => 80,  289 => 79,  282 => 78,  279 => 77,  276 => 76,  273 => 75,  270 => 74,  267 => 73,  265 => 71,  264 => 70,  262 => 69,  259 => 68,  256 => 67,  253 => 66,  250 => 65,  247 => 64,  244 => 63,  241 => 62,  238 => 61,  233 => 60,  231 => 59,  226 => 58,  224 => 57,  221 => 56,  218 => 55,  215 => 54,  212 => 53,  209 => 52,  206 => 51,  204 => 50,  201 => 49,  195 => 48,  193 => 47,  187 => 45,  180 => 44,  173 => 43,  170 => 42,  167 => 41,  164 => 40,  161 => 39,  158 => 38,  155 => 37,  152 => 36,  149 => 35,  147 => 33,  146 => 32,  144 => 31,  141 => 30,  138 => 29,  135 => 28,  132 => 27,  129 => 26,  126 => 25,  123 => 24,  120 => 23,  117 => 22,  112 => 21,  110 => 20,  105 => 19,  103 => 18,  100 => 17,  98 => 16,  92 => 14,  86 => 13,  84 => 12,  81 => 11,  78 => 10,  75 => 9,  72 => 8,  69 => 7,  66 => 6,  63 => 5,  60 => 4,  46 => 3,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/charts.html.twig", "/opt/kimai/templates/project/charts.html.twig");
    }
}
