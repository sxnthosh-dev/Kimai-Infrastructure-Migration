<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/flash.html.twig */
class __TwigTemplate_2391bfc8b3fcf25938b39f2029a9a93b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "
";
        // line 19
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_flash($type = null, $message = null, $close = null, $use_raw = null, $class = null, $domain = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "message" => $message,
            "close" => $close,
            "use_raw" => $use_raw,
            "class" => $class,
            "domain" => $domain,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["_v0"] = $this->load("@Tabler/components/alert.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            if ((($context["type"] ?? null) == "error")) {
                // line 4
                yield "        ";
                $context["type"] = "danger";
                // line 5
                yield "    ";
            }
            // line 6
            yield "    ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 6, $this->getSourceContext())->macro_alert(...[["type" =>             // line 7
($context["type"] ?? null), "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(            // line 8
($context["message"] ?? null), [], ((array_key_exists("domain", $context)) ? (Twig\Extension\CoreExtension::default(($context["domain"] ?? null), "TablerBundle")) : ("TablerBundle"))), "dismissible" => (((            // line 9
array_key_exists("close", $context) &&  !(null === $context["close"]))) ? ($context["close"]) : (false)), "important" => true, "raw" => (((            // line 11
array_key_exists("use_raw", $context) &&  !(null === $context["use_raw"]))) ? ($context["use_raw"]) : (false)), "class" => ((            // line 12
array_key_exists("class", $context)) ? (Twig\Extension\CoreExtension::default(($context["class"] ?? null), "")) : (""))]]);
            // line 13
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 16
    public function macro_session_flash($close = null, $use_raw = null, $class = null, $domain = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "close" => $close,
            "use_raw" => $use_raw,
            "class" => $class,
            "domain" => $domain,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 17
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_flashes", $context, 17, $this->getSourceContext())->macro_flashes(...[CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [], "any", false, false, false, 17), ($context["close"] ?? null), ($context["use_raw"] ?? null), ($context["class"] ?? null), ($context["domain"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 20
    public function macro_flashes($flashes = null, $close = null, $use_raw = null, $class = null, $domain = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "flashes" => $flashes,
            "close" => $close,
            "use_raw" => $use_raw,
            "class" => $class,
            "domain" => $domain,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 21
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["flashes"] ?? null));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 22
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 23
                    yield "            ";
                    yield (string) $this->getTemplateForMacro("macro_flash", $context, 23, $this->getSourceContext())->macro_flash(...[$context["type"], $context["message"], ($context["close"] ?? null), ($context["use_raw"] ?? null), ($context["class"] ?? null), ($context["domain"] ?? null)]);
                    yield "
        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['message'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 25
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['type'], $context['messages'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/flash.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  156 => 25,  146 => 23,  141 => 22,  136 => 21,  120 => 20,  111 => 17,  96 => 16,  89 => 13,  87 => 12,  86 => 11,  85 => 9,  84 => 8,  83 => 7,  81 => 6,  78 => 5,  75 => 4,  72 => 3,  69 => 2,  52 => 1,  46 => 19,  43 => 15,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/flash.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/flash.html.twig");
    }
}
