<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/card.html.twig */
class __TwigTemplate_ce3096334091d0486526f2a484818899 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'box_header' => [$this, 'block_box_header'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_title' => [$this, 'block_box_title'],
            'box_before' => [$this, 'block_box_before'],
            'box_class' => [$this, 'block_box_class'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_header_before' => [$this, 'block_box_header_before'],
            'box_header_classes' => [$this, 'block_box_header_classes'],
            'box_header_class' => [$this, 'block_box_header_class'],
            'box_tools_attributes' => [$this, 'block_box_tools_attributes'],
            'box_header_after' => [$this, 'block_box_header_after'],
            'box_body_before' => [$this, 'block_box_body_before'],
            'box_body_classes' => [$this, 'block_box_body_classes'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body_after' => [$this, 'block_box_body_after'],
            'box_footer_before' => [$this, 'block_box_footer_before'],
            'box_footer_class' => [$this, 'block_box_footer_class'],
            'box_footer_after' => [$this, 'block_box_footer_after'],
            'box_after' => [$this, 'block_box_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["_id"] = ((array_key_exists("id", $context)) ? (Twig\Extension\CoreExtension::default(($context["id"] ?? null), null)) : (null));
        // line 3
        $context["_boxtype"] = (((array_key_exists("boxtype", $context) &&  !(null === $context["boxtype"]))) ? ($context["boxtype"]) : (null));
        // line 4
        $context["_status_position"] = (((array_key_exists("status_position", $context) &&  !(null === $context["status_position"]))) ? ($context["status_position"]) : ("top"));
        // line 5
        $context["_fullsize"] = (((array_key_exists("fullsize", $context) &&  !(null === $context["fullsize"]))) ? ($context["fullsize"]) : (false));
        // line 6
        $context["_margin_bottom"] = (((array_key_exists("margin_bottom", $context) &&  !(null === $context["margin_bottom"]))) ? ($context["margin_bottom"]) : (3));
        // line 7
        $context["_headerBorderNone"] = (((array_key_exists("headerBorderNone", $context) &&  !(null === $context["headerBorderNone"]))) ? ($context["headerBorderNone"]) : (false));
        // line 8
        $context["_collapsed"] = (((array_key_exists("collapsed", $context) &&  !(null === $context["collapsed"]))) ? ($context["collapsed"]) : (false));
        // line 9
        $context["_collapsible"] = (((array_key_exists("collapsible", $context) &&  !(null === $context["collapsible"]))) ? ($context["collapsible"]) : (($context["_collapsed"] ?? null)));
        // line 10
        $context["_bodyScrollable"] = (((array_key_exists("bodyScrollable", $context) &&  !(null === $context["bodyScrollable"]))) ? ($context["bodyScrollable"]) : (false));
        // line 11
        $context["_bodyScrollableShadow"] = (((array_key_exists("bodyScrollableShadow", $context) &&  !(null === $context["bodyScrollableShadow"]))) ? ($context["bodyScrollableShadow"]) : (false));
        // line 12
        $context["_footer_collapsible"] = (((array_key_exists("footer_collapsible", $context) &&  !(null === $context["footer_collapsible"]))) ? ($context["footer_collapsible"]) : (true));
        // line 13
        $context["_use_footer"] = (((array_key_exists("use_footer", $context) &&  !(null === $context["use_footer"]))) ? ($context["use_footer"]) : (false));
        // line 14
        $context["_use_body"] = (((array_key_exists("use_body", $context) &&  !(null === $context["use_body"]))) ? ($context["use_body"]) : (true));
        // line 15
        yield "
";
        // line 17
        $context["header"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->unwrap()->yieldBlock('box_header', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 18
        $context["tools"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->unwrap()->yieldBlock('box_tools', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 19
        $context["body"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->unwrap()->yieldBlock('box_body', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 20
        $context["footer"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->unwrap()->yieldBlock('box_footer', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 21
        $context["title"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->unwrap()->yieldBlock('box_title', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 22
        yield "
";
        // line 23
        $context["_collapsible_class"] = $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->uniqueId("collapse_");
        // line 24
        $context["_hasTitle"] =  !Twig\Extension\CoreExtension::testEmpty(($context["title"] ?? null));
        // line 25
        $context["_hasTools"] =  !Twig\Extension\CoreExtension::testEmpty(($context["tools"] ?? null));
        // line 26
        $context["_hasHeader"] =  !Twig\Extension\CoreExtension::testEmpty(($context["header"] ?? null));
        // line 27
        $context["_hasBody"] = ((($tmp = ($context["_use_body"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) ||  !Twig\Extension\CoreExtension::testEmpty(($context["body"] ?? null)));
        // line 28
        $context["_hasFooter"] = ((($tmp = ($context["_use_footer"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) ||  !Twig\Extension\CoreExtension::testEmpty(($context["footer"] ?? null)));
        // line 29
        yield "
";
        // line 30
        $macros["button"] = $this->macros["button"] = $this->load("@Tabler/components/buttons.html.twig", 30)->unwrap();
        // line 31
        yield "
";
        // line 32
        yield from $this->unwrap()->yieldBlock('box_before', $context, $blocks);
        // line 34
        yield "<div ";
        if ( !(null === ($context["_id"] ?? null))) {
            yield "id=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
            yield "\"";
        }
        yield " class=\"card ";
        yield from $this->unwrap()->yieldBlock('box_class', $context, $blocks);
        yield " mb-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_margin_bottom"] ?? null), "html", null, true);
        yield "\" ";
        yield from $this->unwrap()->yieldBlock('box_attributes', $context, $blocks);
        yield ">

    ";
        // line 37
        yield "    ";
        if ( !(null === ($context["_boxtype"] ?? null))) {
            // line 38
            yield "        <div class=\"card-status-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_status_position"] ?? null), "html", null, true);
            yield " bg-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_boxtype"] ?? null), "html", null, true);
            yield "\"></div>
    ";
        }
        // line 40
        yield "
    ";
        // line 42
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_header_before', $context, $blocks);
        // line 43
        yield "    ";
        if (((((($tmp = ($context["_hasTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["_collapsible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["_hasTools"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($tmp = ($context["_hasHeader"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 44
            yield "        ";
            $context["headerClasses"] = ["card-header"];
            // line 45
            yield "        ";
            if ((($tmp = ($context["_headerBorderNone"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 46
                yield "            ";
                $context["headerClasses"] = Twig\Extension\CoreExtension::merge(($context["headerClasses"] ?? null), ["border-0"]);
                // line 47
                yield "        ";
            }
            // line 48
            yield "        <div class=\"";
            yield from $this->unwrap()->yieldBlock('box_header_classes', $context, $blocks);
            yield "\">
            ";
            // line 49
            if ((($tmp = ($context["_hasHeader"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 50
                yield "                ";
                yield (string) ($context["header"] ?? null);
                yield "
            ";
            } else {
                // line 52
                yield "                ";
                if ((($tmp = ($context["_hasTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "<h3 class=\"card-title\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
                    yield "</h3>";
                }
                // line 53
                yield "                <div class=\"card-actions\" ";
                yield from $this->unwrap()->yieldBlock('box_tools_attributes', $context, $blocks);
                yield ">
                    ";
                // line 55
                yield "                    ";
                yield (string) ($context["tools"] ?? null);
                yield "
                    ";
                // line 56
                if ((($tmp = ($context["_collapsible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 57
                    yield "                        ";
                    yield (string) $macros["button"]->getTemplateForMacro("macro_action_collapsebutton", $context, 57, $this->getSourceContext())->macro_action_collapsebutton(...[((                    // line 58
array_key_exists("collapsible_title", $context)) ? (Twig\Extension\CoreExtension::default(($context["collapsible_title"] ?? null), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Toggle visibility", [], "TablerBundle"))) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Toggle visibility", [], "TablerBundle"))), ("." .                     // line 59
($context["_collapsible_class"] ?? null))]);
                    // line 60
                    yield "
                    ";
                }
                // line 62
                yield "                </div>
            ";
            }
            // line 64
            yield "        </div>
    ";
        }
        // line 66
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_header_after', $context, $blocks);
        // line 67
        yield "
    ";
        // line 69
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_body_before', $context, $blocks);
        // line 70
        yield "    ";
        if ((($tmp = ($context["_hasBody"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 71
            yield "        ";
            $context["bodyClasses"] = ["card-body"];
            // line 72
            yield "        ";
            if ((($tmp = ($context["_fullsize"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 73
                yield "            ";
                $context["bodyClasses"] = Twig\Extension\CoreExtension::merge(($context["bodyClasses"] ?? null), ["p-0"]);
                // line 74
                yield "        ";
            }
            // line 75
            yield "        ";
            if ((($tmp = ($context["_collapsible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 76
                yield "            ";
                $context["bodyClasses"] = Twig\Extension\CoreExtension::merge(($context["bodyClasses"] ?? null), [(($context["_collapsible_class"] ?? null) . (((($tmp = ($context["_collapsed"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" collapse") : (" show")))]);
                // line 77
                yield "        ";
            }
            // line 78
            yield "        ";
            if ((($tmp = ($context["_bodyScrollable"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 79
                yield "            ";
                $context["bodyClasses"] = Twig\Extension\CoreExtension::merge(($context["bodyClasses"] ?? null), ["card-body-scrollable"]);
                // line 80
                yield "        ";
            }
            // line 81
            yield "        ";
            if ((($tmp = ($context["_bodyScrollableShadow"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 82
                yield "            ";
                $context["bodyClasses"] = Twig\Extension\CoreExtension::merge(($context["bodyClasses"] ?? null), ["card-body-scrollable-shadow"]);
                // line 83
                yield "        ";
            }
            // line 84
            yield "
        <div class=\"";
            // line 85
            yield from $this->unwrap()->yieldBlock('box_body_classes', $context, $blocks);
            yield "\">
            ";
            // line 86
            yield (string) ($context["body"] ?? null);
            yield "
        </div>
    ";
        }
        // line 89
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_body_after', $context, $blocks);
        // line 90
        yield "
    ";
        // line 92
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_footer_before', $context, $blocks);
        // line 93
        yield "    ";
        if ((($tmp = ($context["_hasFooter"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 94
            yield "        <div class=\"card-footer ";
            if ((($tmp = ($context["_footer_collapsible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["_collapsible_class"] ?? null) . (((($tmp = ($context["_collapsed"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" collapse") : (" show"))), "html", null, true);
                yield " ";
            }
            yield " ";
            yield from $this->unwrap()->yieldBlock('box_footer_class', $context, $blocks);
            yield "\">
            ";
            // line 95
            yield (string) ($context["footer"] ?? null);
            yield "
        </div>
    ";
        }
        // line 98
        yield "    ";
        yield from $this->unwrap()->yieldBlock('box_footer_after', $context, $blocks);
        // line 99
        yield "
</div>
";
        // line 101
        yield from $this->unwrap()->yieldBlock('box_after', $context, $blocks);
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_header_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 48
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_header_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["headerClasses"] ?? null), " "), "html", null, true);
        yield " ";
        yield from $this->unwrap()->yieldBlock('box_header_class', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 53
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 66
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_header_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["bodyClasses"] ?? null), " "), "html", null, true);
        yield " ";
        yield from $this->unwrap()->yieldBlock('box_body_class', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 89
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 92
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 94
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 98
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 101
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  548 => 101,  538 => 98,  528 => 94,  518 => 92,  508 => 89,  486 => 85,  476 => 69,  466 => 66,  456 => 53,  434 => 48,  424 => 42,  405 => 34,  395 => 32,  385 => 21,  375 => 20,  365 => 19,  355 => 18,  345 => 17,  340 => 101,  336 => 99,  333 => 98,  327 => 95,  316 => 94,  313 => 93,  310 => 92,  307 => 90,  304 => 89,  298 => 86,  294 => 85,  291 => 84,  288 => 83,  285 => 82,  282 => 81,  279 => 80,  276 => 79,  273 => 78,  270 => 77,  267 => 76,  264 => 75,  261 => 74,  258 => 73,  255 => 72,  252 => 71,  249 => 70,  246 => 69,  243 => 67,  240 => 66,  236 => 64,  232 => 62,  228 => 60,  226 => 59,  225 => 58,  223 => 57,  221 => 56,  216 => 55,  211 => 53,  204 => 52,  198 => 50,  196 => 49,  191 => 48,  188 => 47,  185 => 46,  182 => 45,  179 => 44,  176 => 43,  173 => 42,  170 => 40,  162 => 38,  159 => 37,  143 => 34,  141 => 32,  138 => 31,  136 => 30,  133 => 29,  131 => 28,  129 => 27,  127 => 26,  125 => 25,  123 => 24,  121 => 23,  118 => 22,  113 => 21,  108 => 20,  103 => 19,  98 => 18,  93 => 17,  90 => 15,  88 => 14,  86 => 13,  84 => 12,  82 => 11,  80 => 10,  78 => 9,  76 => 8,  74 => 7,  72 => 6,  70 => 5,  68 => 4,  66 => 3,  64 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card.html.twig");
    }
}
