<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/menu.html.twig */
class __TwigTemplate_b9373871b614f46ae810b8a78597d8b1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        if ( !array_key_exists("menu", $context)) {
            // line 2
            yield "    ";
            $context["menu"] = $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getMenu();
        }
        // line 4
        yield "
";
        // line 5
        if ((array_key_exists("menu", $context) &&  !(null === ($context["menu"] ?? null)))) {
            // line 6
            yield "    ";
            if ( !array_key_exists("layout_type", $context)) {
                // line 7
                yield "        ";
                $context["layout_type"] = "horizontal";
                // line 8
                yield "    ";
            }
            // line 9
            yield "    <ul class=\"navbar-nav ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("navbar_class", $context)) ? (Twig\Extension\CoreExtension::default(($context["navbar_class"] ?? null), "")) : ("")), "html", null, true);
            yield "\">
        ";
            // line 10
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["menu"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 11
                yield "            <li id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "identifier", [], "any", false, false, false, 11), "html", null, true);
                yield "\" class=\"nav-item";
                yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "isActive", [], "any", false, false, false, 11)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" active") : (""));
                yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "hasChildren", [], "any", false, false, false, 11)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (" dropdown") : (""));
                yield "\">
                <a ";
                // line 12
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "hasChildren", [], "any", false, false, false, 12)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 13
                    yield "                        class=\"nav-link dropdown-toggle navbar-menu-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "identifier", [], "any", false, false, false, 13), "html", null, true);
                    yield " ";
                    yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 13)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled") : (""));
                    yield "\" role=\"button\"
                        data-bs-toggle=\"dropdown\" data-bs-auto-close=\"";
                    // line 14
                    yield (string) (((($context["layout_type"] ?? null) === "vertical")) ? ("false") : ("outside"));
                    yield "\"
                        aria-expanded=\"";
                    // line 15
                    yield (string) (((($context["layout_type"] ?? null) === "vertical")) ? ("true") : ("false"));
                    yield "\"
                    ";
                } else {
                    // line 17
                    yield "                        class=\"nav-link ";
                    yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 17)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled") : (""));
                    yield "\"";
                    // line 18
                    if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 18)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 19
                        yield "                            href=\"";
                        yield (string) ((CoreExtension::inFilter("/", CoreExtension::getAttribute($this->env, $this->source, $context["item"], "route", [], "any", false, false, false, 19))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "route", [], "any", false, false, false, 19), "html", null, true)) : ((((null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "route", [], "any", false, false, false, 19))) ? ("#") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "route", [], "any", false, false, false, 19)), CoreExtension::getAttribute($this->env, $this->source, $context["item"], "routeArgs", [], "any", false, false, false, 19)), "html", null, true)))));
                        yield "\"
                        ";
                    }
                    // line 21
                    yield "                    ";
                }
                yield ">
                    ";
                // line 22
                yield (string) $this->getTemplateForMacro("macro_item_icon", $context, 22, $this->getSourceContext())->macro_item_icon(...[$context["item"]]);
                yield "
                    <span class=\"nav-link-title\">";
                // line 23
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "label", [], "any", false, false, false, 23), [], CoreExtension::getAttribute($this->env, $this->source, $context["item"], "translationDomain", [], "any", false, false, false, 23)), "html", null, true);
                yield "</span>
                    ";
                // line 24
                if ((($context["layout_type"] ?? null) === "horizontal")) {
                    // line 25
                    yield "                        ";
                    yield (string) $this->getTemplateForMacro("macro_item_badge", $context, 25, $this->getSourceContext())->macro_item_badge(...[$context["item"]]);
                    yield "
                    ";
                }
                // line 27
                yield "                </a>
                ";
                // line 28
                yield (string) $this->getTemplateForMacro("macro_item_childs", $context, 28, $this->getSourceContext())->macro_item_childs(...[$context["item"], ($context["layout_type"] ?? null)]);
                yield "
            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 31
            yield "    </ul>
";
        }
        // line 33
        yield "
";
        // line 60
        yield "
";
        // line 75
        yield "
";
        // line 81
        yield "
";
        yield from [];
    }

    // line 34
    public function macro_item_childs($item = null, $layout_type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "layout_type" => $layout_type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 35
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "hasChildren", [], "any", false, false, false, 35)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 36
                yield "        <div class=\"dropdown-menu ";
                yield (string) ((((($context["layout_type"] ?? null) === "vertical") && ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "isActive", [], "any", false, false, false, 36)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "isExpanded", [], "any", false, false, false, 36)) && $tmp instanceof Markup ? (string) $tmp : $tmp)))) ? ("show") : (""));
                yield "\" data-bs-popper=\"none\">
            <div class=\"dropdown-menu-columns\">
                <div class=\"dropdown-menu-column\">
                    ";
                // line 39
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "children", [], "any", false, false, false, 39));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["child"]) {
                    // line 40
                    yield "                        ";
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["child"], "hasChildren", [], "any", false, false, false, 40)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 41
                        yield "                            <div class=\"dropend\">
                                <a class=\"dropdown-item dropdown-toggle ";
                        // line 42
                        yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["child"], "isActive", [], "any", false, false, false, 42)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active") : (""));
                        yield " ";
                        yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["child"], "disabled", [], "any", false, false, false, 42)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled") : (""));
                        yield " navbar-menu-";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["child"], "identifier", [], "any", false, false, false, 42), "html", null, true);
                        yield "\" role=\"button\"
                                   data-bs-toggle=\"dropdown\" data-bs-auto-close=\"";
                        // line 43
                        yield (string) (((($context["layout_type"] ?? null) === "vertical")) ? ("false") : ("outside"));
                        yield "\"
                                   aria-expanded=\"";
                        // line 44
                        yield (string) (((($context["layout_type"] ?? null) === "vertical")) ? ("true") : ("false"));
                        yield "\">
                                    ";
                        // line 45
                        yield (string) $this->getTemplateForMacro("macro_item_icon", $context, 45, $this->getSourceContext())->macro_item_icon(...[$context["child"]]);
                        yield "
                                    ";
                        // line 46
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["child"], "label", [], "any", false, false, false, 46), [], CoreExtension::getAttribute($this->env, $this->source, $context["child"], "translationDomain", [], "any", false, false, false, 46)), "html", null, true);
                        yield "
                                    ";
                        // line 47
                        yield (string) $this->getTemplateForMacro("macro_item_badge", $context, 47, $this->getSourceContext())->macro_item_badge(...[$context["child"]]);
                        yield "
                                </a>
                                ";
                        // line 49
                        yield (string) $this->getTemplateForMacro("macro_item_childs", $context, 49, $this->getSourceContext())->macro_item_childs(...[$context["child"], ($context["layout_type"] ?? null)]);
                        yield "
                            </div>
                        ";
                    } else {
                        // line 52
                        yield "                            ";
                        yield (string) $this->getTemplateForMacro("macro_child_item", $context, 52, $this->getSourceContext())->macro_child_item(...[$context["child"], CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 52)]);
                        yield "
                        ";
                    }
                    // line 54
                    yield "                    ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['child'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 55
                yield "                </div>
            </div>
        </div>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 61
    public function macro_child_item($child = null, $isLast = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "child" => $child,
            "isLast" => $isLast,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 62
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "divider", [], "any", false, false, false, 62)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 63
                yield "        ";
                if ( !(($tmp = ($context["isLast"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 64
                    yield "<hr class=\"dropdown-divider\">";
                }
                // line 66
                yield "    ";
            } else {
                // line 67
                yield "        <a class=\"dropdown-item ";
                yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "isActive", [], "any", false, false, false, 67)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active") : (""));
                yield " ";
                yield (string) (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "disabled", [], "any", false, false, false, 67)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled") : (""));
                yield " navbar-menu-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "identifier", [], "any", false, false, false, 67), "html", null, true);
                yield "\"";
                // line 68
                if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "hasChildren", [], "any", false, false, false, 68)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "disabled", [], "any", false, false, false, 68)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    yield " href=\"";
                    yield (string) ((CoreExtension::inFilter("/", CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "route", [], "any", false, false, false, 68))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "route", [], "any", false, false, false, 68), "html", null, true)) : ((((null === CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "route", [], "any", false, false, false, 68))) ? ("#") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias(CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "route", [], "any", false, false, false, 68)), CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "routeArgs", [], "any", false, false, false, 68)), "html", null, true)))));
                    yield "\"";
                }
                yield ">
            ";
                // line 69
                yield (string) $this->getTemplateForMacro("macro_item_icon", $context, 69, $this->getSourceContext())->macro_item_icon(...[($context["child"] ?? null)]);
                yield "
            ";
                // line 70
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "label", [], "any", false, false, false, 70), [], CoreExtension::getAttribute($this->env, $this->source, ($context["child"] ?? null), "translationDomain", [], "any", false, false, false, 70)), "html", null, true);
                yield "
            ";
                // line 71
                yield (string) $this->getTemplateForMacro("macro_item_badge", $context, 71, $this->getSourceContext())->macro_item_badge(...[($context["child"] ?? null)]);
                yield "
        </a>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 76
    public function macro_item_icon($item = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 77
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 77)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 78
                yield "        <span class=\"nav-link-icon d-md-none d-lg-inline-block text-center\">";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 78), false, CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "icon", [], "any", false, false, false, 78));
                yield "</span>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 82
    public function macro_item_badge($item = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 83
            yield "    ";
            if (( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badge", [], "any", false, false, false, 83)) ||  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badgeColor", [], "any", false, false, false, 83)))) {
                // line 84
                yield "        <span class=\"badge badge-sm bg-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badgeColor", [], "any", true, true, false, 84)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badgeColor", [], "any", false, false, false, 84), "blue")) : ("blue")), "html", null, true);
                yield " text-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badgeColor", [], "any", true, true, false, 84)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badgeColor", [], "any", false, false, false, 84), "blue")) : ("blue")), "html", null, true);
                yield "-fg text-uppercase ms-2\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "badge", [], "any", false, false, false, 84), "html", null, true);
                yield "</span>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/menu.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  374 => 84,  371 => 83,  359 => 82,  349 => 78,  346 => 77,  334 => 76,  324 => 71,  320 => 70,  316 => 69,  308 => 68,  300 => 67,  297 => 66,  294 => 64,  291 => 63,  288 => 62,  275 => 61,  265 => 55,  250 => 54,  244 => 52,  238 => 49,  233 => 47,  229 => 46,  225 => 45,  221 => 44,  217 => 43,  209 => 42,  206 => 41,  203 => 40,  186 => 39,  179 => 36,  176 => 35,  163 => 34,  157 => 81,  154 => 75,  151 => 60,  148 => 33,  144 => 31,  134 => 28,  131 => 27,  125 => 25,  123 => 24,  119 => 23,  115 => 22,  110 => 21,  104 => 19,  102 => 18,  98 => 17,  93 => 15,  89 => 14,  82 => 13,  80 => 12,  72 => 11,  68 => 10,  63 => 9,  60 => 8,  57 => 7,  54 => 6,  52 => 5,  49 => 4,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/menu.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/menu.html.twig");
    }
}
