<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/status_indicator.html.twig */
class __TwigTemplate_848342214d124cb1f9dccf144c3e6f4f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_status_indicator($options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "
    ";
            // line 4
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 4) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 4)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 4)) : ("green"));
            // line 5
            yield "    ";
            $context["_animated"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", false, false, false, 5)) : (true)) === true);
            // line 6
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 6)) : (""));
            // line 7
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 7)) : ([]));
            // line 8
            yield "
    <span
        class=\"status-indicator ";
            // line 10
            if ((($tmp = ($context["_animated"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "status-indicator-animated";
            }
            yield " status-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_color"] ?? null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\"
        ";
            // line 11
            yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 11, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
      <span class=\"status-indicator-circle\"></span>
      <span class=\"status-indicator-circle\"></span>
      <span class=\"status-indicator-circle\"></span>
    </span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/status_indicator.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  89 => 11,  79 => 10,  75 => 8,  72 => 7,  69 => 6,  66 => 5,  64 => 4,  61 => 3,  58 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/status_indicator.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/status_indicator.html.twig");
    }
}
