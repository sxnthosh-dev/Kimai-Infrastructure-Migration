<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/charts.html.twig */
class __TwigTemplate_ab77efbb64a27d99843a4433b18e7917 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        // line 5
        yield "
";
        // line 56
        yield "
";
        // line 101
        yield "
";
        // line 105
        yield "
";
        // line 190
        yield "
";
        yield from [];
    }

    // line 9
    public function macro_doughnut_javascript($options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 10
            yield "    <script type=\"text/javascript\">
        function doughnutChartOptions() {
            return {
                maintainAspectRatio: false,
                responsive: true,
                cutoutPercentage: 40,
                animation: {
                    animateRotate: true
                },
                plugins: {
                    ";
            // line 20
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", true, true, false, 20) && is_iterable(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", false, false, false, 20)))) {
                // line 21
                yield "                    legend: ";
                yield (string) json_encode(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", false, false, false, 21));
                yield ",
                    ";
            }
            // line 23
            yield "                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return \x27 \x27 + tooltipData[\x27";
            // line 27
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "label", [], "any", true, true, false, 27)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "label", [], "any", false, false, false, 27), "label")) : ("label")), "html", null, true);
            yield "\x27];
                            },
                            afterTitle: function(tooltipItems) {
                                return \x27 \x27;
                            },
                            ";
            // line 32
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 32) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 32)))) {
                // line 33
                yield "                            title: function(tooltipItems) {
                                const tooltipItem = tooltipItems[0];
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return \x27 \x27 + tooltipData[\x27";
                // line 36
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 36), "html", null, true);
                yield "\x27];
                            },
                            ";
            }
            // line 39
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", true, true, false, 39) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", false, false, false, 39)))) {
                // line 40
                yield "                            beforeFooter: function(tooltipItems) {
                                return \x27 \x27;
                            },
                            footer: function(tooltipItems) {
                                const tooltipItem = tooltipItems[0];
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return tooltipData[\x27";
                // line 46
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", false, false, false, 46), "html", null, true);
                yield "\x27];
                            },
                            ";
            }
            // line 49
            yield "                        }
                    }
                },
            };
        }
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 63
    public function macro_doughnut_chart($id = null, $labels = null, $dataset = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "id" => $id,
            "labels" => $labels,
            "dataset" => $dataset,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 64
            yield "    ";
            $context["height"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", true, true, false, 64)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 64), ($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height") . "px"))) : (($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height") . "px")));
            // line 65
            yield "    ";
            $context["bgColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.background_color");
            // line 66
            yield "    <div class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "chart-class"), "html", null, true);
            yield "\" style=\"position: relative;\">
        <canvas id=\"";
            // line 67
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\" style=\"height: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["height"] ?? null), "html", null, true);
            yield "; width: 100%;\"></canvas>
    </div>
    <script type=\"text/javascript\">
        document.addEventListener(\x27";
            // line 70
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "renderEvent", [], "any", true, true, false, 70)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "renderEvent", [], "any", false, false, false, 70), "kimai.initialized")) : ("kimai.initialized")), "html", null, true);
            yield "\x27, function() {
            new Chart(
                document.getElementById(\"";
            // line 72
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\").getContext(\"2d\"), {
                    type: \x27doughnut\x27,
                    data: {
                        ";
            // line 75
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["labels"] ?? null))) {
                // line 76
                yield "                        labels: ";
                yield (string) json_encode(($context["labels"] ?? null));
                yield ",
                        ";
            }
            // line 78
            yield "                        datasets: [
                            {
                                backgroundColor: [
                                    ";
            // line 81
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["dataset"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 82
                yield "                                    \x27";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "color", [], "any", true, true, false, 82)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "color", [], "any", false, false, false, 82), ($context["bgColor"] ?? null))) : (($context["bgColor"] ?? null))), "html", null, true);
                yield "\x27,
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 84
            yield "                                ],
                                data: [
                                    ";
            // line 86
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["dataset"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 87
                yield "                                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "value", [], "any", false, false, false, 87), "html", null, true);
                yield "
                                    ";
                // line 88
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 88)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield ",";
                }
                // line 89
                yield "                                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 90
            yield "                                ],
                                realData: ";
            // line 91
            yield (string) json_encode(($context["dataset"] ?? null));
            yield ",
                            }
                        ]
                    },
                    options: Object.assign(doughnutChartOptions(),";
            // line 95
            yield (string) json_encode(($context["options"] ?? null));
            yield ")
                }
            );
        });
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 109
    public function macro_bar_javascript($options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 110
            yield "    <script type=\"text/javascript\">
        function barChartOptions() {
            return {
                maintainAspectRatio: true,
                responsive: true,
                barPercentage: 0.5,
                categoryPercentage: 1.0,
                scales: {
                    x: {
                        gridLines: {
                            display: false
                        }
                    },
                    y: {
                        ticks: {
                            beginAtZero: true,
                        },
                        gridLines: {
                            display: true,
                            color: \x27";
            // line 129
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.grid_color"), "html", null, true);
            yield "\x27,
                            lineWidth: 1
                        }
                    }
                },
                plugins: {
                    ";
            // line 135
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", true, true, false, 135) && is_iterable(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", false, false, false, 135)))) {
                // line 136
                yield "                    legend: ";
                yield (string) json_encode(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "legend", [], "any", false, false, false, 136));
                yield ",
                    ";
            }
            // line 138
            yield "                    tooltip: {
                        titleSpacing: 0,
                        titleMarginBottom: 0,
                        footerMarginTop: 0,
                        callbacks: {
                            label: function(tooltipItem) {
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return \x27 \x27 + tooltipData[\x27";
            // line 145
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "label", [], "any", true, true, false, 145)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "label", [], "any", false, false, false, 145), "label")) : ("label")), "html", null, true);
            yield "\x27];
                            },
                            afterTitle: function(tooltipItems) {
                                return \x27 \x27;
                            },
                            ";
            // line 150
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 150) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 150)))) {
                // line 151
                yield "                            title: function(tooltipItems) {
                                const tooltipItem = tooltipItems[0];
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return \x27 \x27 + tooltipData[\x27";
                // line 154
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 154), "html", null, true);
                yield "\x27];
                            },
                            ";
            }
            // line 157
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", true, true, false, 157) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", false, false, false, 157)))) {
                // line 158
                yield "                            beforeFooter: function(tooltipItems) {
                                return \x27 \x27;
                            },
                            footer: function(tooltipItems) {
                                const tooltipItem = tooltipItems[0];
                                const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                return tooltipData[\x27";
                // line 164
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "footer", [], "any", false, false, false, 164), "html", null, true);
                yield "\x27];
                            },
                            ";
            }
            // line 167
            yield "                        }
                    },
                },
                ";
            // line 170
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "onclick", [], "any", true, true, false, 170) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "onclick", [], "any", false, true, false, 170), "url", [], "any", true, true, false, 170))) {
                // line 171
                yield "                onClick: function(event, elements, chart) {
                    if (elements.length !== 1) {
                        return;
                    }
                    const element = elements[0];
                    const data = this.data.datasets[element.datasetIndex].realData[element.index];
                    let url = \x27";
                // line 177
                yield (string) CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "onclick", [], "any", false, false, false, 177), "url", [], "any", false, false, false, 177);
                yield "\x27;
                    ";
                // line 178
                if (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "onclick", [], "any", false, true, false, 178), "replacer", [], "any", true, true, false, 178)) {
                    // line 179
                    yield "                        ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "onclick", [], "any", false, false, false, 179), "replacer", [], "any", false, false, false, 179));
                    foreach ($context['_seq'] as $context["replacer"] => $context["field"]) {
                        // line 180
                        yield "                        url = url.replace(/";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["replacer"], "html", null, true);
                        yield "/, data[\x27";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["field"], "html", null, true);
                        yield "\x27]);
                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['replacer'], $context['field'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 182
                    yield "                        document.location = url;
                    ";
                }
                // line 184
                yield "                },
                ";
            }
            // line 186
            yield "            };
        }
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 197
    public function macro_bar_chart($id = null, $labels = null, $datasets = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "id" => $id,
            "labels" => $labels,
            "datasets" => $datasets,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 198
            yield "    ";
            $context["height"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", true, true, false, 198)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 198), ($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height") . "px"))) : (($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height") . "px")));
            // line 199
            yield "    ";
            $context["bgColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.background_color");
            // line 200
            yield "    <div class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "chart-class"), "html", null, true);
            yield "\" style=\"position: relative;\">
        <canvas id=\"";
            // line 201
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\" style=\"height: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["height"] ?? null), "html", null, true);
            yield "; width: 100%;\"></canvas>
    </div>
    <script type=\"text/javascript\">
        document.addEventListener(\x27";
            // line 204
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "renderEvent", [], "any", true, true, false, 204)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "renderEvent", [], "any", false, false, false, 204), "kimai.initialized")) : ("kimai.initialized")), "html", null, true);
            yield "\x27, function() {
            new Chart(
                document.getElementById(\x27";
            // line 206
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\x27).getContext(\"2d\"), {
                    type: \x27";
            // line 207
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", true, true, false, 207)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", false, false, false, 207), "bar")) : ("bar")), "html", null, true);
            yield "\x27,
                    data: {
                        ";
            // line 209
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["labels"] ?? null))) {
                // line 210
                yield "                        labels: ";
                yield (string) json_encode(($context["labels"] ?? null));
                yield ",
                        ";
            }
            // line 212
            yield "                        datasets: [
                            ";
            // line 213
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["datasets"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["dataset"]) {
                // line 214
                yield "                            {
                                backgroundColor: [
                                    ";
                // line 216
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["dataset"]);
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 217
                    yield "                                    \x27";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "color", [], "any", true, true, false, 217)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "color", [], "any", false, false, false, 217), ($context["bgColor"] ?? null))) : (($context["bgColor"] ?? null))), "html", null, true);
                    yield "\x27,
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 219
                yield "                                ],
                                data: [
                                    ";
                // line 221
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["dataset"]);
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 222
                    yield "                                    ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "value", [], "any", false, false, false, 222), "html", null, true);
                    yield ",
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 224
                yield "                                ],
                                realData: ";
                // line 225
                yield (string) json_encode($context["dataset"]);
                yield ",
                            },
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['dataset'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 228
            yield "                        ]
                    },
                    options: Object.assign(barChartOptions(),";
            // line 230
            yield (string) json_encode(($context["options"] ?? null));
            yield ")
                }
            );
        });
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/charts.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  559 => 230,  555 => 228,  545 => 225,  542 => 224,  532 => 222,  528 => 221,  524 => 219,  514 => 217,  510 => 216,  506 => 214,  502 => 213,  499 => 212,  493 => 210,  491 => 209,  486 => 207,  482 => 206,  477 => 204,  469 => 201,  464 => 200,  461 => 199,  458 => 198,  443 => 197,  434 => 186,  430 => 184,  426 => 182,  414 => 180,  409 => 179,  407 => 178,  403 => 177,  395 => 171,  393 => 170,  388 => 167,  382 => 164,  374 => 158,  371 => 157,  365 => 154,  360 => 151,  358 => 150,  350 => 145,  341 => 138,  335 => 136,  333 => 135,  324 => 129,  303 => 110,  291 => 109,  279 => 95,  272 => 91,  269 => 90,  254 => 89,  250 => 88,  245 => 87,  228 => 86,  224 => 84,  214 => 82,  210 => 81,  205 => 78,  199 => 76,  197 => 75,  191 => 72,  186 => 70,  178 => 67,  173 => 66,  170 => 65,  167 => 64,  152 => 63,  140 => 49,  134 => 46,  126 => 40,  123 => 39,  117 => 36,  112 => 33,  110 => 32,  102 => 27,  96 => 23,  90 => 21,  88 => 20,  76 => 10,  64 => 9,  58 => 190,  55 => 105,  52 => 101,  49 => 56,  46 => 5,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/charts.html.twig", "/opt/kimai/templates/macros/charts.html.twig");
    }
}
