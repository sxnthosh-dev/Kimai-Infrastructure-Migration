<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/renderer.pdf.twig */
class __TwigTemplate_dcbb916c53619c96c44cf727fce289f7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<html lang=\"";
        yield (string) (((array_key_exists("locale", $context) &&  !(null === $context["locale"]))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["locale"], "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 1), "locale", [], "any", false, false, false, 1), "html", null, true)));
        yield "\">
";
        // line 2
        $context["title"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["template"] ?? null), "options", [], "any", false, true, false, 2), "name", [], "any", true, true, false, 2) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["template"] ?? null), "options", [], "any", false, false, false, 2), "name", [], "any", false, false, false, 2)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["template"] ?? null), "options", [], "any", false, false, false, 2), "name", [], "any", false, false, false, 2)) : ("export.document_title")));
        // line 4
        $context["now"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate("now", CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 4));
        // line 6
        $context["duration"] = 0;
        // line 7
        $context["rate"] = 0;
        // line 8
        $context["rateInternal"] = 0;
        // line 9
        $context["currency"] = false;
        // line 10
        yield "<head>
    <title>";
        // line 11
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
        yield "</title>
    <style>
        ";
        // line 13
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("export-pdf");
        yield "
        body { font-family: ";
        // line 14
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["font"] ?? null), "html", null, true);
        yield " !important; }
    </style>
</head>
<body>
<!--mpdf
<htmlpageheader name=\"header\">
<table style=\"font-size: 10pt; width: 100%; border-bottom: 1px solid #000000\" cellspacing=\"0\">
    <tr>
        <td style=\"text-align: left; padding-left: 0; font-weight: bold;\">
            ";
        // line 23
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
        yield "
        </td>
        <td style=\"text-align: right; padding-right: 0;\">
            ";
        // line 26
        if (array_key_exists("query", $context)) {
            // line 27
            yield "                ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.period"), "html", null, true);
            yield ":
                ";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "begin", [], "any", false, false, false, 28)), "html", null, true);
            yield " &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "end", [], "any", false, false, false, 28)), "html", null, true);
            yield "
            ";
        }
        // line 30
        yield "        </td>
    </tr>
</table>
</htmlpageheader>
<sethtmlpageheader name=\"header\" page=\"ALL\" value=\"on\" show-this-page=\"1\" />
<htmlpagefooter name=\"myfooter\">
<table style=\"border-top: 1px solid #000000; font-size: 9pt; padding-top: 3mm; width: 100%\" cellspacing=\"0\">
<tr>
    <td style=\"text-align: left; padding-left: 0;\">
        ";
        // line 39
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.page_of", ["%page%" => "{PAGENO}", "%pages%" => "{nb}"]), "html", null, true);
        yield "
    </td>
    <td style=\"text-align: right; padding-right: 0;\">
        ";
        // line 42
        $context["company"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.company");
        // line 43
        yield "        ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["company"] ?? null))) {
            // line 44
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["company"] ?? null), "html", null, true);
            yield " &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["now"] ?? null)), "html", null, true);
            yield "
        ";
        } else {
            // line 46
            yield "            ";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.date_copyright", ["%date%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["now"] ?? null)), "%kimai%" => (((("<a href=\"" . Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE")) . "\">") . Twig\Extension\CoreExtension::constant("App\\Constants::SOFTWARE")) . "</a>")]);
            yield "
        ";
        }
        // line 48
        yield "    </td>
</tr>
</table>
</htmlpagefooter>
<sethtmlpagefooter name=\"myfooter\" value=\"on\" />
mpdf-->
<div style=\"margin-top: 120px;\">

    ";
        // line 57
        yield "    ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["summary"] ?? null)) > 0)) {
            // line 58
            yield "        ";
            $context["summaryColumns"] = ["customer", "project"];
            // line 59
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summary"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 60
                yield "            ";
                if (($context["column"] == "project_budget_time")) {
                    // line 61
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["timeBudget"]);
                    // line 62
                    yield "            ";
                } elseif (($context["column"] == "project_budget_money")) {
                    // line 63
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["budget"]);
                    // line 64
                    yield "            ";
                } elseif (($context["column"] == "duration")) {
                    // line 65
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["duration"]);
                    // line 66
                    yield "            ";
                } elseif (($context["column"] == "internal_rate")) {
                    // line 67
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["internalRate"]);
                    // line 68
                    yield "            ";
                } elseif (($context["column"] == "duration_decimal")) {
                    // line 69
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["duration_decimal"]);
                    // line 70
                    yield "            ";
                } elseif (($context["column"] == "rate")) {
                    // line 71
                    yield "                ";
                    $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["rate"]);
                    // line 72
                    yield "            ";
                }
                // line 73
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['column'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 74
            yield "        <h3>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
            yield "</h3>
        <table class=\"items\">
            <thead>
            <tr>
                ";
            // line 78
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                // line 79
                yield "                    ";
                if (($context["summaryColumn"] == "duration_decimal")) {
                    // line 80
                    yield "                        <th class=\"text-left\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
                    yield "</th>
                    ";
                } elseif ((                // line 81
$context["summaryColumn"] == "budget")) {
                    // line 82
                    yield "                        <th>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("remaining_budget"), "html", null, true);
                    yield "</th>
                    ";
                } elseif ((                // line 83
$context["summaryColumn"] == "timeBudget")) {
                    // line 84
                    yield "                        <th>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("remaining_budget"), "html", null, true);
                    yield "</th>
                    ";
                } elseif (((                // line 85
$context["summaryColumn"] == "customer") || ($context["summaryColumn"] == "project"))) {
                    // line 86
                    yield "                        <th>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["summaryColumn"]), "html", null, true);
                    yield "</th>
                    ";
                } else {
                    // line 88
                    yield "                        <th class=\"center\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["summaryColumn"]), "html", null, true);
                    yield "</th>
                    ";
                }
                // line 90
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 91
            yield "            </tr>
            </thead>
            <tbody>
            ";
            // line 94
            $context["showCustomerSummary"] = true;
            // line 95
            yield "            ";
            $context["showTotalSummary"] = true;
            // line 96
            yield "            ";
            $context["customer"] = null;
            // line 97
            yield "            ";
            $context["customerDuration"] = 0;
            // line 98
            yield "            ";
            $context["customerRate"] = 0;
            // line 99
            yield "            ";
            $context["customerInternalRate"] = 0;
            // line 100
            yield "            ";
            $context["customerCurrency"] = null;
            // line 101
            yield "            ";
            $context["customerCount"] = 0;
            // line 102
            yield "            ";
            $context["multiCurrency"] = false;
            // line 103
            yield "            ";
            $context["totalDuration"] = 0;
            // line 104
            yield "            ";
            $context["totalInternalRate"] = 0;
            // line 105
            yield "            ";
            $context["totalRate"] = 0;
            // line 106
            yield "            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summaries"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["summary"]) {
                // line 107
                yield "                <!-- CONTENT_PART -->
                ";
                // line 108
                $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 108));
                // line 109
                yield "                ";
                $context["totalInternalRate"] = (($context["totalInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 109));
                // line 110
                yield "                ";
                $context["totalRate"] = (($context["totalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 110));
                // line 111
                yield "                ";
                if (( !(null === ($context["customerCurrency"] ?? null)) &&  !(($context["customerCurrency"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 111)))) {
                    // line 112
                    yield "                    ";
                    $context["multiCurrency"] = true;
                    // line 113
                    yield "                ";
                }
                // line 114
                yield "                ";
                if ((($context["customer"] ?? null) === null)) {
                    // line 115
                    yield "                    ";
                    $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 115);
                    // line 116
                    yield "                    ";
                    $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 116);
                    // line 117
                    yield "                ";
                }
                // line 118
                yield "                ";
                if ( !(($context["customer"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 118))) {
                    // line 119
                    yield "                    <tr class=\"summary\">
                        ";
                    // line 120
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
                    foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                        // line 121
                        yield "                            ";
                        if (($context["summaryColumn"] == "duration")) {
                            // line 122
                            yield "                                <td class=\"totals duration\">";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null)), "html", null, true);
                            yield "</td>
                            ";
                        } elseif ((                        // line 123
$context["summaryColumn"] == "duration_decimal")) {
                            // line 124
                            yield "                                <td class=\"totals duration\">";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true), "html", null, true);
                            yield "</td>
                            ";
                        } elseif ((                        // line 125
$context["summaryColumn"] == "internalRate")) {
                            // line 126
                            yield "                                <td class=\"totals cost\">";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                            yield "</td>
                            ";
                        } elseif ((                        // line 127
$context["summaryColumn"] == "rate")) {
                            // line 128
                            yield "                                <td class=\"totals cost\">";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                            yield "</td>
                            ";
                        } else {
                            // line 130
                            yield "                                <td></td>
                            ";
                        }
                        // line 132
                        yield "                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 133
                    yield "                    </tr>
                    ";
                    // line 134
                    $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 134);
                    // line 135
                    yield "                    ";
                    $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 135);
                    // line 136
                    yield "                    ";
                    $context["customerDuration"] = 0;
                    // line 137
                    yield "                    ";
                    $context["customerRate"] = 0;
                    // line 138
                    yield "                    ";
                    $context["customerInternalRate"] = 0;
                    // line 139
                    yield "                    ";
                    $context["customerCount"] = 0;
                    // line 140
                    yield "                ";
                }
                // line 141
                yield "                <tr class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::cycle(["odd", "even"], ($context["customerCount"] ?? null)), "html", null, true);
                yield "\">
                    ";
                // line 142
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                    // line 143
                    yield "                        ";
                    if (($context["summaryColumn"] == "customer")) {
                        // line 144
                        yield "                            <td>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 144), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 145
$context["summaryColumn"] == "project")) {
                        // line 146
                        yield "                            <td>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "project", [], "any", false, false, false, 146), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 147
$context["summaryColumn"] == "timeBudget")) {
                        // line 148
                        yield "                            <td class=\"center\">
                                ";
                        // line 149
                        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 149) && (CoreExtension::getAttribute($this->env, $this->source, (($_v0 = ($context["budgets"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = $context["id"]) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null), "time_left", [], "any", false, false, false, 149) > 0))) {
                            // line 150
                            yield "                                    ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v2 = ($context["budgets"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = $context["id"]) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null), "time_left", [], "any", false, false, false, 150)), "html", null, true);
                            yield "
                                ";
                        }
                        // line 152
                        yield "                            </td>
                        ";
                    } elseif ((                    // line 153
$context["summaryColumn"] == "budget")) {
                        // line 154
                        yield "                            <td class=\"center\">
                                ";
                        // line 155
                        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 155) && (CoreExtension::getAttribute($this->env, $this->source, (($_v4 = ($context["budgets"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[(($_v5 = $context["id"]) instanceof \Stringable ? (string) $_v5 : $_v5)] ?? null) : null), "money_left", [], "any", false, false, false, 155) > 0))) {
                            // line 156
                            yield "                                    ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, (($_v6 = ($context["budgets"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[(($_v7 = $context["id"]) instanceof \Stringable ? (string) $_v7 : $_v7)] ?? null) : null), "money_left", [], "any", false, false, false, 156), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 156)), "html", null, true);
                            yield "
                                ";
                        }
                        // line 158
                        yield "                            </td>
                        ";
                    } elseif ((                    // line 159
$context["summaryColumn"] == "hourlyRate")) {
                        // line 160
                        yield "                            ";
                        $context["summaryHourlyRate"] = (CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 160) / 3600);
                        // line 161
                        yield "                            <td class=\"cost\">";
                        yield (string) (((($context["summaryHourlyRate"] ?? null) > 0)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 161) / ($context["summaryHourlyRate"] ?? null)), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 161)), "html", null, true)) : (""));
                        yield "</td>
                        ";
                    } elseif ((                    // line 162
$context["summaryColumn"] == "duration")) {
                        // line 163
                        yield "                            <td class=\"duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 163)), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 164
$context["summaryColumn"] == "duration_decimal")) {
                        // line 165
                        yield "                            <td class=\"duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 165), true), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 166
$context["summaryColumn"] == "internalRate")) {
                        // line 167
                        yield "                            <td class=\"cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 167), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 167)), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 168
$context["summaryColumn"] == "rate")) {
                        // line 169
                        yield "                            <td class=\"cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 169), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 169)), "html", null, true);
                        yield "</td>
                        ";
                    }
                    // line 171
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 172
                yield "                </tr>
                ";
                // line 173
                $context["customerDuration"] = (($context["customerDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 173));
                // line 174
                yield "                ";
                $context["customerRate"] = (($context["customerRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 174));
                // line 175
                yield "                ";
                $context["customerInternalRate"] = (($context["customerInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 175));
                // line 176
                yield "                ";
                $context["customerCount"] = (($context["customerCount"] ?? null) + 1);
                // line 177
                yield "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['summary'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 178
            yield "            ";
            if (((($tmp = ($context["showCustomerSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($context["customer"] ?? null) === null))) {
                // line 179
                yield "            <tr class=\"summary\">
                ";
                // line 180
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                    // line 181
                    yield "                    ";
                    if (($context["summaryColumn"] == "duration")) {
                        // line 182
                        yield "                        <td class=\"totals duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null)), "html", null, true);
                        yield "</td>
                    ";
                    } elseif ((                    // line 183
$context["summaryColumn"] == "duration_decimal")) {
                        // line 184
                        yield "                        <td class=\"totals duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true), "html", null, true);
                        yield "</td>
                    ";
                    } elseif ((                    // line 185
$context["summaryColumn"] == "internalRate")) {
                        // line 186
                        yield "                        <td class=\"totals cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                        yield "</td>
                    ";
                    } elseif ((                    // line 187
$context["summaryColumn"] == "rate")) {
                        // line 188
                        yield "                        <td class=\"totals cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                        yield "</td>
                    ";
                    } else {
                        // line 190
                        yield "                        <td></td>
                    ";
                    }
                    // line 192
                    yield "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 193
                yield "            </tr>
            ";
            }
            // line 195
            yield "            ";
            if ((($tmp = ($context["showTotalSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 196
                yield "            <tr class=\"";
                if ( !(($tmp = ($context["showCustomerSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "summary";
                } else {
                    yield "summary-total";
                }
                yield "\">
                <td class=\"totals\" colspan=\"2\">
                    ";
                // line 198
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
                yield "
                </td>
                ";
                // line 200
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                    // line 201
                    yield "                    ";
                    if (($context["summaryColumn"] == "duration")) {
                        // line 202
                        yield "                        <td class=\"totals duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null)), "html", null, true);
                        yield "</td>
                    ";
                    } elseif ((                    // line 203
$context["summaryColumn"] == "duration_decimal")) {
                        // line 204
                        yield "                        <td class=\"totals duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null), true), "html", null, true);
                        yield "</td>
                    ";
                    } elseif ((                    // line 205
$context["summaryColumn"] == "internalRate")) {
                        // line 206
                        yield "                        <td class=\"totals cost\">
                            ";
                        // line 207
                        if ( !(($tmp = ($context["multiCurrency"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 208
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                            yield "
                            ";
                        }
                        // line 210
                        yield "                        </td>
                    ";
                    } elseif ((                    // line 211
$context["summaryColumn"] == "rate")) {
                        // line 212
                        yield "                        <td class=\"totals cost\">
                            ";
                        // line 213
                        if ( !(($tmp = ($context["multiCurrency"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 214
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                            yield "
                            ";
                        }
                        // line 216
                        yield "                        </td>
                    ";
                    } elseif (!CoreExtension::inFilter(                    // line 217
$context["summaryColumn"], ["customer", "project"])) {
                        // line 218
                        yield "                        <td></td>
                    ";
                    }
                    // line 220
                    yield "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 221
                yield "            </tr>
            ";
            }
            // line 223
            yield "            </tbody>
        </table>

        <pagebreak/>
    ";
        }
        // line 228
        yield "
    ";
        // line 230
        yield "
    <h3>";
        // line 231
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.full_list"), "html", null, true);
        yield "</h3>

    ";
        // line 233
        $context["replace_classes"] = ["hourlyRate" => "center", "internalRate" => "center", "fixedRate" => "center", "rate" => "center", "duration" => "center", "break" => "center"];
        // line 241
        yield "
    <table class=\"items\">
        <thead>
        <tr>
            ";
        // line 245
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
            // line 246
            yield "                <th";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["replace_classes"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 246), [], "array", true, true, false, 246)) {
                yield " class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v8 = ($context["replace_classes"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[(($_v9 = CoreExtension::getAttribute($this->env, $this->source, $context["column"], "name", [], "any", false, false, false, 246)) instanceof \Stringable ? (string) $_v9 : $_v9)] ?? null) : null), "html", null, true);
                yield "\"";
            }
            yield ">
                    ";
            // line 247
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "header", [], "any", false, false, false, 247)), "html", null, true);
            yield "
                </th>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['column'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 250
        yield "        </tr>
        </thead>
        <tbody>
        ";
        // line 253
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 254
            yield "            <!-- CONTENT_PART -->
            ";
            // line 255
            $context["duration"] = (($context["duration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 255));
            // line 256
            yield "            ";
            $context["entryCurrency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 256), "customer", [], "any", false, false, false, 256), "currency", [], "any", false, false, false, 256);
            // line 257
            yield "            ";
            if ((($context["currency"] ?? null) === false)) {
                // line 258
                yield "                ";
                $context["currency"] = ($context["entryCurrency"] ?? null);
                // line 259
                yield "            ";
            }
            // line 260
            yield "            ";
            if ( !(($context["currency"] ?? null) === ($context["entryCurrency"] ?? null))) {
                // line 261
                yield "                ";
                $context["currency"] = null;
                // line 262
                yield "            ";
            }
            // line 263
            yield "            ";
            // line 265
            yield "            ";
            $context["rate"] = (($context["rate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 265));
            // line 266
            yield "            ";
            $context["rateInternal"] = (($context["rateInternal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 266));
            // line 267
            yield "            <tr class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::cycle(["odd", "even"], CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 267)), "html", null, true);
            yield "\">
                ";
            // line 268
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["col"]) {
                // line 269
                yield "                    ";
                $context["column"] = CoreExtension::getAttribute($this->env, $this->source, $context["col"], "name", [], "any", false, false, false, 269);
                // line 270
                yield "                    ";
                $context["value"] = CoreExtension::getAttribute($this->env, $this->source, $context["col"], "extract", [$context["entry"]], "method", false, false, false, 270);
                // line 271
                yield "                    ";
                if ((($context["column"] ?? null) == "date")) {
                    // line 272
                    yield "                        <td class=\"text-nowrap\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["value"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 273
($context["column"] ?? null) == "begin")) {
                    // line 274
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(($context["value"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 275
($context["column"] ?? null) == "end")) {
                    // line 276
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(($context["value"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 277
($context["column"] ?? null) == "user")) {
                    // line 278
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 279
($context["column"] ?? null) == "currency")) {
                    // line 280
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["entryCurrency"] ?? null), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 281
($context["column"] ?? null) == "description")) {
                    // line 282
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(($context["value"] ?? null));
                    yield "</td>
                    ";
                } elseif ((                // line 283
$context["id"] == "hourly_rate")) {
                    // line 284
                    yield "                        <td class=\"cost\">
                            ";
                    // line 285
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 285)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 286
                        yield "                                -
                            ";
                    } else {
                        // line 288
                        yield "                                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["entryCurrency"] ?? null)), "html", null, true);
                        yield "
                            ";
                    }
                    // line 290
                    yield "                        </td>
                    ";
                } elseif (CoreExtension::inFilter(                // line 291
$context["id"], ["duration", "duration_decimal", "duration_seconds"])) {
                    // line 292
                    yield "                        <td class=\"duration\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), ($context["id"] == "duration_decimal")), "html", null, true);
                    yield "</td>
                    ";
                } elseif (CoreExtension::inFilter(                // line 293
$context["id"], ["break", "break_decimal", "break_seconds"])) {
                    // line 294
                    yield "                        <td class=\"duration\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), ($context["id"] == "break_decimal")), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 295
$context["id"] == "internal_rate")) {
                    // line 296
                    yield "                        <td class=\"cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["entryCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 297
$context["id"] == "rate")) {
                    // line 298
                    yield "                        <td class=\"cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["entryCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif (((                // line 299
$context["id"] == "exported") || ($context["id"] == "billable"))) {
                    // line 300
                    yield "                        <td>";
                    yield (string) (((($context["value"] ?? null) === false)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("no"), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("yes"), "html", null, true)));
                    yield "</td>
                    ";
                } elseif ((                // line 301
($context["column"] ?? null) == "tags")) {
                    // line 302
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["value"] ?? null), ", "), "html", null, true);
                    yield "</td>
                    ";
                } else {
                    // line 304
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                    yield "</td>
                    ";
                }
                // line 306
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['col'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 307
            yield "            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 309
        yield "        <tr class=\"summary\">
            ";
        // line 310
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["column"]) {
            // line 311
            yield "                ";
            if (CoreExtension::inFilter($context["id"], ["duration", "duration_decimal", "duration_seconds"])) {
                // line 312
                yield "                    <td class=\"totals duration\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["duration"] ?? null), ($context["id"] == "duration_decimal")), "html", null, true);
                yield "</td>
                ";
            } elseif ((            // line 313
$context["id"] == "internal_rate")) {
                // line 314
                yield "                    <td class=\"totals cost\">";
                if ( !(null === ($context["currency"] ?? null))) {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateInternal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                }
                yield "</td>
                ";
            } elseif ((            // line 315
$context["id"] == "rate")) {
                // line 316
                yield "                    <td class=\"totals cost\">";
                if ( !(null === ($context["currency"] ?? null))) {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                }
                yield "</td>
                ";
            } else {
                // line 318
                yield "                    <td></td>
                ";
            }
            // line 320
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['column'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 321
        yield "        </tr>
        </tbody>
    </table>
</div>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/renderer.pdf.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  977 => 321,  970 => 320,  966 => 318,  958 => 316,  956 => 315,  949 => 314,  947 => 313,  942 => 312,  939 => 311,  935 => 310,  932 => 309,  916 => 307,  909 => 306,  903 => 304,  897 => 302,  895 => 301,  890 => 300,  888 => 299,  883 => 298,  881 => 297,  876 => 296,  874 => 295,  869 => 294,  867 => 293,  862 => 292,  860 => 291,  857 => 290,  851 => 288,  847 => 286,  845 => 285,  842 => 284,  840 => 283,  835 => 282,  833 => 281,  828 => 280,  826 => 279,  821 => 278,  819 => 277,  814 => 276,  812 => 275,  807 => 274,  805 => 273,  800 => 272,  797 => 271,  794 => 270,  791 => 269,  787 => 268,  782 => 267,  779 => 266,  776 => 265,  774 => 263,  771 => 262,  768 => 261,  765 => 260,  762 => 259,  759 => 258,  756 => 257,  753 => 256,  751 => 255,  748 => 254,  731 => 253,  726 => 250,  716 => 247,  707 => 246,  703 => 245,  697 => 241,  695 => 233,  690 => 231,  687 => 230,  684 => 228,  677 => 223,  673 => 221,  666 => 220,  662 => 218,  660 => 217,  657 => 216,  651 => 214,  649 => 213,  646 => 212,  644 => 211,  641 => 210,  635 => 208,  633 => 207,  630 => 206,  628 => 205,  623 => 204,  621 => 203,  616 => 202,  613 => 201,  609 => 200,  604 => 198,  594 => 196,  591 => 195,  587 => 193,  580 => 192,  576 => 190,  570 => 188,  568 => 187,  563 => 186,  561 => 185,  556 => 184,  554 => 183,  549 => 182,  546 => 181,  542 => 180,  539 => 179,  536 => 178,  529 => 177,  526 => 176,  523 => 175,  520 => 174,  518 => 173,  515 => 172,  508 => 171,  502 => 169,  500 => 168,  495 => 167,  493 => 166,  488 => 165,  486 => 164,  481 => 163,  479 => 162,  474 => 161,  471 => 160,  469 => 159,  466 => 158,  460 => 156,  458 => 155,  455 => 154,  453 => 153,  450 => 152,  444 => 150,  442 => 149,  439 => 148,  437 => 147,  432 => 146,  430 => 145,  425 => 144,  422 => 143,  418 => 142,  413 => 141,  410 => 140,  407 => 139,  404 => 138,  401 => 137,  398 => 136,  395 => 135,  393 => 134,  390 => 133,  383 => 132,  379 => 130,  373 => 128,  371 => 127,  366 => 126,  364 => 125,  359 => 124,  357 => 123,  352 => 122,  349 => 121,  345 => 120,  342 => 119,  339 => 118,  336 => 117,  333 => 116,  330 => 115,  327 => 114,  324 => 113,  321 => 112,  318 => 111,  315 => 110,  312 => 109,  310 => 108,  307 => 107,  302 => 106,  299 => 105,  296 => 104,  293 => 103,  290 => 102,  287 => 101,  284 => 100,  281 => 99,  278 => 98,  275 => 97,  272 => 96,  269 => 95,  267 => 94,  262 => 91,  255 => 90,  249 => 88,  243 => 86,  241 => 85,  236 => 84,  234 => 83,  229 => 82,  227 => 81,  222 => 80,  219 => 79,  215 => 78,  207 => 74,  200 => 73,  197 => 72,  194 => 71,  191 => 70,  188 => 69,  185 => 68,  182 => 67,  179 => 66,  176 => 65,  173 => 64,  170 => 63,  167 => 62,  164 => 61,  161 => 60,  156 => 59,  153 => 58,  150 => 57,  140 => 48,  134 => 46,  126 => 44,  123 => 43,  121 => 42,  115 => 39,  104 => 30,  97 => 28,  92 => 27,  90 => 26,  84 => 23,  72 => 14,  68 => 13,  63 => 11,  60 => 10,  58 => 9,  56 => 8,  54 => 7,  52 => 6,  50 => 4,  48 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/renderer.pdf.twig", "/opt/kimai/templates/export/renderer.pdf.twig");
    }
}
