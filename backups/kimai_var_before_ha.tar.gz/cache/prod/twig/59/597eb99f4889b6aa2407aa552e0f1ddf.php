<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/2fa.html.twig */
class __TwigTemplate_58e58e0a984c8e7e7d617d5d1f75b7c2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("user/form.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    <div class=\"card-body\">
        <div class=\"row mb-3\">
            <p>
                ";
        // line 8
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profile.2fa_intro"), "html", null, true);
        yield "
            </p>
            <p>
                <img onclick=\"document.getElementById(\x27totp_secret\x27).classList.toggle(\x27d-none\x27);\" data-toggle=\"tooltip\" title=\"Click to show code\" alt=\"TOTP QR Code\" style=\"max-width: 200px; max-height: 200px;\" src=\"";
        // line 11
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["qr_code"] ?? null), "dataUri", [], "any", false, false, false, 11), "html", null, true);
        yield "\" />
                <span id=\"totp_secret\" style=\"display: block\" class=\"d-none\">";
        // line 12
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["secret"] ?? null), "html", null, true);
        yield "</span>
            </p>
            ";
        // line 14
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "totpAuthenticationEnabled", [], "any", false, false, false, 14)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 15
            yield "                ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["id" => "user_two_factor_form"]]);
            yield "
                <p>";
            // line 16
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profile.2fa_confirmation"), "html", null, true);
            yield "</p>
                ";
            // line 17
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
                ";
            // line 18
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
            yield "
            ";
        } else {
            // line 20
            yield "                <strong><i class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", true), "html", null, true);
            yield " text-success\"></i> ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activated"), "html", null, true);
            yield "</strong>
            ";
        }
        // line 22
        yield "        </div>
    </div>
    <div class=\"card-footer\">
        ";
        // line 25
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "totpAuthenticationEnabled", [], "any", false, false, false, 25)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 26
            yield "            ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["deactivate"] ?? null), 'form_start', ["attr" => ["id" => "user_two_factor_form"]]);
            yield "
                <input type=\"submit\" value=\"";
            // line 27
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("deactivate"), "html", null, true);
            yield "\" class=\"btn btn-warning confirmation-link\" id=\"user_two_factor_button\" data-question=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("deactivate"), "html", null, true);
            yield "?\"  />
            ";
            // line 28
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["deactivate"] ?? null), 'form_end');
            yield "
        ";
        } else {
            // line 30
            yield "            <input type=\"submit\" value=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
            yield "\" class=\"btn btn-primary\" id=\"user_two_factor_button\" />
        ";
        }
        // line 32
        yield "    </div>

";
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 37
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 38
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "totpAuthenticationEnabled", [], "any", false, false, false, 38)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 39
            yield "    <script>
        document.getElementById(\x27user_two_factor_button\x27).addEventListener(\x27click\x27, function(){
            document.getElementById(\x27user_two_factor_form\x27).submit();
        });
    </script>
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/2fa.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  161 => 39,  159 => 38,  154 => 37,  147 => 36,  140 => 32,  134 => 30,  129 => 28,  123 => 27,  118 => 26,  116 => 25,  111 => 22,  103 => 20,  98 => 18,  94 => 17,  90 => 16,  85 => 15,  83 => 14,  78 => 12,  74 => 11,  68 => 8,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/2fa.html.twig", "/opt/kimai/templates/user/2fa.html.twig");
    }
}
