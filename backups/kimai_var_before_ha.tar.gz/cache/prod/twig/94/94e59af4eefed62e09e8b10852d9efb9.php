<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_user_list_monthly.html.twig */
class __TwigTemplate_482cfa519f5b9e168a960fe0d69af7aa extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_content' => [$this, 'block_report_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/report_user_list_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/report_user_list_layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from $this->load("reporting/report_user_list_monthly.html.twig", 4, 1)->unwrap()->yield(CoreExtension::toArray(["stats" => ($context["stats"] ?? null), "dataType" => ($context["dataType"] ?? null), "period_attribute" => ($context["period_attribute"] ?? null), "subReportDate" => ($context["subReportDate"] ?? null), "decimal" => ($context["decimal"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_monthly.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_monthly.html.twig", "/opt/kimai/templates/reporting/report_user_list_monthly.html.twig");
    }
}


/* reporting/report_user_list_monthly.html.twig */
class __TwigTemplate_482cfa519f5b9e168a960fe0d69af7aa___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'period_name' => [$this, 'block_period_name'],
            'total_rate_user' => [$this, 'block_total_rate_user'],
            'total_internal_rate_user' => [$this, 'block_total_internal_rate_user'],
            'total_duration_user' => [$this, 'block_total_duration_user'],
            'rate' => [$this, 'block_rate'],
            'internal_rate' => [$this, 'block_internal_rate'],
            'duration' => [$this, 'block_duration'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "reporting/user_list_period_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/user_list_period_data.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "            <th class=\"text-center text-nowrap\">
                <a href=\"";
        // line 7
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_monthly_users", ["date" => $this->extensions['App\Twig\Extensions']->formatReportDate(($context["column"] ?? null)), "sumType" => ($context["dataType"] ?? null)]), "html", null, true);
        yield "\">
                    ";
        // line 8
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(($context["column"] ?? null)), "html", null, true);
        yield "<br>
                    ";
        // line 9
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["column"] ?? null), "Y"), "html", null, true);
        yield "
                </a>
            </th>
        ";
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_year", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((CoreExtension::getAttribute($this->env, $this->source, ($context["subReportDate"] ?? null), "format", ["Y"], "method", false, false, false, 14) . "-01-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 14), "id", [], "any", false, false, false, 14)]), "html", null, true);
        yield "\">
                ";
        // line 15
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["usersTotalRate"] ?? null)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 19
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_year", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((CoreExtension::getAttribute($this->env, $this->source, ($context["subReportDate"] ?? null), "format", ["Y"], "method", false, false, false, 19) . "-01-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 19), "id", [], "any", false, false, false, 19)]), "html", null, true);
        yield "\">
                ";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["usersTotalInternalRate"] ?? null)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_year", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((CoreExtension::getAttribute($this->env, $this->source, ($context["subReportDate"] ?? null), "format", ["Y"], "method", false, false, false, 24) . "-01-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 24), "id", [], "any", false, false, false, 24)]), "html", null, true);
        yield "\">
                ";
        // line 25
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["usersTotalDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_month", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 29), "format", ["Y"], "method", false, false, false, 29) . "-") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 29), "format", ["m"], "method", false, false, false, 29)) . "-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 29), "id", [], "any", false, false, false, 29)]), "html", null, true);
        yield "\" data-toggle=\"tooltip\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
        yield ": ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "billableDuration", [], "any", false, false, false, 29), ($context["decimal"] ?? null)), "html", null, true);
        yield "\">
                ";
        // line 30
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalRate", [], "any", false, false, false, 30)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_month", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 34), "format", ["Y"], "method", false, false, false, 34) . "-") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 34), "format", ["m"], "method", false, false, false, 34)) . "-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 34), "id", [], "any", false, false, false, 34)]), "html", null, true);
        yield "\" data-toggle=\"tooltip\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
        yield ": ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "billableDuration", [], "any", false, false, false, 34), ($context["decimal"] ?? null)), "html", null, true);
        yield "\">
                ";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalInternalRate", [], "any", false, false, false, 35)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_user_month", ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate($this->extensions['App\Twig\LocaleFormatExtensions']->createDate((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 39), "format", ["Y"], "method", false, false, false, 39) . "-") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 39), "format", ["m"], "method", false, false, false, 39)) . "-01"))), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 39), "id", [], "any", false, false, false, 39)]), "html", null, true);
        yield "\" data-toggle=\"tooltip\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
        yield ": ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "billableDuration", [], "any", false, false, false, 39), ($context["decimal"] ?? null)), "html", null, true);
        yield "\">
                ";
        // line 40
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalDuration", [], "any", false, false, false, 40), ($context["decimal"] ?? null)), "html", null, true);
        yield "
            </a>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_monthly.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  285 => 40,  276 => 39,  269 => 38,  261 => 35,  252 => 34,  245 => 33,  237 => 30,  228 => 29,  221 => 28,  213 => 25,  208 => 24,  201 => 23,  193 => 20,  188 => 19,  181 => 18,  173 => 15,  168 => 14,  161 => 13,  152 => 9,  148 => 8,  144 => 7,  141 => 6,  134 => 5,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_monthly.html.twig", "/opt/kimai/templates/reporting/report_user_list_monthly.html.twig");
    }
}
