<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* favorite/index.html.twig */
class __TwigTemplate_ea2b7922423fbf6fd4d93ee2dc889a27 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["favorites"] = $this->env->getRuntime('App\Twig\Runtime\TimesheetExtension')->favoriteEntries(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 1), 10);
        // line 2
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["favorites"] ?? null)) > 0)) {
            // line 3
            yield "    ";
            $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
            // line 4
            yield "    <div class=\"list-group list-group-flush list-group-hoverable menu\">
        ";
            // line 5
            $context["counter"] = 0;
            // line 6
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["favorites"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["favorite"]) {
                // line 7
                yield "            ";
                $context["entry"] = CoreExtension::getAttribute($this->env, $this->source, $context["favorite"], "getTimesheet", [], "method", false, false, false, 7);
                // line 8
                yield "            ";
                if (((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("start", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["counter"] ?? null) < 7))) {
                    // line 9
                    yield "                ";
                    $context["counter"] = (($context["counter"] ?? null) + 1);
                    // line 10
                    yield "                <div class=\"list-group-item\">
                    <div class=\"row align-items-center\">
                        <div class=\"col text-truncate\" >
                            <a class=\"api-link text-decoration-none text-body d-block\" href=\"#\" data-href=\"";
                    // line 13
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("restart_timesheet", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 13)]), "html", null, true);
                    yield "\"
                               data-event=\"kimai.timesheetStart kimai.timesheetUpdate\" data-method=\"PATCH\" data-msg-error=\"timesheet.start.error\"
                               data-msg-success=\"timesheet.start.success\" data-bs-dismiss=\"modal\">
                                ";
                    // line 16
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_label_activity", $context, 16, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 16)]);
                    yield "
                                <div class=\"d-block text-truncate\">
                                    ";
                    // line 18
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_label_project", $context, 18, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 18)]);
                    yield "
                                    ";
                    // line 19
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_label_customer", $context, 19, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 19), "customer", [], "any", false, false, false, 19)]);
                    yield "
                                </div>
                            </a>
                        </div>
                        <div class=\"col-auto\">
                            ";
                    // line 24
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["favorite"], "isFavorite", [], "method", false, false, false, 24)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 25
                        yield "                            <a href=\"#\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_favorite_timesheet", ["id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["favorite"], "timesheet", [], "any", false, false, false, 25), "id", [], "any", false, false, false, 25)]), "html", null, true);
                        yield "\"
                               data-method=\"DELETE\" data-event=\"kimai.favoriteUpdate\" data-msg-error=\"action.delete.error\"
                               class=\"list-group-item-actions show api-link\">
                                <i class=\"text-yellow ";
                        // line 28
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("bookmarked"), "html", null, true);
                        yield "\"></i>
                            </a>
                            ";
                    } else {
                        // line 31
                        yield "                            <a href=\"#\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post_favorite_timesheet", ["id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["favorite"], "timesheet", [], "any", false, false, false, 31), "id", [], "any", false, false, false, 31)]), "html", null, true);
                        yield "\"
                               data-method=\"POST\" data-event=\"kimai.favoriteUpdate\" data-msg-error=\"action.update.error\"
                               class=\"list-group-item-actions api-link\">
                                ";
                        // line 34
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("bookmark");
                        yield "
                            </a>
                            ";
                    }
                    // line 37
                    yield "                        </div>
                    </div>
                </div>
            ";
                }
                // line 41
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['favorite'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 42
            yield "    </div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "favorite/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  138 => 42,  131 => 41,  125 => 37,  119 => 34,  112 => 31,  106 => 28,  99 => 25,  97 => 24,  89 => 19,  85 => 18,  80 => 16,  74 => 13,  69 => 10,  66 => 9,  63 => 8,  60 => 7,  55 => 6,  53 => 5,  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "favorite/index.html.twig", "/opt/kimai/templates/favorite/index.html.twig");
    }
}
