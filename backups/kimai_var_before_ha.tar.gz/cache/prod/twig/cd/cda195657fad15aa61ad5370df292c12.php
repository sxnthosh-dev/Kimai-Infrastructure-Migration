<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* dashboard/grid.html.twig */
class __TwigTemplate_5718bac4bb0a6a0f251a7c4f616c5688 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_class' => [$this, 'block_page_class'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "dashboard";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    ";
        yield from $this->yieldParentBlock("stylesheets", $context, $blocks);
        yield "
    ";
        // line 8
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("chart");
        yield "
    ";
        // line 9
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("dashboard");
        yield "
";
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        yield from $this->yieldParentBlock("head", $context, $blocks);
        yield "
    ";
        // line 14
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("chart");
        yield "
    ";
        // line 15
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("dashboard");
        yield "
";
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 19
        yield "
    ";
        // line 20
        if (Twig\Extension\CoreExtension::testEmpty(($context["widgets"] ?? null))) {
            // line 21
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_nothing_found", $context, 21, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
    ";
        } else {
            // line 23
            yield "        ";
            if (array_key_exists("form", $context)) {
                // line 24
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 24, $this->getSourceContext())->macro_alert(...["warning", "dashboard.edit_mode"]);
                yield "

            ";
                // line 26
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["style" => "display: none", "id" => "dashboard-widgets"]]);
                yield "
            ";
                // line 27
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
                yield "
        ";
            }
            // line 29
            yield "
        <div class=\"grid-stack\" id=\"dashboard-grid-container\" style=\"visibility: hidden\">
            ";
            // line 31
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["widgets"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["widget"]) {
                // line 32
                yield "                ";
                $context["gridWidth"] = CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "width", [], "any", false, false, false, 32);
                // line 33
                yield "                ";
                $context["gridHeight"] = CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "height", [], "any", false, false, false, 33);
                // line 34
                yield "                ";
                $context["widgetWidth"] = (($context["gridWidth"] ?? null) * 100);
                // line 35
                yield "                ";
                $context["widgetHeight"] = (($context["gridHeight"] ?? null) * 72);
                // line 36
                yield "                ";
                if ((($context["gridHeight"] ?? null) == 1)) {
                    // line 37
                    yield "                    ";
                    $context["widgetHeight"] = (($context["widgetHeight"] ?? null) - 67);
                    // line 38
                    yield "                ";
                } elseif ((($context["gridHeight"] ?? null) == 3)) {
                    // line 39
                    yield "                    ";
                    $context["widgetHeight"] = ($context["widgetHeight"] ?? null);
                    // line 40
                    yield "                ";
                } elseif ((($context["gridHeight"] ?? null) == 5)) {
                    // line 41
                    yield "                    ";
                    $context["widgetHeight"] = (($context["widgetHeight"] ?? null) - 10);
                    // line 42
                    yield "                ";
                } elseif ((($context["gridHeight"] ?? null) == 7)) {
                    // line 43
                    yield "                    ";
                    $context["widgetHeight"] = (($context["widgetHeight"] ?? null) - 10);
                    // line 44
                    yield "                ";
                }
                // line 45
                yield "                <div class=\"grid-stack-item\" data-widget=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "id", [], "any", false, false, false, 45), "html", null, true);
                yield "\" gs-w=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["gridWidth"] ?? null), "html", null, true);
                yield "\" gs-min-w=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["gridWidth"] ?? null), "html", null, true);
                yield "\" gs-h=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["gridHeight"] ?? null), "html", null, true);
                yield "\" gs-id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "id", [], "any", false, false, false, 45), "html", null, true);
                yield "\" id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "id", [], "any", false, false, false, 45), "html", null, true);
                yield "\">
                    <div class=\"grid-stack-item-content\">
                        <div class=\"card\">
                            <div class=\"card-header\">
                                <h3 class=\"card-title\">";
                // line 49
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "title", [], "any", false, false, false, 49), [], CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "translationDomain", [], "any", false, false, false, 49)), "html", null, true);
                yield "</h3>
                                <div class=\"card-actions\">
                                    ";
                // line 51
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "hasForm", [], "method", false, false, false, 51)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 52
                    yield "                                        ";
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_card_tool_button", $context, 52, $this->getSourceContext())->macro_card_tool_button(...["configuration", ["title" => "settings", "class" => "modal-ajax-form", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tasks_create")]]);
                    yield "
                                    ";
                }
                // line 54
                yield "                                    ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_card_tool_button", $context, 54, $this->getSourceContext())->macro_card_tool_button(...["delete", ["title" => "widget_remove", "url" => "#", "onclick" => (("removeWidget(this, \x27" . CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "id", [], "any", false, false, false, 54)) . "\x27); return false;")]]);
                yield "
                                </div>
                            </div>
                            <div class=\"card-body p-0\">
                                <svg xmlns=\"http://www.w3.org/2000/svg\" class=\"w-100\" preserveAspectRatio=\"none\" width=\"";
                // line 58
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetWidth"] ?? null), "html", null, true);
                yield "\" height=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetHeight"] ?? null), "html", null, true);
                yield "\" viewBox=\"0 0 ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetWidth"] ?? null), "html", null, true);
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetHeight"] ?? null), "html", null, true);
                yield "\" stroke=\"var(--tblr-border-color, #b8cef1)\">
                                    <line x1=\"0\" y1=\"0\" x2=\"";
                // line 59
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetWidth"] ?? null), "html", null, true);
                yield "\" y2=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetHeight"] ?? null), "html", null, true);
                yield "\"></line>
                                    <line x1=\"0\" y1=\"";
                // line 60
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetHeight"] ?? null), "html", null, true);
                yield "\" x2=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widgetWidth"] ?? null), "html", null, true);
                yield "\" y2=\"0\"></line>
                                </svg>
                            </div>
                        </div>
                    </div>
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['widget'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 67
            yield "        </div>
    ";
        }
        // line 69
        yield "
";
        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script>
        let grid = null;

        function resizeGrid() {
            let width = document.body.clientWidth;
            if (width < 576) {
                grid.column(1);
            } else if (width < 992) {
                grid.column(2);
            } else if (width) {
                grid.column(4);
            }
        }

        window.addEventListener(\x27resize\x27, function() {
            resizeGrid();
        });

        ";
        // line 92
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["widgets"] ?? null)) > 0)) {
            // line 93
            yield "        document.addEventListener(\x27kimai.initialized\x27, function() {
            grid = GridStack.init({
                \x27float\x27: false,
                \x27cellHeight\x27: 84,
                \x27disableResize\x27: true,
                \x27column\x27: 4,
                \x27marginTop\x27: 0,
                \x27marginBottom\x27: 0,
                \x27marginLeft\x27: 5,
                \x27marginRight\x27: 5,
                \x27disableOneColumnMode\x27: true,
                ";
            // line 104
            if ( !array_key_exists("form", $context)) {
                // line 105
                yield "                \x27staticGrid\x27: true,
                ";
            }
            // line 107
            yield "            });

            resizeGrid();

            document.dispatchEvent(new Event(\x27dashboard.initialized\x27));
            document.getElementById(\x27dashboard-grid-container\x27).style.visibility = \x27visible\x27;
        });
        ";
        }
        // line 115
        yield "
        ";
        // line 116
        if (array_key_exists("form", $context)) {
            // line 117
            yield "        function removeWidget(button, widgetId)
        {
            ";
            // line 120
            yield "            const id = button.attributes[\x27aria-describedBy\x27].value;
            const tooltip = document.getElementById(id);
            if (tooltip !== null) {
                tooltip.remove();
            }

            const widget = document.querySelector(\x27div[data-widget=\x27 + widgetId + \x27]\x27);
            if (widget !== null) {
                grid.removeWidget(widget);
            }
        }

        function saveDashboard()
        {
            let serializedData = grid.save();
            const choice = document.getElementById(\x27form_widgets\x27);
            const values = [];
            const newChoices = [];

            for (let item of serializedData) {
                values.push(item.id);
                for (let i = 0; i < choice.options.length; i++) {
                    if (choice.options[i].value === item.id) {
                        choice.options[i].selected = true;
                        newChoices.push(choice.options[i]);
                        break;
                    }
                }
            }

            choice.options.length = 0;
            newChoices.forEach(child => choice.appendChild(child));
            choice.dispatchEvent(new Event(\x27change\x27));

            document.getElementById(\x27dashboard-widgets\x27).submit();
        }
        ";
        }
        // line 157
        yield "
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.dashboardUpdate\x27, true);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "dashboard/grid.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  389 => 157,  350 => 120,  346 => 117,  344 => 116,  341 => 115,  331 => 107,  327 => 105,  325 => 104,  312 => 93,  310 => 92,  287 => 73,  280 => 72,  274 => 69,  270 => 67,  254 => 60,  248 => 59,  238 => 58,  230 => 54,  224 => 52,  222 => 51,  217 => 49,  199 => 45,  196 => 44,  193 => 43,  190 => 42,  187 => 41,  184 => 40,  181 => 39,  178 => 38,  175 => 37,  172 => 36,  169 => 35,  166 => 34,  163 => 33,  160 => 32,  156 => 31,  152 => 29,  147 => 27,  143 => 26,  137 => 24,  134 => 23,  128 => 21,  126 => 20,  123 => 19,  116 => 18,  109 => 15,  105 => 14,  100 => 13,  93 => 12,  86 => 9,  82 => 8,  77 => 7,  70 => 6,  59 => 4,  54 => 1,  52 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "dashboard/grid.html.twig", "/opt/kimai/templates/dashboard/grid.html.twig");
    }
}
