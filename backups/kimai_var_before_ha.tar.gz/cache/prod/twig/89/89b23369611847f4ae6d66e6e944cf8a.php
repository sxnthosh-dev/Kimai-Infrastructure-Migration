<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* partials/recent-activities.html.twig */
class __TwigTemplate_d9688938f8d0a805590ae72893cd852d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("start_own_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 2
            yield "    <div class=\"nav-item d-flex me-1 recent-activities\">
        <a href=\"";
            // line 3
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("favorites_timesheets");
            yield "\" class=\"btn btn-icon px-0 remote-modal-load recent-activities-btn\" data-modal-class=\"p-0\" data-modal-title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("recent.activities"), "html", null, true);
            yield "\" tabindex=\"-1\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("recent.activities"), "html", null, true);
            yield "\">
            ";
            // line 4
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("repeat", true);
            yield "
        </a>
    </div>
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            // the favorite buttons live inside the modal and change the list they are rendered in,
            // so the modal content is re-fetched after the API call succeeded
            document.addEventListener(\x27kimai.favoriteUpdate\x27, function() {
                const button = document.querySelector(\x27a.recent-activities-btn\x27);
                if (button !== null) {
                    button.click();
                }
            });
        });
    </script>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "partials/recent-activities.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  56 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "partials/recent-activities.html.twig", "/opt/kimai/templates/partials/recent-activities.html.twig");
    }
}
