<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/form.html.twig */
class __TwigTemplate_cc2778725f1386ba865b1b1e028f3b8c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'profile_content' => [$this, 'block_profile_content'],
            'form_header' => [$this, 'block_form_header'],
            'form_body' => [$this, 'block_form_body'],
            'form_body_class' => [$this, 'block_form_body_class'],
            'form_pre_content' => [$this, 'block_form_pre_content'],
            'form_content' => [$this, 'block_form_content'],
            'form_post_content' => [$this, 'block_form_post_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("user/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_profile_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "
    <div class=\"card\">
        <div class=\"card-header\">
            ";
        // line 7
        yield from $this->unwrap()->yieldBlock('form_header', $context, $blocks);
        // line 18
        yield "        </div>
        ";
        // line 19
        yield from $this->unwrap()->yieldBlock('form_body', $context, $blocks);
        // line 34
        yield "    </div>

";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "            <ul class=\"nav nav-pills card-header-pills\" data-bs-toggle=\"tabs\">
                ";
        // line 9
        $macros["actions"] = $this->load("user/actions.html.twig", 9)->unwrap();
        // line 10
        yield "                ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 10), "user_forms", ($context["tab"] ?? null), ["user" => ($context["user"] ?? null)]);
        // line 11
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 11));
        foreach ($context['_seq'] as $context["name"] => $context["settings"]) {
            // line 12
            yield "                    <li class=\"nav-item\" role=\"presentation\">
                        <a href=\"";
            // line 13
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "url", [], "any", false, false, false, 13), "html", null, true);
            yield "\" class=\"nav-link";
            if ((($context["tab"] ?? null) == $context["name"])) {
                yield " active";
            }
            yield "\" role=\"tab\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "title", [], "any", false, false, false, 13), [], (((CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "translation_domain", [], "any", true, true, false, 13) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "translation_domain", [], "any", false, false, false, 13)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "translation_domain", [], "any", false, false, false, 13)) : ("messages"))), "html", null, true);
            yield "</a>
                    </li>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['settings'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 16
        yield "            </ul>
            ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "        ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield "
        <div class=\"card-body ";
        // line 21
        yield from $this->unwrap()->yieldBlock('form_body_class', $context, $blocks);
        yield "\">
            ";
        // line 22
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
            ";
        // line 23
        yield from $this->unwrap()->yieldBlock('form_pre_content', $context, $blocks);
        // line 24
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_content', $context, $blocks);
        // line 27
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_post_content', $context, $blocks);
        // line 28
        yield "        </div>
        <div class=\"card-footer\">
            <input type=\"submit\" value=\"";
        // line 30
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
        yield "\" class=\"btn btn-primary\" />
        </div>
        ";
        // line 32
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
        ";
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_pre_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "                ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        yield "
            ";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_post_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/form.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  208 => 27,  200 => 25,  193 => 24,  183 => 23,  173 => 21,  166 => 32,  161 => 30,  157 => 28,  154 => 27,  151 => 24,  149 => 23,  145 => 22,  141 => 21,  136 => 20,  129 => 19,  123 => 16,  107 => 13,  104 => 12,  99 => 11,  96 => 10,  94 => 9,  91 => 8,  84 => 7,  77 => 34,  75 => 19,  72 => 18,  70 => 7,  65 => 4,  58 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/form.html.twig", "/opt/kimai/templates/user/form.html.twig");
    }
}
