<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* embeds/rates-table.html.twig */
class __TwigTemplate_5d163e4c165e1ec089bf7387d80c2de8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("embeds/rates-table.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => ($context["id"] ?? null), "entity" => ($context["entity"] ?? null), "create_url" => ($context["create_url"] ?? null), "delete_route" => ($context["delete_route"] ?? null), "currency" => ($context["currency"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/rates-table.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/rates-table.html.twig", "/opt/kimai/templates/embeds/rates-table.html.twig");
    }
}


/* embeds/rates-table.html.twig */
class __TwigTemplate_5d163e4c165e1ec089bf7387d80c2de8___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_title' => [$this, 'block_box_title'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
        yield "\"";
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rates.title"), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "        ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 8, $this->getSourceContext())->macro_card_tool_button(...["create", ["class" => "modal-ajax-form open-edit", "title" => "create", "url" => ($context["create_url"] ?? null)]]);
        yield "
    ";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["rates"] ?? null))) {
            yield "p-0";
        }
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        ";
        if (Twig\Extension\CoreExtension::testEmpty(($context["rates"] ?? null))) {
            // line 13
            yield "            <div class=\"comment\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rates.empty"), "html", null, true);
            yield "</div>
        ";
        } else {
            // line 15
            yield "            <table class=\"table dataTable\">
                <thead>
                <tr>
                    <th>
                        ";
            // line 19
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
            yield "
                    </th>
                    <th class=\"text-end\">
                        ";
            // line 22
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate"), "html", null, true);
            yield "
                    </th>
                    <th class=\"d-none d-sm-table-cell text-end\">
                        ";
            // line 25
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate"), "html", null, true);
            yield "
                    </th>
                    <th class=\"text-center\">
                        ";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("fixedRate"), "html", null, true);
            yield "
                    </th>
                    <th class=\"actions\"></th>
                </tr>
                </thead>
                <tbody>
                ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["rates"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["rate"]) {
                // line 35
                yield "                    <tr class=\"modal-ajax-form open-edit\" data-href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["edit_route"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "id", [], "any", false, false, false, 35), "rate" => CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "id", [], "any", false, false, false, 35)]), "html", null, true);
                yield "\">
                        <td>
                            ";
                // line 37
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "user", [], "any", false, false, false, 37))) {
                    // line 38
                    yield "                                ";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 38, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "user", [], "any", false, false, false, 38)]);
                    yield "
                            ";
                } else {
                    // line 40
                    yield "                                &ndash;
                            ";
                }
                // line 42
                yield "                        </td>
                        <td class=\"text-end\">
                            ";
                // line 44
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "rate", [], "any", false, false, false, 44), ($context["currency"] ?? null)), "html", null, true);
                yield "
                        </td>
                        <td class=\"d-none d-sm-table-cell text-end\">
                            ";
                // line 47
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "internalRate", [], "any", false, false, false, 47))) {
                    // line 48
                    yield "                                ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "internalRate", [], "any", false, false, false, 48), ($context["currency"] ?? null)), "html", null, true);
                    yield "
                            ";
                } else {
                    // line 50
                    yield "                                &ndash;
                            ";
                }
                // line 52
                yield "                        </td>
                        <td class=\"text-center\">
                            ";
                // line 54
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 54, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "fixed", [], "any", false, false, false, 54)]);
                yield "
                        </td>
                        <td class=\"actions\">
                            <div class=\"btn-group\">
                                <a href=\"";
                // line 58
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["edit_route"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "id", [], "any", false, false, false, 58), "rate" => CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "id", [], "any", false, false, false, 58)]), "html", null, true);
                yield "\" class=\"modal-ajax-form btn btn-icon\">";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("edit", true);
                yield "</a>
                                <a href=\"#\" data-href=\"";
                // line 59
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["delete_route"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "id", [], "any", false, false, false, 59), "rateId" => CoreExtension::getAttribute($this->env, $this->source, $context["rate"], "id", [], "any", false, false, false, 59)]), "html", null, true);
                yield "\" class=\"btn btn-icon api-link\" data-question=\"confirm.delete\" data-event=\"kimai.rateUpdate kimai.rateDelete\" data-method=\"DELETE\" data-msg-error=\"action.delete.error\">";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("delete", true);
                yield "</a>
                            </div>
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['rate'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 64
            yield "                </tbody>
            </table>
        ";
        }
        // line 67
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/rates-table.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  303 => 67,  298 => 64,  284 => 59,  278 => 58,  271 => 54,  267 => 52,  263 => 50,  257 => 48,  255 => 47,  249 => 44,  245 => 42,  241 => 40,  235 => 38,  233 => 37,  227 => 35,  223 => 34,  214 => 28,  208 => 25,  202 => 22,  196 => 19,  190 => 15,  184 => 13,  181 => 12,  174 => 11,  161 => 10,  153 => 8,  146 => 7,  138 => 5,  131 => 4,  118 => 3,  113 => 1,  111 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/rates-table.html.twig", "/opt/kimai/templates/embeds/rates-table.html.twig");
    }
}
