<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/renderer/default.pdf.twig */
class __TwigTemplate_80fab35c7a74139a6162dffd0409781c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v0 = ($context["invoice"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["invoice.language"] ?? null) : null), "html", null, true);
        yield "\">
<head>
    <meta charset=\"utf-8\">
    <title>";
        // line 5
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v1 = ($context["invoice"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["invoice.number"] ?? null) : null), "html", null, true);
        yield "-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $this->extensions['Twig\Extra\String\StringExtension']->createUnicodeString(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default((($_v2 = ($context["invoice"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["customer.company"] ?? null) : null), (($_v3 = ($context["invoice"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["customer.name"] ?? null) : null))) : ((($_v4 = ($context["invoice"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["customer.name"] ?? null) : null)))), "snake", [], "any", false, false, false, 5), "html", null, true);
        yield "</title>
    <style>
        ";
        // line 7
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("invoice-pdf");
        yield "
    </style>
</head>
<body>
<!--mpdf
<htmlpageheader name=\"header\">
    <table class=\"header\">
        <tr>
            <td class=\"title\">
                ";
        // line 16
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v5 = ($context["invoice"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["template.title"] ?? null) : null), "html", null, true);
        yield "
            </td>
            <td class=\"date text-right\">
                ";
        // line 19
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield ": ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v6 = ($context["invoice"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["invoice.date"] ?? null) : null), "html", null, true);
        yield "
            </td>
        </tr>
    </table>
</htmlpageheader>
<sethtmlpageheader name=\"header\" page=\"ALL\" value=\"on\" show-this-page=\"1\" />
<htmlpagefooter name=\"footer\">
    <table class=\"footer\">
        <tr>
            <td>
                <strong>";
        // line 29
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("contact"), "html", null, true);
        yield "</strong>:
                ";
        // line 30
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v7 = ($context["invoice"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["template.contact"] ?? null) : null), "html", null, true), " – ");
        yield "
                <br>
                <strong>";
        // line 32
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice_bank_account"), "html", null, true);
        yield "</strong>:
                ";
        // line 33
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v8 = ($context["invoice"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["template.payment_details"] ?? null) : null), "html", null, true), " – ");
        yield "
            </td>
            <td align=\"right\">
                ";
        // line 36
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.page_of", ["%page%" => "{PAGENO}", "%pages%" => "{nb}"]), "html", null, true);
        yield "
            </td>
        </tr>
    </table>
</htmlpagefooter>
<sethtmlpagefooter page=\"ALL\" value=\"on\" name=\"footer\" show-this-page=\"1\" />
mpdf-->
    <table class=\"addresses\">
        <tr>
            <td style=\"width:60%\">
                ";
        // line 46
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.to"), "html", null, true);
        yield "
                <br>
                <strong>";
        // line 48
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 48)) ? (Twig\Extension\CoreExtension::default((($_v9 = ($context["invoice"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["customer.company"] ?? null) : null), (($_v10 = ($context["invoice"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["customer.name"] ?? null) : null))) : ((($_v11 = ($context["invoice"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["customer.name"] ?? null) : null))), "html", null, true);
        yield "</strong>
                <br>
                ";
        // line 50
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v12 = ($context["invoice"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["customer.address"] ?? null) : null), "html", null, true));
        yield "
                ";
        // line 51
        $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v13 = ($context["invoice"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["customer.country"] ?? null) : null), (($_v14 = ($context["invoice"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["invoice.language"] ?? null) : null));
        // line 52
        yield "                ";
        if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v15 = ($context["invoice"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["customer.address"] ?? null) : null))) {
            // line 53
            yield "                    <br> ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
            yield "
                ";
        }
        // line 55
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v16 = ($context["invoice"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["customer.vat_id"] ?? null) : null))) {
            // line 56
            yield "                    <br>
                    ";
            // line 57
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v17 = ($context["invoice"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["customer.vat_id"] ?? null) : null), "html", null, true);
            yield "
                ";
        }
        // line 59
        yield "            </td>
            <td>
                ";
        // line 61
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.from"), "html", null, true);
        yield "
                <br>
                <strong>";
        // line 63
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v18 = ($context["invoice"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["template.company"] ?? null) : null), "html", null, true);
        yield "</strong>
                <br>
                ";
        // line 65
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::trim((($_v19 = ($context["invoice"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["template.address"] ?? null) : null)), "html", null, true));
        yield "
                ";
        // line 66
        if ( !(null === (($_v20 = ($context["invoice"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20["template.country"] ?? null) : null))) {
            // line 67
            yield "                    ";
            $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v21 = ($context["invoice"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21["template.country"] ?? null) : null), (($_v22 = ($context["invoice"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22["invoice.language"] ?? null) : null));
            // line 68
            yield "                    ";
            if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v23 = ($context["invoice"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23["template.address"] ?? null) : null))) {
                // line 69
                yield "                        <br> ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
                yield "
                    ";
            }
            // line 71
            yield "                ";
        }
        // line 72
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v24 = ($context["invoice"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24["template.vat_id"] ?? null) : null))) {
            // line 73
            yield "                    <br>
                    ";
            // line 74
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ":
                    ";
            // line 75
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v25 = ($context["invoice"] ?? null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25["template.vat_id"] ?? null) : null), "html", null, true);
            yield "
                ";
        }
        // line 77
        yield "            </td>
        </tr>
    </table>

    <p>
        ";
        // line 82
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.number"), "html", null, true);
        yield ":
        ";
        // line 83
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v26 = ($context["invoice"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26["invoice.number"] ?? null) : null), "html", null, true);
        yield "

        <br>
        ";
        // line 86
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.due_days"), "html", null, true);
        yield ":
        ";
        // line 87
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v27 = ($context["invoice"] ?? null)) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27["invoice.due_date"] ?? null) : null), "html", null, true);
        yield "

        ";
        // line 89
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v28 = ($context["invoice"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28["customer.number"] ?? null) : null))) {
            // line 90
            yield "            <br>
            ";
            // line 91
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("number"), "html", null, true);
            yield ":
            ";
            // line 92
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v29 = ($context["invoice"] ?? null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29["customer.number"] ?? null) : null), "html", null, true);
            yield "
        ";
        }
        // line 94
        yield "
        ";
        // line 95
        if ((((($_v30 = ($context["invoice"] ?? null)) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30["project.counter"] ?? null) : null) == 1) &&  !Twig\Extension\CoreExtension::testEmpty((($_v31 = ($context["invoice"] ?? null)) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["project.order_number"] ?? null) : null)))) {
            // line 96
            yield "            <br>
            ";
            // line 97
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderNumber"), "html", null, true);
            yield ":
            ";
            // line 98
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v32 = ($context["invoice"] ?? null)) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["project.order_number"] ?? null) : null), "html", null, true);
            yield "
        ";
        }
        // line 100
        yield "    </p>

    ";
        // line 102
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v33 = ($context["invoice"] ?? null)) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["customer.invoice_text"] ?? null) : null))) {
            // line 103
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v34 = ($context["invoice"] ?? null)) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["customer.invoice_text"] ?? null) : null));
            yield "
    ";
        }
        // line 105
        yield "
    ";
        // line 106
        if ((((($_v35 = ($context["invoice"] ?? null)) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["project.counter"] ?? null) : null) == 1) &&  !Twig\Extension\CoreExtension::testEmpty((($_v36 = ($context["invoice"] ?? null)) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["project.invoice_text"] ?? null) : null)))) {
            // line 107
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v37 = ($context["invoice"] ?? null)) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["project.invoice_text"] ?? null) : null));
            yield "
    ";
        }
        // line 109
        yield "
    <table class=\"items\">
        <thead>
            <tr>
                <th class=\"first\"><strong>";
        // line 113
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</strong></th>
                <th><strong>";
        // line 114
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("description"), "html", null, true);
        yield "</strong></th>
                <th class=\"text-right\"><strong>";
        // line 115
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("unit_price"), "html", null, true);
        yield "</strong></th>
                <th class=\"text-right\"><strong>";
        // line 116
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("amount"), "html", null, true);
        yield "</strong></th>
                <th class=\"last text-right\"><strong>";
        // line 117
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("total_rate"), "html", null, true);
        yield "</strong></th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 121
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["invoiceLineItem"]) {
            // line 122
            yield "            <!-- CONTENT_PART -->
            <tr>
                <td nowrap class=\"first text-nowrap\">";
            // line 124
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v38 = $context["invoiceLineItem"]) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["entry.begin"] ?? null) : null), "html", null, true);
            yield "</td>
                <td>
                    ";
            // line 126
            if ( !Twig\Extension\CoreExtension::testEmpty((($_v39 = $context["invoiceLineItem"]) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39["entry.description"] ?? null) : null))) {
                // line 127
                yield "                        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v40 = $context["invoiceLineItem"]) && is_array($_v40) || $_v40 instanceof ArrayAccess ? ($_v40["entry.description"] ?? null) : null), "html", null, true));
                yield "
                    ";
            } else {
                // line 129
                yield "                        ";
                if (CoreExtension::getAttribute($this->env, $this->source, $context["invoiceLineItem"], "entry.activity", [], "array", true, true, false, 129)) {
                    // line 130
                    yield "                            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v41 = $context["invoiceLineItem"]) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41["entry.activity"] ?? null) : null), "html", null, true);
                    yield " /
                        ";
                }
                // line 132
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v42 = $context["invoiceLineItem"]) && is_array($_v42) || $_v42 instanceof ArrayAccess ? ($_v42["entry.project"] ?? null) : null), "html", null, true);
                yield "
                    ";
            }
            // line 134
            yield "                </td>
                <td nowrap class=\"text-nowrap text-right\">";
            // line 135
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v43 = $context["invoiceLineItem"]) && is_array($_v43) || $_v43 instanceof ArrayAccess ? ($_v43["entry.rate"] ?? null) : null), "html", null, true);
            yield "</td>
                <td nowrap class=\"text-nowrap text-right\">";
            // line 136
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v44 = $context["invoiceLineItem"]) && is_array($_v44) || $_v44 instanceof ArrayAccess ? ($_v44["entry.amount"] ?? null) : null), "html", null, true);
            yield "</td>
                <td nowrap class=\"last text-nowrap text-right\">";
            // line 137
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v45 = $context["invoiceLineItem"]) && is_array($_v45) || $_v45 instanceof ArrayAccess ? ($_v45["entry.total"] ?? null) : null), "html", null, true);
            yield "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['invoiceLineItem'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 140
        yield "        </tbody>
        <tfoot>
            <tr>
                <td colspan=\"4\" class=\"text-right\">
                    ";
        // line 144
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.subtotal"), "html", null, true);
        yield "
                </td>
                <td class=\"last text-right\">";
        // line 146
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v46 = ($context["invoice"] ?? null)) && is_array($_v46) || $_v46 instanceof ArrayAccess ? ($_v46["invoice.subtotal"] ?? null) : null), "html", null, true);
        yield "</td>
            </tr>
            ";
        // line 148
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v47 = ($context["invoice"] ?? null)) && is_array($_v47) || $_v47 instanceof ArrayAccess ? ($_v47["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 149
            yield "                ";
            if ((($tmp = (($_v48 = $context["taxRow"]) && is_array($_v48) || $_v48 instanceof ArrayAccess ? ($_v48["show"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 150
                yield "                <tr>
                    <td colspan=\"4\" class=\"text-right\">
                        ";
                // line 152
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v49 = $context["taxRow"]) && is_array($_v49) || $_v49 instanceof ArrayAccess ? ($_v49["name"] ?? null) : null)), "html", null, true);
                yield " (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v50 = $context["taxRow"]) && is_array($_v50) || $_v50 instanceof ArrayAccess ? ($_v50["rate"] ?? null) : null), "html", null, true);
                yield "%)
                        ";
                // line 153
                if ( !(null === (($_v51 = $context["taxRow"]) && is_array($_v51) || $_v51 instanceof ArrayAccess ? ($_v51["note"] ?? null) : null))) {
                    // line 154
                    yield "                            <sup>[";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v52 = $context["taxRow"]) && is_array($_v52) || $_v52 instanceof ArrayAccess ? ($_v52["counter"] ?? null) : null), "html", null, true);
                    yield "]</sup>
                        ";
                }
                // line 156
                yield "                    </td>
                    <td class=\"last text-right\">";
                // line 157
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v53 = $context["taxRow"]) && is_array($_v53) || $_v53 instanceof ArrayAccess ? ($_v53["amount"] ?? null) : null), (($_v54 = $context["taxRow"]) && is_array($_v54) || $_v54 instanceof ArrayAccess ? ($_v54["currency"] ?? null) : null)), "html", null, true);
                yield "</td>
                </tr>
                ";
            }
            // line 160
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 161
        yield "            <tr>
                <td colspan=\"4\" class=\"text-right text-nowrap\">
                    <strong>";
        // line 163
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.total"), "html", null, true);
        yield "</strong>
                </td>
                <td class=\"last text-right\">
                    <strong>";
        // line 166
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v55 = ($context["invoice"] ?? null)) && is_array($_v55) || $_v55 instanceof ArrayAccess ? ($_v55["invoice.total"] ?? null) : null), "html", null, true);
        yield "</strong>
                </td>
            </tr>
        </tfoot>
    </table>

    ";
        // line 172
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v56 = ($context["invoice"] ?? null)) && is_array($_v56) || $_v56 instanceof ArrayAccess ? ($_v56["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 173
            yield "        ";
            if ( !(null === (($_v57 = $context["taxRow"]) && is_array($_v57) || $_v57 instanceof ArrayAccess ? ($_v57["note"] ?? null) : null))) {
                // line 174
                yield "            <p>
                <sup>[";
                // line 175
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v58 = $context["taxRow"]) && is_array($_v58) || $_v58 instanceof ArrayAccess ? ($_v58["counter"] ?? null) : null), "html", null, true);
                yield "]</sup>
                ";
                // line 176
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v59 = $context["taxRow"]) && is_array($_v59) || $_v59 instanceof ArrayAccess ? ($_v59["note"] ?? null) : null)), "html", null, true);
                yield "
            </p>
        ";
            }
            // line 179
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 180
        yield "
    ";
        // line 181
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v60 = ($context["invoice"] ?? null)) && is_array($_v60) || $_v60 instanceof ArrayAccess ? ($_v60["template.payment_terms"] ?? null) : null))) {
            // line 182
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v61 = ($context["invoice"] ?? null)) && is_array($_v61) || $_v61 instanceof ArrayAccess ? ($_v61["template.payment_terms"] ?? null) : null));
            yield "
    ";
        }
        // line 184
        yield "</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/renderer/default.pdf.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  492 => 184,  486 => 182,  484 => 181,  481 => 180,  474 => 179,  468 => 176,  464 => 175,  461 => 174,  458 => 173,  454 => 172,  445 => 166,  439 => 163,  435 => 161,  428 => 160,  422 => 157,  419 => 156,  413 => 154,  411 => 153,  405 => 152,  401 => 150,  398 => 149,  394 => 148,  389 => 146,  384 => 144,  378 => 140,  368 => 137,  364 => 136,  360 => 135,  357 => 134,  351 => 132,  345 => 130,  342 => 129,  336 => 127,  334 => 126,  329 => 124,  325 => 122,  321 => 121,  314 => 117,  310 => 116,  306 => 115,  302 => 114,  298 => 113,  292 => 109,  286 => 107,  284 => 106,  281 => 105,  275 => 103,  273 => 102,  269 => 100,  264 => 98,  260 => 97,  257 => 96,  255 => 95,  252 => 94,  247 => 92,  243 => 91,  240 => 90,  238 => 89,  233 => 87,  229 => 86,  223 => 83,  219 => 82,  212 => 77,  207 => 75,  203 => 74,  200 => 73,  197 => 72,  194 => 71,  188 => 69,  185 => 68,  182 => 67,  180 => 66,  176 => 65,  171 => 63,  166 => 61,  162 => 59,  155 => 57,  152 => 56,  149 => 55,  143 => 53,  140 => 52,  138 => 51,  134 => 50,  129 => 48,  124 => 46,  111 => 36,  105 => 33,  101 => 32,  96 => 30,  92 => 29,  77 => 19,  71 => 16,  59 => 7,  52 => 5,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/renderer/default.pdf.twig", "/opt/kimai/templates/invoice/renderer/default.pdf.twig");
    }
}
