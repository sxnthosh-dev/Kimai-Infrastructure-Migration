<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/utils.html.twig */
class __TwigTemplate_31e9bede869ba504fa70bcbce7f2586b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        yield "
";
        yield from [];
    }

    // line 3
    public function macro_attr_to_html($attr = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "attr" => $attr,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 4
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["attr"] ?? null))) {
                // line 5
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["attr"] ?? null));
                foreach ($context['_seq'] as $context["name"] => $context["value"]) {
                    yield " ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
                    yield "=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html_attr");
                    yield "\"";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/utils.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  63 => 5,  61 => 4,  49 => 3,  43 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/utils.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/utils.html.twig");
    }
}
