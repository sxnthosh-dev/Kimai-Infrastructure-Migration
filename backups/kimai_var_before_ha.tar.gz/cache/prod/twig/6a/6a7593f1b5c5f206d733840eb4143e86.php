<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/create.html.twig */
class __TwigTemplate_37e61a3a48a5091f605586dc01921244 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create"), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user")];
        // line 10
        yield "    ";
        yield from $this->load("user/create.html.twig", 10, 1)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/create.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 10,  64 => 7,  62 => 5,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/create.html.twig", "/opt/kimai/templates/user/create.html.twig");
    }
}


/* user/create.html.twig */
class __TwigTemplate_37e61a3a48a5091f605586dc01921244___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 14
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "username", [], "any", false, false, false, 14), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 17
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 17), 'row');
        yield "
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 23
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "plainPassword", [], "any", false, false, false, 23), "first", [], "any", false, false, false, 23), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 26
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "plainPassword", [], "any", false, false, false, 26), "second", [], "any", false, false, false, 26), 'row');
        yield "
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 32
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "alias", [], "any", false, false, false, 32), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 35
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 35), 'row');
        yield "
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-md";
        // line 40
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "avatar", [], "any", true, true, false, 40)) {
            yield "-6";
        }
        yield "\">
                    ";
        // line 41
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "color", [], "any", false, false, false, 41), 'row');
        yield "
                </div>
                ";
        // line 43
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "avatar", [], "any", true, true, false, 43)) {
            // line 44
            yield "                <div class=\"col-md-6\">
                    ";
            // line 45
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "avatar", [], "any", false, false, false, 45), 'row');
            yield "
                </div>
                ";
        }
        // line 48
        yield "            </div>

            ";
        // line 50
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "language", [], "any", true, true, false, 50) && CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timezone", [], "any", true, true, false, 50))) {
            // line 51
            yield "            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
            // line 53
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "language", [], "any", false, false, false, 53), 'row');
            yield "
                </div>
                <div class=\"col-md-6\">
                    ";
            // line 56
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timezone", [], "any", false, false, false, 56), 'row');
            yield "
                </div>
            </div>
            ";
        }
        // line 60
        yield "
            ";
        // line 61
        $context["length"] = 12;
        // line 62
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "supervisor", [], "any", true, true, false, 62)) {
            // line 63
            yield "                ";
            $context["length"] = 6;
            // line 64
            yield "            ";
        }
        // line 65
        yield "
            <div class=\"row\">
                <div class=\"col-md-";
        // line 67
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["length"] ?? null), "html", null, true);
        yield "\">
                    ";
        // line 68
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "accountNumber", [], "any", false, false, false, 68), 'row');
        yield "
                </div>
                ";
        // line 70
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "supervisor", [], "any", true, true, false, 70)) {
            // line 71
            yield "                <div class=\"col-md-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["length"] ?? null), "html", null, true);
            yield "\">
                    ";
            // line 72
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "supervisor", [], "any", false, false, false, 72), 'row');
            yield "
                </div>
                ";
        }
        // line 75
        yield "            </div>

            ";
        // line 77
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 77) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "roles", [], "any", true, true, false, 77))) {
            // line 78
            yield "                ";
            $context["length"] = 12;
            // line 79
            yield "                ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 79) && CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "roles", [], "any", true, true, false, 79))) {
                // line 80
                yield "                    ";
                $context["length"] = 6;
                // line 81
                yield "                ";
            }
            // line 82
            yield "                <div class=\"row\">
                    ";
            // line 83
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 83)) {
                // line 84
                yield "                    <div class=\"col-md-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["length"] ?? null), "html", null, true);
                yield "\">
                        ";
                // line 85
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 85), 'row');
                yield "
                    </div>
                    ";
            }
            // line 88
            yield "                    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "roles", [], "any", true, true, false, 88)) {
                // line 89
                yield "                    <div class=\"col-md-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["length"] ?? null), "html", null, true);
                yield "\">
                        ";
                // line 90
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "roles", [], "any", false, false, false, 90), 'row');
                yield "
                    </div>
                    ";
            }
            // line 93
            yield "                </div>
            ";
        }
        // line 95
        yield "
            ";
        // line 96
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/create.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  329 => 96,  326 => 95,  322 => 93,  316 => 90,  311 => 89,  308 => 88,  302 => 85,  297 => 84,  295 => 83,  292 => 82,  289 => 81,  286 => 80,  283 => 79,  280 => 78,  278 => 77,  274 => 75,  268 => 72,  263 => 71,  261 => 70,  256 => 68,  252 => 67,  248 => 65,  245 => 64,  242 => 63,  239 => 62,  237 => 61,  234 => 60,  227 => 56,  221 => 53,  217 => 51,  215 => 50,  211 => 48,  205 => 45,  202 => 44,  200 => 43,  195 => 41,  189 => 40,  181 => 35,  175 => 32,  166 => 26,  160 => 23,  151 => 17,  145 => 14,  141 => 12,  134 => 11,  66 => 10,  64 => 7,  62 => 5,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/create.html.twig", "/opt/kimai/templates/user/create.html.twig");
    }
}
