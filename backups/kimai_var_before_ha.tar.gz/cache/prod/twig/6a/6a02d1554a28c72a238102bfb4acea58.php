<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/print.html.twig */
class __TwigTemplate_bd23db8060d233784a071012637b5b7c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 2), "html", null, true);
        yield "\">
";
        // line 3
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/meta_fields.html.twig", 3)->unwrap();
        // line 4
        $context["storageItemName"] = "kimai_html_export";
        // line 5
        $context["decimal"] = ((array_key_exists("decimal", $context)) ? (Twig\Extension\CoreExtension::default(($context["decimal"] ?? null), false)) : (false));
        // line 6
        $context["columnTitles"] = [];
        // line 7
        $context["columns"] = ["date" => true, "begin" => false, "end" => false, "username" => false, "customer" => true, "project" => true, "activity" => true, "description" => false, "exported" => false, "tags" => false];
        // line 19
        yield "
";
        // line 20
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["timesheetMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["field"]) {
            // line 21
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)("t_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 21)) => true]);
            // line 22
            yield "    ";
            $context["columnTitles"] = Twig\Extension\CoreExtension::merge(($context["columnTitles"] ?? null), [ (string)("t_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 22)) => CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 22)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["customerMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["field"]) {
            // line 25
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)("c_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 25)) => true]);
            // line 26
            yield "    ";
            $context["columnTitles"] = Twig\Extension\CoreExtension::merge(($context["columnTitles"] ?? null), [ (string)("c_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 26)) => CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 26)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["projectMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["field"]) {
            // line 29
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)("p_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 29)) => true]);
            // line 30
            yield "    ";
            $context["columnTitles"] = Twig\Extension\CoreExtension::merge(($context["columnTitles"] ?? null), [ (string)("p_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 30)) => CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 30)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["activityMetaFields"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["field"]) {
            // line 33
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)("a_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 33)) => true]);
            // line 34
            yield "    ";
            $context["columnTitles"] = Twig\Extension\CoreExtension::merge(($context["columnTitles"] ?? null), [ (string)("a_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 34)) => CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 34)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["userPreferences"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["field"]) {
            // line 37
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)("u_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 37)) => true]);
            // line 38
            yield "    ";
            $context["columnTitles"] = Twig\Extension\CoreExtension::merge(($context["columnTitles"] ?? null), [ (string)("u_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 38)) => CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 38)]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 40
        yield "
";
        // line 41
        $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["hourlyRate" => false, "fixedRate" => false, "duration" => "duration", "internalRate" => "internalRate", "rate" => "rate"]);
        // line 48
        yield "
";
        // line 49
        $context["formItemClass"] = "d-inline-block w-auto text-nowrap me-2";
        // line 50
        yield "<head>
    <meta charset=\"utf-8\">
    <meta content=\"width=device-width, initial-scale=1\" name=\"viewport\">
    ";
        // line 53
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app");
        yield "
    ";
        // line 54
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("app");
        yield "
    <title>";
        // line 55
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export"), "html", null, true);
        yield "</title>
    <style>
        @media print{
            h2 { font-size: 22px; }
            h3 { font-size: 18px; }
            p, td { font-size: 11px; }
            th, td.totals { font-size: 12px; }
        }
        .items td.totals {
            font-weight: bold;
            text-align: right;
        }
        .items td.duration,
        .items th.duration,
        .items th.cost,
        .items td.cost,
        .items th.column-rate,
        .items th.column-internalRate,
        .items th.column-hourlyRate,
        .items th.column-fixedRate,
        .items th.column-duration {
            text-align: right;
        }
        .items th.column-exported {
            text-align: center;
        }
        .table>thead:first-child>tr:first-child>th {
            padding-right: 5px;
        }
    </style>
</head>
<body class=\"pad export_print\">
    <div class=\"wrapper\">
        <section class=\"export\">

            <form class=\"w-100 d-print-none row row-cards p-3\">
                <div class=\"card mb-1 p-0\">
                    <div class=\"card-header\">
                        ";
        // line 93
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("settings"), "html", null, true);
        yield "
                    </div>
                    <div class=\"card-body\">
                        <label for=\"duration-decimal\">
                            <input type=\"checkbox\" id=\"duration-decimal\" name=\"duration-decimal\"";
        // line 97
        if ((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " checked=\"checked\"";
        }
        yield ">
                            ";
        // line 98
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export_decimal"), "html", null, true);
        yield "
                        </label>
                        |
                        <label for=\"date-format\">
                            ";
        // line 102
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield ":
                            ";
        // line 103
        $context["demo_date"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate("2024-01-01 11:00:00");
        // line 104
        yield "                            <select id=\"date-format\" name=\"date-format\">
                                <option value=\"short\">";
        // line 105
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                                <option value=\"time\">";
        // line 106
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                            </select>
                        </label>
                        |
                        <label for=\"begin-format\">
                            ";
        // line 111
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("begin"), "html", null, true);
        yield ":
                            ";
        // line 112
        $context["demo_date"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate("2024-01-01 11:00:00");
        // line 113
        yield "                            <select id=\"begin-format\" name=\"begin-format\">
                                <option value=\"plain\">";
        // line 114
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["demo_date"] ?? null), "H:i"), "html", null, true);
        yield "</option>
                                <option value=\"short\">";
        // line 115
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                                <option value=\"time\">";
        // line 116
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                            </select>
                        </label>
                        |
                        <label for=\"end-format\">
                            ";
        // line 121
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("end"), "html", null, true);
        yield ":
                            ";
        // line 122
        $context["demo_date"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate("2024-01-01 18:00:00");
        // line 123
        yield "                            <select id=\"end-format\" name=\"end-format\">
                                <option value=\"plain\">";
        // line 124
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["demo_date"] ?? null), "H:i"), "html", null, true);
        yield "</option>
                                <option value=\"short\">";
        // line 125
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                                <option value=\"time\">";
        // line 126
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["demo_date"] ?? null)), "html", null, true);
        yield "</option>
                            </select>
                        </label>
                        <button type=\"reset\" class=\"btn btn-primary btn-sm pull-right\" onclick=\"resetExport()\">";
        // line 129
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.reset"), "html", null, true);
        yield "</button>
                    </div>
                </div>

                <div class=\"card mb-1 p-0\">
                    <div class=\"card-header\">
                        <label for=\"summary-show\">
                            <input type=\"checkbox\" id=\"summary-show\" name=\"summary-show\" checked=\"checked\">
                            ";
        // line 137
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
        yield "
                        </label>
                    </div>
                    <div class=\"card-body w-100\">
                        <div class=\"";
        // line 141
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-by-activities\">
                                <input type=\"checkbox\" id=\"summary-by-activities\" name=\"summary-by-activities\">
                                ";
        // line 144
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
        yield "
                            </label>
                        </div>
                        <div class=\"";
        // line 147
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-timeBudget\">
                                <input type=\"checkbox\" id=\"summary-timeBudget\" name=\"summary-timeBudget\" checked>
                                ";
        // line 150
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
        yield "
                            </label>
                        </div>
                        <div class=\"";
        // line 153
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-budget\">
                                <input type=\"checkbox\" id=\"summary-budget\" name=\"summary-budget\" checked>
                                ";
        // line 156
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
        yield "
                            </label>
                        </div>

                        <div class=\"";
        // line 160
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-duration\">
                                <input type=\"checkbox\" id=\"summary-duration\" name=\"summary-duration\" checked>
                                ";
        // line 163
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "
                            </label>
                        </div>
                        <div class=\"";
        // line 166
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-internalRate\">
                                <input type=\"checkbox\" id=\"summary-internalRate\" name=\"summary-internalRate\" checked>
                                ";
        // line 169
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate"), "html", null, true);
        yield "
                            </label>
                        </div>
                        <div class=\"";
        // line 172
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"summary-rate\">
                                <input type=\"checkbox\" id=\"summary-rate\" name=\"summary-rate\" checked>
                                ";
        // line 175
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rate"), "html", null, true);
        yield "
                            </label>
                        </div>
                    </div>
                </div>

                <div class=\"card mb-1 p-0\">
                    <div class=\"card-header\">
                        <div class=\"";
        // line 183
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
        yield "\">
                            <label for=\"records-show\">
                                <input type=\"checkbox\" id=\"records-show\" name=\"records-show\" checked=\"checked\">
                                ";
        // line 186
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.full_list"), "html", null, true);
        yield "
                            </label>
                        </div>
                    </div>
                    <div class=\"card-body\">
                        ";
        // line 191
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["columnId"] => $context["visibility"]) {
            // line 192
            yield "                            <div class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formItemClass"] ?? null), "html", null, true);
            yield "\">
                                <label for=\"records-column-";
            // line 193
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["columnId"], "html", null, true);
            yield "\">
                                    <input type=\"checkbox\" class=\"column-visibility-changer\" id=\"records-column-";
            // line 194
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["columnId"], "html", null, true);
            yield "\" name=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["columnId"], "html", null, true);
            yield "\" ";
            if ((($tmp = $context["visibility"]) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "checked=\"checked\"";
            }
            yield ">
                                    ";
            // line 195
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((CoreExtension::getAttribute($this->env, $this->source, ($context["columnTitles"] ?? null), $context["columnId"], [], "array", true, true, false, 195)) ? (Twig\Extension\CoreExtension::default((($_v1 = ($context["columnTitles"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1[(($_v2 = $context["columnId"]) instanceof \Stringable ? (string) $_v2 : $_v2)] ?? null) : null), $context["columnId"])) : ($context["columnId"]))), "html", null, true);
            yield "
                                </label>
                            </div>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['columnId'], $context['visibility'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 199
        yield "                    </div>
                </div>
            </form>

            <div class=\"row m-3\">
                <div class=\"col-xs-12\">
                    <h2 id=\"doc-title\" contenteditable=\"true\" data-original=\"";
        // line 205
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.document_title"), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.document_title"), "html", null, true);
        yield "</h2>
                    <p>
                        ";
        // line 207
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.period"), "html", null, true);
        yield ":
                        ";
        // line 208
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "begin", [], "any", false, false, false, 208)), "html", null, true);
        yield " - ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "end", [], "any", false, false, false, 208)), "html", null, true);
        yield "
                    </p>
                </div>
            </div>

            <div class=\"row m-3\" id=\"export-summary\">
                <div class=\"card p-0\">
                    <div class=\"card-header\">
                        <h3 class=\"card-title\" id=\"doc-summary\" contenteditable=\"true\" data-original=\"";
        // line 216
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
        yield "</h3>
                    </div>
                    <table class=\"items table table-sm table-bordered dataTable\" id=\"summary-project\">
                        <thead>
                        <tr>
                            <th>";
        // line 221
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                            <th>";
        // line 222
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
        yield "</th>
                            <th class=\"center export-timeBudget\">";
        // line 223
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
        yield "</th>
                            <th class=\"center export-budget\">";
        // line 224
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
        yield "</th>
                            <th class=\"duration summary-duration\">";
        // line 225
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
                            <th class=\"cost summary-internalRate\">";
        // line 226
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate"), "html", null, true);
        yield "</th>
                            <th class=\"cost summary-rate\">";
        // line 227
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rate"), "html", null, true);
        yield "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 231
        $context["customer"] = null;
        // line 232
        yield "                        ";
        $context["customerDuration"] = 0;
        // line 233
        yield "                        ";
        $context["customerRate"] = 0;
        // line 234
        yield "                        ";
        $context["customerInternalRate"] = 0;
        // line 235
        yield "                        ";
        $context["customerCurrency"] = null;
        // line 236
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["summaries"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["summary"]) {
            // line 237
            yield "                            ";
            if ((($context["customer"] ?? null) === null)) {
                // line 238
                yield "                                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 238);
                // line 239
                yield "                                ";
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 239);
                // line 240
                yield "                            ";
            }
            // line 241
            yield "                            ";
            if ( !(($context["customer"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 241))) {
                // line 242
                yield "                                ";
                $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), false);
                // line 243
                yield "                                ";
                $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true);
                // line 244
                yield "                                <tr class=\"summary\">
                                    <td colspan=\"2\">&nbsp;</td>
                                    <td class=\"export-timeBudget\"></td>
                                    <td class=\"export-budget\"></td>
                                    <td class=\"totals duration summary-duration\">
                                        <span class=\"duration-format\" data-duration-decimal=\"";
                // line 249
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
                yield "\" data-duration=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
                yield "\">";
                yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
                yield "</span>
                                    </td>
                                    <td class=\"totals cost summary-internalRate\">";
                // line 251
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "</td>
                                    <td class=\"totals cost summary-rate\">";
                // line 252
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "</td>
                                </tr>
                                ";
                // line 254
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 254);
                // line 255
                yield "                                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 255);
                // line 256
                yield "                                ";
                $context["customerDuration"] = 0;
                // line 257
                yield "                                ";
                $context["customerRate"] = 0;
                // line 258
                yield "                                ";
                $context["customerInternalRate"] = 0;
                // line 259
                yield "                            ";
            }
            // line 260
            yield "                            <tr>
                                <td>";
            // line 261
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 261), "html", null, true);
            yield "</td>
                                <td>";
            // line 262
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "project", [], "any", false, false, false, 262), "html", null, true);
            yield "</td>
                                <td class=\"center export-timeBudget\">
                                    ";
            // line 264
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 264) && (CoreExtension::getAttribute($this->env, $this->source, (($_v3 = ($context["budgets"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[(($_v4 = $context["id"]) instanceof \Stringable ? (string) $_v4 : $_v4)] ?? null) : null), "time_left", [], "any", false, false, false, 264) > 0))) {
                // line 265
                yield "                                        ";
                $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v5 = ($context["budgets"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[(($_v6 = $context["id"]) instanceof \Stringable ? (string) $_v6 : $_v6)] ?? null) : null), "time_left", [], "any", false, false, false, 265), false);
                // line 266
                yield "                                        ";
                $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v7 = ($context["budgets"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[(($_v8 = $context["id"]) instanceof \Stringable ? (string) $_v8 : $_v8)] ?? null) : null), "time_left", [], "any", false, false, false, 266), true);
                // line 267
                yield "                                        <span class=\"duration-format\" data-duration-decimal=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
                yield "\" data-duration=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
                yield "\">";
                yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
                yield "</span>
                                    ";
            }
            // line 269
            yield "                                </td>
                                <td class=\"center export-budget\">
                                    ";
            // line 271
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 271) && (CoreExtension::getAttribute($this->env, $this->source, (($_v9 = ($context["budgets"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[(($_v10 = $context["id"]) instanceof \Stringable ? (string) $_v10 : $_v10)] ?? null) : null), "money_left", [], "any", false, false, false, 271) > 0))) {
                // line 272
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, (($_v11 = ($context["budgets"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11[(($_v12 = $context["id"]) instanceof \Stringable ? (string) $_v12 : $_v12)] ?? null) : null), "money_left", [], "any", false, false, false, 272), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 272)), "html", null, true);
                yield "
                                    ";
            }
            // line 274
            yield "                                </td>
                                <td class=\"duration summary-duration\">
                                    ";
            // line 276
            $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 276), false);
            // line 277
            yield "                                    ";
            $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 277), true);
            // line 278
            yield "                                    <span class=\"duration-format\" data-duration-decimal=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
            yield "\" data-duration=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
            yield "\">";
            yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
            yield "</span>
                                </td>
                                <td class=\"cost summary-internalRate\">";
            // line 280
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 280), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 280)), "html", null, true);
            yield "</td>
                                <td class=\"cost summary-rate\">";
            // line 281
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 281), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 281)), "html", null, true);
            yield "</td>
                            </tr>
                            ";
            // line 283
            $context["customerDuration"] = (($context["customerDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 283));
            // line 284
            yield "                            ";
            $context["customerRate"] = (($context["customerRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 284));
            // line 285
            yield "                            ";
            $context["customerInternalRate"] = (($context["customerInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 285));
            // line 286
            yield "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['summary'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 287
        yield "                        ";
        if ( !(($context["customer"] ?? null) === null)) {
            // line 288
            yield "                            ";
            $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), false);
            // line 289
            yield "                            ";
            $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true);
            // line 290
            yield "                            <tr class=\"summary\">
                                <td colspan=\"2\">&nbsp;</td>
                                <td class=\"export-timeBudget\"></td>
                                <td class=\"export-budget\"></td>
                                <td class=\"totals duration summary-duration\">
                                    <span class=\"duration-format\" data-duration-decimal=\"";
            // line 295
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
            yield "\" data-duration=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
            yield "\">";
            yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
            yield "</span>
                                </td>
                                <td class=\"totals cost summary-internalRate\">";
            // line 297
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
            yield "</td>
                                <td class=\"totals cost summary-rate\">";
            // line 298
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
            yield "</td>
                            </tr>
                        ";
        }
        // line 301
        yield "                        </tbody>
                    </table>

                    ";
        // line 309
        yield "
                    <table class=\"items table table-sm table-bordered dataTable\" id=\"summary-activity\" style=\"display:none\">
                        <thead>
                        <tr>
                            <th>";
        // line 313
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                            <th>";
        // line 314
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
        yield "</th>
                            <th>";
        // line 315
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
        yield "</th>
                            <th class=\"center export-timeBudget\">";
        // line 316
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
        yield "</th>
                            <th class=\"center export-budget\">";
        // line 317
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
        yield "</th>
                            <th class=\"duration summary-duration\">";
        // line 318
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
                            <th class=\"cost summary-internalRate\">";
        // line 319
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate"), "html", null, true);
        yield "</th>
                            <th class=\"cost summary-rate\">";
        // line 320
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rate"), "html", null, true);
        yield "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 324
        $context["customer"] = null;
        // line 325
        yield "                        ";
        $context["customerDuration"] = 0;
        // line 326
        yield "                        ";
        $context["customerRate"] = 0;
        // line 327
        yield "                        ";
        $context["customerInternalRate"] = 0;
        // line 328
        yield "                        ";
        $context["customerCurrency"] = null;
        // line 329
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["summaries"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["summary"]) {
            // line 330
            yield "                            ";
            if ((($context["customer"] ?? null) === null)) {
                // line 331
                yield "                                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 331);
                // line 332
                yield "                                ";
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 332);
                // line 333
                yield "                            ";
            }
            // line 334
            yield "                            ";
            if ( !(($context["customer"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 334))) {
                // line 335
                yield "                                <tr class=\"summary\">
                                    <td colspan=\"3\"></td>
                                    <td class=\"export-timeBudget\"></td>
                                    <td class=\"export-budget\"></td>
                                    <td class=\"totals duration summary-duration\">
                                        ";
                // line 340
                $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), false);
                // line 341
                yield "                                        ";
                $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true);
                // line 342
                yield "                                        <span class=\"duration-format\" data-duration-decimal=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
                yield "\" data-duration=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
                yield "\">";
                yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
                yield "</span>
                                    </td>
                                    <td class=\"totals cost summary-internalRate\">";
                // line 344
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "</td>
                                    <td class=\"totals cost summary-rate\">";
                // line 345
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "</td>
                                </tr>
                                ";
                // line 347
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 347);
                // line 348
                yield "                                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 348);
                // line 349
                yield "                                ";
                $context["customerDuration"] = 0;
                // line 350
                yield "                                ";
                $context["customerRate"] = 0;
                // line 351
                yield "                                ";
                $context["customerInternalRate"] = 0;
                // line 352
                yield "                            ";
            }
            // line 353
            yield "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "activities", [], "any", false, false, false, 353));
            foreach ($context['_seq'] as $context["activityId"] => $context["activitySummary"]) {
                // line 354
                yield "                                <tr>
                                    <td>";
                // line 355
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 355), "html", null, true);
                yield "</td>
                                    <td>";
                // line 356
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "project", [], "any", false, false, false, 356), "html", null, true);
                yield "</td>
                                    <td>";
                // line 357
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "activity", [], "any", false, false, false, 357), "html", null, true);
                yield "</td>
                                    ";
                // line 358
                if ((CoreExtension::getAttribute($this->env, $this->source, ($context["activity_budgets"] ?? null), $context["id"], [], "array", true, true, false, 358) && CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity_budgets"] ?? null), $context["id"], [], "array", false, true, false, 358), $context["activityId"], [], "array", true, true, false, 358))) {
                    // line 359
                    yield "                                        <td class=\"center export-timeBudget\">
                                            ";
                    // line 360
                    if ((CoreExtension::getAttribute($this->env, $this->source, (($_v13 = (($_v14 = ($context["activity_budgets"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[(($_v15 = $context["id"]) instanceof \Stringable ? (string) $_v15 : $_v15)] ?? null) : null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13[(($_v16 = $context["activityId"]) instanceof \Stringable ? (string) $_v16 : $_v16)] ?? null) : null), "time_left", [], "any", false, false, false, 360) > 0)) {
                        // line 361
                        yield "                                                ";
                        $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v17 = (($_v18 = ($context["activity_budgets"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[(($_v19 = $context["id"]) instanceof \Stringable ? (string) $_v19 : $_v19)] ?? null) : null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17[(($_v20 = $context["activityId"]) instanceof \Stringable ? (string) $_v20 : $_v20)] ?? null) : null), "time_left", [], "any", false, false, false, 361), false);
                        // line 362
                        yield "                                                ";
                        $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v21 = (($_v22 = ($context["activity_budgets"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22[(($_v23 = $context["id"]) instanceof \Stringable ? (string) $_v23 : $_v23)] ?? null) : null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21[(($_v24 = $context["activityId"]) instanceof \Stringable ? (string) $_v24 : $_v24)] ?? null) : null), "time_left", [], "any", false, false, false, 362), true);
                        // line 363
                        yield "                                                <span class=\"duration-format\" data-duration-decimal=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
                        yield "\" data-duration=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
                        yield "\">";
                        yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
                        yield "</span>
                                            ";
                    }
                    // line 365
                    yield "                                        </td>
                                        <td class=\"center export-budget\">
                                            ";
                    // line 367
                    if ((CoreExtension::getAttribute($this->env, $this->source, (($_v25 = (($_v26 = ($context["activity_budgets"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26[(($_v27 = $context["id"]) instanceof \Stringable ? (string) $_v27 : $_v27)] ?? null) : null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25[(($_v28 = $context["activityId"]) instanceof \Stringable ? (string) $_v28 : $_v28)] ?? null) : null), "money_left", [], "any", false, false, false, 367) > 0)) {
                        // line 368
                        yield "                                                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, (($_v29 = (($_v30 = ($context["activity_budgets"] ?? null)) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30[(($_v31 = $context["id"]) instanceof \Stringable ? (string) $_v31 : $_v31)] ?? null) : null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29[(($_v32 = $context["activityId"]) instanceof \Stringable ? (string) $_v32 : $_v32)] ?? null) : null), "money_left", [], "any", false, false, false, 368), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 368)), "html", null, true);
                        yield "
                                            ";
                    }
                    // line 370
                    yield "                                        </td>
                                    ";
                } else {
                    // line 372
                    yield "                                        <td class=\"center export-timeBudget\"></td>
                                        <td class=\"center export-budget\"></td>
                                    ";
                }
                // line 375
                yield "                                    <td class=\"duration summary-duration\">
                                        ";
                // line 376
                $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "duration", [], "any", false, false, false, 376), false);
                // line 377
                yield "                                        ";
                $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "duration", [], "any", false, false, false, 377), true);
                // line 378
                yield "                                        <span class=\"duration-format\" data-duration-decimal=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
                yield "\" data-duration=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
                yield "\">";
                yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
                yield "</span>
                                    </td>
                                    <td class=\"cost summary-internalRate\">";
                // line 380
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "rate_internal", [], "any", false, false, false, 380), CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "currency", [], "any", false, false, false, 380)), "html", null, true);
                yield "</td>
                                    <td class=\"cost summary-rate\">";
                // line 381
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "rate", [], "any", false, false, false, 381), CoreExtension::getAttribute($this->env, $this->source, $context["activitySummary"], "currency", [], "any", false, false, false, 381)), "html", null, true);
                yield "</td>
                                </tr>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['activityId'], $context['activitySummary'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 384
            yield "                            ";
            $context["customerDuration"] = (($context["customerDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 384));
            // line 385
            yield "                            ";
            $context["customerRate"] = (($context["customerRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 385));
            // line 386
            yield "                            ";
            $context["customerInternalRate"] = (($context["customerInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 386));
            // line 387
            yield "                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['summary'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 388
        yield "                        ";
        if ( !(($context["customer"] ?? null) === null)) {
            // line 389
            yield "                            <tr class=\"summary\">
                                <td colspan=\"3\"></td>
                                <td class=\"export-timeBudget\"></td>
                                <td class=\"export-budget\"></td>
                                <td class=\"totals duration summary-duration\">
                                    ";
            // line 394
            $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), false);
            // line 395
            yield "                                    ";
            $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), true);
            // line 396
            yield "                                    <span class=\"duration-format\" data-duration-decimal=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
            yield "\" data-duration=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
            yield "\">";
            yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
            yield "</span>
                                </td>
                                <td class=\"totals cost summary-internalRate\">";
            // line 398
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
            yield "</td>
                                <td class=\"totals cost summary-rate\">";
            // line 399
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
            yield "</td>
                            </tr>
                        ";
        }
        // line 402
        yield "                        </tbody>
                    </table>
                </div>
            </div>

            <div class=\"row m-3\" id=\"export-records\">
                <div class=\"card p-0\">
                    <div class=\"card-header\">
                        <h3 class=\"card-title\" id=\"doc-records\" contenteditable=\"true\" data-original=\"";
        // line 410
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.full_list"), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.full_list"), "html", null, true);
        yield "</h3>
                    </div>
                    <table class=\"items table table-sm table-bordered dataTable\">
                        <thead>
                        <tr>
                            ";
        // line 415
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["columnId"] => $context["visibility"]) {
            // line 416
            yield "                                <th class=\"column column-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["columnId"], "html", null, true);
            yield "\" ";
            if ( !(($tmp = $context["visibility"]) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 417
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((CoreExtension::getAttribute($this->env, $this->source, ($context["columnTitles"] ?? null), $context["columnId"], [], "array", true, true, false, 417)) ? (Twig\Extension\CoreExtension::default((($_v33 = ($context["columnTitles"] ?? null)) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33[(($_v34 = $context["columnId"]) instanceof \Stringable ? (string) $_v34 : $_v34)] ?? null) : null), $context["columnId"])) : ($context["columnId"]))), "html", null, true);
            yield "
                                </th>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['columnId'], $context['visibility'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 420
        yield "                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 423
        $context["timeWorked"] = 0;
        // line 424
        yield "                        ";
        $context["rateTotal"] = 0;
        // line 425
        yield "                        ";
        $context["rateInternalTotal"] = 0;
        // line 426
        yield "                        ";
        $context["currency"] = false;
        // line 427
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 428
            yield "                            ";
            $context["timeWorked"] = (($context["timeWorked"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 428));
            // line 429
            yield "                            ";
            $context["rateTotal"] = (($context["rateTotal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 429));
            // line 430
            yield "                            ";
            if (CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", true, true, false, 430)) {
                // line 431
                yield "                                ";
                $context["rateInternalTotal"] = (($context["rateInternalTotal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 431));
                // line 432
                yield "                            ";
            } else {
                // line 433
                yield "                                ";
                $context["rateInternalTotal"] = (($context["rateInternalTotal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 433));
                // line 434
                yield "                            ";
            }
            // line 435
            yield "                            ";
            if ((($context["currency"] ?? null) === false)) {
                // line 436
                yield "                                ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 436), "customer", [], "any", false, false, false, 436), "currency", [], "any", false, false, false, 436);
                // line 437
                yield "                            ";
            }
            // line 438
            yield "                            ";
            if ( !(($context["currency"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 438), "customer", [], "any", false, false, false, 438), "currency", [], "any", false, false, false, 438))) {
                // line 439
                yield "                                ";
                $context["currency"] = null;
                // line 440
                yield "                            ";
            }
            // line 441
            yield "                            <tr>
                                <td class=\"column-date text-nowrap\" ";
            // line 442
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "date", [], "any", false, false, false, 442)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                        <span class=\"dateformat\" data-short=\"";
            // line 443
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 443)), "html", null, true);
            yield "\" data-full=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 443)), "html", null, true);
            yield "\" data-time=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 443)), "html", null, true);
            yield "\">
                                        ";
            // line 444
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 444)), "html", null, true);
            yield "
                                        </span>
                                </td>
                                <td class=\"column-begin text-nowrap\" ";
            // line 447
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "begin", [], "any", false, false, false, 447)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                        <span class=\"beginformat\" data-short=\"";
            // line 448
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 448)), "html", null, true);
            yield "\" data-full=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 448)), "html", null, true);
            yield "\" data-time=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 448)), "html", null, true);
            yield "\" data-plain=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 448), "H:i"), "html", null, true);
            yield "\">
                                        ";
            // line 449
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 449), "H:i"), "html", null, true);
            yield "
                                        </span>
                                </td>
                                <td class=\"column-end text-nowrap\" ";
            // line 452
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "end", [], "any", false, false, false, 452)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                        <span class=\"endformat\" data-short=\"";
            // line 453
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 453)), "html", null, true);
            yield "\" data-full=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 453)), "html", null, true);
            yield "\" data-time=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 453)), "html", null, true);
            yield "\" data-plain=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 453), "H:i"), "html", null, true);
            yield "\">
                                        ";
            // line 454
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 454), "H:i"), "html", null, true);
            yield "
                                        </span>
                                </td>
                                <td class=\"column-username\" ";
            // line 457
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "username", [], "any", false, false, false, 457)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 458
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 458), "displayName", [], "any", false, false, false, 458), "html", null, true);
            yield "
                                </td>
                                <td class=\"column-customer\" ";
            // line 460
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "customer", [], "any", false, false, false, 460)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 461
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 461), "customer", [], "any", false, false, false, 461), "name", [], "any", false, false, false, 461), "html", null, true);
            yield "
                                </td>
                                <td class=\"column-project\" ";
            // line 463
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "project", [], "any", false, false, false, 463)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 463), "name", [], "any", false, false, false, 463), "html", null, true);
            yield "
                                </td>
                                <td class=\"column-activity\" ";
            // line 465
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "activity", [], "any", false, false, false, 465)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 466
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 466))) {
                // line 467
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 467), "name", [], "any", false, false, false, 467), "html", null, true);
                yield "
                                    ";
            }
            // line 469
            yield "                                </td>
                                <td class=\"column-description\" ";
            // line 470
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "description", [], "any", false, false, false, 470)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 471
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 471))) {
                // line 472
                yield "                                        ";
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 472));
                yield "
                                    ";
            }
            // line 474
            yield "                                </td>
                                <td class=\"column-exported text-center\" ";
            // line 475
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "exported", [], "any", false, false, false, 475)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 476
            $context["export_class"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "exported", [], "any", false, false, false, 476)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("success") : ("default"));
            // line 477
            yield "                                    <span class=\"badge bg-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["export_class"] ?? null), "html", null, true);
            yield " text-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["export_class"] ?? null), "html", null, true);
            yield "-fg\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "exported", [], "any", false, false, false, 477)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("yes") : ("no"))), "html", null, true);
            yield "</span>
                                </td>
                                <td class=\"column-tags\" ";
            // line 479
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "tags", [], "any", false, false, false, 479)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 480
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "tags", [], "any", true, true, false, 480) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "tags", [], "any", false, false, false, 480)))) {
                // line 481
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "tagsAsArray", [], "any", false, false, false, 481), ", "), "html", null, true);
                yield "
                                    ";
            }
            // line 483
            yield "                                </td>
                                ";
            // line 484
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["timesheetMetaFields"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["field"]) {
                // line 485
                yield "                                    <td class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("t_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 485)), "html", null, true);
                yield " text-nowrap\" ";
                if ( !(($tmp = (($_v35 = ($context["columns"] ?? null)) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35[(($_v36 = ("t_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 485))) instanceof \Stringable ? (string) $_v36 : $_v36)] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield ">
                                        ";
                // line 486
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 486, $this->getSourceContext())->macro_meta_field_value(...[$context["entry"], $context["field"]]);
                yield "
                                    </td>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 489
            yield "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["customerMetaFields"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["field"]) {
                // line 490
                yield "                                    <td class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("c_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 490)), "html", null, true);
                yield " text-nowrap\" ";
                if ( !(($tmp = (($_v37 = ($context["columns"] ?? null)) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37[(($_v38 = ("c_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 490))) instanceof \Stringable ? (string) $_v38 : $_v38)] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield ">
                                        ";
                // line 491
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 491, $this->getSourceContext())->macro_meta_field_value(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 491), "customer", [], "any", false, false, false, 491), $context["field"]]);
                yield "
                                    </td>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 494
            yield "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["projectMetaFields"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["field"]) {
                // line 495
                yield "                                    <td class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("p_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 495)), "html", null, true);
                yield " text-nowrap\" ";
                if ( !(($tmp = (($_v39 = ($context["columns"] ?? null)) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39[(($_v40 = ("p_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 495))) instanceof \Stringable ? (string) $_v40 : $_v40)] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield ">
                                        ";
                // line 496
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 496, $this->getSourceContext())->macro_meta_field_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 496), $context["field"]]);
                yield "
                                    </td>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 499
            yield "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["activityMetaFields"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["field"]) {
                // line 500
                yield "                                    <td class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("a_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 500)), "html", null, true);
                yield " text-nowrap\" ";
                if ( !(($tmp = (($_v41 = ($context["columns"] ?? null)) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41[(($_v42 = ("a_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 500))) instanceof \Stringable ? (string) $_v42 : $_v42)] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield ">
                                        ";
                // line 501
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 501))) {
                    // line 502
                    yield "                                            ";
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 502, $this->getSourceContext())->macro_meta_field_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 502), $context["field"]]);
                    yield "
                                        ";
                }
                // line 504
                yield "                                    </td>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 506
            yield "                                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["userPreferences"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["field"]) {
                // line 507
                yield "                                    <td class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("u_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 507)), "html", null, true);
                yield " text-nowrap\" ";
                if ( !(($tmp = (($_v43 = ($context["columns"] ?? null)) && is_array($_v43) || $_v43 instanceof ArrayAccess ? ($_v43[(($_v44 = ("u_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 507))) instanceof \Stringable ? (string) $_v44 : $_v44)] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield ">
                                        ";
                // line 508
                $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 508), "preference", [CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 508)], "method", false, false, false, 508);
                // line 509
                yield "                                        ";
                if ((( !(null === ($context["metaField"] ?? null)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 509))) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 509)))) {
                    // line 510
                    yield "                                            ";
                    yield (string) $macros["_v0"]->getTemplateForMacro("macro_form_type_value", $context, 510, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["field"], "type", [], "any", false, false, false, 510), CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 510), CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 510)]);
                    yield "
                                        ";
                }
                // line 512
                yield "                                    </td>
                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 514
            yield "                                <td class=\"cost column-hourlyRate text-nowrap\" ";
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "hourlyRate", [], "any", false, false, false, 514)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 515
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 515), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 515), "customer", [], "any", false, false, false, 515), "currency", [], "any", false, false, false, 515)), "html", null, true);
            yield "
                                </td>
                                <td class=\"cost column-fixedRate text-nowrap\" ";
            // line 517
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "fixedRate", [], "any", false, false, false, 517)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 518
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 518), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 518), "customer", [], "any", false, false, false, 518), "currency", [], "any", false, false, false, 518)), "html", null, true);
            yield "
                                </td>
                                <td class=\"duration column-duration text-nowrap\" ";
            // line 520
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "duration", [], "any", false, false, false, 520)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 521
            $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 521), false);
            // line 522
            yield "                                    ";
            $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 522), true);
            // line 523
            yield "                                    <span class=\"duration-format\" data-duration-decimal=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
            yield "\" data-duration=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
            yield "\">";
            yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
            yield "</span>
                                </td>
                                <td class=\"cost column-internalRate text-nowrap\" ";
            // line 525
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "internalRate", [], "any", false, false, false, 525)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 526
            if (CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", true, true, false, 526)) {
                // line 527
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 527), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 527), "customer", [], "any", false, false, false, 527), "currency", [], "any", false, false, false, 527)), "html", null, true);
                yield "
                                    ";
            } else {
                // line 529
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 529), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 529), "customer", [], "any", false, false, false, 529), "currency", [], "any", false, false, false, 529)), "html", null, true);
                yield "
                                    ";
            }
            // line 531
            yield "                                </td>
                                <td class=\"cost column-rate text-nowrap\" ";
            // line 532
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["columns"] ?? null), "rate", [], "any", false, false, false, 532)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"display: none\"";
            }
            yield ">
                                    ";
            // line 533
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 533), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 533), "customer", [], "any", false, false, false, 533), "currency", [], "any", false, false, false, 533)), "html", null, true);
            yield "
                                </td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 537
        yield "                        ";
        // line 538
        yield "                        <tr>
                            ";
        // line 539
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["visibility"]) {
            // line 540
            yield "                                ";
            if (!CoreExtension::inFilter($context["id"], ["duration", "rate", "internalRate"])) {
                // line 541
                yield "                                    <th class=\"column-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["id"], "html", null, true);
                yield "\" ";
                if ( !(($tmp = $context["visibility"]) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "style=\"display: none\"";
                }
                yield "></th>
                                ";
            }
            // line 543
            yield "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['visibility'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 544
        yield "                            <th class=\"text-nowrap column-duration\">
                                ";
        // line 545
        $context["durationNormal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["timeWorked"] ?? null), false);
        // line 546
        yield "                                ";
        $context["durationDecimal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["timeWorked"] ?? null), true);
        // line 547
        yield "                                <span class=\"duration-format\" data-duration-decimal=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true);
        yield "\" data-duration=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true);
        yield "\">";
        yield (string) (((($tmp = ($context["decimal"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationDecimal"] ?? null), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["durationNormal"] ?? null), "html", null, true)));
        yield "</span>
                            </th>
                            <th class=\"text-nowrap column-internalRate\">";
        // line 550
        if (( !(null === ($context["currency"] ?? null)) &&  !(($context["currency"] ?? null) === false))) {
            // line 551
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateInternalTotal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
                                ";
        } else {
            // line 553
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateInternalTotal"] ?? null)), "html", null, true);
            yield "
                                ";
        }
        // line 555
        yield "</th>
                            <th class=\"text-nowrap column-rate\">";
        // line 557
        if (( !(null === ($context["currency"] ?? null)) &&  !(($context["currency"] ?? null) === false))) {
            // line 558
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateTotal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
                                ";
        } else {
            // line 560
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateTotal"] ?? null)), "html", null, true);
            yield "
                                ";
        }
        // line 562
        yield "</th>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </section>
    </div>

    <script type=\"text/javascript\">
        let initialized = false;

        document.getElementById(\x27duration-decimal\x27).addEventListener(\x27click\x27, function(event) {
            var spans = document.getElementsByClassName(\x27duration-format\x27);
            for (var span of spans) {
                if (!event.target.checked) {
                    if (span.dataset[\x27duration\x27] !== undefined) {
                        span.innerHTML = span.dataset[\x27duration\x27];
                    }
                } else {
                    if (span.dataset[\x27durationDecimal\x27] !== undefined) {
                        span.innerHTML = span.dataset[\x27durationDecimal\x27];
                    }
                }
            }
            saveVisibility();
        });

        document.getElementById(\x27summary-by-activities\x27).addEventListener(\x27click\x27, function(event) {
            document.getElementById(\x27summary-project\x27).style.display = event.target.checked ? \x27none\x27 : \x27table\x27;
            document.getElementById(\x27summary-activity\x27).style.display = event.target.checked ? \x27table\x27 : \x27none\x27;
            saveVisibility();
        });
        document.getElementById(\x27date-format\x27).addEventListener(\x27change\x27, function(event) {
            changedDateFormat(event.target.value, \x27dateformat\x27);
        });
        document.getElementById(\x27begin-format\x27).addEventListener(\x27change\x27, function(event) {
            changedDateFormat(event.target.value, \x27beginformat\x27);
        });
        document.getElementById(\x27end-format\x27).addEventListener(\x27change\x27, function(event) {
            changedDateFormat(event.target.value, \x27endformat\x27);
        });
        document.getElementById(\x27summary-show\x27).addEventListener(\x27click\x27, function(event) {
            document.getElementById(\x27export-summary\x27).style.display = event.target.checked ? \x27block\x27 : \x27none\x27;
            saveVisibility();
        });
        document.getElementById(\x27summary-timeBudget\x27).addEventListener(\x27click\x27, function(event) {
            let cells = document.getElementsByClassName(\x27export-timeBudget\x27);
            for (let columnCell of cells) {
                columnCell.style.display = event.target.checked ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        });
        document.getElementById(\x27summary-budget\x27).addEventListener(\x27click\x27, function(event) {
            let cells = document.getElementsByClassName(\x27export-budget\x27);
            for (let columnCell of cells) {
                columnCell.style.display = event.target.checked ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        });
        document.getElementById(\x27summary-duration\x27).addEventListener(\x27click\x27, function(event) {
            let cells = document.getElementsByClassName(\x27summary-duration\x27);
            for (let columnCell of cells) {
                columnCell.style.display = event.target.checked ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        });
        document.getElementById(\x27summary-rate\x27).addEventListener(\x27click\x27, function(event) {
            let cells = document.getElementsByClassName(\x27summary-rate\x27);
            for (let columnCell of cells) {
                columnCell.style.display = event.target.checked ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        });
        document.getElementById(\x27summary-internalRate\x27).addEventListener(\x27click\x27, function(event) {
            let cells = document.getElementsByClassName(\x27summary-internalRate\x27);
            for (let columnCell of cells) {
                columnCell.style.display = event.target.checked ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        });
        document.getElementById(\x27summary-show\x27).addEventListener(\x27click\x27, function(event) {
            document.getElementById(\x27export-summary\x27).style.display = event.target.checked ? \x27block\x27 : \x27none\x27;
            saveVisibility();
        });
        document.getElementById(\x27records-show\x27).addEventListener(\x27click\x27, function(event) {
            document.getElementById(\x27export-records\x27).style.display = event.target.checked ? \x27block\x27 : \x27none\x27;
            saveVisibility();
        });

        let columnCheckboxes = document.getElementsByClassName(\x27column-visibility-changer\x27);

        for (let checkbox of columnCheckboxes) {
            checkbox.addEventListener(\x27click\x27, function(event) {
                changeVisibility(event.target.name, event.target.checked);
            });
        }

        let editableTitles = document.querySelectorAll(\x27[contenteditable=true]\x27);

        for (let editable of editableTitles) {
            editable.addEventListener(\x27input\x27, function(event) {
                if (event.target.innerText === \x27\x27) {
                    return;
                }
                saveVisibility();
            });
        }

        // needs to be executed as last action in the flow, after the listener were registered
        let config = localStorage.getItem(\x27";
        // line 673
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["storageItemName"] ?? null), "html", null, true);
        yield "\x27);
        if (config !== null) {
            try {
                config = JSON.parse(config);
                for (const elName in config) {
                    if (!config.hasOwnProperty(elName)) {
                        continue;
                    }
                    let elValue = config[elName];
                    let el = document.getElementById(elName);
                    if (el === undefined || el === null) {
                        el = document.getElementById(\x27records-column-\x27 + elName);
                        if (el === undefined || el === null) {
                            continue;
                        }
                    }
                    if (el.type === \x27checkbox\x27) {
                        if (elValue !== el.checked) {
                            el.click();
                        }
                    } else if (el.type === \x27select-one\x27) {
                        if (el.value !== elValue) {
                            el.value = elValue;
                            el.dispatchEvent(new Event(\x27change\x27));
                        }
                    } else if (el.isContentEditable) {
                        el.innerText = elValue;
                    }
                }
            } catch (e) {
                // ignore error in restoring
                console.log(\x27Failed to restore settings, removing invalid settings\x27, e);
                localStorage.removeItem(\x27";
        // line 705
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["storageItemName"] ?? null), "html", null, true);
        yield "\x27);
            }
        }

        initialized = true;

        function changeVisibility(column, visible)
        {
            let cells = document.getElementsByClassName(\x27column-\x27 + column);
            for (let columnCell of cells) {
                columnCell.style.display = visible ? \x27table-cell\x27 : \x27none\x27;
            }
            saveVisibility();
        }

        function changedDateFormat(formatType, className)
        {
            let elements = document.getElementsByClassName(className);
            for (let elem of elements) {
                let formattedDate = elem.dataset[formatType];
                if (formattedDate === undefined) {
                    continue;
                }
                elem.innerHTML = formattedDate;
            }
            saveVisibility();
        }

        function saveVisibility()
        {
            if (!initialized) {
                return;
            }

            const form = document.getElementsByTagName(\x27form\x27)[0];
            let settings = {};
            for (let checkbox of form.querySelectorAll(\x27input[type=checkbox]\x27)) {
                settings[checkbox.getAttribute(\x27id\x27)] = checkbox.checked;
            }
            for (let selectbox of form.querySelectorAll(\x27select\x27)) {
                settings[selectbox.getAttribute(\x27id\x27)] = selectbox.value;
            }
            for (let editable of document.querySelectorAll(\x27[contenteditable=true]\x27)) {
                settings[editable.getAttribute(\x27id\x27)] = editable.innerText;
            }
            localStorage.setItem(\x27";
        // line 750
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["storageItemName"] ?? null), "html", null, true);
        yield "\x27, JSON.stringify(settings));
        }

        function resetExport()
        {
            let editableTitles = document.querySelectorAll(\x27[contenteditable=true]\x27);

            for (let editable of editableTitles) {
                editable.innerText = editable.dataset[\x27original\x27];
            }

            localStorage.removeItem(\x27";
        // line 761
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["storageItemName"] ?? null), "html", null, true);
        yield "\x27);
            const form = document.getElementsByTagName(\x27form\x27)[0];
            form.reset();
        }
    </script>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/print.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1761 => 761,  1747 => 750,  1699 => 705,  1664 => 673,  1551 => 562,  1545 => 560,  1539 => 558,  1537 => 557,  1534 => 555,  1528 => 553,  1522 => 551,  1520 => 550,  1510 => 547,  1507 => 546,  1505 => 545,  1502 => 544,  1495 => 543,  1485 => 541,  1482 => 540,  1478 => 539,  1475 => 538,  1473 => 537,  1462 => 533,  1456 => 532,  1453 => 531,  1447 => 529,  1441 => 527,  1439 => 526,  1433 => 525,  1423 => 523,  1420 => 522,  1418 => 521,  1412 => 520,  1407 => 518,  1401 => 517,  1396 => 515,  1389 => 514,  1381 => 512,  1375 => 510,  1372 => 509,  1370 => 508,  1361 => 507,  1356 => 506,  1348 => 504,  1342 => 502,  1340 => 501,  1331 => 500,  1326 => 499,  1316 => 496,  1307 => 495,  1302 => 494,  1292 => 491,  1283 => 490,  1278 => 489,  1268 => 486,  1259 => 485,  1255 => 484,  1252 => 483,  1246 => 481,  1244 => 480,  1238 => 479,  1228 => 477,  1226 => 476,  1220 => 475,  1217 => 474,  1211 => 472,  1209 => 471,  1203 => 470,  1200 => 469,  1194 => 467,  1192 => 466,  1186 => 465,  1177 => 463,  1172 => 461,  1166 => 460,  1161 => 458,  1155 => 457,  1149 => 454,  1139 => 453,  1133 => 452,  1127 => 449,  1117 => 448,  1111 => 447,  1105 => 444,  1097 => 443,  1091 => 442,  1088 => 441,  1085 => 440,  1082 => 439,  1079 => 438,  1076 => 437,  1073 => 436,  1070 => 435,  1067 => 434,  1064 => 433,  1061 => 432,  1058 => 431,  1055 => 430,  1052 => 429,  1049 => 428,  1044 => 427,  1041 => 426,  1038 => 425,  1035 => 424,  1033 => 423,  1028 => 420,  1018 => 417,  1009 => 416,  1005 => 415,  995 => 410,  985 => 402,  979 => 399,  975 => 398,  965 => 396,  962 => 395,  960 => 394,  953 => 389,  950 => 388,  943 => 387,  940 => 386,  937 => 385,  934 => 384,  924 => 381,  920 => 380,  910 => 378,  907 => 377,  905 => 376,  902 => 375,  897 => 372,  893 => 370,  887 => 368,  885 => 367,  881 => 365,  871 => 363,  868 => 362,  865 => 361,  863 => 360,  860 => 359,  858 => 358,  854 => 357,  850 => 356,  846 => 355,  843 => 354,  838 => 353,  835 => 352,  832 => 351,  829 => 350,  826 => 349,  823 => 348,  821 => 347,  816 => 345,  812 => 344,  802 => 342,  799 => 341,  797 => 340,  790 => 335,  787 => 334,  784 => 333,  781 => 332,  778 => 331,  775 => 330,  770 => 329,  767 => 328,  764 => 327,  761 => 326,  758 => 325,  756 => 324,  749 => 320,  745 => 319,  741 => 318,  737 => 317,  733 => 316,  729 => 315,  725 => 314,  721 => 313,  715 => 309,  710 => 301,  704 => 298,  700 => 297,  691 => 295,  684 => 290,  681 => 289,  678 => 288,  675 => 287,  668 => 286,  665 => 285,  662 => 284,  660 => 283,  655 => 281,  651 => 280,  641 => 278,  638 => 277,  636 => 276,  632 => 274,  626 => 272,  624 => 271,  620 => 269,  610 => 267,  607 => 266,  604 => 265,  602 => 264,  597 => 262,  593 => 261,  590 => 260,  587 => 259,  584 => 258,  581 => 257,  578 => 256,  575 => 255,  573 => 254,  568 => 252,  564 => 251,  555 => 249,  548 => 244,  545 => 243,  542 => 242,  539 => 241,  536 => 240,  533 => 239,  530 => 238,  527 => 237,  522 => 236,  519 => 235,  516 => 234,  513 => 233,  510 => 232,  508 => 231,  501 => 227,  497 => 226,  493 => 225,  489 => 224,  485 => 223,  481 => 222,  477 => 221,  467 => 216,  454 => 208,  450 => 207,  443 => 205,  435 => 199,  424 => 195,  414 => 194,  410 => 193,  405 => 192,  401 => 191,  393 => 186,  387 => 183,  376 => 175,  370 => 172,  364 => 169,  358 => 166,  352 => 163,  346 => 160,  339 => 156,  333 => 153,  327 => 150,  321 => 147,  315 => 144,  309 => 141,  302 => 137,  291 => 129,  285 => 126,  281 => 125,  277 => 124,  274 => 123,  272 => 122,  268 => 121,  260 => 116,  256 => 115,  252 => 114,  249 => 113,  247 => 112,  243 => 111,  235 => 106,  231 => 105,  228 => 104,  226 => 103,  222 => 102,  215 => 98,  209 => 97,  202 => 93,  161 => 55,  157 => 54,  153 => 53,  148 => 50,  146 => 49,  143 => 48,  141 => 41,  138 => 40,  130 => 38,  127 => 37,  123 => 36,  115 => 34,  112 => 33,  108 => 32,  100 => 30,  97 => 29,  93 => 28,  85 => 26,  82 => 25,  78 => 24,  70 => 22,  67 => 21,  63 => 20,  60 => 19,  58 => 7,  56 => 6,  54 => 5,  52 => 4,  50 => 3,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/print.html.twig", "/opt/kimai/templates/export/print.html.twig");
    }
}
