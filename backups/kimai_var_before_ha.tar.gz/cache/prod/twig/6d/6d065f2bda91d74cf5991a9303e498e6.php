<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/meta_fields.html.twig */
class __TwigTemplate_e4fe4f7e5fdf87d6edfe6e1102b0187f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        // line 9
        yield "
";
        yield from [];
    }

    // line 2
    public function macro_meta_field_value($entity = null, $field = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "entity" => $entity,
            "field" => $field,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "    ";
            $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "metaField", [CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 3)], "method", false, false, false, 3);
            // line 4
            yield "    ";
            if ( !(null === ($context["metaField"] ?? null))) {
                // line 5
                yield "        ";
                $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "merge", [($context["field"] ?? null)], "method", false, false, false, 5);
                // line 6
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_form_type_value", $context, 6, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "type", [], "any", false, false, false, 6), CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 6), ($context["entity"] ?? null)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 10
    public function macro_form_type_value($type = null, $value = null, $entity = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "value" => $value,
            "entity" => $entity,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 11
            yield "    ";
            if (CoreExtension::inFilter("DurationType", ($context["type"] ?? null))) {
                // line 12
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif ((CoreExtension::inFilter("YesNoType",             // line 13
($context["type"] ?? null)) || CoreExtension::inFilter("CheckboxType", ($context["type"] ?? null)))) {
                // line 14
                yield "        ";
                yield (string) (((($tmp = ($context["value"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("yes"), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("no"), "html", null, true)));
                yield "
    ";
            } elseif (CoreExtension::inFilter("DatePickerType",             // line 15
($context["type"] ?? null))) {
                // line 16
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("DateTimePickerType",             // line 17
($context["type"] ?? null))) {
                // line 18
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("CountryType",             // line 19
($context["type"] ?? null))) {
                // line 20
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("CurrencyType",             // line 21
($context["type"] ?? null))) {
                // line 22
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCurrencyName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("LanguageType",             // line 23
($context["type"] ?? null))) {
                // line 24
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getLocaleName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("MoneyType",             // line 25
($context["type"] ?? null))) {
                // line 26
                yield "        ";
                $context["classname"] = $this->extensions['App\Twig\Extensions']->getClassName(($context["entity"] ?? null));
                // line 27
                yield "        ";
                if ((($context["classname"] ?? null) == "App\\Entity\\Timesheet")) {
                    // line 28
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 28), "customer", [], "any", false, false, false, 28), "currency", [], "any", false, false, false, 28)), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 29
($context["classname"] ?? null) == "App\\Entity\\Customer")) {
                    // line 30
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "currency", [], "any", false, false, false, 30)), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 31
($context["classname"] ?? null) == "App\\Entity\\Project")) {
                    // line 32
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "customer", [], "any", false, false, false, 32), "currency", [], "any", false, false, false, 32)), "html", null, true);
                    yield "
        ";
                } elseif (((                // line 33
($context["classname"] ?? null) == "App\\Entity\\Activity") &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 33)))) {
                    // line 34
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 34), "customer", [], "any", false, false, false, 34), "currency", [], "any", false, false, false, 34)), "html", null, true);
                    yield "
        ";
                } else {
                    // line 36
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                    yield "
        ";
                }
                // line 38
                yield "    ";
            } elseif (CoreExtension::inFilter("TextareaType", ($context["type"] ?? null))) {
                // line 39
                yield "        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true));
                yield "
    ";
            } else {
                // line 41
                yield "        ";
                // line 42
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/meta_fields.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  200 => 42,  198 => 41,  192 => 39,  189 => 38,  183 => 36,  177 => 34,  175 => 33,  170 => 32,  168 => 31,  163 => 30,  161 => 29,  156 => 28,  153 => 27,  150 => 26,  148 => 25,  143 => 24,  141 => 23,  136 => 22,  134 => 21,  129 => 20,  127 => 19,  122 => 18,  120 => 17,  115 => 16,  113 => 15,  108 => 14,  106 => 13,  101 => 12,  98 => 11,  84 => 10,  74 => 6,  71 => 5,  68 => 4,  65 => 3,  52 => 2,  46 => 9,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/meta_fields.html.twig", "/opt/kimai/templates/macros/meta_fields.html.twig");
    }
}
