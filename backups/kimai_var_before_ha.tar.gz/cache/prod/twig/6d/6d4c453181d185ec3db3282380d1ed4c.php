<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/alert.html.twig */
class __TwigTemplate_a23861ffdc4ee2dab178e07795a8b68f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_alert($options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "
    ";
            // line 5
            yield "    ";
            $context["_title"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 5)) : (null));
            // line 6
            yield "    ";
            $context["_description"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "description", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "description", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "description", [], "any", false, false, false, 6)) : (null));
            // line 7
            yield "    ";
            $context["_icon"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", false, false, false, 7)) : (null));
            // line 8
            yield "
    ";
            // line 10
            yield "    ";
            $context["_type"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", true, true, false, 10) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", false, false, false, 10)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", false, false, false, 10)) : ("danger"));
            // line 11
            yield "    ";
            $context["_dismissible"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dismissible", [], "any", true, true, false, 11) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dismissible", [], "any", false, false, false, 11)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dismissible", [], "any", false, false, false, 11)) : (false)) === true);
            // line 12
            yield "    ";
            $context["_important"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "important", [], "any", true, true, false, 12) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "important", [], "any", false, false, false, 12)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "important", [], "any", false, false, false, 12)) : (false)) === true);
            // line 13
            yield "
    ";
            // line 14
            $context["_id"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", true, true, false, 14) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 14)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 14)) : (null));
            // line 15
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 15) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 15)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 15)) : ([]));
            // line 16
            yield "    ";
            $context["_class"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", true, true, false, 16) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", false, false, false, 16)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", false, false, false, 16)) : (""));
            // line 17
            yield "    ";
            $context["_raw"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", true, true, false, 17) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 17)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 17)) : (false)) === true);
            // line 18
            yield "
    ";
            // line 19
            if (((Twig\Extension\CoreExtension::testEmpty(($context["_title"] ?? null)) || Twig\Extension\CoreExtension::testEmpty(($context["_description"] ?? null))) &&  !CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "important", [], "any", true, true, false, 19))) {
                // line 20
                yield "        ";
                trigger_deprecation('', '', "Using important alert without setting the \x27important\x27 option is deprecated, set option to true instead."." in \"@Tabler/components/alert.html.twig\" at line 20.");
                // line 21
                yield "        ";
                $context["_important"] = true;
                // line 22
                yield "    ";
            }
            // line 23
            yield "
    <div
        ";
            // line 25
            if ((($tmp = ($context["_id"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 26
            yield "        class=\"alert alert-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_type"] ?? null), "html", null, true);
            yield " ";
            if ((($tmp = ($context["_dismissible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "alert-dismissible";
            }
            yield " ";
            if ((($tmp = ($context["_important"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "alert-important";
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_class"] ?? null), "html", null, true);
            yield "\"
        role=\"alert\"
        ";
            // line 28
            yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 28, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        ";
            // line 30
            if ((($tmp = ($context["_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 31
                yield "            <div class=\"alert-icon\">
                ";
                // line 32
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["_icon"] ?? null), true);
                yield "
            </div>
        ";
            }
            // line 35
            yield "
        ";
            // line 36
            if (( !Twig\Extension\CoreExtension::testEmpty(($context["_title"] ?? null)) ||  !Twig\Extension\CoreExtension::testEmpty(($context["_description"] ?? null)))) {
                // line 37
                yield "            <div>
                ";
                // line 38
                if ( !Twig\Extension\CoreExtension::testEmpty(($context["_title"] ?? null))) {
                    // line 39
                    yield "                    <h4 class=\"alert-heading\">";
                    yield (string) (((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["_title"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true)));
                    yield "</h4>
                ";
                }
                // line 41
                yield "                ";
                if ( !Twig\Extension\CoreExtension::testEmpty(($context["_description"] ?? null))) {
                    // line 42
                    yield "                    ";
                    if ((($tmp = ($context["_important"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 43
                        yield "                        ";
                        yield (string) (((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["_description"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_description"] ?? null), "html", null, true)));
                        yield "
                    ";
                    } else {
                        // line 45
                        yield "                        <div class=\"alert-description\">";
                        yield (string) (((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["_description"] ?? null)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_description"] ?? null), "html", null, true)));
                        yield "</div>
                    ";
                    }
                    // line 47
                    yield "                ";
                }
                // line 48
                yield "            </div>
        ";
            }
            // line 50
            yield "
        ";
            // line 51
            if ((($tmp = ($context["_dismissible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "<a class=\"btn-close\" data-bs-dismiss=\"alert\" aria-label=\"close\"></a>";
            }
            // line 52
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/alert.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  203 => 52,  199 => 51,  196 => 50,  192 => 48,  189 => 47,  183 => 45,  177 => 43,  174 => 42,  171 => 41,  165 => 39,  163 => 38,  160 => 37,  158 => 36,  155 => 35,  149 => 32,  146 => 31,  144 => 30,  139 => 28,  123 => 26,  117 => 25,  113 => 23,  110 => 22,  107 => 21,  104 => 20,  102 => 19,  99 => 18,  96 => 17,  93 => 16,  90 => 15,  88 => 14,  85 => 13,  82 => 12,  79 => 11,  76 => 10,  73 => 8,  70 => 7,  67 => 6,  64 => 5,  61 => 3,  58 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/alert.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/alert.html.twig");
    }
}
