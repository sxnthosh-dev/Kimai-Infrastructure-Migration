<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* wizard/done.html.twig */
class __TwigTemplate_7a678f33974322286e153dc2a7bfec27 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'wizard_content' => [$this, 'block_wizard_content'],
            'wizard_next_button' => [$this, 'block_wizard_next_button'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "wizard/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("@Tabler/components/button.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("wizard/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    <div class=\"card-body text-center py-4 p-sm-7\">
        <img src=\"";
        // line 6
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("touch-icon-512x512.png"), "html", null, true);
        yield "\" style=\"height: 200px\" alt=\"Kimai Logo\">
        <h1 class=\"mt-5\">";
        // line 7
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("wizard.done.title", [], "wizard"), "html", null, true);
        yield "</h1>
        <p class=\"text-body-secondary\">";
        // line 8
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("wizard.done.description", [], "wizard"), "html", null, true);
        yield "</p>
    </div>
";
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_next_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_button", $context, 13, $this->getSourceContext())->macro_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Next", [], "TablerBundle"), "combined" => true, "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("homepage")], "primary"]);
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "wizard/done.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  89 => 13,  82 => 12,  74 => 8,  70 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "wizard/done.html.twig", "/opt/kimai/templates/wizard/done.html.twig");
    }
}
