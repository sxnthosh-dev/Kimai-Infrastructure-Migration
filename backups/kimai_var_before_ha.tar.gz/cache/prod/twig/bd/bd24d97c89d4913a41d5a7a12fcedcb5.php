<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* partials/ticktack.html.twig */
class __TwigTemplate_7899ab2fcd481e17086acac948f50423 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["active_timesheets"] = $this->env->getRuntime('App\Twig\Runtime\TimesheetExtension')->activeEntries(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 1));
        // line 2
        $context["hasActiveRecords"] =  !Twig\Extension\CoreExtension::testEmpty(($context["active_timesheets"] ?? null));
        // line 3
        if ( !(($tmp = ($context["hasActiveRecords"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 4
            yield "    ";
            // line 5
            yield "    ";
            $context["active_timesheets"] = [["id" => "000", "begin" => null, "activity" => ["name" => ""], "project" => ["name" => "", "customer" => ["name" => ""]]]];
        }
        // line 7
        yield "<div class=\"nav-item d-flex me-1 ticktac\">
    <div class=\"btn-list\">
        ";
        // line 9
        $context["entry"] = (($_v0 = ($context["active_timesheets"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[0] ?? null) : null);
        // line 10
        yield "        <div class=\"ticktac-menu\" data-api=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("active_timesheet");
        yield "\" data-href=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("stop_timesheet", ["id" => "000"]);
        yield "\" style=\"";
        if ( !(($tmp = ($context["hasActiveRecords"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "display:none";
        }
        yield "\">
            <a title=\"";
        // line 11
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timesheet.stop"), "html", null, true);
        yield "\" data-replacer=\"url\" class=\"api-link ticktac-running ticktac-stop btn btn-default btn-icon px-sm-2\" href=\"#\" data-href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("stop_timesheet", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 11)]), "html", null, true);
        yield "\" data-event=\"kimai.timesheetStop kimai.timesheetUpdate\" data-method=\"PATCH\" data-msg-error=\"timesheet.stop.error\" data-msg-success=\"timesheet.stop.success\"";
        if ((($tmp = ($context["hasActiveRecords"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " accesskey=\"s\"";
        }
        yield ">
                <i class=\"text-red ";
        // line 12
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("stop-small", false), "html", null, true);
        yield " me-0 me-sm-1\"></i>
                <span class=\"d-none d-sm-block\" data-replacer=\"duration\" data-title=\"true\" data-since=\"";
        // line 13
        yield (string) (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 13))) ? ("") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 13), Twig\Extension\CoreExtension::constant("DATE_ISO8601")), "html", null, true)));
        yield "\">";
        yield (string) ((is_iterable(($context["entry"] ?? null))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(0), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["entry"] ?? null)), "html", null, true)));
        yield "</span>
            </a>
        </div>
        <div class=\"ticktac-menu-empty\" style=\"";
        // line 16
        if ((($tmp = ($context["hasActiveRecords"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "display:none";
        }
        yield "\">
            <a title=\"";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timesheet.start"), "html", null, true);
        yield "\" href=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("timesheet_create");
        yield "\" class=\"modal-ajax-form ticktac-start btn btn-default btn-icon px-sm-2\" accesskey=\"n\">
                <i class=\"text-green ";
        // line 18
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("start", false), "html", null, true);
        yield " me-0 me-sm-1\"></i>
                <span class=\"d-none d-sm-block\">";
        // line 19
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(0), "html", null, true);
        yield "</span>
            </a>
        </div>
    </div>
</div>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "partials/ticktack.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  110 => 19,  106 => 18,  100 => 17,  94 => 16,  86 => 13,  82 => 12,  72 => 11,  61 => 10,  59 => 9,  55 => 7,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "partials/ticktack.html.twig", "/opt/kimai/templates/partials/ticktack.html.twig");
    }
}
