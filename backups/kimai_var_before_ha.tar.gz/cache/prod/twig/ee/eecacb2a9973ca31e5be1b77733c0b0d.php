<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-paginatedworkingtimechart.html.twig */
class __TwigTemplate_fbaa7b7edacc39a8ceccea308d2c8d65 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("widget/widget-paginatedworkingtimechart.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["margin_bottom" => 0]));
        // line 70
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "javascriptRequest", [], "any", false, false, false, 70)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 71
            yield "<script type=\"text/javascript\">
    document.addEventListener(\x27kimai.initialized\x27, function() {
        KimaiPaginatedBoxWidget.create(\x27#PaginatedWorkingTimeChartBox\x27);
    });
</script>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-paginatedworkingtimechart.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  47 => 71,  45 => 70,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-paginatedworkingtimechart.html.twig", "/opt/kimai/templates/widget/widget-paginatedworkingtimechart.html.twig");
    }
}


/* widget/widget-paginatedworkingtimechart.html.twig */
class __TwigTemplate_fbaa7b7edacc39a8ceccea308d2c8d65___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("@theme/components/buttons.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "        ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["title"] ?? null))) {
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
        }
        // line 5
        yield "    ";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "        id=\"PaginatedWorkingTimeChartBox\" data-href=\"#\" data-reload=\"\"
    ";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "        ";
        $context["prevYear"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "year", [], "any", false, false, false, 10);
        // line 11
        yield "        ";
        $context["prevWeek"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "week", [], "any", false, false, false, 11);
        // line 12
        yield "        ";
        $context["nextYear"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "year", [], "any", false, false, false, 12);
        // line 13
        yield "        ";
        $context["nextWeek"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "week", [], "any", false, false, false, 13);
        // line 14
        yield "        ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "week", [], "any", false, false, false, 14) == 1)) {
            // line 15
            yield "            ";
            $context["prevYear"] = (($context["prevYear"] ?? null) - 1);
            // line 16
            yield "            ";
            $context["prevWeek"] = CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "lastWeekInLastYear", [], "any", false, false, false, 16);
            // line 17
            yield "        ";
        } else {
            // line 18
            yield "            ";
            $context["prevWeek"] = (($context["prevWeek"] ?? null) - 1);
            // line 19
            yield "        ";
        }
        // line 20
        yield "        ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "week", [], "any", false, false, false, 20) == CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "lastWeekInYear", [], "any", false, false, false, 20))) {
            // line 21
            yield "            ";
            $context["nextYear"] = (($context["nextYear"] ?? null) + 1);
            // line 22
            yield "            ";
            $context["nextWeek"] = 1;
            // line 23
            yield "        ";
        } else {
            // line 24
            yield "            ";
            $context["nextWeek"] = (($context["nextWeek"] ?? null) + 1);
            // line 25
            yield "        ";
        }
        // line 26
        yield "        ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_action_cardtoolbutton", $context, 26, $this->getSourceContext())->macro_action_cardtoolbutton(...["left", ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeekShort", ["%week%" => ((($context["prevWeek"] ?? null) . "/") . ($context["prevYear"] ?? null))]), "class" => "pagination-link", "onclick" => "myChart.destroy()", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("widgets_working_time_chart", ["year" => ($context["prevYear"] ?? null), "week" => ($context["prevWeek"] ?? null)])]]);
        yield "
        ";
        // line 27
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_action_cardtoolbutton", $context, 27, $this->getSourceContext())->macro_action_cardtoolbutton(...["right", ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeekShort", ["%week%" => ((($context["nextWeek"] ?? null) . "/") . ($context["nextYear"] ?? null))]), "class" => "pagination-link", "onclick" => "myChart.destroy()", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("widgets_working_time_chart", ["year" => ($context["nextYear"] ?? null), "week" => ($context["nextWeek"] ?? null)])]]);
        yield "
    ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "        ";
        yield (string) $this->env->getRuntime('App\Twig\Runtime\WidgetExtension')->renderWidget($this->env, "DailyWorkingTimeChart", Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["begin" => CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "begin", [], "any", false, false, false, 30), "end" => CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "end", [], "any", false, false, false, 30)]));
        yield "
    ";
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 33
        yield "        <div class=\"row\">
            <div class=\"col-sm-3 col-xs-6 mt-1 mb-2 mb-md-0\">
                <div class=\"text-center\">
                    <h5 class=\"mb-1\">";
        // line 36
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "day", [], "any", false, false, false, 36)), "html", null, true);
        yield "</h5>
                    <span>";
        // line 37
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeToday", ["%day%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateShort("now")]), "html", null, true);
        yield "</span>
                </div>
            </div>
            <div class=\"col-sm-3 col-xs-6 mt-1 mb-2 mb-md-0\">
                <div class=\"text-center\">
                    <h5 class=\"mb-1\">";
        // line 42
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "week", [], "any", false, false, false, 42)), "html", null, true);
        yield "</h5>
                    <span>";
        // line 43
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeWeek", ["%week%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "begin", [], "any", false, false, false, 43), "W")]), "html", null, true);
        yield "</span>
                </div>
            </div>
            <div class=\"col-sm-3 col-xs-6 mt-1 mb-2 mb-md-0\">
                <div class=\"text-center\">
                    <h5 class=\"mb-1\">";
        // line 48
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "month", [], "any", false, false, false, 48)), "html", null, true);
        yield "</h5>
                    <span>";
        // line 49
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeMonth", ["%month%" => $this->extensions['App\Twig\LocaleFormatExtensions']->monthName(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "thisMonth", [], "any", false, false, false, 49)), "%year%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "thisMonth", [], "any", false, false, false, 49), "Y")]), "html", null, true);
        yield "</span>
                </div>
            </div>
            ";
        // line 52
        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "financial", [], "any", false, false, false, 52))) {
            // line 53
            yield "            <div class=\"col-sm-3 col-xs-6 mt-1 mb-2 mb-md-0\">
                <div class=\"text-center\">
                    <h5 class=\"mb-1\">";
            // line 55
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "financial", [], "any", false, false, false, 55)), "html", null, true);
            yield "</h5>
                    <span>";
            // line 56
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeFinancialYear"), "html", null, true);
            yield "</span>
                </div>
            </div>
            ";
        } else {
            // line 60
            yield "            <div class=\"col-sm-3 col-xs-6 mt-1 mb-2 mb-md-0\">
                <div class=\"text-center\">
                    <h5 class=\"mb-1\">";
            // line 62
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "year", [], "any", false, false, false, 62)), "html", null, true);
            yield "</h5>
                    <span>";
            // line 63
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTimeYear", ["%year%" => CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "dateYear", [], "any", false, false, false, 63)]), "html", null, true);
            yield "</span>
                </div>
            </div>
            ";
        }
        // line 67
        yield "        </div>
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-paginatedworkingtimechart.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  319 => 67,  312 => 63,  308 => 62,  304 => 60,  297 => 56,  293 => 55,  289 => 53,  287 => 52,  281 => 49,  277 => 48,  269 => 43,  265 => 42,  257 => 37,  253 => 36,  248 => 33,  241 => 32,  233 => 30,  226 => 29,  219 => 27,  214 => 26,  211 => 25,  208 => 24,  205 => 23,  202 => 22,  199 => 21,  196 => 20,  193 => 19,  190 => 18,  187 => 17,  184 => 16,  181 => 15,  178 => 14,  175 => 13,  172 => 12,  169 => 11,  166 => 10,  159 => 9,  153 => 7,  146 => 6,  141 => 5,  136 => 4,  129 => 3,  124 => 1,  122 => 2,  115 => 1,  47 => 71,  45 => 70,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-paginatedworkingtimechart.html.twig", "/opt/kimai/templates/widget/widget-paginatedworkingtimechart.html.twig");
    }
}
