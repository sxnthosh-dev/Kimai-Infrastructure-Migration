<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* dashboard/index.html.twig */
class __TwigTemplate_35f8e39d435433af4ffe252bd3e494df extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_class' => [$this, 'block_page_class'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'footer' => [$this, 'block_footer'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "dashboard";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    ";
        yield from $this->yieldParentBlock("stylesheets", $context, $blocks);
        yield "
    ";
        // line 8
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("chart");
        yield "
";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "    ";
        yield from $this->yieldParentBlock("head", $context, $blocks);
        yield "
    ";
        // line 13
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("chart");
        yield "
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "    ";
        if (CoreExtension::inFilter("dashboard", CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 17), "attributes", [], "any", false, false, false, 17), "get", ["_route"], "method", false, false, false, 17))) {
            // line 18
            yield "        ";
            yield from $this->yieldParentBlock("footer", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "
    ";
        // line 24
        if (Twig\Extension\CoreExtension::testEmpty(($context["widgets"] ?? null))) {
            // line 25
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 25, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
    ";
        } else {
            // line 27
            yield "        <div class=\"row row-deck row-cards\">
        ";
            // line 28
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["widgets"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["widget"]) {
                // line 29
                yield "            ";
                $context["columnSize"] = CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "width", [], "any", false, false, false, 29);
                // line 30
                yield "            <div class=\"col-md-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["columnSize"] ?? null) * 3), "html", null, true);
                if ((($context["columnSize"] ?? null) <= 2)) {
                    yield " col-sm-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($context["columnSize"] ?? null) * 6), "html", null, true);
                }
                yield "\" id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["widget"], "id", [], "any", false, false, false, 30), "html", null, true);
                yield "\">
                ";
                // line 31
                yield (string) $this->env->getRuntime('App\Twig\Runtime\WidgetExtension')->renderWidget($this->env, $context["widget"]);
                yield "
            </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['widget'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 34
            yield "        </div>
    ";
        }
        // line 36
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "dashboard/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  180 => 36,  176 => 34,  166 => 31,  155 => 30,  152 => 29,  148 => 28,  145 => 27,  139 => 25,  137 => 24,  134 => 23,  127 => 22,  118 => 18,  115 => 17,  108 => 16,  101 => 13,  96 => 12,  89 => 11,  82 => 8,  77 => 7,  70 => 6,  59 => 4,  54 => 1,  52 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "dashboard/index.html.twig", "/opt/kimai/templates/dashboard/index.html.twig");
    }
}
