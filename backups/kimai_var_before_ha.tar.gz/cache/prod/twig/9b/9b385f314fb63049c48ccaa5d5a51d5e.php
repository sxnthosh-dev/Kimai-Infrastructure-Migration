<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/steps.html.twig */
class __TwigTemplate_f57b1ce8a0b386e4b9578cef7a9b0283 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        yield from [];
    }

    // line 2
    public function macro_steps($steps = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "steps" => $steps,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "    ";
            $macros["͜macros"] = $this->load("@Tabler/includes/utils.html.twig", 3)->unwrap();
            // line 4
            yield "
    ";
            // line 5
            $context["_tooltip"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "tooltip", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "tooltip", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "tooltip", [], "any", false, false, false, 5)) : (false));
            // line 6
            yield "    ";
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 6)) : ("primary"));
            // line 7
            yield "    ";
            $context["_counter"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "counter", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "counter", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "counter", [], "any", false, false, false, 7)) : (false));
            // line 8
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 8) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 8)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 8)) : ([]));
            // line 9
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 9) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 9)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 9)) : (""));
            // line 10
            yield "
    <div
            class=\"steps ";
            // line 12
            yield (string) (((($tmp = ($context["_counter"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("steps-counter") : (""));
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(("steps-" . ($context["_color"] ?? null)), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\"
            ";
            // line 13
            yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 13, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >

        ";
            // line 16
            $context["activeStepProcessed"] = false;
            // line 17
            yield "
        ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["steps"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["step"]) {
                // line 19
                yield "            ";
                $context["_type"] = (((($tmp = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "clickable", [], "any", true, true, false, 19) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "clickable", [], "any", false, false, false, 19)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "clickable", [], "any", false, false, false, 19)) : ( !(($tmp = ($context["activeStepProcessed"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("a") : ("span"));
                // line 20
                yield "            ";
                $context["_title"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "title", [], "any", true, true, false, 20) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "title", [], "any", false, false, false, 20)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "title", [], "any", false, false, false, 20)) : (""));
                // line 21
                yield "            ";
                $context["_description"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "description", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "description", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "description", [], "any", false, false, false, 21)) : (($context["_title"] ?? null)));
                // line 22
                yield "            ";
                $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "active", [], "any", true, true, false, 22) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "active", [], "any", false, false, false, 22)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "active", [], "any", false, false, false, 22)) : (false));
                // line 23
                yield "            ";
                $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "attr", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "attr", [], "any", false, false, false, 23)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "attr", [], "any", false, false, false, 23)) : ([]));
                // line 24
                yield "            ";
                $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "extraClass", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "extraClass", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["step"], "extraClass", [], "any", false, false, false, 24)) : (""));
                // line 25
                yield "
            <";
                // line 26
                yield (string) ($context["_type"] ?? null);
                yield "
                class=\"step-item ";
                // line 27
                yield (string) (((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active") : (""));
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
                yield "\"
                href=\"";
                // line 28
                yield (string) (((CoreExtension::getAttribute($this->env, $this->source, $context["step"], "href", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["step"], "href", [], "any", false, false, false, 28)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["step"], "href", [], "any", false, false, false, 28), "html", null, true)) : ("#"));
                yield "\"";
                // line 29
                if ((($tmp = ($context["_tooltip"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "data-bs-toggle=\"tooltip\"";
                }
                // line 30
                yield "title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_description"] ?? null), "html", null, true);
                yield "\"
                ";
                // line 31
                yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 31, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                yield "
            >
                ";
                // line 33
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
                yield "
            </";
                // line 34
                yield (string) ($context["_type"] ?? null);
                yield ">

            ";
                // line 36
                if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 37
                    yield "                ";
                    $context["activeStepProcessed"] = true;
                    // line 38
                    yield "            ";
                }
                // line 39
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['step'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 41
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/steps.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  182 => 41,  174 => 39,  171 => 38,  168 => 37,  166 => 36,  161 => 34,  157 => 33,  152 => 31,  147 => 30,  143 => 29,  140 => 28,  134 => 27,  130 => 26,  127 => 25,  124 => 24,  121 => 23,  118 => 22,  115 => 21,  112 => 20,  109 => 19,  105 => 18,  102 => 17,  100 => 16,  94 => 13,  86 => 12,  82 => 10,  79 => 9,  76 => 8,  73 => 7,  70 => 6,  68 => 5,  65 => 4,  62 => 3,  49 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/steps.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/steps.html.twig");
    }
}
