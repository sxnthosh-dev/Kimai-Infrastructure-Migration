<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* default/_form_delete_modal.html.twig */
class __TwigTemplate_7e616eebbe94f6d522e349baa4b6c129 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("default/_form_delete_modal.html.twig", 1, 1)->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form_delete_modal.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form_delete_modal.html.twig", "/opt/kimai/templates/default/_form_delete_modal.html.twig");
    }
}


/* default/_form_delete_modal.html.twig */
class __TwigTemplate_7e616eebbe94f6d522e349baa4b6c129___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'modal_id' => [$this, 'block_modal_id'],
            'modal_before' => [$this, 'block_modal_before'],
            'modal_effects' => [$this, 'block_modal_effects'],
            'modal_title' => [$this, 'block_modal_title'],
            'modal_body' => [$this, 'block_modal_body'],
            'modal_footer' => [$this, 'block_modal_footer'],
            'modal_end' => [$this, 'block_modal_end'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/modal.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["used"] = ((array_key_exists("used", $context)) ? (Twig\Extension\CoreExtension::default(($context["used"] ?? null), false)) : (false));
        // line 1
        $this->parent = $this->load("@theme/embeds/modal.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "form_modal";
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_effects(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("title", $context)) ? (Twig\Extension\CoreExtension::default(($context["title"] ?? null), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("confirm.delete"))) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("confirm.delete"))), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "        ";
        if (array_key_exists("delete_item_name", $context)) {
            // line 11
            yield "            <p><strong>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["delete_item_name"] ?? null), "html", null, true);
            yield "</strong></p>
        ";
        }
        // line 13
        yield "        ";
        if ((($context["used"] ?? null) === false)) {
            // line 14
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete.not_in_use"), "html", null, true);
            yield "
            <div class=\"d-none\">
                ";
            // line 16
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
            </div>
        ";
        } else {
            // line 19
            yield "            <p>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["message"] ?? null), "html", null, true);
            yield "</p>
            ";
            // line 20
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
        ";
        }
        // line 22
        yield "    ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "        <button type=\"submit\" class=\"btn ";
        if ((($tmp = ($context["used"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "btn-danger";
        } else {
            yield "btn-primary";
        }
        yield " pull-left modal-form-save\" data-loading-text=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete"), "html", null, true);
        yield "...\" id=\"";
        yield from         $this->unwrap()->yieldBlock("modal_id", $context, $blocks);
        yield "_save\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete"), "html", null, true);
        yield "</button>
        <button type=\"button\" class=\"btn btn-cancel\" data-bs-dismiss=\"modal\">";
        // line 25
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
        yield "</button>
    ";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form_delete_modal.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  234 => 27,  227 => 25,  212 => 24,  205 => 23,  200 => 22,  195 => 20,  190 => 19,  184 => 16,  178 => 14,  175 => 13,  169 => 11,  166 => 10,  159 => 9,  151 => 7,  144 => 6,  134 => 5,  123 => 4,  112 => 3,  107 => 1,  105 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form_delete_modal.html.twig", "/opt/kimai/templates/default/_form_delete_modal.html.twig");
    }
}
