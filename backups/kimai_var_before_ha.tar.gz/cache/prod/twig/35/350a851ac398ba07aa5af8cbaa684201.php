<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* datatable.html.twig */
class __TwigTemplate_7878d65d07256bc544b2b6bcb6782a58 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main_before' => [$this, 'block_main_before'],
            'table_actions' => [$this, 'block_table_actions'],
            'status' => [$this, 'block_status'],
            'main' => [$this, 'block_main'],
            'datatable_before' => [$this, 'block_datatable_before'],
            'datatable_outer' => [$this, 'block_datatable_outer'],
            'datatable_row' => [$this, 'block_datatable_row'],
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column' => [$this, 'block_datatable_column'],
            'datatable_column_attr' => [$this, 'block_datatable_column_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
            'datatable_after' => [$this, 'block_datatable_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 5
        if ((( !array_key_exists("dataTable", $context) && array_key_exists("page_setup", $context)) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "hasDataTable", [], "method", false, false, false, 5)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 6
            yield "    ";
            $context["dataTable"] = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "getDataTable", [], "method", false, false, false, 6);
        }
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "    ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_configuration", $context, 10, $this->getSourceContext())->macro_configuration(...[($context["dataTable"] ?? null)]);
        yield "
";
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_table_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "    ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_actions", $context, 14, $this->getSourceContext())->macro_actions(...[($context["dataTable"] ?? null)]);
        yield "
";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "    ";
        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getPagination", [], "method", false, false, false, 18))) {
            // line 19
            yield "        ";
            $macros["_v0"] = $this->load("macros/status.html.twig", 19)->unwrap();
            // line 20
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_status_count", $context, 20, $this->getSourceContext())->macro_status_count(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getPagination", [], "method", false, false, false, 20), "getNbResults", [], "method", false, false, false, 20)]);
            yield "
    ";
        }
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "
    ";
        // line 26
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "hasResults", [], "method", false, false, false, 26)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 27
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 27, $this->getSourceContext())->macro_nothing_found(...[CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getReloadEvents", [], "method", false, false, false, 27)]);
            yield "
    ";
        } else {
            // line 29
            yield "        ";
            yield (string) $macros["tables"]->getTemplateForMacro("macro_header", $context, 29, $this->getSourceContext())->macro_header(...[($context["dataTable"] ?? null)]);
            yield "

        ";
            // line 31
            yield from $this->unwrap()->yieldBlock('datatable_before', $context, $blocks);
            // line 32
            yield "
        ";
            // line 33
            $context["sortedColumns"] = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "sortedColumnNames", [], "any", false, false, false, 33);
            // line 34
            yield "        ";
            yield from $this->unwrap()->yieldBlock('datatable_outer', $context, $blocks);
            // line 49
            yield "
        ";
            // line 50
            yield from $this->unwrap()->yieldBlock('datatable_after', $context, $blocks);
            // line 51
            yield "
        ";
            // line 52
            yield (string) $macros["tables"]->getTemplateForMacro("macro_footer", $context, 52, $this->getSourceContext())->macro_footer(...[($context["dataTable"] ?? null)]);
            yield "
    ";
        }
        // line 54
        yield "
";
        yield from [];
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_outer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["dataTable"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 36
            yield "                ";
            yield from $this->unwrap()->yieldBlock('datatable_row', $context, $blocks);
            // line 47
            yield "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 48
        yield "        ";
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 37
        yield "                    <tr";
        yield from $this->unwrap()->yieldBlock('datatable_row_attr', $context, $blocks);
        yield ">
                        ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sortedColumns"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["column"] => $context["data"]) {
            // line 39
            yield "                            ";
            yield from $this->unwrap()->yieldBlock('datatable_column', $context, $blocks);
            // line 44
            yield "                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['column'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 45
        yield "                    </tr>
                ";
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 40
        yield "                                <td class=\"";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 40, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), ($context["column"] ?? null)]);
        yield "\"";
        yield from $this->unwrap()->yieldBlock('datatable_column_attr', $context, $blocks);
        yield ">
                                    ";
        // line 41
        yield from $this->unwrap()->yieldBlock('datatable_column_value', $context, $blocks);
        // line 42
        yield "                                </td>
                            ";
        yield from [];
    }

    // line 40
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "datatable.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  342 => 50,  332 => 41,  322 => 40,  316 => 42,  314 => 41,  307 => 40,  300 => 39,  290 => 37,  284 => 45,  269 => 44,  266 => 39,  249 => 38,  244 => 37,  237 => 36,  232 => 48,  217 => 47,  214 => 36,  196 => 35,  189 => 34,  179 => 31,  173 => 54,  168 => 52,  165 => 51,  163 => 50,  160 => 49,  157 => 34,  155 => 33,  152 => 32,  150 => 31,  144 => 29,  138 => 27,  136 => 26,  133 => 25,  126 => 24,  117 => 20,  114 => 19,  111 => 18,  104 => 17,  96 => 14,  89 => 13,  81 => 10,  74 => 9,  69 => 1,  65 => 6,  63 => 5,  61 => 3,  59 => 2,  52 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "datatable.html.twig", "/opt/kimai/templates/datatable.html.twig");
    }
}
