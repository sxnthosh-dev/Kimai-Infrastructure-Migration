<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/renderer/invoice.html.twig */
class __TwigTemplate_ff39fb2ca6a9c53b1e5aa27ecb501244 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v0 = ($context["invoice"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["invoice.language"] ?? null) : null), "html", null, true);
        yield "\">
<head>
    <meta charset=\"utf-8\">
    <title>";
        // line 5
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v1 = ($context["invoice"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["invoice.number"] ?? null) : null), "html", null, true);
        yield "-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $this->extensions['Twig\Extra\String\StringExtension']->createUnicodeString(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default((($_v2 = ($context["invoice"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["customer.company"] ?? null) : null), (($_v3 = ($context["invoice"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["customer.name"] ?? null) : null))) : ((($_v4 = ($context["invoice"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["customer.name"] ?? null) : null)))), "snake", [], "any", false, false, false, 5), "html", null, true);
        yield "</title>
    <style>
        ";
        // line 7
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("invoice");
        yield "
    </style>
</head>
<body class=\"invoice_print\">
    <div class=\"wrapper\">
        <section class=\"invoice\">

            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2 class=\"page-header\">
                        <span>";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v5 = ($context["invoice"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["template.title"] ?? null) : null), "html", null, true);
        yield "</span>
                    </h2>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-5\">
                    ";
        // line 24
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.to"), "html", null, true);
        yield "
                    <address>
                        <strong>";
        // line 26
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 26)) ? (Twig\Extension\CoreExtension::default((($_v6 = ($context["invoice"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["customer.company"] ?? null) : null), (($_v7 = ($context["invoice"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["customer.name"] ?? null) : null))) : ((($_v8 = ($context["invoice"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["customer.name"] ?? null) : null))), "html", null, true);
        yield "</strong><br>
                        ";
        // line 27
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v9 = ($context["invoice"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["customer.address"] ?? null) : null), "html", null, true));
        yield "
                        ";
        // line 28
        $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v10 = ($context["invoice"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["customer.country"] ?? null) : null), (($_v11 = ($context["invoice"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["invoice.language"] ?? null) : null));
        // line 29
        yield "                        ";
        if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v12 = ($context["invoice"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["customer.address"] ?? null) : null))) {
            // line 30
            yield "                            <br> ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
            yield "
                        ";
        }
        // line 32
        yield "                        ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v13 = ($context["invoice"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["customer.vat_id"] ?? null) : null))) {
            // line 33
            yield "                            <br>
                            ";
            // line 34
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v14 = ($context["invoice"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["customer.vat_id"] ?? null) : null), "html", null, true);
            yield "
                        ";
        }
        // line 36
        yield "                        ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v15 = ($context["invoice"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["customer.number"] ?? null) : null))) {
            // line 37
            yield "                            <br>
                            ";
            // line 38
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("number"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v16 = ($context["invoice"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["customer.number"] ?? null) : null), "html", null, true);
            yield "
                        ";
        }
        // line 40
        yield "                        ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "query.project.order_number", [], "array", true, true, false, 40) &&  !Twig\Extension\CoreExtension::testEmpty((($_v17 = ($context["invoice"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["query.project.order_number"] ?? null) : null)))) {
            // line 41
            yield "                            <br>
                            ";
            // line 42
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderNumber"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v18 = ($context["invoice"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["query.project.order_number"] ?? null) : null), "html", null, true);
            yield "
                        ";
        }
        // line 44
        yield "                    </address>
                </div>
                <div class=\"col-sm-2\"></div>
                <div class=\"col-sm-5\">
                    ";
        // line 48
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.from"), "html", null, true);
        yield "
                    <address>
                        <strong>";
        // line 50
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v19 = ($context["invoice"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["template.company"] ?? null) : null), "html", null, true);
        yield "</strong><br>
                        ";
        // line 51
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::trim((($_v20 = ($context["invoice"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20["template.address"] ?? null) : null)), "html", null, true));
        yield "
                        ";
        // line 52
        if ( !(null === (($_v21 = ($context["invoice"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21["template.country"] ?? null) : null))) {
            // line 53
            yield "                            ";
            $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v22 = ($context["invoice"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22["template.country"] ?? null) : null), (($_v23 = ($context["invoice"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23["invoice.language"] ?? null) : null));
            // line 54
            yield "                            ";
            if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v24 = ($context["invoice"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24["template.address"] ?? null) : null))) {
                // line 55
                yield "                                <br> ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
                yield "
                            ";
            }
            // line 57
            yield "                        ";
        }
        // line 58
        yield "                        ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v25 = ($context["invoice"] ?? null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25["template.vat_id"] ?? null) : null))) {
            // line 59
            yield "                            <br>
                            ";
            // line 60
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ":
                            ";
            // line 61
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v26 = ($context["invoice"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26["template.vat_id"] ?? null) : null), "html", null, true);
            yield "
                        ";
        }
        // line 63
        yield "                    </address>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-sm-5\">
                    <p>
                        <strong>";
        // line 70
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield ":</strong>
                        ";
        // line 71
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v27 = ($context["invoice"] ?? null)) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27["invoice.date"] ?? null) : null), "html", null, true);
        yield "

                        <br>
                        <strong>";
        // line 74
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.number"), "html", null, true);
        yield ":</strong>
                        ";
        // line 75
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v28 = ($context["invoice"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28["invoice.number"] ?? null) : null), "html", null, true);
        yield "

                        <br>
                        <strong>";
        // line 78
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.due_days"), "html", null, true);
        yield ":</strong>
                        ";
        // line 79
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v29 = ($context["invoice"] ?? null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29["invoice.due_date"] ?? null) : null), "html", null, true);
        yield "
                    </p>
                </div>
                <div class=\"col-sm-7\"></div>
            </div>

            <div class=\"row invoice-items mt-2 mb-3\">
                <div class=\"col-xs-12 table-responsive\">
                    <table class=\"table\">
                        <thead>
                        <tr>
                            <th>";
        // line 90
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</th>
                            <th>";
        // line 91
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("description"), "html", null, true);
        yield "</th>
                            <th class=\"text-end\">";
        // line 92
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("unit_price"), "html", null, true);
        yield "</th>
                            <th class=\"text-end\">";
        // line 93
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("amount"), "html", null, true);
        yield "</th>
                            <th class=\"text-end\">";
        // line 94
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("total_rate"), "html", null, true);
        yield "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["invoiceLineItem"]) {
            // line 99
            yield "                            <tr>
                                <td nowrap class=\"text-nowrap\">";
            // line 100
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v30 = $context["invoiceLineItem"]) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30["entry.begin"] ?? null) : null), "html", null, true);
            yield "</td>
                                <td>
                                    ";
            // line 102
            if ( !Twig\Extension\CoreExtension::testEmpty((($_v31 = $context["invoiceLineItem"]) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["entry.description"] ?? null) : null))) {
                // line 103
                yield "                                        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v32 = $context["invoiceLineItem"]) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["entry.description"] ?? null) : null), "html", null, true));
                yield "
                                    ";
            } else {
                // line 105
                yield "                                        ";
                if (CoreExtension::getAttribute($this->env, $this->source, $context["invoiceLineItem"], "entry.activity", [], "array", true, true, false, 105)) {
                    // line 106
                    yield "                                            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v33 = $context["invoiceLineItem"]) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["entry.activity"] ?? null) : null), "html", null, true);
                    yield " /
                                        ";
                }
                // line 108
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v34 = $context["invoiceLineItem"]) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["entry.project"] ?? null) : null), "html", null, true);
                yield "
                                    ";
            }
            // line 110
            yield "                                </td>
                                <td nowrap class=\"text-nowrap text-end\">";
            // line 111
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v35 = $context["invoiceLineItem"]) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["entry.rate"] ?? null) : null), "html", null, true);
            yield "</td>
                                <td nowrap class=\"text-nowrap text-end\">";
            // line 112
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v36 = $context["invoiceLineItem"]) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["entry.amount"] ?? null) : null), "html", null, true);
            yield "</td>
                                <td nowrap class=\"text-nowrap text-end\">";
            // line 113
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v37 = $context["invoiceLineItem"]) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["entry.total"] ?? null) : null), "html", null, true);
            yield "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['invoiceLineItem'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 116
        yield "                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan=\"4\" class=\"text-end\">
                                    ";
        // line 120
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.subtotal"), "html", null, true);
        yield "
                                </td>
                                <td class=\"text-end\">";
        // line 122
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v38 = ($context["invoice"] ?? null)) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["invoice.subtotal"] ?? null) : null), "html", null, true);
        yield "</td>
                            </tr>
                            ";
        // line 124
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v39 = ($context["invoice"] ?? null)) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 125
            yield "                                ";
            if ((($tmp = (($_v40 = $context["taxRow"]) && is_array($_v40) || $_v40 instanceof ArrayAccess ? ($_v40["show"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 126
                yield "                                    <tr>
                                        <td colspan=\"4\" class=\"text-end\">
                                            ";
                // line 128
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v41 = $context["taxRow"]) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41["name"] ?? null) : null)), "html", null, true);
                yield " (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v42 = $context["taxRow"]) && is_array($_v42) || $_v42 instanceof ArrayAccess ? ($_v42["rate"] ?? null) : null), "html", null, true);
                yield "%)
                                            ";
                // line 129
                if ( !(null === (($_v43 = $context["taxRow"]) && is_array($_v43) || $_v43 instanceof ArrayAccess ? ($_v43["note"] ?? null) : null))) {
                    // line 130
                    yield "                                                <sup>[";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v44 = $context["taxRow"]) && is_array($_v44) || $_v44 instanceof ArrayAccess ? ($_v44["counter"] ?? null) : null), "html", null, true);
                    yield "]</sup>
                                            ";
                }
                // line 132
                yield "                                        </td>
                                        <td class=\"last text-right\">";
                // line 133
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v45 = $context["taxRow"]) && is_array($_v45) || $_v45 instanceof ArrayAccess ? ($_v45["amount"] ?? null) : null), (($_v46 = $context["taxRow"]) && is_array($_v46) || $_v46 instanceof ArrayAccess ? ($_v46["currency"] ?? null) : null)), "html", null, true);
                yield "</td>
                                    </tr>
                                ";
            }
            // line 136
            yield "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 137
        yield "                        <tr>
                            <td colspan=\"4\" class=\"text-end text-nowrap\">
                                <strong>";
        // line 139
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.total"), "html", null, true);
        yield "</strong>
                            </td>
                            <td class=\"text-end\">
                                <strong>";
        // line 142
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v47 = ($context["invoice"] ?? null)) && is_array($_v47) || $_v47 instanceof ArrayAccess ? ($_v47["invoice.total"] ?? null) : null), "html", null, true);
        yield "</strong>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-xs-12\">
                    ";
        // line 152
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v48 = ($context["invoice"] ?? null)) && is_array($_v48) || $_v48 instanceof ArrayAccess ? ($_v48["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 153
            yield "                        ";
            if ( !(null === (($_v49 = $context["taxRow"]) && is_array($_v49) || $_v49 instanceof ArrayAccess ? ($_v49["note"] ?? null) : null))) {
                // line 154
                yield "                        <p>
                            <sup>[";
                // line 155
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v50 = $context["taxRow"]) && is_array($_v50) || $_v50 instanceof ArrayAccess ? ($_v50["counter"] ?? null) : null), "html", null, true);
                yield "]</sup>
                            ";
                // line 156
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v51 = $context["taxRow"]) && is_array($_v51) || $_v51 instanceof ArrayAccess ? ($_v51["note"] ?? null) : null)), "html", null, true);
                yield "
                        </p>
                        ";
            }
            // line 159
            yield "                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 160
        yield "                    ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v52 = ($context["invoice"] ?? null)) && is_array($_v52) || $_v52 instanceof ArrayAccess ? ($_v52["template.payment_terms"] ?? null) : null))) {
            // line 161
            yield "                        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v53 = ($context["invoice"] ?? null)) && is_array($_v53) || $_v53 instanceof ArrayAccess ? ($_v53["template.payment_terms"] ?? null) : null));
            yield "
                    ";
        }
        // line 163
        yield "                </div>
            </div>

            <footer class=\"footer\">
                <p>
                    <strong>";
        // line 168
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address"), "html", null, true);
        yield "</strong>: ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v54 = ($context["invoice"] ?? null)) && is_array($_v54) || $_v54 instanceof ArrayAccess ? ($_v54["template.company"] ?? null) : null), "html", null, true);
        yield " &ndash; ";
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v55 = ($context["invoice"] ?? null)) && is_array($_v55) || $_v55 instanceof ArrayAccess ? ($_v55["template.address"] ?? null) : null), "html", null, true), " – ");
        yield "
                    <br>
                    <strong>";
        // line 170
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice_bank_account"), "html", null, true);
        yield "</strong>: ";
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v56 = ($context["invoice"] ?? null)) && is_array($_v56) || $_v56 instanceof ArrayAccess ? ($_v56["template.payment_details"] ?? null) : null), "html", null, true), " – ");
        yield "
                    <br>
                    <strong>";
        // line 172
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("contact"), "html", null, true);
        yield "</strong>: ";
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v57 = ($context["invoice"] ?? null)) && is_array($_v57) || $_v57 instanceof ArrayAccess ? ($_v57["template.contact"] ?? null) : null), "html", null, true), " – ");
        yield "
                </p>
            </footer>

        </section>
    </div>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/renderer/invoice.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  461 => 172,  454 => 170,  445 => 168,  438 => 163,  432 => 161,  429 => 160,  422 => 159,  416 => 156,  412 => 155,  409 => 154,  406 => 153,  402 => 152,  389 => 142,  383 => 139,  379 => 137,  372 => 136,  366 => 133,  363 => 132,  357 => 130,  355 => 129,  349 => 128,  345 => 126,  342 => 125,  338 => 124,  333 => 122,  328 => 120,  322 => 116,  312 => 113,  308 => 112,  304 => 111,  301 => 110,  295 => 108,  289 => 106,  286 => 105,  280 => 103,  278 => 102,  273 => 100,  270 => 99,  266 => 98,  259 => 94,  255 => 93,  251 => 92,  247 => 91,  243 => 90,  229 => 79,  225 => 78,  219 => 75,  215 => 74,  209 => 71,  205 => 70,  196 => 63,  191 => 61,  187 => 60,  184 => 59,  181 => 58,  178 => 57,  172 => 55,  169 => 54,  166 => 53,  164 => 52,  160 => 51,  156 => 50,  151 => 48,  145 => 44,  138 => 42,  135 => 41,  132 => 40,  125 => 38,  122 => 37,  119 => 36,  112 => 34,  109 => 33,  106 => 32,  100 => 30,  97 => 29,  95 => 28,  91 => 27,  87 => 26,  82 => 24,  72 => 17,  59 => 7,  52 => 5,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/renderer/invoice.html.twig", "/opt/kimai/templates/invoice/renderer/invoice.html.twig");
    }
}
