<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/progressbar.html.twig */
class __TwigTemplate_cecac8a24bc4fb31e8a05be3f70d5846 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 56
        yield "
";
        // line 87
        yield "
";
        // line 110
        yield "
";
        // line 133
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_progressbar_full($options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $context["max"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "max", [], "array", true, true, false, 2) &&  !(null === (($_v0 = ($context["options"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["max"] ?? null) : null)))) ? ((($_v1 = ($context["options"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["max"] ?? null) : null)) : (0));
            // line 3
            yield "    ";
            $context["current"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "current", [], "array", true, true, false, 3) &&  !(null === (($_v2 = ($context["options"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["current"] ?? null) : null)))) ? ((($_v3 = ($context["options"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["current"] ?? null) : null)) : (0));
            // line 4
            yield "    ";
            $context["open"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "open", [], "array", true, true, false, 4) &&  !(null === (($_v4 = ($context["options"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["open"] ?? null) : null)))) ? ((($_v5 = ($context["options"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["open"] ?? null) : null)) : (null));
            // line 5
            yield "    ";
            $context["reverseColors"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "reverseColors", [], "array", true, true, false, 5) &&  !(null === (($_v6 = ($context["options"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["reverseColors"] ?? null) : null)))) ? ((($_v7 = ($context["options"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["reverseColors"] ?? null) : null)) : (false));
            // line 6
            yield "    ";
            $context["formatter"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "format", [], "array", true, true, false, 6) &&  !(null === (($_v8 = ($context["options"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["format"] ?? null) : null)))) ? ((($_v9 = ($context["options"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["format"] ?? null) : null)) : (null));
            // line 7
            yield "    ";
            $context["currency"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "array", true, true, false, 7) &&  !(null === (($_v10 = ($context["options"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["currency"] ?? null) : null)))) ? ((($_v11 = ($context["options"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["currency"] ?? null) : null)) : (null));
            // line 8
            yield "    ";
            $context["percentDecimals"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "decimals", [], "array", true, true, false, 8) &&  !(null === (($_v12 = ($context["options"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["decimals"] ?? null) : null)))) ? ((($_v13 = ($context["options"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["decimals"] ?? null) : null)) : (1));
            // line 9
            yield "    ";
            $context["transPercentOpen"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "trans_percent_open", [], "array", true, true, false, 9) &&  !(null === (($_v14 = ($context["options"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["trans_percent_open"] ?? null) : null)))) ? ((($_v15 = ($context["options"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["trans_percent_open"] ?? null) : null)) : ("stats.percentUsedLeft"));
            // line 10
            yield "    ";
            $context["transPercentSpent"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "trans_percent_spent", [], "array", true, true, false, 10) &&  !(null === (($_v16 = ($context["options"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["trans_percent_spent"] ?? null) : null)))) ? ((($_v17 = ($context["options"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["trans_percent_spent"] ?? null) : null)) : ("stats.percentUsed"));
            // line 11
            yield "    ";
            $context["outerClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "array", true, true, false, 11) &&  !(null === (($_v18 = ($context["options"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["class"] ?? null) : null)))) ? ((($_v19 = ($context["options"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["class"] ?? null) : null)) : (""));
            // line 12
            yield "    ";
            if ((($context["formatter"] ?? null) == "duration")) {
                // line 13
                yield "        ";
                $context["currentFormatted"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["current"] ?? null));
                // line 14
                yield "        ";
                $context["maxFormatted"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["max"] ?? null));
                // line 15
                yield "        ";
                $context["openFormatted"] = (( !(null === ($context["open"] ?? null))) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["open"] ?? null))) : (null));
                // line 16
                yield "    ";
            } elseif (((($context["formatter"] ?? null) == "money") &&  !(null === ($context["currency"] ?? null)))) {
                // line 17
                yield "        ";
                $context["currentFormatted"] = $this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["current"] ?? null), ($context["currency"] ?? null));
                // line 18
                yield "        ";
                $context["maxFormatted"] = $this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["max"] ?? null), ($context["currency"] ?? null));
                // line 19
                yield "        ";
                $context["openFormatted"] = (( !(null === ($context["open"] ?? null))) ? ($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["open"] ?? null), ($context["currency"] ?? null))) : (null));
                // line 20
                yield "    ";
            } else {
                // line 21
                yield "        ";
                $context["currentFormatted"] = ($context["current"] ?? null);
                // line 22
                yield "        ";
                $context["maxFormatted"] = ($context["max"] ?? null);
                // line 23
                yield "        ";
                $context["openFormatted"] = (( !(null === ($context["open"] ?? null))) ? (($context["open"] ?? null)) : (null));
                // line 24
                yield "    ";
            }
            // line 25
            yield "    ";
            $context["percentReached"] = 0;
            // line 26
            yield "    ";
            if ((($context["max"] ?? null) > 0)) {
                // line 27
                yield "        ";
                $context["percentReached"] = (($context["current"] ?? null) / (($context["max"] ?? null) / 100));
                // line 28
                yield "    ";
            }
            // line 29
            yield "    ";
            $context["width"] = $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 1, ".", "");
            // line 30
            yield "
    ";
            // line 31
            if ((($context["width"] ?? null) > 100)) {
                // line 32
                yield "        ";
                $context["width"] = 100;
                // line 33
                yield "    ";
            }
            // line 34
            yield "
    <div class=\"progress-group ";
            // line 35
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["outerClass"] ?? null), "html", null, true);
            yield "\">
        <div class=\"progress-title\">
            <span class=\"progress-text\">
                ";
            // line 38
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["currentFormatted"] ?? null), "html", null, true);
            yield "
            </span>
            <span class=\"progress-number text-end\">
                <strong>
                    ";
            // line 42
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["maxFormatted"] ?? null), "html", null, true);
            yield "
                </strong>
            </span>
        </div>
        <div class=\"progress\">
            <div class=\"progress-bar ";
            // line 47
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->getProgressbarClass(($context["percentReached"] ?? null), ($context["reverseColors"] ?? null)), "html", null, true);
            yield "\" role=\"progressbar\" aria-valuenow=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "%\"></div>
        </div>
        ";
            // line 49
            if (( !(null === ($context["open"] ?? null)) && (($context["open"] ?? null) > 0))) {
                // line 50
                yield "            <small>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["transPercentOpen"] ?? null), ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), ($context["percentDecimals"] ?? null)), "%left%" => ($context["openFormatted"] ?? null)]), "html", null, true);
                yield "</small>
        ";
            } else {
                // line 52
                yield "            <small>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["transPercentSpent"] ?? null), ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), ($context["percentDecimals"] ?? null))]), "html", null, true);
                yield "</small>
        ";
            }
            // line 54
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 57
    public function macro_progressbar($max = null, $current = null, $title = null, $subTitle = null, $reverseColors = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "max" => $max,
            "current" => $current,
            "title" => $title,
            "subTitle" => $subTitle,
            "reverseColors" => $reverseColors,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 58
            yield "    ";
            $context["percentReached"] = 0;
            // line 59
            yield "    ";
            if ((($context["max"] ?? null) > 0)) {
                // line 60
                yield "        ";
                $context["percentReached"] = (($context["current"] ?? null) / (($context["max"] ?? null) / 100));
                // line 61
                yield "    ";
            }
            // line 62
            yield "    ";
            $context["width"] = $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 1, ".", "");
            // line 63
            yield "
    ";
            // line 64
            if ((($context["width"] ?? null) > 100)) {
                // line 65
                yield "        ";
                $context["width"] = 100;
                // line 66
                yield "    ";
            }
            // line 67
            yield "
    <div class=\"progress-group\">
        <div class=\"progress-title\">
            <span class=\"progress-text\">
                ";
            // line 71
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "
                ";
            // line 72
            if (((($context["percentReached"] ?? null) >= 0) &&  !Twig\Extension\CoreExtension::testEmpty(($context["subTitle"] ?? null)))) {
                yield " &ndash; ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 2), "html", null, true);
                yield "%";
            }
            // line 73
            yield "            </span>
            <span class=\"progress-number text-end\">
                ";
            // line 75
            if (((($context["percentReached"] ?? null) >= 0) && Twig\Extension\CoreExtension::testEmpty(($context["subTitle"] ?? null)))) {
                // line 76
                yield "                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 2), "html", null, true);
                yield "%
                ";
            } elseif ( !Twig\Extension\CoreExtension::testEmpty(            // line 77
($context["subTitle"] ?? null))) {
                // line 78
                yield "                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["subTitle"] ?? null), "html", null, true);
                yield "
                ";
            }
            // line 80
            yield "            </span>
        </div>
        <div class=\"progress\">
            <div class=\"progress-bar ";
            // line 83
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->getProgressbarClass(($context["percentReached"] ?? null), ($context["reverseColors"] ?? null)), "html", null, true);
            yield "\" role=\"progressbar\" aria-valuenow=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "%\"></div>
        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 88
    public function macro_progressbar_small($max = null, $current = null, $leftValue = null, $leftFormatted = null, $reverseColors = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "max" => $max,
            "current" => $current,
            "leftValue" => $leftValue,
            "leftFormatted" => $leftFormatted,
            "reverseColors" => $reverseColors,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 89
            yield "    ";
            $context["percentReached"] = 0;
            // line 90
            yield "    ";
            if ((($context["max"] ?? null) > 0)) {
                // line 91
                yield "        ";
                $context["percentReached"] = (($context["current"] ?? null) / (($context["max"] ?? null) / 100));
                // line 92
                yield "    ";
            }
            // line 93
            yield "    ";
            $context["width"] = $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 1, ".", "");
            // line 94
            yield "
    ";
            // line 95
            if ((($context["width"] ?? null) > 100)) {
                // line 96
                yield "        ";
                $context["width"] = 100;
                // line 97
                yield "    ";
            }
            // line 98
            yield "
    <div class=\"progress-group\">
        <div class=\"progress progress-sm\">
            <div class=\"progress-bar ";
            // line 101
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->getProgressbarClass(($context["percentReached"] ?? null), ($context["reverseColors"] ?? null)), "html", null, true);
            yield "\" role=\"progressbar\" aria-valuenow=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "\" aria-valuemin=\"0\" aria-valuemax=\"100\" style=\"width: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["width"] ?? null), "html", null, true);
            yield "%\"></div>
        </div>
        ";
            // line 103
            if (( !(null === ($context["leftValue"] ?? null)) && (($context["leftValue"] ?? null) > 0))) {
                // line 104
                yield "            <small>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsedLeft", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 0), "%left%" => ($context["leftFormatted"] ?? null)]), "html", null, true);
                yield "</small>
        ";
            } else {
                // line 106
                yield "            <small>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsed", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentReached"] ?? null), 0)]), "html", null, true);
                yield "</small>
        ";
            }
            // line 108
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 115
    public function macro_progressbar_budget($budgetStatisticModel = null, $currency = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "budgetStatisticModel" => $budgetStatisticModel,
            "currency" => $currency,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 116
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "hasBudget", [], "method", false, false, false, 116)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 117
                yield "        ";
                $context["options"] = ["max" => CoreExtension::getAttribute($this->env, $this->source,                 // line 118
($context["budgetStatisticModel"] ?? null), "getBudget", [], "method", false, false, false, 118), "current" => CoreExtension::getAttribute($this->env, $this->source,                 // line 119
($context["budgetStatisticModel"] ?? null), "getBudgetSpent", [], "method", false, false, false, 119), "open" => CoreExtension::getAttribute($this->env, $this->source,                 // line 120
($context["budgetStatisticModel"] ?? null), "getBudgetOpen", [], "method", false, false, false, 120), "format" => "money", "currency" =>                 // line 122
($context["currency"] ?? null)];
                // line 124
                yield "        ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 124)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 125
                    yield "            ";
                    $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["trans_percent_open" => "stats.percentUsedLeft_month", "trans_percent_spent" => "stats.percentUsed_month"]);
                    // line 129
                    yield "        ";
                }
                // line 130
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_progressbar_full", $context, 130, $this->getSourceContext())->macro_progressbar_full(...[($context["options"] ?? null)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 137
    public function macro_progressbar_timebudget($budgetStatisticModel = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "budgetStatisticModel" => $budgetStatisticModel,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 138
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "hasTimeBudget", [], "method", false, false, false, 138)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 139
                yield "        ";
                $context["options"] = ["max" => CoreExtension::getAttribute($this->env, $this->source,                 // line 140
($context["budgetStatisticModel"] ?? null), "getTimeBudget", [], "method", false, false, false, 140), "current" => CoreExtension::getAttribute($this->env, $this->source,                 // line 141
($context["budgetStatisticModel"] ?? null), "getTimeBudgetSpent", [], "method", false, false, false, 141), "open" => CoreExtension::getAttribute($this->env, $this->source,                 // line 142
($context["budgetStatisticModel"] ?? null), "getTimeBudgetOpen", [], "method", false, false, false, 142), "format" => "duration"];
                // line 145
                yield "        ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 145)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 146
                    yield "            ";
                    $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["trans_percent_open" => "stats.percentUsedLeft_month", "trans_percent_spent" => "stats.percentUsed_month"]);
                    // line 150
                    yield "        ";
                }
                // line 151
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_progressbar_full", $context, 151, $this->getSourceContext())->macro_progressbar_full(...[($context["options"] ?? null)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/progressbar.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  464 => 151,  461 => 150,  458 => 146,  455 => 145,  453 => 142,  452 => 141,  451 => 140,  449 => 139,  446 => 138,  434 => 137,  424 => 130,  421 => 129,  418 => 125,  415 => 124,  413 => 122,  412 => 120,  411 => 119,  410 => 118,  408 => 117,  405 => 116,  392 => 115,  385 => 108,  379 => 106,  373 => 104,  371 => 103,  362 => 101,  357 => 98,  354 => 97,  351 => 96,  349 => 95,  346 => 94,  343 => 93,  340 => 92,  337 => 91,  334 => 90,  331 => 89,  315 => 88,  301 => 83,  296 => 80,  290 => 78,  288 => 77,  283 => 76,  281 => 75,  277 => 73,  271 => 72,  267 => 71,  261 => 67,  258 => 66,  255 => 65,  253 => 64,  250 => 63,  247 => 62,  244 => 61,  241 => 60,  238 => 59,  235 => 58,  219 => 57,  212 => 54,  206 => 52,  200 => 50,  198 => 49,  189 => 47,  181 => 42,  174 => 38,  168 => 35,  165 => 34,  162 => 33,  159 => 32,  157 => 31,  154 => 30,  151 => 29,  148 => 28,  145 => 27,  142 => 26,  139 => 25,  136 => 24,  133 => 23,  130 => 22,  127 => 21,  124 => 20,  121 => 19,  118 => 18,  115 => 17,  112 => 16,  109 => 15,  106 => 14,  103 => 13,  100 => 12,  97 => 11,  94 => 10,  91 => 9,  88 => 8,  85 => 7,  82 => 6,  79 => 5,  76 => 4,  73 => 3,  70 => 2,  58 => 1,  52 => 133,  49 => 110,  46 => 87,  43 => 56,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/progressbar.html.twig", "/opt/kimai/templates/macros/progressbar.html.twig");
    }
}
