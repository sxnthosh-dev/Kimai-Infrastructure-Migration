<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* customer/actions.html.twig */
class __TwigTemplate_f8090e296925d79e3026bddd79e2e569 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_customer($customer = null, $view = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "customer" => $customer,
            "view" => $view,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 3), "customer", ($context["view"] ?? null), ["customer" => ($context["customer"] ?? null)]);
            // line 4
            yield "    ";
            if (((($context["view"] ?? null) == "index") || (($context["view"] ?? null) == "custom"))) {
                // line 5
                yield "        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 5, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 5)]);
                yield "
    ";
            } else {
                // line 7
                yield "        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_page_actions", $context, 7, $this->getSourceContext())->macro_page_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 7)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/actions.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  75 => 7,  69 => 5,  66 => 4,  63 => 3,  60 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/actions.html.twig", "/opt/kimai/templates/customer/actions.html.twig");
    }
}
