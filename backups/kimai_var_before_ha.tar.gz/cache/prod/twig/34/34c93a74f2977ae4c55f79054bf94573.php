<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/renderer/timesheet.pdf.twig */
class __TwigTemplate_dca1d2fb0b5f697c95144a17682adf31 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'description' => [$this, 'block_description'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "export/pdf-layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["showRateColumn"] = false;
        // line 3
        $context["showRateBudget"] = false;
        // line 4
        $context["showTimeBudget"] = false;
        // line 5
        $context["showUserColumn"] = true;
        // line 6
        $context["showCustomerSummary"] = false;
        // line 7
        $context["decimal"] = true;
        // line 8
        $context["showDateTimeShort"] = true;
        // line 1
        $this->parent = $this->load("export/pdf-layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timesheet"), "html", null, true);
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_description(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "    ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 11))) {
            // line 12
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 12));
            yield "
    ";
        } elseif ( !(null === CoreExtension::getAttribute($this->env, $this->source,         // line 13
($context["entry"] ?? null), "activity", [], "any", false, false, false, 13))) {
            // line 14
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 14), "name", [], "any", false, false, false, 14), "html", null, true);
            yield "
    ";
        }
        // line 16
        yield "    <br>
    <small>";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 17), "customer", [], "any", false, false, false, 17), "name", [], "any", false, false, false, 17), "html", null, true);
        yield ", ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 17), "name", [], "any", false, false, false, 17), "html", null, true);
        yield "</small>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/renderer/timesheet.pdf.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  105 => 17,  102 => 16,  96 => 14,  94 => 13,  89 => 12,  86 => 11,  79 => 10,  68 => 9,  63 => 1,  61 => 8,  59 => 7,  57 => 6,  55 => 5,  53 => 4,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/renderer/timesheet.pdf.twig", "/opt/kimai/templates/export/renderer/timesheet.pdf.twig");
    }
}
