<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-yearchart.html.twig */
class __TwigTemplate_f5d6347fb2ca358517c841604d13d7f5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["backgroundColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.background_color");
        // line 2
        $context["borderColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.border_color");
        // line 3
        $context["gridColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.grid_color");
        // line 4
        $context["colors"] = Twig\Extension\CoreExtension::split($this->env->getCharset(), ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 4)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 4), "")) : ("")), ";");
        // line 5
        $context["type"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", false, false, false, 5), "line")) : ("line"));
        // line 6
        if (!CoreExtension::inFilter(($context["type"] ?? null), ["line", "bar"])) {
            // line 7
            yield "    ";
            $context["type"] = "line";
        }
        // line 9
        yield "
";
        // line 10
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["title"] ?? null))) {
            // line 11
            yield "<p class=\"text-center\">
    <strong>
        ";
            // line 13
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
            yield "
    </strong>
</p>
";
        }
        // line 17
        yield "
<div class=\"chart\">
    <canvas id=\"timeChart\" style=\"height: ";
        // line 19
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height"), "html", null, true);
        yield "px;\"></canvas>
</div>

<script type=\"text/javascript\">
document.addEventListener(\x27kimai.initialized\x27, function() {
    new Chart(
        document.getElementById(\x27timeChart\x27).getContext(\x272d\x27), {
            type: \x27";
        // line 26
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["type"] ?? null), "html", null, true);
        yield "\x27,
            data: {
                labels: ";
        // line 28
        yield (string) json_encode($this->extensions['App\Twig\LocaleFormatExtensions']->getMonthNames());
        yield ",
                datasets: [
                ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["yearName"] => $context["year"]) {
            // line 31
            yield "                    ";
            $context["yearBackgroundColor"] = ($context["backgroundColor"] ?? null);
            // line 32
            yield "                    ";
            $context["yearBorderColor"] = ($context["borderColor"] ?? null);
            // line 33
            yield "
                    ";
            // line 34
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["colors"] ?? null), (CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 34) - 1), [], "array", true, true, false, 34)) {
                // line 35
                yield "                    ";
                $context["yearColors"] = Twig\Extension\CoreExtension::split($this->env->getCharset(), (($_v0 = ($context["colors"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = (CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 35) - 1)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null), "|");
                // line 36
                yield "                    ";
                if ((CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 0, [], "any", true, true, false, 36) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 0, [], "any", false, false, false, 36)))) {
                    // line 37
                    yield "                    ";
                    $context["yearBackgroundColor"] = CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 0, [], "any", false, false, false, 37);
                    // line 38
                    yield "                    ";
                    $context["yearBorderColor"] = CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 0, [], "any", false, false, false, 38);
                    // line 39
                    yield "                    ";
                    if ((CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 1, [], "any", true, true, false, 39) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 1, [], "any", false, false, false, 39)))) {
                        // line 40
                        yield "                    ";
                        $context["yearBorderColor"] = CoreExtension::getAttribute($this->env, $this->source, ($context["yearColors"] ?? null), 1, [], "any", false, false, false, 40);
                        // line 41
                        yield "                    ";
                    }
                    // line 42
                    yield "                    ";
                }
                // line 43
                yield "                    ";
            }
            // line 44
            yield "
                    {
                        label           : \x27";
            // line 46
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["yearName"], "html", null, true);
            yield "\x27,
                        backgroundColor : \x27";
            // line 47
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["yearBackgroundColor"] ?? null), "html", null, true);
            yield "\x27,
                        borderColor     : \x27";
            // line 48
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["yearBorderColor"] ?? null), "html", null, true);
            yield "\x27,
                        pointRadius     : 2,
                        borderWidth     : 1,
                        pointHitRadius  : 10,
                        lineTension     : 0.3,
                        data            : [
                            ";
            // line 54
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "months", [], "any", false, false, false, 54));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                // line 55
                yield "                            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "totalDuration", [], "any", false, false, false, 55)), "html", null, true);
                yield "
                            ";
                // line 56
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 56)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield ",";
                }
                // line 57
                yield "                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['month'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 58
            yield "                        ],
                        realData        : [
                            ";
            // line 60
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "months", [], "any", false, false, false, 60));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                // line 61
                yield "                            \x27";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "totalDuration", [], "any", false, false, false, 61)), "html", null, true);
                yield "\x27
                            ";
                // line 62
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 62)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield ",";
                }
                // line 63
                yield "                            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['month'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 64
            yield "                        ]
                    }
                    ";
            // line 66
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 66)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield ",";
            }
            // line 67
            yield "                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['yearName'], $context['year'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 68
        yield "                ]
            },
            options: {
                maintainAspectRatio: true,
                responsive: true,
                scales: {
                    x: {
                        gridLines: {
                            display: false
                        }
                    },
                    y: {
                        gridLines: {
                            display: true,
                            color: \x27";
        // line 82
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["gridColor"] ?? null), "html", null, true);
        yield "\x27,
                            lineWidth: 1
                        }
                    }
                },
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(tooltipItem) {
                                return tooltipItem.dataset.realData[tooltipItem.dataIndex];
                            }
                        }
                    }
                },
            }
        }
    );
});
</script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-yearchart.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  300 => 82,  284 => 68,  269 => 67,  265 => 66,  261 => 64,  246 => 63,  242 => 62,  237 => 61,  220 => 60,  216 => 58,  201 => 57,  197 => 56,  192 => 55,  175 => 54,  166 => 48,  162 => 47,  158 => 46,  154 => 44,  151 => 43,  148 => 42,  145 => 41,  142 => 40,  139 => 39,  136 => 38,  133 => 37,  130 => 36,  127 => 35,  125 => 34,  122 => 33,  119 => 32,  116 => 31,  99 => 30,  94 => 28,  89 => 26,  79 => 19,  75 => 17,  68 => 13,  64 => 11,  62 => 10,  59 => 9,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-yearchart.html.twig", "/opt/kimai/templates/widget/widget-yearchart.html.twig");
    }
}
