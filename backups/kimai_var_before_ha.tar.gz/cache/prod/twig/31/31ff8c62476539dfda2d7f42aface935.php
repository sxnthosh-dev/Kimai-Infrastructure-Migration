<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* wizard/layout.html.twig */
class __TwigTemplate_1497950b0975974fef3248816c77a649 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'container_size' => [$this, 'block_container_size'],
            'wizard_logo' => [$this, 'block_wizard_logo'],
            'wizard_before' => [$this, 'block_wizard_before'],
            'wizard_after' => [$this, 'block_wizard_after'],
            'wizard_progress_bar' => [$this, 'block_wizard_progress_bar'],
            'wizard_previous_button' => [$this, 'block_wizard_previous_button'],
            'wizard_next_button' => [$this, 'block_wizard_next_button'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@Tabler/wizard.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("@Tabler/components/button.html.twig", 2)->unwrap();
        // line 3
        $macros["_v1"] = $this->macros["_v1"] = $this->load("@Tabler/components/buttons.html.twig", 3)->unwrap();
        // line 4
        $macros["_v2"] = $this->macros["_v2"] = $this->load("@Tabler/components/progress_bar.html.twig", 4)->unwrap();
        // line 1
        $this->parent = $this->load("@Tabler/wizard.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html", null, true);
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "container-tight";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "    ";
        if (array_key_exists("form", $context)) {
            // line 12
            yield "        ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
            yield "
    ";
        }
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "    ";
        if (array_key_exists("form", $context)) {
            // line 18
            yield "        ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
            yield "
    ";
        }
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_progress_bar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "    ";
        if ((array_key_exists("percent", $context) &&  !(null === ($context["percent"] ?? null)))) {
            // line 24
            yield "        ";
            yield (string) $macros["_v2"]->getTemplateForMacro("macro_progress_bar", $context, 24, $this->getSourceContext())->macro_progress_bar(...[["value" => ($context["percent"] ?? null), "max" => 100, "min" => 0]]);
            yield "
    ";
        }
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_previous_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "    ";
        if ((array_key_exists("previous", $context) &&  !(null === ($context["previous"] ?? null)))) {
            // line 30
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_button", $context, 30, $this->getSourceContext())->macro_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Previous", [], "TablerBundle"), "combined" => true, "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["previous"] ?? null))], "link"]);
            yield "
    ";
        }
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_next_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "    ";
        if (array_key_exists("form", $context)) {
            // line 36
            yield "        ";
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_submit_button", $context, 36, $this->getSourceContext())->macro_submit_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Next", [], "TablerBundle"), "combined" => true], "primary"]);
            yield "
    ";
        } else {
            // line 38
            yield "        ";
            if ((array_key_exists("next", $context) &&  !(null === ($context["next"] ?? null)))) {
                // line 39
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_button", $context, 39, $this->getSourceContext())->macro_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Next", [], "TablerBundle"), "combined" => true, "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["next"] ?? null))], "primary"]);
                yield "
        ";
            }
            // line 41
            yield "    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "wizard/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  199 => 41,  193 => 39,  190 => 38,  184 => 36,  181 => 35,  174 => 34,  165 => 30,  162 => 29,  155 => 28,  146 => 24,  143 => 23,  136 => 22,  127 => 18,  124 => 17,  117 => 16,  108 => 12,  105 => 11,  98 => 10,  88 => 8,  77 => 7,  66 => 6,  61 => 1,  59 => 4,  57 => 3,  55 => 2,  48 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "wizard/layout.html.twig", "/opt/kimai/templates/wizard/layout.html.twig");
    }
}
