<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/fullpage.html.twig */
class __TwigTemplate_9ecf882c48b665c23f7257abc1cd3f6f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'html_start' => [$this, 'block_html_start'],
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body_start' => [$this, 'block_body_start'],
            'body_class' => [$this, 'block_body_class'],
            'after_body_start' => [$this, 'block_after_body_start'],
            'page_classes' => [$this, 'block_page_classes'],
            'page_content' => [$this, 'block_page_content'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!doctype html";
        yield from $this->unwrap()->yieldBlock('html_start', $context, $blocks);
        yield ">
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 2), "html", null, true);
        yield "\"";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 2)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " dir=\"rtl\"";
        }
        yield " data-bs-theme=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->theme(), "html", null, true);
        yield "\" data-bs-theme-base=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeBase", [], "method", false, false, false, 2), "html", null, true);
        yield "\" data-bs-theme-radius=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeRadius", [], "method", false, false, false, 2), "html", null, true);
        yield "\" data-bs-theme-primary=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemePrimary", [], "method", false, false, false, 2), "html", null, true);
        yield "\">
<head>
    ";
        // line 4
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 7
        yield "    <title>";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>
    ";
        // line 8
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 15
        yield "</head>
<body";
        // line 16
        yield from $this->unwrap()->yieldBlock('body_start', $context, $blocks);
        yield " class=\"d-flex flex-column ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->bodyClass("border-top-wide border-primary theme-light"), "html", null, true);
        yield " ";
        yield from $this->unwrap()->yieldBlock('body_class', $context, $blocks);
        yield "\">
";
        // line 17
        yield from $this->unwrap()->yieldBlock('after_body_start', $context, $blocks);
        // line 18
        yield "
<div class=\"";
        // line 19
        yield from $this->unwrap()->yieldBlock('page_classes', $context, $blocks);
        yield "\">
    ";
        // line 20
        yield from $this->unwrap()->yieldBlock('page_content', $context, $blocks);
        // line 21
        yield "</div>

";
        // line 23
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 26
        yield "</body>
</html>
";
        yield from [];
    }

    // line 1
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_html_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "        ";
        yield from $this->load("@Tabler/includes/html_head.html.twig", 5)->unwrap()->yield($context);
        // line 6
        yield "    ";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from         $this->unwrap()->yieldBlock("page_title", $context, $blocks);
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "        ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 10
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler-rtl.css"), "html", null, true);
            yield "\">
        ";
        } else {
            // line 12
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.css"), "html", null, true);
            yield "\">
        ";
        }
        // line 14
        yield "    ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "page page-center";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "    <script src=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.js"), "html", null, true);
        yield "\"></script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/fullpage.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  239 => 24,  232 => 23,  222 => 20,  211 => 19,  201 => 17,  182 => 16,  177 => 14,  171 => 12,  165 => 10,  162 => 9,  155 => 8,  144 => 7,  139 => 6,  136 => 5,  129 => 4,  119 => 1,  112 => 26,  110 => 23,  106 => 21,  104 => 20,  100 => 19,  97 => 18,  95 => 17,  87 => 16,  84 => 15,  82 => 8,  77 => 7,  75 => 4,  58 => 2,  53 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/fullpage.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/fullpage.html.twig");
    }
}
