<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/details.html.twig */
class __TwigTemplate_5fd4f10c9a25ab7e508abaf8baf00e4d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        $context["can_edit"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["project"] ?? null));
        // line 6
        yield "
    ";
        // line 7
        yield from $this->load("project/details.html.twig", 7, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        // line 147
        yield "
    ";
        // line 148
        yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("App\\Controller\\ProjectController::activitiesAction", ["project" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 148), "page" => 1]));
        yield "

    ";
        // line 150
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 151
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/rates-table.html.twig", ["id" => "project_rates_box", "entity" => ($context["project"] ?? null), "create_url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project_rate_add", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 151)]), "delete_route" => "delete_project_rate", "currency" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 151), "currency", [], "any", false, false, false, 151), "edit_route" => "admin_project_rate_edit"]);
            yield "
    ";
        }
        // line 153
        yield "
    ";
        // line 154
        if ( !(null === ($context["stats"] ?? null))) {
            // line 155
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/budgets.html.twig", ["entity" => ($context["project"] ?? null), "stats" => ($context["stats"] ?? null), "currency" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 155), "currency", [], "any", false, false, false, 155)]);
            yield "
    ";
        }
        // line 157
        yield "
    ";
        // line 158
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["boxes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["controller"]) {
            // line 159
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller($context["controller"], ["project" => ($context["project"] ?? null), "page" => 1]));
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['controller'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 161
        yield "
    ";
        // line 162
        if ( !(null === ($context["teams"] ?? null))) {
            // line 163
            yield "        ";
            $context["options"] = ["teams" => ($context["teams"] ?? null)];
            // line 164
            yield "        ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("permissions", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 165
                yield "            ";
                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_team")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 166
                    yield "                ";
                    $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_create" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("project_team_create", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 166)])]);
                    // line 167
                    yield "            ";
                }
                // line 168
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project_permissions", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 168)])]);
                // line 169
                yield "        ";
            }
            // line 170
            yield "        ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 170), "teams", [], "any", false, false, false, 170)) > 0)) {
                // line 171
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["empty_message" => "team.project_visibility_inherited"]);
                // line 172
                yield "        ";
            }
            // line 173
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/teams.html.twig", ($context["options"] ?? null));
            yield "
    ";
        }
        // line 175
        yield "
    ";
        // line 176
        if ( !(null === ($context["comments"] ?? null))) {
            // line 177
            yield "        ";
            $context["options"] = ["form" => ($context["commentForm"] ?? null), "comments" => ($context["comments"] ?? null)];
            // line 178
            yield "        ";
            if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 179
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_pin" => "toggle_project_comment_pin", "route_api_options" => ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 179)], "route_delete" => "delete_project_comment"]);
                // line 180
                yield "        ";
            }
            // line 181
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/comments.html.twig", ($context["options"] ?? null));
            yield "
    ";
        }
        // line 183
        yield "
";
        yield from [];
    }

    // line 186
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 187
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.commentUpdate kimai.customerTeamUpdate kimai.projectTeamUpdate kimai.activityTeamUpdate kimai.projectUpdate kimai.teamUpdate kimai.customerUpdate kimai.rateUpdate\x27);
        });
    </script>
    ";
        // line 193
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "project/duplicate-redirect.html.twig");
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  202 => 193,  192 => 187,  185 => 186,  179 => 183,  173 => 181,  170 => 180,  167 => 179,  164 => 178,  161 => 177,  159 => 176,  156 => 175,  150 => 173,  147 => 172,  144 => 171,  141 => 170,  138 => 169,  135 => 168,  132 => 167,  129 => 166,  126 => 165,  123 => 164,  120 => 163,  118 => 162,  115 => 161,  105 => 159,  101 => 158,  98 => 157,  92 => 155,  90 => 154,  87 => 153,  81 => 151,  79 => 150,  74 => 148,  71 => 147,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/details.html.twig", "/opt/kimai/templates/project/details.html.twig");
    }
}


/* project/details.html.twig */
class __TwigTemplate_5fd4f10c9a25ab7e508abaf8baf00e4d___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 7
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 8)->unwrap();
        // line 9
        $macros["customerActions"] = $this->macros["customerActions"] = $this->load("customer/actions.html.twig", 9)->unwrap();
        // line 7
        $this->parent = $this->load("@theme/embeds/card.html.twig", 7);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"project_details_box\"";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "            ";
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 13
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 13, $this->getSourceContext())->macro_card_tool_button(...["edit", ["class" => "modal-ajax-form open-edit", "title" => "edit", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 13)])]]);
            yield "
            ";
        }
        // line 15
        yield "        ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "            ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_dot", $context, 17, $this->getSourceContext())->macro_label_dot(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "name", [], "any", false, false, false, 17), CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "color", [], "any", false, false, false, 17)]);
        yield "
        ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "comment", [], "any", false, false, false, 20))) {
            // line 21
            yield "                <div class=\"comment p-3\">
                    ";
            // line 22
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentContent(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "comment", [], "any", false, false, false, 22), true);
            yield "
                </div>
            ";
        }
        // line 25
        yield "            <table class=\"table table-hover dataTable\">
                ";
        // line 26
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visible", [], "any", false, false, false, 26)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 27
            yield "                    <tr class=\"";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_class_project_row", $context, 27, $this->getSourceContext())->macro_class_project_row(...[($context["project"] ?? null), ($context["now"] ?? null)]);
            yield "\">
                        <th>";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("visible"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 30
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 30, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visible", [], "any", false, false, false, 30)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 34
        yield "                <tr ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_customer_row_attr", $context, 34, $this->getSourceContext())->macro_customer_row_attr(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 34), ($context["now"] ?? null)]);
        yield ">
                    <th>";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                    <td>
                        ";
        // line 37
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 37, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 37)]);
        yield "
                    </td>
                    <td class=\"w-min\">
                        ";
        // line 40
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 40, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 40), "teams", [], "any", false, false, false, 40)]);
        yield "
                    </td>
                    <td class=\"actions\">
                        ";
        // line 43
        yield (string) $macros["customerActions"]->getTemplateForMacro("macro_customer", $context, 43, $this->getSourceContext())->macro_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 43), "custom"]);
        yield "
                    </td>
                </tr>
                ";
        // line 46
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("details", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 47
            yield "                    ";
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "billable", [], "any", false, false, false, 47)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 48
                yield "                        <tr>
                            <th>";
                // line 49
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
                yield "</th>
                            <td colspan=\"3\">
                                ";
                // line 51
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 51, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "billable", [], "any", false, false, false, 51)]);
                yield "
                            </td>
                        </tr>
                    ";
            }
            // line 55
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "orderNumber", [], "any", false, false, false, 55))) {
                // line 56
                yield "                    <tr>
                        <th>";
                // line 57
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderNumber"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 59
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "orderNumber", [], "any", false, false, false, 59), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 63
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "orderDate", [], "any", false, false, false, 63))) {
                // line 64
                yield "                    <tr>
                        <th>";
                // line 65
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderDate"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 67
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "orderDate", [], "any", false, false, false, 67)), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 71
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 71))) {
                // line 72
                yield "                    <tr>
                        <th>";
                // line 73
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_start"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 75
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 75)), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 79
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 79))) {
                // line 80
                yield "                    <tr>
                        <th>";
                // line 81
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_end"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 83
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 83)), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 87
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "lockedUntil", [], "any", false, false, false, 87))) {
                // line 88
                yield "                    <tr>
                        <th>";
                // line 89
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_locked_until"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 91
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "lockedUntil", [], "any", false, false, false, 91)), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 95
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "number", [], "any", false, false, false, 95))) {
                // line 96
                yield "                    <tr>
                        <th>";
                // line 97
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_number"), "html", null, true);
                yield "</th>
                        <td colspan=\"3\">
                            ";
                // line 99
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "number", [], "any", false, false, false, 99), "html", null, true);
                yield "
                        </td>
                    </tr>
                    ";
            }
            // line 103
            yield "                ";
        }
        // line 104
        yield "                ";
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 104)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 105
            yield "                    <tr>
                        <th>
                            ";
            // line 107
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
            yield "
                            ";
            // line 108
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 108)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 109
                yield "                                (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
                yield ")
                            ";
            }
            // line 111
            yield "                        </th>
                        <td colspan=\"3\">
                            ";
            // line 113
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getBudget", [], "method", false, false, false, 113), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 113), "currency", [], "any", false, false, false, 113)), "html", null, true);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 117
        yield "                ";
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 117)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 118
            yield "                    <tr>
                        <th>
                            ";
            // line 120
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
            yield "
                            ";
            // line 121
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 121)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 122
                yield "                                (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
                yield ")
                            ";
            }
            // line 124
            yield "                        </th>
                        <td colspan=\"3\">
                            ";
            // line 126
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "getTimeBudget", [], "method", false, false, false, 126)), "html", null, true);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 130
        yield "                ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "globalActivities", [], "any", false, false, false, 130)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 131
            yield "                    <tr>
                        <th>";
            // line 132
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("globalActivities"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 134
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 134, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "globalActivities", [], "any", false, false, false, 134)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 138
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visibleMetaFields", [], "any", false, false, false, 138), function ($__field__) use ($context, $macros) { $context["field"] = $__field__; return CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "defined", [], "any", false, false, false, 138); }), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "order", [], "any", false, false, false, 138) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "order", [], "any", false, false, false, 138)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["metaField"]) {
            // line 139
            yield "                    <tr>
                        <th>";
            // line 140
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "label", [], "any", false, false, false, 140)), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">";
            // line 141
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_form_type_value", $context, 141, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "type", [], "any", false, false, false, 141), CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "value", [], "any", false, false, false, 141), ($context["project"] ?? null)]);
            yield "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['metaField'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 144
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  628 => 144,  618 => 141,  614 => 140,  611 => 139,  606 => 138,  599 => 134,  594 => 132,  591 => 131,  588 => 130,  581 => 126,  577 => 124,  571 => 122,  569 => 121,  565 => 120,  561 => 118,  558 => 117,  551 => 113,  547 => 111,  541 => 109,  539 => 108,  535 => 107,  531 => 105,  528 => 104,  525 => 103,  518 => 99,  513 => 97,  510 => 96,  507 => 95,  500 => 91,  495 => 89,  492 => 88,  489 => 87,  482 => 83,  477 => 81,  474 => 80,  471 => 79,  464 => 75,  459 => 73,  456 => 72,  453 => 71,  446 => 67,  441 => 65,  438 => 64,  435 => 63,  428 => 59,  423 => 57,  420 => 56,  417 => 55,  410 => 51,  405 => 49,  402 => 48,  399 => 47,  397 => 46,  391 => 43,  385 => 40,  379 => 37,  374 => 35,  369 => 34,  362 => 30,  357 => 28,  352 => 27,  350 => 26,  347 => 25,  341 => 22,  338 => 21,  335 => 20,  328 => 19,  320 => 17,  313 => 16,  308 => 15,  302 => 13,  299 => 12,  292 => 11,  281 => 10,  276 => 7,  274 => 9,  272 => 8,  265 => 7,  202 => 193,  192 => 187,  185 => 186,  179 => 183,  173 => 181,  170 => 180,  167 => 179,  164 => 178,  161 => 177,  159 => 176,  156 => 175,  150 => 173,  147 => 172,  144 => 171,  141 => 170,  138 => 169,  135 => 168,  132 => 167,  129 => 166,  126 => 165,  123 => 164,  120 => 163,  118 => 162,  115 => 161,  105 => 159,  101 => 158,  98 => 157,  92 => 155,  90 => 154,  87 => 153,  81 => 151,  79 => 150,  74 => 148,  71 => 147,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/details.html.twig", "/opt/kimai/templates/project/details.html.twig");
    }
}
