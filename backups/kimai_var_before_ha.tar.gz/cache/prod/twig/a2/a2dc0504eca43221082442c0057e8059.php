<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/card_vertical_navigation.html.twig */
class __TwigTemplate_a3c5f9063cc9dc08fce4a06d1a93fac9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'card_before' => [$this, 'block_card_before'],
            'card_class' => [$this, 'block_card_class'],
            'nav_before' => [$this, 'block_nav_before'],
            'nav_size' => [$this, 'block_nav_size'],
            'nav_border' => [$this, 'block_nav_border'],
            'nav_display' => [$this, 'block_nav_display'],
            'nav_list_class' => [$this, 'block_nav_list_class'],
            'nav_header_class' => [$this, 'block_nav_header_class'],
            'nav_after' => [$this, 'block_nav_after'],
            'content_before' => [$this, 'block_content_before'],
            'content_size' => [$this, 'block_content_size'],
            'content_display' => [$this, 'block_content_display'],
            'content_after' => [$this, 'block_content_after'],
            'card_after' => [$this, 'block_card_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        // line 2
        $context["_items"] = [];
        // line 3
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((((array_key_exists("items", $context) &&  !(null === $context["items"]))) ? ($context["items"]) : ([])));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 4
            yield "    ";
            if ( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", true, true, false, 4)) {
                // line 5
                yield "        ";
                // line 6
                yield "        ";
                $context["item"] = Twig\Extension\CoreExtension::merge($context["item"], ["id" => $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->uniqueId()]);
                // line 7
                yield "    ";
            }
            // line 8
            yield "
    ";
            // line 9
            $context["_items"] = Twig\Extension\CoreExtension::merge(($context["_items"] ?? null), [ (string)$context["key"] => $context["item"]]);
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 11
        yield "
";
        // line 12
        yield from $this->unwrap()->yieldBlock('card_before', $context, $blocks);
        // line 13
        yield "<div class=\"card ";
        yield from $this->unwrap()->yieldBlock('card_class', $context, $blocks);
        yield "\">
    <div class=\"row g-0\">

        ";
        // line 17
        yield "        ";
        yield from $this->unwrap()->yieldBlock('nav_before', $context, $blocks);
        // line 18
        yield "        <div class=\"";
        yield from $this->unwrap()->yieldBlock('nav_size', $context, $blocks);
        yield " ";
        yield from $this->unwrap()->yieldBlock('nav_border', $context, $blocks);
        yield " ";
        yield from $this->unwrap()->yieldBlock('nav_display', $context, $blocks);
        yield "\">
            <div class=\"card-body\">
                <div class=\"list-group ";
        // line 20
        yield from $this->unwrap()->yieldBlock('nav_list_class', $context, $blocks);
        yield "\">
                    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["_items"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 22
            yield "
                        ";
            // line 23
            $context["_id"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 23);
            // line 24
            yield "                        ";
            $context["_header"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", false, false, false, 24)) : (false));
            // line 25
            yield "                        ";
            $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", true, true, false, 25) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 25)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 25)) : (false));
            // line 26
            yield "                        ";
            $context["_name"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 26)) : (""));
            // line 27
            yield "                        ";
            if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 27)) {
                // line 28
                yield "                            ";
                // line 29
                yield "                            ";
                // line 30
                yield "                            ";
                $context["_href"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 30);
                // line 31
                yield "                        ";
            } else {
                // line 32
                yield "                            ";
                $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 32) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 32)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 32)) : (("#tabs-" . CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 32))));
                // line 33
                yield "                        ";
            }
            // line 34
            yield "                        ";
            $context["_raw"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", true, true, false, 34) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 34)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 34)) : (false));
            // line 35
            yield "
                        ";
            // line 36
            if ((($tmp = ($context["_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 37
                yield "                            <h4 class=\"subheader ";
                yield from $this->unwrap()->yieldBlock('nav_header_class', $context, $blocks);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_name"] ?? null), "html", null, true);
                yield "</h4>
                        ";
            } else {
                // line 39
                yield "                            <a
                                href=\"";
                // line 40
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
                yield "\"
                                class=\"list-group-item list-group-item-action d-flex align-items-center ";
                // line 41
                if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "active";
                }
                yield "\"
                                ";
                // line 43
                yield "                                ";
                if ((( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 43) &&  !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 43)) &&  !                $this->unwrap()->hasBlock("content", $context, $blocks))) {
                    yield "data-bs-toggle=\"tab\"";
                }
                // line 44
                yield "                            >
                                ";
                // line 45
                if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 46
                    yield "                                    ";
                    yield (string) ($context["_name"] ?? null);
                    yield "
                                ";
                } else {
                    // line 48
                    yield "                                    ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_name"] ?? null), "html", null, true);
                    yield "
                                ";
                }
                // line 50
                yield "                            </a>
                        ";
            }
            // line 52
            yield "                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['item'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 53
        yield "                </div>
            </div>
        </div>
        ";
        // line 56
        yield from $this->unwrap()->yieldBlock('nav_after', $context, $blocks);
        // line 57
        yield "
        ";
        // line 59
        yield "        ";
        yield from $this->unwrap()->yieldBlock('content_before', $context, $blocks);
        // line 60
        yield "        <div class=\"";
        yield from $this->unwrap()->yieldBlock('content_size', $context, $blocks);
        yield " ";
        yield from $this->unwrap()->yieldBlock('content_display', $context, $blocks);
        yield "\">
            <div class=\"card-body\">
                ";
        // line 62
        if (        $this->unwrap()->hasBlock("content", $context, $blocks)) {
            // line 63
            yield "                    ";
            yield from             $this->unwrap()->yieldBlock("content", $context, $blocks);
            yield "
                ";
        } else {
            // line 65
            yield "                    <div class=\"tab-content\">
                        ";
            // line 66
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["_items"] ?? null));
            foreach ($context['_seq'] as $context["key"] => $context["item"]) {
                // line 67
                yield "
                            ";
                // line 68
                $context["_id"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 68);
                // line 69
                yield "                            ";
                $context["_header"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", true, true, false, 69) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", false, false, false, 69)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "header", [], "any", false, false, false, 69)) : (false));
                // line 70
                yield "                            ";
                $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", true, true, false, 70) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 70)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 70)) : (false));
                // line 71
                yield "                            ";
                $context["_content"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", true, true, false, 71) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", false, false, false, 71)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", false, false, false, 71)) : (""));
                // line 72
                yield "
                            ";
                // line 73
                if ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "content", [], "any", true, true, false, 73) &&  !(($tmp = ($context["_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    // line 74
                    yield "                                <div class=\"tab-pane ";
                    if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield "active show";
                    }
                    yield "\"
                                     id=\"tabs-";
                    // line 75
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                    yield "\"
                                    ";
                    // line 77
                    yield "                                    ";
                    if (( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 77) &&  !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 77))) {
                        yield "role=\"tabpanel\"";
                    }
                    // line 78
                    yield "                                >
                                    ";
                    // line 79
                    yield (string) ($context["_content"] ?? null);
                    yield "
                                </div>
                            ";
                }
                // line 82
                yield "                        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 83
            yield "                    </div>
                ";
        }
        // line 85
        yield "            </div>
        </div>
        ";
        // line 87
        yield from $this->unwrap()->yieldBlock('content_after', $context, $blocks);
        // line 88
        yield "
    </div>
</div>
";
        // line 91
        yield from $this->unwrap()->yieldBlock('card_after', $context, $blocks);
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "mb-3";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "col-3";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_border(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "border-end";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_display(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "d-none d-md-block";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_list_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "list-group-transparent";
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "mx-4 mt-3";
        yield from [];
    }

    // line 56
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_nav_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 60
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "col";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content_display(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "d-flex flex-column";
        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 91
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card_vertical_navigation.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  478 => 91,  468 => 87,  447 => 60,  437 => 59,  427 => 56,  416 => 37,  405 => 20,  374 => 18,  364 => 17,  353 => 13,  343 => 12,  338 => 91,  333 => 88,  331 => 87,  327 => 85,  323 => 83,  316 => 82,  310 => 79,  307 => 78,  302 => 77,  298 => 75,  291 => 74,  289 => 73,  286 => 72,  283 => 71,  280 => 70,  277 => 69,  275 => 68,  272 => 67,  268 => 66,  265 => 65,  259 => 63,  257 => 62,  249 => 60,  246 => 59,  243 => 57,  241 => 56,  236 => 53,  221 => 52,  217 => 50,  211 => 48,  205 => 46,  203 => 45,  200 => 44,  195 => 43,  189 => 41,  185 => 40,  182 => 39,  174 => 37,  172 => 36,  169 => 35,  166 => 34,  163 => 33,  160 => 32,  157 => 31,  154 => 30,  152 => 29,  150 => 28,  147 => 27,  144 => 26,  141 => 25,  138 => 24,  136 => 23,  133 => 22,  116 => 21,  112 => 20,  102 => 18,  99 => 17,  92 => 13,  90 => 12,  87 => 11,  80 => 9,  77 => 8,  74 => 7,  71 => 6,  69 => 5,  66 => 4,  62 => 3,  60 => 2,  57 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card_vertical_navigation.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card_vertical_navigation.html.twig");
    }
}
