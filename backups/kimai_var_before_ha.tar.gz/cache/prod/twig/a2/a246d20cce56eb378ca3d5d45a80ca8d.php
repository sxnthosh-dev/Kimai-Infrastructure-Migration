<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-counter.html.twig */
class __TwigTemplate_341690a83a92101ed3898fe4ced23382 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'widget_data' => [$this, 'block_widget_data'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["url"] = null;
        // line 2
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "route", [], "any", true, true, false, 2)) {
            // line 3
            yield "    ";
            $context["url"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "route", [], "any", false, false, false, 3), ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "routeOptions", [], "any", true, true, false, 3)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "routeOptions", [], "any", false, false, false, 3), [])) : ([])));
        }
        // line 5
        $context["color"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 5), "green")) : ("green"));
        // line 6
        yield "
<div class=\"card card-sm\">
    <div class=\"card-body\">
        <div class=\"row align-items-center\">
            <div class=\"col-auto\">
                ";
        // line 11
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) {
            yield "<a href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
            yield "\">";
        }
        // line 12
        yield "                <span class=\"bg-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
        yield " text-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
        yield "-fg avatar\">
                    ";
        // line 13
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", false, false, false, 13), true);
        yield "
                </span>
                ";
        // line 15
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) {
            yield "</a>";
        }
        // line 16
        yield "            </div>
            <div class=\"col\">

                <div class=\"font-weight-medium\">
                    ";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
        yield "
                </div>
                <div class=\"text-body-secondary\">
                    ";
        // line 23
        yield from $this->unwrap()->yieldBlock('widget_data', $context, $blocks);
        // line 26
        yield "                </div>
            </div>
        </div>
    </div>
</div>
";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_widget_data(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["data"] ?? null), "html", null, true);
        yield "
                    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-counter.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  114 => 24,  107 => 23,  97 => 26,  95 => 23,  89 => 20,  83 => 16,  79 => 15,  74 => 13,  67 => 12,  61 => 11,  54 => 6,  52 => 5,  48 => 3,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-counter.html.twig", "/opt/kimai/templates/widget/widget-counter.html.twig");
    }
}
