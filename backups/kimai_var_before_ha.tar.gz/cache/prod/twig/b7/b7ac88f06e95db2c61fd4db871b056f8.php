<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* timesheet/index.html.twig */
class __TwigTemplate_8cfeb692c05df3d770660fb7afde79a5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_outer' => [$this, 'block_datatable_outer'],
            'datatable_row' => [$this, 'block_datatable_row'],
            'status' => [$this, 'block_status'],
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column' => [$this, 'block_datatable_column'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_outer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    ";
        $context["checkOverlappingDesc"] = false;
        // line 7
        yield "    ";
        $context["checkOverlappingAsc"] = false;
        // line 8
        yield "    ";
        $context["query"] = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getQuery", [], "method", false, false, false, 8);
        // line 9
        yield "    ";
        if (((CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "orderBy", [], "any", false, false, false, 9) == "begin") || (CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "orderBy", [], "any", false, false, false, 9) == "end"))) {
            // line 10
            yield "        ";
            $context["checkOverlappingDesc"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "order", [], "any", false, false, false, 10) == "DESC");
            // line 11
            yield "        ";
            $context["checkOverlappingAsc"] =  !(($tmp = ($context["checkOverlappingDesc"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp);
            // line 12
            yield "    ";
        }
        // line 13
        yield "
    ";
        // line 14
        $context["day"] = null;
        // line 15
        yield "    ";
        $context["dayDuration"] = 0;
        // line 16
        yield "    ";
        $context["dayRate"] = [];
        // line 17
        yield "    ";
        $context["dayInternalRate"] = [];
        // line 18
        yield "    ";
        $context["dayHourlyRate"] = 0;
        // line 19
        yield "    ";
        $context["lastEntry"] = null;
        // line 20
        yield "
    ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["dataTable"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 22
            if ((($context["day"] ?? null) === null)) {
                // line 23
                $context["day"] = $this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 23));
                // line 24
                yield "        ";
            }
            // line 25
            if (((($tmp = ($context["showSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($context["day"] ?? null) === $this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 25))))) {
                // line 26
                yield (string) $this->getTemplateForMacro("macro_summary", $context, 26, $this->getSourceContext())->macro_summary(...[($context["day"] ?? null), ($context["dayDuration"] ?? null), ($context["dayHourlyRate"] ?? null), ($context["dayInternalRate"] ?? null), ($context["dayRate"] ?? null), ($context["sortedColumns"] ?? null), ($context["dataTable"] ?? null)]);
                yield "
            ";
                // line 27
                $context["day"] = $this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 27));
                // line 28
                yield "            ";
                $context["dayDuration"] = 0;
                // line 29
                yield "            ";
                $context["dayRate"] = [];
                // line 30
                yield "            ";
                $context["dayInternalRate"] = [];
                // line 31
                yield "            ";
                $context["dayHourlyRate"] = 0;
            }
            // line 33
            $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 33), "customer", [], "any", false, false, false, 33), "currency", [], "any", false, false, false, 33);
            // line 34
            $context["entryHourlyRate"] = $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 34), ($context["customerCurrency"] ?? null));
            // line 35
            yield from $this->unwrap()->yieldBlock('datatable_row', $context, $blocks);
            // line 42
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 42)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 43
                if ( !CoreExtension::getAttribute($this->env, $this->source, ($context["dayRate"] ?? null), ($context["customerCurrency"] ?? null), [], "array", true, true, false, 43)) {
                    // line 44
                    yield "                ";
                    $context["dayRate"] = Twig\Extension\CoreExtension::merge(($context["dayRate"] ?? null), [ (string)($context["customerCurrency"] ?? null) => 0]);
                    // line 45
                    yield "            ";
                }
                // line 46
                yield "            ";
                if ( !CoreExtension::getAttribute($this->env, $this->source, ($context["dayInternalRate"] ?? null), ($context["customerCurrency"] ?? null), [], "array", true, true, false, 46)) {
                    // line 47
                    yield "                ";
                    $context["dayInternalRate"] = Twig\Extension\CoreExtension::merge(($context["dayInternalRate"] ?? null), [ (string)($context["customerCurrency"] ?? null) => 0]);
                    // line 48
                    yield "            ";
                }
                // line 49
                yield "            ";
                $context["dayRate"] = Twig\Extension\CoreExtension::merge(($context["dayRate"] ?? null), [ (string)($context["customerCurrency"] ?? null) => ((($_v0 = ($context["dayRate"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = ($context["customerCurrency"] ?? null)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 49))]);
                // line 50
                yield "            ";
                $context["dayInternalRate"] = Twig\Extension\CoreExtension::merge(($context["dayInternalRate"] ?? null), [ (string)($context["customerCurrency"] ?? null) => ((($_v2 = ($context["dayInternalRate"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = ($context["customerCurrency"] ?? null)) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 50))]);
            }
            // line 52
            if ( !(null === ($context["dayHourlyRate"] ?? null))) {
                // line 53
                yield "            ";
                if ((($context["dayHourlyRate"] ?? null) == 0)) {
                    // line 54
                    yield "                ";
                    $context["dayHourlyRate"] = ($context["entryHourlyRate"] ?? null);
                    // line 55
                    yield "            ";
                } elseif ((($context["dayHourlyRate"] ?? null) != ($context["entryHourlyRate"] ?? null))) {
                    // line 56
                    yield "                ";
                    $context["dayHourlyRate"] = null;
                    // line 57
                    yield "            ";
                }
                // line 58
                yield "        ";
            }
            // line 59
            $context["dayDuration"] = (($context["dayDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 59));
            // line 60
            $context["lastEntry"] = $context["entry"];
            // line 61
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 62
        yield "    ";
        if ((($tmp = ($context["showSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 63
            yield "        ";
            yield (string) $this->getTemplateForMacro("macro_summary", $context, 63, $this->getSourceContext())->macro_summary(...[($context["day"] ?? null), ($context["dayDuration"] ?? null), ($context["dayHourlyRate"] ?? null), ($context["dayInternalRate"] ?? null), ($context["dayRate"] ?? null), ($context["sortedColumns"] ?? null), ($context["dataTable"] ?? null)]);
            yield "
    ";
        }
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "            <tr";
        yield from         $this->unwrap()->yieldBlock("datatable_row_attr", $context, $blocks);
        yield ">
                ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sortedColumns"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["column"] => $context["data"]) {
            // line 38
            yield "                    ";
            yield from             $this->unwrap()->yieldBlock("datatable_column", $context, $blocks);
            yield "
                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['column'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 40
        yield "            </tr>
        ";
        yield from [];
    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "    ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 68) > 0)) {
            // line 69
            yield "        ";
            $macros["_v4"] = $this->load("macros/status.html.twig", 69)->unwrap();
            // line 70
            yield "        ";
            yield (string) $macros["_v4"]->getTemplateForMacro("macro_status_duration", $context, 70, $this->getSourceContext())->macro_status_duration(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 70))]);
            yield "
    ";
        }
        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 75
        yield "    ";
        $context["class"] = "";
        // line 76
        yield "    ";
        if (((($tmp = ($context["checkOverlappingDesc"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = ($context["checkOverlappingAsc"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 77
            yield "        ";
            if ((( !(null === ($context["lastEntry"] ?? null)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 77))) && (CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "user", [], "any", false, false, false, 77) === CoreExtension::getAttribute($this->env, $this->source, ($context["lastEntry"] ?? null), "user", [], "any", false, false, false, 77)))) {
                // line 78
                yield "            ";
                if (((($tmp = ($context["checkOverlappingDesc"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 78), "timestamp", [], "any", false, false, false, 78) > CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["lastEntry"] ?? null), "begin", [], "any", false, false, false, 78), "timestamp", [], "any", false, false, false, 78)))) {
                    // line 79
                    yield "                ";
                    $context["class"] = (($context["class"] ?? null) . " overlapping");
                    // line 80
                    yield "            ";
                } elseif ((((($tmp = ($context["checkOverlappingAsc"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["lastEntry"] ?? null), "end", [], "any", false, false, false, 80))) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 80), "timestamp", [], "any", false, false, false, 80) < CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["lastEntry"] ?? null), "end", [], "any", false, false, false, 80), "timestamp", [], "any", false, false, false, 80)))) {
                    // line 81
                    yield "                ";
                    $context["class"] = (($context["class"] ?? null) . " overlapping");
                    // line 82
                    yield "            ";
                }
                // line 83
                yield "        ";
            }
            // line 84
            yield "    ";
        }
        // line 85
        yield "    ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 85)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 86
            yield "        ";
            $context["class"] = (($context["class"] ?? null) . " recording");
            // line 87
            yield "    ";
        }
        // line 88
        yield "    ";
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " class=\"modal-ajax-form open-edit";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["editRoute"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 88)]), "html", null, true);
            yield "\"";
        }
        yield from [];
    }

    // line 91
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 92
        yield "    <td class=\"";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 92, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), ($context["column"] ?? null)]);
        if ((($context["column"] ?? null) == "description")) {
            yield " timesheet-description";
        }
        yield "\">
    ";
        // line 93
        if ((($context["column"] ?? null) == "id")) {
            // line 94
            yield "        ";
            if (((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("delete", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 95
                yield "            ";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_multiupdate_row", $context, 95, $this->getSourceContext())->macro_datatable_multiupdate_row(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 95)]);
                yield "
        ";
            }
            // line 97
            yield "    ";
        } elseif ((($context["column"] ?? null) == "date")) {
            // line 98
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 98)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 99
($context["column"] ?? null) == "starttime")) {
            // line 100
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 100)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 101
($context["column"] ?? null) == "endtime")) {
            // line 102
            yield "        ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 102)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 103
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 103)), "html", null, true);
                yield "
        ";
            } else {
                // line 105
                yield "            &dash;
        ";
            }
            // line 107
            yield "    ";
        } elseif ((($context["column"] ?? null) == "duration")) {
            // line 108
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_duration", $context, 108, $this->getSourceContext())->macro_duration(...[($context["entry"] ?? null)]);
            yield "
    ";
        } elseif ((        // line 109
($context["column"] ?? null) == "break")) {
            // line 110
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "break", [], "any", false, false, false, 110)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 111
($context["column"] ?? null) == "hourlyRate")) {
            // line 112
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["entryHourlyRate"] ?? null), "html", null, true);
            yield "
    ";
        } elseif ((        // line 113
($context["column"] ?? null) == "rate")) {
            // line 114
            yield "        ";
            if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 114)) && $tmp instanceof Markup ? (string) $tmp : $tmp) ||  !(($tmp = ($context["view_rate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 115
                yield "            &dash;
        ";
            } else {
                // line 117
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "rate", [], "any", false, false, false, 117), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "
        ";
            }
            // line 119
            yield "    ";
        } elseif ((($context["column"] ?? null) == "internalRate")) {
            // line 120
            yield "        ";
            if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 120)) && $tmp instanceof Markup ? (string) $tmp : $tmp) ||  !(($tmp = ($context["view_rate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 121
                yield "            &dash;
        ";
            } else {
                // line 123
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "internalRate", [], "any", false, false, false, 123), ($context["customerCurrency"] ?? null)), "html", null, true);
                yield "
        ";
            }
            // line 125
            yield "    ";
        } elseif ((($context["column"] ?? null) == "customer")) {
            // line 126
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 126, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 126), "customer", [], "any", false, false, false, 126)]);
            yield "
    ";
        } elseif ((        // line 127
($context["column"] ?? null) == "project")) {
            // line 128
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 128, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 128)]);
            yield "
    ";
        } elseif ((        // line 129
($context["column"] ?? null) == "activity")) {
            // line 130
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 130))) {
                // line 131
                yield "            ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 131, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 131)]);
                yield "
        ";
            }
            // line 133
            yield "    ";
        } elseif ((($context["column"] ?? null) == "description")) {
            // line 134
            yield "        ";
            if ((($tmp = ($context["allowMarkdown"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 135
                yield "            ";
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 135));
                yield "
        ";
            } else {
                // line 137
                yield "            ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 137), "html", null, true));
                yield "
        ";
            }
            // line 139
            yield "    ";
        } elseif ((($context["column"] ?? null) == "tags")) {
            // line 140
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_tag_list", $context, 140, $this->getSourceContext())->macro_tag_list(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "tags", [], "any", false, false, false, 140)]);
            yield "
    ";
        } elseif ((        // line 141
($context["column"] ?? null) == "billable")) {
            // line 142
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 142, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "billable", [], "any", false, false, false, 142)]);
            yield "
    ";
        } elseif ((        // line 143
($context["column"] ?? null) == "exported")) {
            // line 144
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 144, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "exported", [], "any", false, false, false, 144)]);
            yield "
    ";
        } elseif ((        // line 145
($context["column"] ?? null) == "username")) {
            // line 146
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_user", $context, 146, $this->getSourceContext())->macro_label_user(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "user", [], "any", false, false, false, 146)]);
            yield "
    ";
        } elseif ((        // line 147
($context["column"] ?? null) == "actions")) {
            // line 148
            yield "        ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 148), ($context["action_single"] ?? null), "index", ["timesheet" => ($context["entry"] ?? null)]);
            // line 149
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 149, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 149)]);
            yield "
    ";
        } elseif ((is_string($_v5 =         // line 150
($context["column"] ?? null)) && is_string($_v6 = "mf_") && str_starts_with($_v5, $_v6))) {
            // line 151
            yield "            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_meta_field_value", $context, 151, $this->getSourceContext())->macro_meta_field_value(...[($context["entry"] ?? null), ($context["data"] ?? null)]);
            yield "
    ";
        }
        // line 153
        yield "    </td>
";
        yield from [];
    }

    // line 156
    public function macro_summary($day = null, $duration = null, $dayHourlyRate = null, $dayInternalRates = null, $dayRates = null, $sortedColumns = null, $dataTable = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "day" => $day,
            "duration" => $duration,
            "dayHourlyRate" => $dayHourlyRate,
            "dayInternalRates" => $dayInternalRates,
            "dayRates" => $dayRates,
            "sortedColumns" => $sortedColumns,
            "dataTable" => $dataTable,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 157
            yield "    ";
            $macros["tables"] = $this->load("macros/datatables.html.twig", 157)->unwrap();
            // line 158
            yield "    <tr class=\"summary info\">
    ";
            // line 159
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["sortedColumns"] ?? null));
            foreach ($context['_seq'] as $context["column"] => $context["data"]) {
                // line 160
                yield "        <td class=\"";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 160, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), $context["column"]]);
                yield "\">
        ";
                // line 161
                if (($context["column"] == "date")) {
                    // line 162
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["day"] ?? null), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 163
$context["column"] == "duration")) {
                    // line 164
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["duration"] ?? null)), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 165
$context["column"] == "hourlyRate")) {
                    // line 166
                    yield "            ";
                    if (( !(null === ($context["dayHourlyRate"] ?? null)) && (($context["dayHourlyRate"] ?? null) != 0))) {
                        // line 167
                        yield "                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["dayHourlyRate"] ?? null), "html", null, true);
                        yield "
            ";
                    }
                    // line 169
                    yield "        ";
                } elseif (($context["column"] == "rate")) {
                    // line 170
                    yield "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["dayRates"] ?? null));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["currency"] => $context["rate"]) {
                        // line 171
                        yield "                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money($context["rate"], $context["currency"]), "html", null, true);
                        yield "
                ";
                        // line 172
                        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 172)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 173
                            yield "                    <br>
                ";
                        }
                        // line 175
                        yield "            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['currency'], $context['rate'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 176
                    yield "        ";
                } elseif (($context["column"] == "internalRate")) {
                    // line 177
                    yield "            ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["dayInternalRates"] ?? null));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["currency"] => $context["rate"]) {
                        // line 178
                        yield "                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money($context["rate"], $context["currency"]), "html", null, true);
                        yield "
                ";
                        // line 179
                        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 179)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 180
                            yield "                    <br>
                ";
                        }
                        // line 182
                        yield "            ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['currency'], $context['rate'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 183
                    yield "        ";
                } else {
                    // line 184
                    yield "
        ";
                }
                // line 186
                yield "        </td>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['column'], $context['data'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 188
            yield "    </tr>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  746 => 188,  738 => 186,  734 => 184,  731 => 183,  716 => 182,  712 => 180,  710 => 179,  705 => 178,  687 => 177,  684 => 176,  669 => 175,  665 => 173,  663 => 172,  658 => 171,  640 => 170,  637 => 169,  631 => 167,  628 => 166,  626 => 165,  621 => 164,  619 => 163,  614 => 162,  612 => 161,  607 => 160,  603 => 159,  600 => 158,  597 => 157,  579 => 156,  573 => 153,  567 => 151,  565 => 150,  560 => 149,  557 => 148,  555 => 147,  550 => 146,  548 => 145,  543 => 144,  541 => 143,  536 => 142,  534 => 141,  529 => 140,  526 => 139,  520 => 137,  514 => 135,  511 => 134,  508 => 133,  502 => 131,  499 => 130,  497 => 129,  492 => 128,  490 => 127,  485 => 126,  482 => 125,  476 => 123,  472 => 121,  469 => 120,  466 => 119,  460 => 117,  456 => 115,  453 => 114,  451 => 113,  446 => 112,  444 => 111,  439 => 110,  437 => 109,  432 => 108,  429 => 107,  425 => 105,  419 => 103,  416 => 102,  414 => 101,  409 => 100,  407 => 99,  402 => 98,  399 => 97,  393 => 95,  390 => 94,  388 => 93,  380 => 92,  373 => 91,  361 => 88,  358 => 87,  355 => 86,  352 => 85,  349 => 84,  346 => 83,  343 => 82,  340 => 81,  337 => 80,  334 => 79,  331 => 78,  328 => 77,  325 => 76,  322 => 75,  315 => 74,  306 => 70,  303 => 69,  300 => 68,  293 => 67,  287 => 40,  269 => 38,  252 => 37,  247 => 36,  240 => 35,  231 => 63,  228 => 62,  213 => 61,  211 => 60,  209 => 59,  206 => 58,  203 => 57,  200 => 56,  197 => 55,  194 => 54,  191 => 53,  189 => 52,  185 => 50,  182 => 49,  179 => 48,  176 => 47,  173 => 46,  170 => 45,  167 => 44,  165 => 43,  163 => 42,  161 => 35,  159 => 34,  157 => 33,  153 => 31,  150 => 30,  147 => 29,  144 => 28,  142 => 27,  138 => 26,  136 => 25,  133 => 24,  131 => 23,  129 => 22,  112 => 21,  109 => 20,  106 => 19,  103 => 18,  100 => 17,  97 => 16,  94 => 15,  92 => 14,  89 => 13,  86 => 12,  83 => 11,  80 => 10,  77 => 9,  74 => 8,  71 => 7,  68 => 6,  61 => 5,  56 => 1,  54 => 3,  52 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/index.html.twig", "/opt/kimai/templates/timesheet/index.html.twig");
    }
}
