<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/modal.html.twig */
class __TwigTemplate_27ec62460456ba4975393e4521b695b0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'modal_attributes' => [$this, 'block_modal_attributes'],
            'modal_effects' => [$this, 'block_modal_effects'],
            'modal_class' => [$this, 'block_modal_class'],
            'modal_size' => [$this, 'block_modal_size'],
            'modal_content_class' => [$this, 'block_modal_content_class'],
            'modal_before' => [$this, 'block_modal_before'],
            'modal_header_attributes' => [$this, 'block_modal_header_attributes'],
            'modal_header_class' => [$this, 'block_modal_header_class'],
            'modal_title_class' => [$this, 'block_modal_title_class'],
            'modal_title' => [$this, 'block_modal_title'],
            'modal_body_attributes' => [$this, 'block_modal_body_attributes'],
            'modal_body_class' => [$this, 'block_modal_body_class'],
            'modal_body' => [$this, 'block_modal_body'],
            'modal_footer_attributes' => [$this, 'block_modal_footer_attributes'],
            'modal_footer_class' => [$this, 'block_modal_footer_class'],
            'modal_footer' => [$this, 'block_modal_footer'],
            'modal_end' => [$this, 'block_modal_end'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["_id"] = (((array_key_exists("id", $context) &&  !(null === $context["id"]))) ? ($context["id"]) : (((        $this->unwrap()->hasBlock("modal_id", $context, $blocks)) ? (        $this->unwrap()->renderBlock("modal_id", $context, $blocks)) : (("modal-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))))));
        // line 2
        $context["_close"] = ((((array_key_exists("close", $context) &&  !(null === $context["close"]))) ? ($context["close"]) : (true)) === true);
        // line 3
        $context["_header"] = ((((array_key_exists("header", $context) &&  !(null === $context["header"]))) ? ($context["header"]) : (true)) === true);
        // line 4
        $context["_footer"] = ((((array_key_exists("footer", $context) &&  !(null === $context["footer"]))) ? ($context["footer"]) : (true)) === true);
        // line 5
        $context["_status"] = (((array_key_exists("status", $context) &&  !(null === $context["status"]))) ? ($context["status"]) : (null));
        // line 6
        yield "
<div ";
        // line 7
        yield from $this->unwrap()->yieldBlock('modal_attributes', $context, $blocks);
        yield " class=\"modal ";
        yield from $this->unwrap()->yieldBlock('modal_effects', $context, $blocks);
        yield " ";
        yield from $this->unwrap()->yieldBlock('modal_class', $context, $blocks);
        yield "\" id=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
        yield "\" tabindex=\"-1\" role=\"dialog\"";
        if ((($tmp = ($context["_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " aria-labelledby=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
            yield "_label\"";
        }
        yield ">
    <div class=\"modal-dialog ";
        // line 8
        yield from $this->unwrap()->yieldBlock('modal_size', $context, $blocks);
        yield "\" role=\"document\">
        <div class=\"modal-content ";
        // line 9
        yield from $this->unwrap()->yieldBlock('modal_content_class', $context, $blocks);
        yield "\">
            ";
        // line 10
        yield from $this->unwrap()->yieldBlock('modal_before', $context, $blocks);
        // line 11
        yield "            ";
        if ( !(null === ($context["_status"] ?? null))) {
            yield "<div class=\"modal-status bg-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_status"] ?? null), "html", null, true);
            yield "\"></div>";
        }
        // line 12
        yield "            ";
        if ((($tmp = ($context["_header"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 13
            yield "                <div ";
            yield from $this->unwrap()->yieldBlock('modal_header_attributes', $context, $blocks);
            yield " class=\"modal-header ";
            yield from $this->unwrap()->yieldBlock('modal_header_class', $context, $blocks);
            yield "\">
                    <h5 class=\"modal-title ";
            // line 14
            yield from $this->unwrap()->yieldBlock('modal_title_class', $context, $blocks);
            yield "\" id=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
            yield "_label\">";
            yield from $this->unwrap()->yieldBlock('modal_title', $context, $blocks);
            yield "</h5>
                    ";
            // line 15
            if ((($tmp = ($context["_close"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "<button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Close", [], "TablerBundle"), "html", null, true);
                yield "\"></button>";
            }
            // line 16
            yield "                </div>
            ";
        }
        // line 18
        yield "            <div ";
        yield from $this->unwrap()->yieldBlock('modal_body_attributes', $context, $blocks);
        yield " class=\"modal-body ";
        yield from $this->unwrap()->yieldBlock('modal_body_class', $context, $blocks);
        yield "\">
                ";
        // line 19
        yield from $this->unwrap()->yieldBlock('modal_body', $context, $blocks);
        // line 20
        yield "            </div>
            ";
        // line 21
        if ((($tmp = ($context["_footer"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 22
            yield "                <div ";
            yield from $this->unwrap()->yieldBlock('modal_footer_attributes', $context, $blocks);
            yield " class=\"modal-footer ";
            yield from $this->unwrap()->yieldBlock('modal_footer_class', $context, $blocks);
            yield "\">
                    ";
            // line 23
            yield from $this->unwrap()->yieldBlock('modal_footer', $context, $blocks);
            // line 24
            yield "                </div>
            ";
        }
        // line 26
        yield "            ";
        yield from $this->unwrap()->yieldBlock('modal_end', $context, $blocks);
        // line 27
        yield "        </div>
    </div>
</div>
";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_effects(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "modal-blur fade";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "modal-lg";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_content_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_header_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/modal.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  328 => 26,  318 => 23,  299 => 22,  289 => 19,  270 => 18,  251 => 14,  232 => 13,  222 => 10,  212 => 9,  201 => 8,  172 => 7,  164 => 27,  161 => 26,  157 => 24,  155 => 23,  148 => 22,  146 => 21,  143 => 20,  141 => 19,  134 => 18,  130 => 16,  124 => 15,  116 => 14,  109 => 13,  106 => 12,  99 => 11,  97 => 10,  93 => 9,  89 => 8,  73 => 7,  70 => 6,  68 => 5,  66 => 4,  64 => 3,  62 => 2,  60 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/modal.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/modal.html.twig");
    }
}
