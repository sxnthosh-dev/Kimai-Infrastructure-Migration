<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* security/login.html.twig */
class __TwigTemplate_3b456da7498afc863b11f7099ad57e79 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'logo_login' => [$this, 'block_logo_login'],
            'title' => [$this, 'block_title'],
            'head' => [$this, 'block_head'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'javascripts' => [$this, 'block_javascripts'],
            'login_social_auth' => [$this, 'block_login_social_auth'],
            'login_box' => [$this, 'block_login_box'],
            'login_form' => [$this, 'block_login_form'],
            'password_forgotten' => [$this, 'block_password_forgotten'],
            'registration' => [$this, 'block_registration'],
            'remember_me' => [$this, 'block_remember_me'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@theme/security/login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/security/login.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_logo_login(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->load("partials/logo_login.html.twig", 3)->unwrap()->yield($context);
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html", null, true);
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    ";
        yield from $this->load("partials/head.html.twig", 7)->unwrap()->yield($context);
        // line 8
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::HTML_HEAD"));
        // line 9
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 9);
        yield "
";
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 13)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 14
            yield "        ";
            yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app-rtl");
            yield "
    ";
        } else {
            // line 16
            yield "        ";
            yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app");
            yield "
    ";
        }
        // line 18
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::STYLESHEET"));
        // line 19
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 19);
        yield "
";
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "    ";
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("app");
        yield "
    ";
        // line 24
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::JAVASCRIPT"));
        // line 25
        yield "    <script>
        let profile = localStorage.getItem(\x27kimai_profile\x27);
        if (profile === null) {
            ";
        // line 37
        yield "            profile = \x27";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::PROFILE_DESKTOP"), "html", null, true);
        yield "\x27
            const size = window.visualViewport !== undefined ? window.visualViewport.width : window.innerWidth;
            if (size < 576) {
                profile = \x27";
        // line 40
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::PROFILE_MOBILE"), "html", null, true);
        yield "\x27;
            }
            localStorage.setItem(\x27kimai_profile\x27, profile);
        }
        document.cookie = \"";
        // line 44
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::COOKIE_PROFILE"), "html", null, true);
        yield "=\"+profile+\"; path=/; expires=; SameSite=Strict; Secure\";
    </script>
    ";
        // line 46
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 46);
        yield "
";
        yield from [];
    }

    // line 49
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_social_auth(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 50
        yield "    ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["saml_config"] ?? null), "isActivated", [], "method", false, false, false, 50)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 51
            yield "        ";
            if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "loginFormActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 52
                yield "            <div class=\"hr-text\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("or", [], "TablerBundle"), "html", null, true);
                yield "</div>
        ";
            }
            // line 54
            yield "        <div class=\"card-body\">
            <div class=\"row\">
                ";
            // line 56
            if ( !(($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "loginFormActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 57
                yield "                    <h2 class=\"card-title text-center mb-4\">";
                yield from                 $this->unwrap()->yieldBlock("login_box_msg", $context, $blocks);
                yield "</h2>
                ";
            }
            // line 59
            yield "                <div class=\"col text-center\">
                    <a href=\"";
            // line 60
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("saml_login");
            yield "\" id=\"social-login-button\" tabindex=\"50\" class=\"btn btn-white w-50\">
                        ";
            // line 61
            $context["provider"] = CoreExtension::getAttribute($this->env, $this->source, ($context["saml_config"] ?? null), "getProvider", [], "method", false, false, false, 61);
            // line 62
            yield "                        ";
            if ( !(null === ($context["provider"] ?? null))) {
                // line 63
                yield "                            ";
                if (CoreExtension::inFilter("fa-", ($context["provider"] ?? null))) {
                    // line 64
                    yield "                                <i class=\"icon ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["provider"] ?? null), "html", null, true);
                    yield " text-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace(($context["provider"] ?? null), ["fas " => "", "far " => "", "fab " => ""]), "html", null, true);
                    yield "\"></i>
                            ";
                } else {
                    // line 66
                    yield "                                <i class=\"icon fab fa-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["provider"] ?? null), "html", null, true);
                    yield " text-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["provider"] ?? null), "html", null, true);
                    yield "\"></i>
                            ";
                }
                // line 68
                yield "                        ";
            }
            // line 69
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["saml_config"] ?? null), "getTitle", [], "method", false, false, false, 69)), "html", null, true);
            yield "
                    </a>
                </div>
            </div>
        </div>
    ";
        }
        yield from [];
    }

    // line 77
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 78
        yield "    ";
        if (((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "loginFormActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_2FA_IN_PROGRESS")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 79
            yield "        ";
            yield from $this->yieldParentBlock("login_box", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 83
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 84
        yield "    ";
        if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "loginFormActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 85
            yield "        ";
            yield from $this->yieldParentBlock("login_form", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 89
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_password_forgotten(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 90
        yield "    ";
        if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "passwordResetActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 91
            yield "        ";
            yield from $this->yieldParentBlock("password_forgotten", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 95
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_registration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 96
        yield "    ";
        if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "selfRegistrationActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 97
            yield "        ";
            yield from $this->yieldParentBlock("registration", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 101
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_remember_me(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "security/login.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  337 => 101,  328 => 97,  325 => 96,  318 => 95,  309 => 91,  306 => 90,  299 => 89,  290 => 85,  287 => 84,  280 => 83,  271 => 79,  268 => 78,  261 => 77,  248 => 69,  245 => 68,  237 => 66,  229 => 64,  226 => 63,  223 => 62,  221 => 61,  217 => 60,  214 => 59,  208 => 57,  206 => 56,  202 => 54,  196 => 52,  193 => 51,  190 => 50,  183 => 49,  176 => 46,  171 => 44,  164 => 40,  157 => 37,  152 => 25,  150 => 24,  145 => 23,  138 => 22,  130 => 19,  127 => 18,  121 => 16,  115 => 14,  112 => 13,  105 => 12,  97 => 9,  94 => 8,  91 => 7,  84 => 6,  73 => 4,  62 => 3,  51 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "security/login.html.twig", "/opt/kimai/templates/security/login.html.twig");
    }
}
