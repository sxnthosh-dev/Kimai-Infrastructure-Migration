<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_user_list.html.twig */
class __TwigTemplate_905664b607f68a491fab7bbfa34145fd extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_content' => [$this, 'block_report_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/report_user_list_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/report_user_list_layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from $this->load("reporting/report_user_list.html.twig", 4, 1)->unwrap()->yield(CoreExtension::toArray(["stats" => ($context["stats"] ?? null), "dataType" => ($context["dataType"] ?? null), "period_attribute" => ($context["period_attribute"] ?? null), "subReportRoute" => ($context["subReportRoute"] ?? null), "subReportDate" => ($context["subReportDate"] ?? null), "decimal" => ($context["decimal"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list.html.twig", "/opt/kimai/templates/reporting/report_user_list.html.twig");
    }
}


/* reporting/report_user_list.html.twig */
class __TwigTemplate_905664b607f68a491fab7bbfa34145fd___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'period_name' => [$this, 'block_period_name'],
            'total_rate_user' => [$this, 'block_total_rate_user'],
            'total_internal_rate_user' => [$this, 'block_total_internal_rate_user'],
            'total_duration_user' => [$this, 'block_total_duration_user'],
            'rate' => [$this, 'block_rate'],
            'internal_rate' => [$this, 'block_internal_rate'],
            'duration' => [$this, 'block_duration'],
            'period_cell_class' => [$this, 'block_period_cell_class'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "reporting/user_list_period_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/user_list_period_data.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "            <th class=\"text-center text-nowrap";
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(($context["column"] ?? null))) {
            yield " weekend";
        }
        if ($this->env->getTest('today')->getCallable()(($context["column"] ?? null))) {
            yield " today";
        }
        yield "\">
                ";
        // line 7
        yield (string) $this->extensions['App\Twig\LocaleFormatExtensions']->dateWeekday(($context["column"] ?? null));
        yield "
            </th>
        ";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["subReportRoute"] ?? null), ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate(($context["subReportDate"] ?? null)), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 11), "id", [], "any", false, false, false, 11)]), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["usersTotalRate"] ?? null)), "html", null, true);
        yield "</a>
        ";
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["subReportRoute"] ?? null), ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate(($context["subReportDate"] ?? null)), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 14), "id", [], "any", false, false, false, 14)]), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["usersTotalInternalRate"] ?? null)), "html", null, true);
        yield "</a>
        ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "            <a href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["subReportRoute"] ?? null), ["sumType" => ($context["dataType"] ?? null), "date" => $this->extensions['App\Twig\Extensions']->formatReportDate(($context["subReportDate"] ?? null)), "user" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["userPeriod"] ?? null), "user", [], "any", false, false, false, 17), "id", [], "any", false, false, false, 17)]), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["usersTotalDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "</a>
        ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalRate", [], "any", false, false, false, 20)), "html", null, true);
        yield "
        ";
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalInternalRate", [], "any", false, false, false, 23)), "html", null, true);
        yield "
        ";
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "totalDuration", [], "any", false, false, false, 26), ($context["decimal"] ?? null)), "html", null, true);
        yield "
        ";
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 28))) {
            yield " weekend";
        }
        if ($this->env->getTest('today')->getCallable()(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "date", [], "any", false, false, false, 28))) {
            yield " today";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  256 => 28,  248 => 26,  241 => 25,  233 => 23,  226 => 22,  218 => 20,  211 => 19,  201 => 17,  194 => 16,  184 => 14,  177 => 13,  167 => 11,  160 => 10,  152 => 7,  142 => 6,  135 => 5,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list.html.twig", "/opt/kimai/templates/reporting/report_user_list.html.twig");
    }
}
