<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* base.html.twig */
class __TwigTemplate_d4489032eef228dbeaaa3d5efb32ff3c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body_start' => [$this, 'block_body_start'],
            'after_body_start' => [$this, 'block_after_body_start'],
            'page_search' => [$this, 'block_page_search'],
            'page_content_start' => [$this, 'block_page_content_start'],
            'page_content_before' => [$this, 'block_page_content_before'],
            'main_before' => [$this, 'block_main_before'],
            'page_class' => [$this, 'block_page_class'],
            'page_content_after' => [$this, 'block_page_content_after'],
            'page_content' => [$this, 'block_page_content'],
            'main' => [$this, 'block_main'],
            'title' => [$this, 'block_title'],
            'footer' => [$this, 'block_footer'],
            'navbar_start' => [$this, 'block_navbar_start'],
            'navbar_extensions' => [$this, 'block_navbar_extensions'],
            'navbar_extensions_after' => [$this, 'block_navbar_extensions_after'],
            'page_pretitle' => [$this, 'block_page_pretitle'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'javascripts' => [$this, 'block_javascripts'],
            'navbar_brand_class' => [$this, 'block_navbar_brand_class'],
            'app_logo' => [$this, 'block_app_logo'],
            'navbar_search' => [$this, 'block_navbar_search'],
            'page_intro' => [$this, 'block_page_intro'],
            'page_title' => [$this, 'block_page_title'],
            'page_actions' => [$this, 'block_page_actions'],
            'page_header' => [$this, 'block_page_header'],
            'navbar_menu_start' => [$this, 'block_navbar_menu_start'],
            'navbar_menu_end' => [$this, 'block_navbar_menu_end'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isBoxedLayout", [], "method", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("@Tabler/layout_horizontal.html.twig") : ("@Tabler/layout_vertical.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    data-title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html_attr");
        yield "\"";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        yield from $this->load("base.html.twig", 8, 1)->unwrap()->yield($context);
        // line 15
        yield "    ";
        yield from $this->load("base.html.twig", 15, 2)->unwrap()->yield($context);
        // line 24
        yield "    ";
        yield from $this->unwrap()->yieldBlock('page_search', $context, $blocks);
        // line 25
        yield "    <div id=\"toast-container\" class=\"toast-container position-fixed top-0 start-50 translate-middle-x p-3\" style=\"z-index: 11\"></div>
";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_search(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "    ";
        $context["flashes"] = CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [], "any", false, false, false, 29);
        // line 30
        yield "    ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["flashes"] ?? null)) > 0)) {
            // line 31
            yield "        ";
            $context["domain"] = "flashmessages";
            // line 32
            yield "        <script type=\"text/javascript\">
            document.addEventListener(\x27kimai.initialized\x27, function(options) {
                const ALERT = options.detail.kimai.getPlugin(\x27alert\x27);
                ";
            // line 35
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["flashes"] ?? null));
            foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
                // line 36
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["messages"]);
                foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                    // line 37
                    yield "                        ";
                    if (($context["type"] == "error")) {
                        // line 38
                        yield "                            ALERT.error(\x27";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], ($context["domain"] ?? null)), "js"), "html", null, true);
                        yield "\x27);
                        ";
                    } elseif ((                    // line 39
$context["type"] == "warning")) {
                        // line 40
                        yield "                            ALERT.warning(\x27";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], ($context["domain"] ?? null)), "js"), "html", null, true);
                        yield "\x27);
                        ";
                    } elseif ((                    // line 41
$context["type"] == "success")) {
                        // line 42
                        yield "                            ";
                        // line 43
                        yield "                            ";
                        // line 44
                        yield "                            // ALERT.success(\x27";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], ($context["domain"] ?? null)), "js"), "html", null, true);
                        yield "\x27);
                        ";
                    } else {
                        // line 46
                        yield "                            ALERT.info(\x27";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["message"], [], ($context["domain"] ?? null)), "js"), "html", null, true);
                        yield "\x27);
                        ";
                    }
                    // line 48
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['message'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 49
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['type'], $context['messages'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 50
            yield "            });
        </script>
    ";
        }
        yield from [];
    }

    // line 55
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 56
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::CONTENT_BEFORE"));
        // line 57
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 57);
        yield "
    <div class=\"d-print-none hidden-no-space\">
        ";
        // line 59
        yield from $this->unwrap()->yieldBlock('main_before', $context, $blocks);
        // line 60
        yield "    </div>
    <section class=\"content ";
        // line 61
        yield from $this->unwrap()->yieldBlock('page_class', $context, $blocks);
        yield "\">
";
        yield from [];
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 64
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 65
        yield "    </section>
    ";
        // line 66
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::CONTENT_AFTER"));
        // line 67
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 67);
        yield "
    ";
        // line 68
        if ((array_key_exists("page_setup", $context) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "help", [], "any", false, false, false, 68)))) {
            // line 69
            yield "        <a class=\"float-help btn btn-primary\" href=\"";
            if (CoreExtension::inFilter("://", CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "help", [], "any", false, false, false, 69))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "help", [], "any", false, false, false, 69), "html", null, true);
            } else {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->documentationLink(CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "help", [], "any", false, false, false, 69), "float-help"), "html", null, true);
            }
            yield "\" target=\"_blank\" rel=\"noopener\" accesskey=\"h\">
            <i class=\"fas fa-question\"></i>
            <span class=\"float-help-label\"><span>";
            // line 71
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("help"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "title", [], "any", false, false, false, 71), [], CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "translationDomain", [], "any", false, false, false, 71)), "html", null, true);
            yield "</span></span>
        </a>
        <div class=\"mb-4\"></div>
    ";
        }
        yield from [];
    }

    // line 77
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 78
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::CONTENT_START"));
        // line 79
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 79);
        yield "
    ";
        // line 80
        yield from $this->unwrap()->yieldBlock('main', $context, $blocks);
        // line 81
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::CONTENT_END"));
        // line 82
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 82);
        yield "
";
        yield from [];
    }

    // line 80
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 86
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html", null, true);
        yield from [];
    }

    // line 89
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 90
        yield "    ";
        if (CoreExtension::inFilter("dashboard", CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 90), "attributes", [], "any", false, false, false, 90), "get", ["_route"], "method", false, false, false, 90))) {
            // line 91
            yield "        ";
            yield from $this->yieldParentBlock("footer", $context, $blocks);
            yield "
    ";
        }
        yield from [];
    }

    // line 95
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 96
        yield "    ";
        if (( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 96)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("IS_AUTHENTICATED_REMEMBERED")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 97
            yield "        ";
            yield from $this->unwrap()->yieldBlock('navbar_extensions', $context, $blocks);
            // line 98
            yield "        ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_own_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 99
                yield "            ";
                yield from $this->load("partials/ticktack.html.twig", 99)->unwrap()->yield($context);
                // line 100
                yield "        ";
            }
            // line 101
            yield "        ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_own_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 102
                yield "            ";
                yield from $this->load("partials/recent-activities.html.twig", 102)->unwrap()->yield($context);
                // line 103
                yield "        ";
            }
            // line 104
            yield "        ";
            yield from $this->load("partials/user-shortcuts.html.twig", 104)->unwrap()->yield($context);
            // line 105
            yield "        ";
            yield from $this->unwrap()->yieldBlock('navbar_extensions_after', $context, $blocks);
            // line 109
            yield "    ";
        }
        yield from [];
    }

    // line 97
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_extensions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 105
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_extensions_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 106
        yield "            ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::TOOLBAR"));
        // line 107
        yield "            ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 107);
        yield "
        ";
        yield from [];
    }

    // line 113
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_pretitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 115
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 116
        yield "    ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 116)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 117
            yield "        ";
            yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app-rtl");
            yield "
    ";
        } else {
            // line 119
            yield "        ";
            yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("app");
            yield "
    ";
        }
        // line 121
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::STYLESHEET"));
        // line 122
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 122);
        yield "
";
        yield from [];
    }

    // line 125
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 126
        yield "    ";
        yield from $this->load("partials/head.html.twig", 126)->unwrap()->yield($context);
        // line 127
        yield "    ";
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("app");
        yield "
    ";
        // line 128
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::HTML_HEAD"));
        // line 129
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 129);
        yield "
";
        yield from [];
    }

    // line 132
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 133
        yield "    ";
        // line 134
        yield "    ";
        $macros["webloader"] = $this->load("macros/webloader.html.twig", 134)->unwrap();
        // line 135
        yield "    ";
        yield (string) $macros["webloader"]->getTemplateForMacro("macro_init_frontend_loader", $context, 135, $this->getSourceContext())->macro_init_frontend_loader(...[]);
        yield "
    ";
        // line 136
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->trigger($this->env, Twig\Extension\CoreExtension::constant("App\\Event\\ThemeEvent::JAVASCRIPT"));
        // line 137
        yield "    ";
        yield (string) CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "content", [], "any", false, false, false, 137);
        yield "
";
        yield from [];
    }

    // line 140
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " d-none d-lg-inline-flex";
        yield from [];
    }

    // line 142
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_app_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 143
        yield "    ";
        $context["mylogo"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            yield from $this->yieldParentBlock("app_logo", $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 144
        yield "    ";
        // line 145
        yield "    <div class=\"d-flex justify-content-start flex-fill d-lg-none\">
        <h2 class=\"page-title d-lg-none ps-2\">";
        // line 147
        yield from         $this->unwrap()->yieldBlock("page_title", $context, $blocks);
        // line 148
        yield "</h2>
        ";
        // line 149
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["mylogo"] ?? null), "html", null, true);
        yield "
    </div>
    ";
        // line 151
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["mylogo"] ?? null), "html", null, true);
        yield "
";
        yield from [];
    }

    // line 154
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_search(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 155
        yield "    ";
        // line 156
        yield "    <h2 class=\"page-title me-2\">";
        // line 157
        yield from         $this->unwrap()->yieldBlock("page_title", $context, $blocks);
        // line 158
        yield "</h2>";
        // line 159
        if (        $this->unwrap()->hasBlock("status", $context, $blocks)) {
            yield "<div class=\"btn-list\">";
            yield from             $this->unwrap()->yieldBlock("status", $context, $blocks);
            yield "</div>";
        }
        // line 160
        if (        $this->unwrap()->hasBlock("subtitle", $context, $blocks)) {
            yield from             $this->unwrap()->yieldBlock("subtitle", $context, $blocks);
        }
        // line 161
        if ((        $this->unwrap()->hasBlock("breadcrumb", $context, $blocks) &&         $this->unwrap()->hasBlock("table_actions", $context, $blocks))) {
            yield from             $this->unwrap()->yieldBlock("breadcrumb", $context, $blocks);
        }
        yield from [];
    }

    // line 164
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_intro(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 165
        yield "    ";
        if (        $this->unwrap()->hasBlock("table_actions", $context, $blocks)) {
            // line 166
            yield "        ";
            yield from             $this->unwrap()->yieldBlock("table_actions", $context, $blocks);
            yield "
    ";
        } elseif (        $this->unwrap()->hasBlock("breadcrumb", $context, $blocks)) {
            // line 168
            yield "        <div class=\"text-body-secondary mt-1\">
            ";
            // line 169
            yield from             $this->unwrap()->yieldBlock("breadcrumb", $context, $blocks);
            yield "
        </div>
    ";
        }
        yield from [];
    }

    // line 174
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 175
        if (array_key_exists("page_setup", $context)) {
            // line 176
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "title", [], "any", false, false, false, 176), [], CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "translationDomain", [], "any", false, false, false, 176)), "html", null, true);
        } else {
            // line 178
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html", null, true);
        }
        yield from [];
    }

    // line 182
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 183
        yield "    ";
        $macros["_v0"] = $this->load("macros/widgets.html.twig", 183)->unwrap();
        // line 184
        if ((array_key_exists("page_setup", $context) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "actionName", [], "any", false, false, false, 184)))) {
            // line 185
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 185), CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "actionName", [], "any", false, false, false, 185), CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "actionView", [], "any", false, false, false, 185), CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "actionPayload", [], "any", false, false, false, 185));
            // line 186
            yield "        ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "tableAction", [], "method", false, false, false, 186)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 187
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_table_actions", $context, 187, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 187)]);
                yield "
        ";
            } else {
                // line 189
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_page_actions", $context, 189, $this->getSourceContext())->macro_page_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 189)]);
                yield "
        ";
            }
        }
        yield from [];
    }

    // line 194
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 195
        if (array_key_exists("page_setup", $context)) {
            // line 196
            if (( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "actionName", [], "any", false, false, false, 196)) || (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "hasSearchForm", [], "method", false, false, false, 196)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 197
                yield from $this->yieldParentBlock("page_header", $context, $blocks);
            }
        } else {
            // line 200
            yield from $this->yieldParentBlock("page_header", $context, $blocks);
        }
        yield from [];
    }

    // line 204
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 205
        yield "    ";
        yield (string) $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->themeEvent("\\App\\Event\\ThemeEventMenuStart");
        yield "
";
        yield from [];
    }

    // line 208
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 209
        yield "    ";
        yield (string) $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->themeEvent("\\App\\Event\\ThemeEventMenuEnd");
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  733 => 209,  726 => 208,  718 => 205,  711 => 204,  705 => 200,  701 => 197,  699 => 196,  697 => 195,  690 => 194,  680 => 189,  674 => 187,  671 => 186,  669 => 185,  667 => 184,  664 => 183,  657 => 182,  651 => 178,  648 => 176,  646 => 175,  639 => 174,  630 => 169,  627 => 168,  621 => 166,  618 => 165,  611 => 164,  604 => 161,  600 => 160,  594 => 159,  592 => 158,  590 => 157,  588 => 156,  586 => 155,  579 => 154,  572 => 151,  567 => 149,  564 => 148,  562 => 147,  559 => 145,  557 => 144,  551 => 143,  544 => 142,  533 => 140,  525 => 137,  523 => 136,  518 => 135,  515 => 134,  513 => 133,  506 => 132,  498 => 129,  496 => 128,  491 => 127,  488 => 126,  481 => 125,  473 => 122,  470 => 121,  464 => 119,  458 => 117,  455 => 116,  448 => 115,  438 => 113,  430 => 107,  427 => 106,  420 => 105,  410 => 97,  404 => 109,  401 => 105,  398 => 104,  395 => 103,  392 => 102,  389 => 101,  386 => 100,  383 => 99,  380 => 98,  377 => 97,  374 => 96,  367 => 95,  358 => 91,  355 => 90,  348 => 89,  343 => 86,  336 => 85,  326 => 80,  318 => 82,  315 => 81,  313 => 80,  308 => 79,  305 => 78,  298 => 77,  286 => 71,  276 => 69,  274 => 68,  269 => 67,  267 => 66,  264 => 65,  257 => 64,  247 => 61,  237 => 59,  230 => 61,  227 => 60,  225 => 59,  219 => 57,  216 => 56,  209 => 55,  201 => 50,  194 => 49,  187 => 48,  181 => 46,  175 => 44,  173 => 43,  171 => 42,  169 => 41,  164 => 40,  162 => 39,  157 => 38,  154 => 37,  149 => 36,  145 => 35,  140 => 32,  137 => 31,  134 => 30,  131 => 29,  124 => 28,  114 => 24,  108 => 25,  105 => 24,  102 => 15,  99 => 8,  92 => 7,  85 => 4,  78 => 3,  68 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "base.html.twig", "/opt/kimai/templates/base.html.twig");
    }
}


/* base.html.twig */
class __TwigTemplate_d4489032eef228dbeaaa3d5efb32ff3c___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'modal_id' => [$this, 'block_modal_id'],
            'modal_title' => [$this, 'block_modal_title'],
            'modal_body' => [$this, 'block_modal_body'],
            'modal_footer' => [$this, 'block_modal_footer'],
            'modal_effects' => [$this, 'block_modal_effects'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 8
        return "@theme/embeds/modal.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/modal.html.twig", 8);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "remote_form_modal";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_effects(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  850 => 13,  840 => 12,  830 => 11,  820 => 10,  809 => 9,  798 => 8,  733 => 209,  726 => 208,  718 => 205,  711 => 204,  705 => 200,  701 => 197,  699 => 196,  697 => 195,  690 => 194,  680 => 189,  674 => 187,  671 => 186,  669 => 185,  667 => 184,  664 => 183,  657 => 182,  651 => 178,  648 => 176,  646 => 175,  639 => 174,  630 => 169,  627 => 168,  621 => 166,  618 => 165,  611 => 164,  604 => 161,  600 => 160,  594 => 159,  592 => 158,  590 => 157,  588 => 156,  586 => 155,  579 => 154,  572 => 151,  567 => 149,  564 => 148,  562 => 147,  559 => 145,  557 => 144,  551 => 143,  544 => 142,  533 => 140,  525 => 137,  523 => 136,  518 => 135,  515 => 134,  513 => 133,  506 => 132,  498 => 129,  496 => 128,  491 => 127,  488 => 126,  481 => 125,  473 => 122,  470 => 121,  464 => 119,  458 => 117,  455 => 116,  448 => 115,  438 => 113,  430 => 107,  427 => 106,  420 => 105,  410 => 97,  404 => 109,  401 => 105,  398 => 104,  395 => 103,  392 => 102,  389 => 101,  386 => 100,  383 => 99,  380 => 98,  377 => 97,  374 => 96,  367 => 95,  358 => 91,  355 => 90,  348 => 89,  343 => 86,  336 => 85,  326 => 80,  318 => 82,  315 => 81,  313 => 80,  308 => 79,  305 => 78,  298 => 77,  286 => 71,  276 => 69,  274 => 68,  269 => 67,  267 => 66,  264 => 65,  257 => 64,  247 => 61,  237 => 59,  230 => 61,  227 => 60,  225 => 59,  219 => 57,  216 => 56,  209 => 55,  201 => 50,  194 => 49,  187 => 48,  181 => 46,  175 => 44,  173 => 43,  171 => 42,  169 => 41,  164 => 40,  162 => 39,  157 => 38,  154 => 37,  149 => 36,  145 => 35,  140 => 32,  137 => 31,  134 => 30,  131 => 29,  124 => 28,  114 => 24,  108 => 25,  105 => 24,  102 => 15,  99 => 8,  92 => 7,  85 => 4,  78 => 3,  68 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "base.html.twig", "/opt/kimai/templates/base.html.twig");
    }
}


/* base.html.twig */
class __TwigTemplate_d4489032eef228dbeaaa3d5efb32ff3c___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'modal_id' => [$this, 'block_modal_id'],
            'modal_title' => [$this, 'block_modal_title'],
            'modal_body' => [$this, 'block_modal_body'],
            'modal_effects' => [$this, 'block_modal_effects'],
            'modal_footer' => [$this, 'block_modal_footer'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 15
        return "@theme/embeds/modal.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/modal.html.twig", 15);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "remote_modal";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_effects(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        yield "            <button type=\"button\" class=\"btn btn-cancel\" data-bs-dismiss=\"modal\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
        yield "</button>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "base.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  976 => 21,  969 => 20,  959 => 19,  949 => 18,  939 => 17,  928 => 16,  917 => 15,  850 => 13,  840 => 12,  830 => 11,  820 => 10,  809 => 9,  798 => 8,  733 => 209,  726 => 208,  718 => 205,  711 => 204,  705 => 200,  701 => 197,  699 => 196,  697 => 195,  690 => 194,  680 => 189,  674 => 187,  671 => 186,  669 => 185,  667 => 184,  664 => 183,  657 => 182,  651 => 178,  648 => 176,  646 => 175,  639 => 174,  630 => 169,  627 => 168,  621 => 166,  618 => 165,  611 => 164,  604 => 161,  600 => 160,  594 => 159,  592 => 158,  590 => 157,  588 => 156,  586 => 155,  579 => 154,  572 => 151,  567 => 149,  564 => 148,  562 => 147,  559 => 145,  557 => 144,  551 => 143,  544 => 142,  533 => 140,  525 => 137,  523 => 136,  518 => 135,  515 => 134,  513 => 133,  506 => 132,  498 => 129,  496 => 128,  491 => 127,  488 => 126,  481 => 125,  473 => 122,  470 => 121,  464 => 119,  458 => 117,  455 => 116,  448 => 115,  438 => 113,  430 => 107,  427 => 106,  420 => 105,  410 => 97,  404 => 109,  401 => 105,  398 => 104,  395 => 103,  392 => 102,  389 => 101,  386 => 100,  383 => 99,  380 => 98,  377 => 97,  374 => 96,  367 => 95,  358 => 91,  355 => 90,  348 => 89,  343 => 86,  336 => 85,  326 => 80,  318 => 82,  315 => 81,  313 => 80,  308 => 79,  305 => 78,  298 => 77,  286 => 71,  276 => 69,  274 => 68,  269 => 67,  267 => 66,  264 => 65,  257 => 64,  247 => 61,  237 => 59,  230 => 61,  227 => 60,  225 => 59,  219 => 57,  216 => 56,  209 => 55,  201 => 50,  194 => 49,  187 => 48,  181 => 46,  175 => 44,  173 => 43,  171 => 42,  169 => 41,  164 => 40,  162 => 39,  157 => 38,  154 => 37,  149 => 36,  145 => 35,  140 => 32,  137 => 31,  134 => 30,  131 => 29,  124 => 28,  114 => 24,  108 => 25,  105 => 24,  102 => 15,  99 => 8,  92 => 7,  85 => 4,  78 => 3,  68 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "base.html.twig", "/opt/kimai/templates/base.html.twig");
    }
}
