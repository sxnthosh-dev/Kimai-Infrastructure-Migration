<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/profile.html.twig */
class __TwigTemplate_fd95912155a311f41b277c756f2a5c7d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user_title_box_attributes' => [$this, 'block_user_title_box_attributes'],
            'form_content' => [$this, 'block_form_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("user/form.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_title_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "username", [], "any", true, true, false, 4)) {
            // line 5
            yield "        ondblclick=\"document.getElementById(\x27user_edit_username_hidden\x27).style.display = \x27flex\x27\"
    ";
        }
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "
    ";
        // line 11
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 12
        yield "
    ";
        // line 13
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
    ";
        // line 14
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 14), 'row');
        yield "

    <fieldset class=\"form-fieldset form-fieldset-light\">
        ";
        // line 17
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "alias", [], "any", false, false, false, 17), 'row');
        yield "
        ";
        // line 18
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 18), 'row');
        yield "
        ";
        // line 19
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "username", [], "any", true, true, false, 19)) {
            // line 20
            yield "            ";
            $context["styleUsername"] = "display:none";
            // line 21
            yield "            ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "username", [], "any", false, false, false, 21), "vars", [], "any", false, false, false, 21), "errors", [], "any", false, false, false, 21)) > 0)) {
                // line 22
                yield "                ";
                $context["styleUsername"] = "";
                // line 23
                yield "            ";
            }
            // line 24
            yield "            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "username", [], "any", false, false, false, 24), 'row', ["row_attr" => ["id" => "user_edit_username_hidden", "style" => ($context["styleUsername"] ?? null)]]);
            yield "
        ";
        }
        // line 26
        yield "    </fieldset>

    <fieldset class=\"form-fieldset form-fieldset-light\">
        ";
        // line 29
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "accountNumber", [], "any", false, false, false, 29), 'row');
        yield "
        ";
        // line 30
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "supervisor", [], "any", true, true, false, 30)) {
            // line 31
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "supervisor", [], "any", false, false, false, 31), 'row');
            yield "
        ";
        }
        // line 33
        yield "    </fieldset>

    <fieldset class=\"form-fieldset form-fieldset-light\">
        ";
        // line 36
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 36), 'row');
        yield "
        ";
        // line 37
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "color", [], "any", false, false, false, 37), 'row');
        yield "
        ";
        // line 38
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "avatar", [], "any", true, true, false, 38)) {
            // line 39
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "avatar", [], "any", false, false, false, 39), 'row');
            yield "
        ";
        }
        // line 41
        yield "    </fieldset>

    <fieldset class=\"form-fieldset form-fieldset-light\">";
        // line 44
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        // line 45
        yield "</fieldset>

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/profile.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  167 => 45,  165 => 44,  161 => 41,  155 => 39,  153 => 38,  149 => 37,  145 => 36,  140 => 33,  134 => 31,  132 => 30,  128 => 29,  123 => 26,  117 => 24,  114 => 23,  111 => 22,  108 => 21,  105 => 20,  103 => 19,  99 => 18,  95 => 17,  89 => 14,  85 => 13,  82 => 12,  80 => 11,  77 => 10,  70 => 9,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/profile.html.twig", "/opt/kimai/templates/user/profile.html.twig");
    }
}
