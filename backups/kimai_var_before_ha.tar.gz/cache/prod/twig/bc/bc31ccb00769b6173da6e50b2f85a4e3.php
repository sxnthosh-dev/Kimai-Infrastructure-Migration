<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/flash_messages.html.twig */
class __TwigTemplate_282d013fbe4a868aac9d7d52060fd0f5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $macros["macro"] = $this->macros["macro"] = $this->load("@Tabler/components/flash.html.twig", 1)->unwrap();
        // line 2
        yield "
";
        // line 3
        $context["flashes"] = CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "flashes", [], "any", false, false, false, 3);
        // line 4
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["flashes"] ?? null)) > 0)) {
            // line 5
            yield "    <div class=\"row\">
        <div class=\"col-sm-12\">
            ";
            // line 7
            yield (string) $macros["macro"]->getTemplateForMacro("macro_flashes", $context, 7, $this->getSourceContext())->macro_flashes(...[($context["flashes"] ?? null), true, false, "", "flashmessages"]);
            yield "
        </div>
    </div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/flash_messages.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  56 => 7,  52 => 5,  50 => 4,  48 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/flash_messages.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/flash_messages.html.twig");
    }
}
