<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/document_upload.html.twig */
class __TwigTemplate_bae63f14f386e9ca278be00fab8eae33 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'status' => [$this, 'block_status'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        $macros["_v0"] = $this->load("macros/status.html.twig", 5)->unwrap();
        // line 6
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_status_count", $context, 6, $this->getSourceContext())->macro_status_count(...[Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["documents"] ?? null))]);
        yield "
";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "    ";
        if (((($tmp = ($context["can_upload"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(null === ($context["form"] ?? null)))) {
            // line 11
            yield "        ";
            yield from $this->load("invoice/document_upload.html.twig", 11, 1)->unwrap()->yield($context);
            // line 33
            yield "    ";
        } elseif ( !(null === ($context["upload_error"] ?? null))) {
            // line 34
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_callout", $context, 34, $this->getSourceContext())->macro_callout(...["warning", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["upload_error"] ?? null), ($context["error_replacer"] ?? null))]);
            yield "
    ";
        }
        // line 36
        yield "
    ";
        // line 37
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["documents"] ?? null)) > 0)) {
            // line 38
            yield "        ";
            yield from $this->load("invoice/document_upload.html.twig", 38, 2)->unwrap()->yield(CoreExtension::merge($context, ["documents" => ($context["documents"] ?? null), "fullsize" => true]));
            // line 75
            yield "    ";
        }
        yield from [];
    }

    // line 78
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 79
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.invoiceDocumentUpdate\x27, true);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/document_upload.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  118 => 79,  111 => 78,  105 => 75,  102 => 38,  100 => 37,  97 => 36,  91 => 34,  88 => 33,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/document_upload.html.twig", "/opt/kimai/templates/invoice/document_upload.html.twig");
    }
}


/* invoice/document_upload.html.twig */
class __TwigTemplate_bae63f14f386e9ca278be00fab8eae33___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_before' => [$this, 'block_box_before'],
            'box_after' => [$this, 'block_box_after'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 11
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 11
        $this->parent = $this->load("@theme/embeds/card.html.twig", 11);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("upload"), "html", null, true);
        yield "
            ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "                ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield "
            ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "                ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
            ";
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "                ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "document", [], "any", false, false, false, 23), 'row');
        yield "
                <p>
                <a href=\"https://github.com/kimai/invoice-templates\" target=\"_blank\">";
        // line 25
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("download_invoice_renderer", [], "invoice-renderer"), "html", null, true);
        yield "</a>
                </p>
            ";
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "                <button type=\"submit\" class=\"btn btn-primary\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
        yield "</button>
                <a href=\"";
        // line 30
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_invoice_template");
        yield "\" class=\"btn btn-link\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("back"), "html", null, true);
        yield "</a>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/document_upload.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  280 => 30,  275 => 29,  268 => 28,  260 => 25,  254 => 23,  247 => 22,  239 => 20,  232 => 19,  224 => 17,  217 => 16,  209 => 14,  202 => 13,  197 => 11,  195 => 12,  188 => 11,  118 => 79,  111 => 78,  105 => 75,  102 => 38,  100 => 37,  97 => 36,  91 => 34,  88 => 33,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/document_upload.html.twig", "/opt/kimai/templates/invoice/document_upload.html.twig");
    }
}


/* invoice/document_upload.html.twig */
class __TwigTemplate_bae63f14f386e9ca278be00fab8eae33___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 38
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 39
        $macros["actions"] = $this->macros["actions"] = $this->load("invoice/actions.html.twig", 39)->unwrap();
        // line 40
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 40)->unwrap();
        // line 38
        $this->parent = $this->load("@theme/embeds/card.html.twig", 38);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 41
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice_renderer", [], "invoice-renderer"), "html", null, true);
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "                id=\"invoice_document_list\"
            ";
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        yield "                <table class=\"table table-hover dataTable\">
                    <thead>
                        <tr>
                            <th>";
        // line 49
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("file"), "html", null, true);
        yield "</th>
                            <th>";
        // line 50
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("updated_at"), "html", null, true);
        yield "</th>
                            <th>";
        // line 51
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("template"), "html", null, true);
        yield "</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
        // line 56
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["documents"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["config"]) {
            // line 57
            yield "                        ";
            $context["document"] = CoreExtension::getAttribute($this->env, $this->source, $context["config"], "document", [], "any", false, false, false, 57);
            // line 58
            yield "                        <tr>
                            <td>";
            // line 59
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["document"] ?? null), "name", [], "any", false, false, false, 59), "html", null, true);
            yield "</td>
                            <td>";
            // line 60
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatDate(CoreExtension::getAttribute($this->env, $this->source, ($context["document"] ?? null), "lastChange", [], "any", false, false, false, 60)), "html", null, true);
            yield "</td>
                            <td>
                                ";
            // line 62
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["config"], "template", [], "any", false, false, false, 62))) {
                // line 63
                yield "                                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["config"], "template", [], "any", false, false, false, 63), "name", [], "any", false, false, false, 63), "html", null, true);
                yield "
                                ";
            }
            // line 65
            yield "                            </td>
                            <td class=\"actions\">
                                ";
            // line 67
            yield (string) $macros["actions"]->getTemplateForMacro("macro_invoice_document", $context, 67, $this->getSourceContext())->macro_invoice_document(...[($context["document"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["config"], "used", [], "any", false, false, false, 67), "index"]);
            yield "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['config'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 71
        yield "                    </tbody>
                </table>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/document_upload.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  454 => 71,  443 => 67,  439 => 65,  433 => 63,  431 => 62,  426 => 60,  422 => 59,  419 => 58,  416 => 57,  412 => 56,  404 => 51,  400 => 50,  396 => 49,  391 => 46,  384 => 45,  378 => 43,  371 => 42,  360 => 41,  355 => 38,  353 => 40,  351 => 39,  344 => 38,  280 => 30,  275 => 29,  268 => 28,  260 => 25,  254 => 23,  247 => 22,  239 => 20,  232 => 19,  224 => 17,  217 => 16,  209 => 14,  202 => 13,  197 => 11,  195 => 12,  188 => 11,  118 => 79,  111 => 78,  105 => 75,  102 => 38,  100 => 37,  97 => 36,  91 => 34,  88 => 33,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/document_upload.html.twig", "/opt/kimai/templates/invoice/document_upload.html.twig");
    }
}
