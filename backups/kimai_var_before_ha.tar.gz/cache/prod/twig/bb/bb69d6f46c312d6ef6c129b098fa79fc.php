<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* partials/user-shortcuts.html.twig */
class __TwigTemplate_746d4f13be5e1da8439101b29987e356 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["user_shortcuts"] = $this->env->getRuntime('App\Twig\Runtime\MenuExtension')->getUserShortcuts(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 1));
        // line 2
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["user_shortcuts"] ?? null)) > 0)) {
            // line 3
            yield "    <div class=\"nav-item dropdown d-flex me-1 user-shortcuts\">
        <a class=\"btn btn-icon px-0 user-shortcuts-toggle\" href=\"javascript:void(0);\" data-bs-toggle=\"dropdown\" data-bs-auto-close=\"outside\" aria-expanded=\"true\" title=\"";
            // line 4
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("favorite_routes"), "html", null, true);
            yield "\">
            ";
            // line 5
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("far fa-bookmark", true);
            yield "
        </a>
        <div class=\"dropdown-menu dropdown-menu-end dropdown-menu-arrow dropdown-menu-card\" data-bs-popper=\"static\">
            <div class=\"card\">
                <div class=\"card-header text-nowrap\">";
            // line 9
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("favorite_routes"), "html", null, true);
            yield "</div>
                <div class=\"card-body user-shortcuts-list scrollable-container p-0 pb-2\">
                    <div class=\"row overflow-visible g-0\">
                        ";
            // line 12
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["user_shortcuts"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["menu"]) {
                // line 13
                yield "                                ";
                if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 13)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && ((CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 13) % 2) == 0))) {
                    // line 14
                    yield "                    </div>
                    <div class=\"row overflow-visible g-0\">
                                ";
                }
                // line 17
                yield "                            <div class=\"text-center pt-3 px-3 col\">
                                <a href=\"";
                // line 18
                yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, $context["menu"], "route", [], "any", false, false, false, 18));
                yield "\" class=\"text-decoration-none\">
                                    <span class=\"user-shortcuts-icon rounded-circle mb-2\">
                                      <i class=\"";
                // line 20
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon(CoreExtension::getAttribute($this->env, $this->source, $context["menu"], "icon", [], "any", false, false, false, 20)), "html", null, true);
                yield " fs-2\"></i>
                                    </span>
                                </a>
                                <a href=\"";
                // line 23
                yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, $context["menu"], "route", [], "any", false, false, false, 23));
                yield "\" class=\"nav-link\">";
                // line 24
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["menu"], "label", [], "any", false, false, false, 24)), "html", null, true);
                // line 25
                yield "</a>
                            </div>
                        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['menu'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 28
            yield "                        ";
            if (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["user_shortcuts"] ?? null)) > 1) && ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["user_shortcuts"] ?? null)) % 2) == 1))) {
                // line 29
                yield "                            <div class=\"pt-3 px-3 col\"></div>
                        ";
            }
            // line 31
            yield "                    </div>
                </div>
            </div>
        </div>
    </div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "partials/user-shortcuts.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  135 => 31,  131 => 29,  128 => 28,  111 => 25,  109 => 24,  106 => 23,  100 => 20,  95 => 18,  92 => 17,  87 => 14,  84 => 13,  67 => 12,  61 => 9,  54 => 5,  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "partials/user-shortcuts.html.twig", "/opt/kimai/templates/partials/user-shortcuts.html.twig");
    }
}
