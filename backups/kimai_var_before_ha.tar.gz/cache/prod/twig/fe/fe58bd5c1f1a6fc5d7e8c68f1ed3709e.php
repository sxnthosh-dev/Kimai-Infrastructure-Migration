<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/carousel.html.twig */
class __TwigTemplate_049ac22ef68c62fe258c947a23cbbd05 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 63
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_carousel($items = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $context["_id"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", true, true, false, 2) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 2)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 2)) : (("carousel-" . Twig\Extension\CoreExtension::random($this->env->getCharset(), 0, 999))));
            // line 3
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 3) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 3)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 3)) : (""));
            // line 4
            yield "
    ";
            // line 5
            $context["_interval"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "interval", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "interval", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "interval", [], "any", false, false, false, 5)) : (5000));
            // line 6
            yield "    ";
            $context["_touch_enabled"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "touch", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "touch", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "touch", [], "any", false, false, false, 6)) : (true));
            // line 7
            yield "    ";
            $context["_pause"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pause", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pause", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pause", [], "any", false, false, false, 7)) : (false));
            // line 8
            yield "    ";
            $context["_wrap"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "wrap", [], "any", true, true, false, 8) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "wrap", [], "any", false, false, false, 8)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "wrap", [], "any", false, false, false, 8)) : (true));
            // line 9
            yield "
    ";
            // line 10
            $context["_show_controls"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "controls", [], "any", true, true, false, 10) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "controls", [], "any", false, false, false, 10)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "controls", [], "any", false, false, false, 10)) : (false));
            // line 11
            yield "
    ";
            // line 12
            $context["_caption_class"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionCustomClass", [], "any", true, true, false, 12) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionCustomClass", [], "any", false, false, false, 12)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionCustomClass", [], "any", false, false, false, 12)) : ("d-none d-md-block"));
            // line 13
            yield "    ";
            $context["_show_caption_background"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionBackground", [], "any", true, true, false, 13) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionBackground", [], "any", false, false, false, 13)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "captionBackground", [], "any", false, false, false, 13)) : (true));
            // line 14
            yield "
    ";
            // line 15
            $context["_show_indicators"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicators", [], "any", true, true, false, 15) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicators", [], "any", false, false, false, 15)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicators", [], "any", false, false, false, 15)) : (true));
            // line 16
            yield "    ";
            $context["_indicators_type"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsType", [], "any", true, true, false, 16) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsType", [], "any", false, false, false, 16)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsType", [], "any", false, false, false, 16)) : (""));
            // line 17
            yield "    ";
            $context["_indicators_ratio"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsRatio", [], "any", true, true, false, 17) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsRatio", [], "any", false, false, false, 17)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsRatio", [], "any", false, false, false, 17)) : (""));
            // line 18
            yield "    ";
            $context["_indicators_orientation"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsOrientation", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsOrientation", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "indicatorsOrientation", [], "any", false, false, false, 18)) : ("horizontal"));
            // line 19
            yield "
    <div id=\"";
            // line 20
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
            yield "\" class=\"carousel slide ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\" data-bs-ride=\"carousel\"
         data-bs-interval=\"";
            // line 21
            yield (string) (((($context["_interval"] ?? null) == false)) ? ("false") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_interval"] ?? null), "html", null, true)));
            yield "\"
         data-bs-touch=\"";
            // line 22
            yield (string) (((($tmp = ($context["_touch_enabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("true") : ("false"));
            yield "\"
         data-bs-pause=\"";
            // line 23
            yield (string) (((($context["_pause"] ?? null) == true)) ? ("true") : ("hover"));
            yield "\" data-bs-wrap=\"";
            yield (string) (((($tmp = ($context["_wrap"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("true") : ("false"));
            yield "\">
        ";
            // line 24
            if ((($tmp = ($context["_show_indicators"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 25
                yield "            ";
                yield (string) $this->getTemplateForMacro("macro_carousel_indicators", $context, 25, $this->getSourceContext())->macro_carousel_indicators(...[($context["items"] ?? null), ($context["_id"] ?? null), ($context["_indicators_type"] ?? null), ($context["_indicators_orientation"] ?? null), ($context["_indicators_ratio"] ?? null)]);
                yield "
        ";
            }
            // line 27
            yield "        ";
            if ((($tmp = ($context["_show_controls"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 28
                yield "            <button class=\"carousel-control-prev\" type=\"button\" data-bs-target=\"#";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                yield "\" data-bs-slide=\"prev\">
                <span class=\"carousel-control-prev-icon\" aria-hidden=\"true\"></span>
            </button>
            <button class=\"carousel-control-next\" type=\"button\" data-bs-target=\"#";
                // line 31
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                yield "\" data-bs-slide=\"next\">
                <span class=\"carousel-control-next-icon\" aria-hidden=\"true\"></span>
            </button>
        ";
            }
            // line 35
            yield "        <div class=\"carousel-inner\">
            ";
            // line 36
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 37
                yield "                ";
                $context["_has_custom"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "customContent", [], "any", true, true, false, 37);
                // line 38
                yield "                <div class=\"carousel-item ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 38)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "active";
                }
                yield "\">
                ";
                // line 39
                if ((($tmp = ($context["_has_custom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 40
                    yield "                    ";
                    // line 41
                    yield "                    ";
                    yield (string) CoreExtension::getAttribute($this->env, $this->source, $context["item"], "customContent", [], "any", false, false, false, 41);
                    yield "
                ";
                } else {
                    // line 43
                    yield "                    <img src=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "image", [], "any", false, false, false, 43), "html", null, true);
                    yield "\" class=\"d-block w-100\" alt=\"";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", true, true, false, 43)) {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 43), "html", null, true);
                    }
                    yield "\">
                    ";
                    // line 44
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", true, true, false, 44) || CoreExtension::getAttribute($this->env, $this->source, $context["item"], "description", [], "any", true, true, false, 44))) {
                        // line 45
                        yield "                        ";
                        if ((($tmp = ($context["_show_caption_background"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 46
                            yield "                            <div class=\"carousel-caption-background ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_caption_class"] ?? null), "html", null, true);
                            yield "\"></div>
                        ";
                        }
                        // line 48
                        yield "                        <div class=\"carousel-caption ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_caption_class"] ?? null), "html", null, true);
                        yield "\">
                            ";
                        // line 49
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 49)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 50
                            yield "                                <h3>";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 50), "html", null, true);
                            yield "</h3>
                            ";
                        }
                        // line 52
                        yield "                            ";
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 52)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 53
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "description", [], "any", false, false, false, 53), "html", null, true);
                            yield "
                            ";
                        }
                        // line 55
                        yield "                        </div>
                    ";
                    }
                    // line 57
                    yield "                ";
                }
                // line 58
                yield "                </div>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 60
            yield "        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 64
    public function macro_carousel_indicators($items = null, $id = null, $type = null, $orientation = null, $ratio = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "id" => $id,
            "type" => $type,
            "orientation" => $orientation,
            "ratio" => $ratio,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 65
            yield "    ";
            $context["_typeClass"] = "";
            // line 66
            yield "    ";
            if ((($context["type"] ?? null) == "dots")) {
                $context["_typeClass"] = "carousel-indicators-dot";
            }
            // line 67
            yield "    ";
            if ((($context["type"] ?? null) == "thumbs")) {
                $context["_typeClass"] = "carousel-indicators-thumb";
            }
            // line 68
            yield "
    ";
            // line 69
            $context["_orientationClass"] = "";
            // line 70
            yield "    ";
            if ((($context["orientation"] ?? null) == "vertical")) {
                $context["_orientationClass"] = "carousel-indicators-vertical";
            }
            // line 71
            yield "    ";
            $context["_ratio"] = ("ratio " . (((($context["ratio"] ?? null) == "")) ? ("ratio-1x1") : (($context["ratio"] ?? null))));
            // line 72
            yield "
    <div class=\"carousel-indicators ";
            // line 73
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_typeClass"] ?? null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_orientationClass"] ?? null), "html", null, true);
            yield "\">
        ";
            // line 74
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 75
                yield "            ";
                $context["_item_class"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "first", [], "any", false, false, false, 75)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active") : (""));
                // line 76
                yield "            ";
                $context["_item_style"] = "";
                // line 77
                yield "            ";
                if ((($context["type"] ?? null) == "thumbs")) {
                    // line 78
                    yield "                ";
                    $context["_item_image"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "image", [], "any", true, true, false, 78) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "image", [], "any", false, false, false, 78)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "image", [], "any", false, false, false, 78)) : (""));
                    // line 79
                    yield "                ";
                    $context["_item_class"] = ((($context["_item_class"] ?? null) . " ") . ($context["_ratio"] ?? null));
                    // line 80
                    yield "                ";
                    $context["_item_style"] = (("background-image: url(\x27" . ($context["_item_image"] ?? null)) . "\x27);");
                    // line 81
                    yield "            ";
                }
                // line 82
                yield "            <button type=\"button\" data-bs-target=\"#";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\" data-bs-slide-to=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 82) - 1), "html", null, true);
                yield "\"
                    class=\"";
                // line 83
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_class"] ?? null), "html", null, true);
                yield "\" style=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_style"] ?? null), "html", null, true);
                yield "\"></button>
        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 85
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/carousel.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  385 => 85,  366 => 83,  359 => 82,  356 => 81,  353 => 80,  350 => 79,  347 => 78,  344 => 77,  341 => 76,  338 => 75,  321 => 74,  315 => 73,  312 => 72,  309 => 71,  304 => 70,  302 => 69,  299 => 68,  294 => 67,  289 => 66,  286 => 65,  270 => 64,  262 => 60,  246 => 58,  243 => 57,  239 => 55,  233 => 53,  230 => 52,  224 => 50,  222 => 49,  217 => 48,  211 => 46,  208 => 45,  206 => 44,  197 => 43,  191 => 41,  189 => 40,  187 => 39,  180 => 38,  177 => 37,  160 => 36,  157 => 35,  150 => 31,  143 => 28,  140 => 27,  134 => 25,  132 => 24,  126 => 23,  122 => 22,  118 => 21,  112 => 20,  109 => 19,  106 => 18,  103 => 17,  100 => 16,  98 => 15,  95 => 14,  92 => 13,  90 => 12,  87 => 11,  85 => 10,  82 => 9,  79 => 8,  76 => 7,  73 => 6,  71 => 5,  68 => 4,  65 => 3,  62 => 2,  49 => 1,  43 => 63,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/carousel.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/carousel.html.twig");
    }
}
