<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_user_list_layout.html.twig */
class __TwigTemplate_da52b91306a46ee5a4eea94000a18fa5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 4), 'widget');
        yield "
    ";
        // line 5
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "team", [], "any", true, true, false, 5)) {
            // line 6
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "team", [], "any", false, false, false, 6), 'widget', ["label" => false, "placeholder" => "team"]);
            yield "
    ";
        }
        // line 8
        yield "    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", true, true, false, 8)) {
            // line 9
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 9), 'widget', ["label" => false, "placeholder" => "project"]);
            yield "
    ";
        }
        // line 11
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "sumType", [], "any", false, false, false, 11), 'widget');
        yield "
    ";
        // line 12
        $macros["_v0"] = $this->load("@theme/components/buttons.html.twig", 12)->unwrap();
        // line 13
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_submit_button", $context, 13, $this->getSourceContext())->macro_submit_button(...["download", ["attr" => ["formaction" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["export_route"] ?? null))], "icon" => "download", "combined" => false]]);
        yield "
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "    ";
        yield from $this->load("reporting/report_user_list_layout.html.twig", 17, 1)->unwrap()->yield(CoreExtension::toArray(["report_content" =>         $this->unwrap()->renderBlock("report_content", $context, $blocks), "box_id" => ($context["box_id"] ?? null), "hasData" => ($context["hasData"] ?? null), "fullsize" => ($context["hasData"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  104 => 17,  97 => 16,  89 => 13,  87 => 12,  82 => 11,  76 => 9,  73 => 8,  67 => 6,  65 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_layout.html.twig", "/opt/kimai/templates/reporting/report_user_list_layout.html.twig");
    }
}


/* reporting/report_user_list_layout.html.twig */
class __TwigTemplate_da52b91306a46ee5a4eea94000a18fa5___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 17);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["box_id"] ?? null), "html", null, true);
        yield " table-responsive m-0";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        if ( !(($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 21
            yield "                ";
            $macros["_v1"] = $this->load("macros/widgets.html.twig", 21)->unwrap();
            // line 22
            yield "                ";
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_nothing_found", $context, 22, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
            ";
        } else {
            // line 24
            yield "                ";
            yield (string) ($context["report_content"] ?? null);
            yield "
            ";
        }
        // line 26
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_user_list_layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  211 => 26,  205 => 24,  199 => 22,  196 => 21,  193 => 20,  186 => 19,  174 => 18,  104 => 17,  97 => 16,  89 => 13,  87 => 12,  82 => 11,  76 => 9,  73 => 8,  67 => 6,  65 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_user_list_layout.html.twig", "/opt/kimai/templates/reporting/report_user_list_layout.html.twig");
    }
}
