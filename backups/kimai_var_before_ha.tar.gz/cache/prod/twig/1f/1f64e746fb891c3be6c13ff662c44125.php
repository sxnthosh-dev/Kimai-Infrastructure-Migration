<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @JMSSerializer/Collector/script/jms.js.twig */
class __TwigTemplate_cee60e24d35bfae40912b752f88a44c5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "/**
 * Toggle visibility on elements.
 */
document.addEventListener(\"DOMContentLoaded\", function() {
    Array.prototype.forEach.call(document.getElementsByClassName(\x27jms-toggle\x27), function (source) {
        source.addEventListener(\x27click\x27, function() {
            Array.prototype.forEach.call(document.querySelectorAll(source.getAttribute(\x27data-toggle\x27)), function (target) {
                target.classList.toggle(\x27jms-hidden\x27);
            });
        });
    });
});

/**
 * Copy as cURL.
 */
document.addEventListener(\"DOMContentLoaded\", function () {
    Array.prototype.forEach.call(document.getElementsByClassName(\x27jms-toolbar\x27), function (toolbar) {
        var button = toolbar.querySelector(\x27.jms-copy-as-curl>button\x27);
        button.addEventListener(\x27click\x27, function() {
            var input = toolbar.querySelector(\x27.jms-copy-as-curl>input\x27);
            input.select();
            document.execCommand(\x27copy\x27);
            input.setSelectionRange(0, 0);
       });
    });
})
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@JMSSerializer/Collector/script/jms.js.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@JMSSerializer/Collector/script/jms.js.twig", "/opt/kimai/vendor/jms/serializer-bundle/Resources/views/Collector/script/jms.js.twig");
    }
}
