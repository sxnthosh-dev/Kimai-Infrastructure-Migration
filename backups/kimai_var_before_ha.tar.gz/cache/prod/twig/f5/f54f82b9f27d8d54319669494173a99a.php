<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* customer/embed_projects.html.twig */
class __TwigTemplate_7065a8d27a14aed8addac92abfe4401e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "    ";
        yield from $this->load("customer/embed_projects.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["customer" => ($context["customer"] ?? null), "projects" => ($context["projects"] ?? null), "page" => ($context["page"] ?? null)]));
        // line 61
        yield "    <script type=\"text/javascript\">
        ";
        // line 62
        $context["eventName"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "javascriptRequest", [], "any", false, false, false, 62)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("kimai.reloadPage") : ("kimai.initialized"));
        // line 63
        yield "        document.addEventListener(\x27";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["eventName"] ?? null), "html", null, true);
        yield "\x27, function() {
            KimaiPaginatedBoxWidget.create(\x27#project_list_box\x27);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/embed_projects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  51 => 63,  49 => 62,  46 => 61,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/embed_projects.html.twig", "/opt/kimai/templates/customer/embed_projects.html.twig");
    }
}


/* customer/embed_projects.html.twig */
class __TwigTemplate_7065a8d27a14aed8addac92abfe4401e___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["actions"] = $this->macros["actions"] = $this->load("project/actions.html.twig", 2)->unwrap();
        // line 3
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("projects"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "            id=\"project_list_box\" data-reload=\"kimai.projectUpdate kimai.projectDelete\"
        ";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        if (((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("report:project")) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_any", "project")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 10
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 10, $this->getSourceContext())->macro_card_tool_button(...["reporting", ["title" => "report_project_view", "translation_domain" => "reporting", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("report_project_view", ["customer" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 10)])]]);
        }
        // line 12
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visible", [], "any", false, false, false, 12)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_project")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 13
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 13, $this->getSourceContext())->macro_card_tool_button(...["create", ["class" => "modal-ajax-form open-edit", "title" => "create", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project_create_with_customer", ["customer" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 13)])]]);
        }
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["projects"] ?? null)) > 0)) {
            // line 18
            yield "<div class=\"d-flex\">
                    ";
            // line 19
            yield (string) $this->extensions['App\Twig\PaginationExtension']->renderPagination(($context["projects"] ?? null), ["css_container_class" => "pagination ms-auto m-0", "routeName" => "customer_projects", "routeParams" => ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 19)]]);
            yield "
                </div>";
        }
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["projects"] ?? null)) > 0)) {
            yield "p-0";
        }
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "            ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["projects"] ?? null)) == 0)) {
            // line 26
            yield "                <div class=\"comment\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("error.no_entries_found"), "html", null, true);
            yield "</div>
            ";
        } else {
            // line 28
            yield "            <table class=\"table table-hover dataTable\">
                <thead>
                    <tr>
                        <th>";
            // line 31
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("name"), "html", null, true);
            yield "</th>
                        <th class=\"d-none d-md-table-cell\">";
            // line 32
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("comment"), "html", null, true);
            yield "</th>
                        <th class=\"d-none d-sm-table-cell w-min text-end\">";
            // line 33
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_end"), "html", null, true);
            yield "</th>
                        <th class=\"d-none d-sm-table-cell w-min text-center\">";
            // line 34
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("visible"), "html", null, true);
            yield "</th>
                        <th class=\"d-none d-sm-table-cell w-min text-center\">";
            // line 35
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team"), "html", null, true);
            yield "</th>
                        <th class=\"actions\"></th>
                    </tr>
                </thead>
                <tbody>
                ";
            // line 40
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["projects"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["project"]) {
                // line 41
                yield "                    <tr ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 41, $this->getSourceContext())->macro_project_row_attr(...[$context["project"], ($context["now"] ?? null)]);
                yield ">
                        <td>";
                // line 42
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 42, $this->getSourceContext())->macro_label_project(...[$context["project"]]);
                yield "</td>
                        <td class=\"d-none d-md-table-cell\">";
                // line 43
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentOneLiner($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "comment", [], "any", false, false, false, 43), "html", null, true), false);
                yield "</td>
                        <td class=\"d-none d-sm-table-cell w-min text-end\">
                            ";
                // line 45
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["project"], "end", [], "any", false, false, false, 45))) {
                    // line 46
                    yield "                                ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "end", [], "any", false, false, false, 46)), "html", null, true);
                    yield "
                            ";
                } else {
                    // line 48
                    yield "                                &ndash;
                            ";
                }
                // line 50
                yield "                        </td>
                        <td class=\"d-none d-sm-table-cell w-min text-center\">";
                // line 51
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 51, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, $context["project"], "visible", [], "any", false, false, false, 51)]);
                yield "</td>
                        <td class=\"d-none d-sm-table-cell w-min text-center\">";
                // line 52
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 52, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, $context["project"], "teams", [], "any", false, false, false, 52)]);
                yield "</td>
                        <td class=\"actions\">";
                // line 53
                yield (string) $macros["actions"]->getTemplateForMacro("macro_project", $context, 53, $this->getSourceContext())->macro_project(...[$context["project"], "customer_details", true]);
                yield "</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['project'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 56
            yield "                </tbody>
            </table>
            ";
        }
        // line 59
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/embed_projects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  314 => 59,  309 => 56,  299 => 53,  295 => 52,  291 => 51,  288 => 50,  284 => 48,  278 => 46,  276 => 45,  271 => 43,  267 => 42,  262 => 41,  258 => 40,  250 => 35,  246 => 34,  242 => 33,  238 => 32,  234 => 31,  229 => 28,  223 => 26,  220 => 25,  213 => 24,  200 => 23,  192 => 19,  189 => 18,  187 => 17,  180 => 16,  174 => 13,  172 => 12,  169 => 10,  167 => 9,  160 => 8,  154 => 6,  147 => 5,  136 => 4,  131 => 1,  129 => 3,  127 => 2,  120 => 1,  51 => 63,  49 => 62,  46 => 61,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/embed_projects.html.twig", "/opt/kimai/templates/customer/embed_projects.html.twig");
    }
}
