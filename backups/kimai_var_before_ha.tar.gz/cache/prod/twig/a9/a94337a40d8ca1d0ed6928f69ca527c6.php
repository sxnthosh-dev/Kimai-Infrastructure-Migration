<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/project_list_export.html.twig */
class __TwigTemplate_cebb563162797b51977753d704bedabc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["columns"] = ["customer" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer")], "name" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("name")], "currency" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("currency")], "budgetType" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType")]];
        // line 7
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_time", "project")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 8
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["timeBudget" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget")], "durationTotal" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal")], "billableTime" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable")], "exported" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_exported")]]);
        }
        // line 15
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_money", "project")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 16
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["budget" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget")], "amountTotal" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.amountTotal")], "billableMoney" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable")], "internalRate" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate")], "revenue" => ["title" => ((((($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue") . " (") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable")) . " - ") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate")) . ")")], "hourlyBillable" => ["title" => ((((($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate") . " (") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable")) . " / ") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal")) . ")")], "hourlyTotal" => ["title" => ((((($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate") . " (") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue")) . " / ") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal")) . ")")], "invoiced" => ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_invoiced")]]);
        }
        // line 27
        yield "<table>
    <thead>
        <tr>
        ";
        // line 30
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
        foreach ($context['_seq'] as $context["column"] => $context["settings"]) {
            // line 31
            yield "            <th>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["settings"], "title", [], "any", false, false, false, 31), "html", null, true);
            yield "</th>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['column'], $context['settings'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 33
        yield "        </tr>
    </thead>
    <tbody>
        ";
        // line 36
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["entries"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer", [], "any", false, false, false, 36), "name", [], "any", false, false, false, 36) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer", [], "any", false, false, false, 36), "name", [], "any", false, false, false, 36)); }));
        foreach ($context['_seq'] as $context["id"] => $context["mapping"]) {
            // line 37
            yield "            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 37), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "project", [], "any", false, false, false, 37), "name", [], "any", false, false, false, 37) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "project", [], "any", false, false, false, 37), "name", [], "any", false, false, false, 37)); }));
            foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                // line 38
                yield "                <tr>
                ";
                // line 39
                $context["project"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 39);
                // line 40
                yield "                ";
                $context["budgetStatisticModel"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "getBudgetStatisticModel", [], "method", false, false, false, 40);
                // line 41
                yield "                ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 41), "currency", [], "any", false, false, false, 41);
                // line 42
                yield "                ";
                $context["durationTotal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationTotal", [], "any", false, false, false, 42));
                // line 43
                yield "                ";
                $context["canSeeTimeBudget"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["project"] ?? null));
                // line 44
                yield "                ";
                $context["showTimeBudget"] = ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 44)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["canSeeTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp));
                // line 45
                yield "                ";
                $context["canSeeMoneyBudget"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null));
                // line 46
                yield "                ";
                $context["showMoneyBudget"] = ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 46)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp));
                // line 47
                yield "                ";
                $context["revenue"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getBudgetSpent", [], "method", false, false, false, 47) - CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getInternalRate", [], "method", false, false, false, 47));
                // line 48
                yield "                ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                    // line 49
                    yield "                    <td>
                    ";
                    // line 50
                    if (($context["name"] == "name")) {
                        // line 51
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "name", [], "any", false, false, false, 51), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 52
$context["name"] == "budgetType")) {
                        // line 53
                        yield "                        ";
                        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "budgetType", [], "any", false, false, false, 53))) {
                            // line 54
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(("budgetType_" . CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "budgetType", [], "any", false, false, false, 54))), "html", null, true);
                            yield "
                        ";
                        }
                        // line 56
                        yield "                    ";
                    } elseif (($context["name"] == "customer")) {
                        // line 57
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 57), "name", [], "any", false, false, false, 57), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 58
$context["name"] == "currency")) {
                        // line 59
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["currency"] ?? null), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 60
$context["name"] == "lastRecord")) {
                        // line 61
                        yield "                        ";
                        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "lastRecord", [], "any", false, false, false, 61))) {
                            // line 62
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "lastRecord", [], "any", false, false, false, 62)), "html", null, true);
                            yield "
                        ";
                        } else {
                            // line 64
                            yield "                            &ndash;
                        ";
                        }
                        // line 66
                        yield "                    ";
                    } elseif (($context["name"] == "today")) {
                        // line 67
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationDay", [], "any", false, false, false, 67), true), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 68
$context["name"] == "week")) {
                        // line 69
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationWeek", [], "any", false, false, false, 69), true), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 70
$context["name"] == "month")) {
                        // line 71
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationMonth", [], "any", false, false, false, 71), true), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 72
$context["name"] == "timeBudget")) {
                        // line 73
                        yield "                        ";
                        if ((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 74
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getTimeBudget", [], "method", false, false, false, 74), true), "html", null, true);
                            yield "
                        ";
                        }
                        // line 76
                        yield "                    ";
                    } elseif (($context["name"] == "durationTotal")) {
                        // line 77
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationTotal", [], "any", false, false, false, 77), true), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 78
$context["name"] == "billableTime")) {
                        // line 79
                        yield "                        ";
                        if ((($tmp = ($context["canSeeTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 80
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getTimeBudgetSpent", [], "method", false, false, false, 80), true), "html", null, true);
                            yield "
                        ";
                        }
                        // line 82
                        yield "                    ";
                    } elseif (($context["name"] == "exported")) {
                        // line 83
                        yield "                        ";
                        if ((($tmp = ($context["canSeeTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 84
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "notExportedDuration", [], "any", false, false, false, 84), true), "html", null, true);
                            yield "
                        ";
                        }
                        // line 86
                        yield "                    ";
                    } elseif (($context["name"] == "budget")) {
                        // line 87
                        yield "                        ";
                        if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 88
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getBudget", [], "method", false, false, false, 88)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 90
                        yield "                    ";
                    } elseif (($context["name"] == "amountTotal")) {
                        // line 91
                        yield "                        ";
                        if ((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 92
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getStatisticTotal", [], "method", false, false, false, 92), "getRate", [], "method", false, false, false, 92)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 94
                        yield "                    ";
                    } elseif (($context["name"] == "billableMoney")) {
                        // line 95
                        yield "                        ";
                        if ((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 96
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getBudgetSpent", [], "method", false, false, false, 96)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 98
                        yield "                    ";
                    } elseif (($context["name"] == "internalRate")) {
                        // line 99
                        yield "                        ";
                        if ((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 100
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getInternalRate", [], "method", false, false, false, 100)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 102
                        yield "                    ";
                    } elseif (($context["name"] == "revenue")) {
                        // line 103
                        yield "                        ";
                        if ((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 104
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["revenue"] ?? null)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 106
                        yield "                    ";
                    } elseif (($context["name"] == "hourlyBillable")) {
                        // line 107
                        yield "                        ";
                        if (((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["durationTotal"] ?? null) > 0))) {
                            // line 108
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStatisticModel"] ?? null), "getBudgetSpent", [], "method", false, false, false, 108) / ($context["durationTotal"] ?? null))), "html", null, true);
                            yield "
                        ";
                        }
                        // line 110
                        yield "                    ";
                    } elseif (($context["name"] == "hourlyTotal")) {
                        // line 111
                        yield "                        ";
                        if (((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["durationTotal"] ?? null) > 0))) {
                            // line 112
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($context["revenue"] ?? null) / ($context["durationTotal"] ?? null))), "html", null, true);
                            yield "
                        ";
                        }
                        // line 114
                        yield "                    ";
                    } elseif (($context["name"] == "invoiced")) {
                        // line 115
                        yield "                        ";
                        if ((($tmp = ($context["canSeeMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 116
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "notExportedRate", [], "any", false, false, false, 116)), "html", null, true);
                            yield "
                        ";
                        }
                        // line 118
                        yield "                    ";
                    } elseif (($context["name"] == "projectStart")) {
                        // line 119
                        yield "                        ";
                        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 119))) {
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 119)), "html", null, true);
                        }
                        // line 120
                        yield "                    ";
                    } elseif (($context["name"] == "projectEnd")) {
                        // line 121
                        yield "                        ";
                        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 121))) {
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 121)), "html", null, true);
                        }
                        // line 122
                        yield "                    ";
                    } elseif (($context["name"] == "comment")) {
                        // line 123
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "comment", [], "any", false, false, false, 123), "html", null, true);
                        yield "
                    ";
                    } elseif ((                    // line 124
$context["name"] == "actions")) {
                        // line 125
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["projectActions"] ?? null), "project", [($context["project"] ?? null), "custom"], "method", false, false, false, 125), "html", null, true);
                        yield "
                    ";
                    }
                    // line 127
                    yield "                    </td>
                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 129
                yield "                </tr>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 131
            yield "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['mapping'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 132
        yield "    </tbody>
</table>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project_list_export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  390 => 132,  383 => 131,  375 => 129,  367 => 127,  361 => 125,  359 => 124,  354 => 123,  351 => 122,  346 => 121,  343 => 120,  338 => 119,  335 => 118,  329 => 116,  326 => 115,  323 => 114,  317 => 112,  314 => 111,  311 => 110,  305 => 108,  302 => 107,  299 => 106,  293 => 104,  290 => 103,  287 => 102,  281 => 100,  278 => 99,  275 => 98,  269 => 96,  266 => 95,  263 => 94,  257 => 92,  254 => 91,  251 => 90,  245 => 88,  242 => 87,  239 => 86,  233 => 84,  230 => 83,  227 => 82,  221 => 80,  218 => 79,  216 => 78,  211 => 77,  208 => 76,  202 => 74,  199 => 73,  197 => 72,  192 => 71,  190 => 70,  185 => 69,  183 => 68,  178 => 67,  175 => 66,  171 => 64,  165 => 62,  162 => 61,  160 => 60,  155 => 59,  153 => 58,  148 => 57,  145 => 56,  139 => 54,  136 => 53,  134 => 52,  129 => 51,  127 => 50,  124 => 49,  119 => 48,  116 => 47,  113 => 46,  110 => 45,  107 => 44,  104 => 43,  101 => 42,  98 => 41,  95 => 40,  93 => 39,  90 => 38,  85 => 37,  81 => 36,  76 => 33,  66 => 31,  62 => 30,  57 => 27,  53 => 16,  51 => 15,  47 => 8,  45 => 7,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project_list_export.html.twig", "/opt/kimai/templates/reporting/project_list_export.html.twig");
    }
}
