<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* embeds/budgets.html.twig */
class __TwigTemplate_4fa7fb656758c4d5b73f7964b68f6606 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["timeBudgetVisible"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["entity"] ?? null));
        // line 2
        $context["durationTrans"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 2)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("stats.durationMonth") : ("stats.workingTime"));
        // line 3
        if ((($tmp = ($context["timeBudgetVisible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 4
            yield "    ";
            yield from $this->load("embeds/budgets.html.twig", 4, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        }
        // line 60
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["entity"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 61
            yield "    ";
            yield from $this->load("embeds/budgets.html.twig", 61, 2)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/budgets.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  55 => 61,  53 => 60,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/budgets.html.twig", "/opt/kimai/templates/embeds/budgets.html.twig");
    }
}


/* embeds/budgets.html.twig */
class __TwigTemplate_4fa7fb656758c4d5b73f7964b68f6606___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 4
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        $macros["progress"] = $this->macros["progress"] = $this->load("macros/progressbar.html.twig", 5)->unwrap();
        // line 6
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 6)->unwrap();
        // line 4
        $this->parent = $this->load("@theme/embeds/card.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
        yield " ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 8)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "(";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
            yield ")";
        }
        // line 9
        yield "        ";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"time_budget_box\"";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "            <div class=\"row\">
                <div class=\"col-12 col-md-6 order-1 order-md-0\">
                    <table class=\"table table-hover dataTable\">
                        <tr>
                            <td>";
        // line 16
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end w-min\">
                                ";
        // line 18
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 18) > 0)) {
            // line 19
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 19)), "html", null, true);
            yield "
                                ";
        } else {
            // line 21
            yield "                                    -
                                ";
        }
        // line 23
        yield "                            </td>
                        </tr>
                        <tr>
                            <td>";
        // line 26
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["durationTrans"] ?? null)), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end\">";
        // line 27
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 27)), "html", null, true);
        yield "</td>
                        </tr>
                        <tr>
                            <td>";
        // line 30
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end\">";
        // line 31
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 31)), "html", null, true);
        yield "</td>
                        </tr>
                        ";
        // line 33
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 33) > 0)) {
            // line 34
            yield "                            ";
            $context["totalPercentReached"] = 100;
            // line 35
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 35) > 0)) {
                // line 36
                yield "                                ";
                $context["totalPercentReached"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 36) / (CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 36) / 100));
                // line 37
                yield "                            ";
            }
            // line 38
            yield "                            <tr>
                                <th colspan=\"2\" class=\"text-nowrap text-end\">
                                    ";
            // line 40
            if ((($context["totalPercentReached"] ?? null) < 100)) {
                // line 41
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsedLeft", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["totalPercentReached"] ?? null), 2), "%left%" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 41) - CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 41)))]), "html", null, true);
                yield "
                                    ";
            } else {
                // line 43
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsed", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["totalPercentReached"] ?? null), 2)]), "html", null, true);
                yield "
                                    ";
            }
            // line 45
            yield "                                </th>
                            </tr>
                        ";
        }
        // line 48
        yield "                    </table>
                </div>
                <div class=\"col-12 col-md-6 order-0 order-md-1 p-3\">
                    ";
        // line 51
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 51) > 0)) {
            // line 52
            yield "                        <div class=\"mb-3\">";
            yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar", $context, 52, $this->getSourceContext())->macro_progressbar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 52), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 52), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["durationTrans"] ?? null)), (($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 52)) . " / ") . $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "timeBudget", [], "any", false, false, false, 52)))]);
            yield "</div>
                    ";
        }
        // line 54
        yield "                    <div class=\"mb-3\">";
        yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar", $context, 54, $this->getSourceContext())->macro_progressbar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 54), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 54), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), (($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "durationBillable", [], "any", false, false, false, 54)) . " / ") . $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 54))), true]);
        yield "</div>
                </div>
            </div>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/budgets.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  269 => 54,  263 => 52,  261 => 51,  256 => 48,  251 => 45,  245 => 43,  239 => 41,  237 => 40,  233 => 38,  230 => 37,  227 => 36,  224 => 35,  221 => 34,  219 => 33,  214 => 31,  210 => 30,  204 => 27,  200 => 26,  195 => 23,  191 => 21,  185 => 19,  183 => 18,  178 => 16,  172 => 12,  165 => 11,  154 => 10,  149 => 9,  140 => 8,  133 => 7,  128 => 4,  126 => 6,  124 => 5,  117 => 4,  55 => 61,  53 => 60,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/budgets.html.twig", "/opt/kimai/templates/embeds/budgets.html.twig");
    }
}


/* embeds/budgets.html.twig */
class __TwigTemplate_4fa7fb656758c4d5b73f7964b68f6606___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 61
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 62
        $macros["progress"] = $this->macros["progress"] = $this->load("macros/progressbar.html.twig", 62)->unwrap();
        // line 63
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 63)->unwrap();
        // line 61
        $this->parent = $this->load("@theme/embeds/card.html.twig", 61);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 64
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 65
        yield "            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
        yield " ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 65)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "(";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
            yield ")";
        }
        // line 66
        yield "        ";
        yield from [];
    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"budget_box\"";
        yield from [];
    }

    // line 68
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 69
        yield "            <div class=\"row\">
                <div class=\"col-12 col-md-6 order-1 order-md-0\">
                    <table class=\"table table-hover dataTable\">
                        <tr>
                            <td>";
        // line 73
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end w-min\">
                                ";
        // line 75
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 75) > 0)) {
            // line 76
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 76), ($context["currency"] ?? null)), "html", null, true);
            yield "
                                ";
        } else {
            // line 78
            yield "                                    -
                                ";
        }
        // line 80
        yield "                            </td>
                        </tr>
                        <tr>
                            <td>";
        // line 83
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end\">";
        // line 84
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 84), ($context["currency"] ?? null)), "html", null, true);
        yield "</td>
                        </tr>
                        <tr>
                            <td>";
        // line 87
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("costs"), "html", null, true);
        yield "</td>
                            <td class=\"text-nowrap text-end\">";
        // line 88
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "internalRate", [], "any", false, false, false, 88), ($context["currency"] ?? null)), "html", null, true);
        yield "</td>
                        </tr>
                        ";
        // line 90
        if (((( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 90)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["timeBudgetVisible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) && (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 90) > 0)) && ($this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 90)) > 0.0))) {
            // line 91
            yield "                            ";
            $context["revenueTotal"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 91) - CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "internalRate", [], "any", false, false, false, 91));
            // line 92
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "internalRate", [], "any", false, false, false, 92) > 0)) {
                // line 93
                yield "                                <tr>
                                    <td>";
                // line 94
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profit"), "html", null, true);
                yield " (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), "html", null, true);
                yield " - ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("costs"), "html", null, true);
                yield ")</td>
                                    <td class=\"text-nowrap text-end\">";
                // line 95
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["revenueTotal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                yield "</td>
                                </tr>
                            ";
            }
            // line 98
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 98) > 0)) {
                // line 99
                yield "                                ";
                $context["realHourlyRate"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 99) / $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 99)));
                // line 100
                yield "                                <tr>
                                    <td>";
                // line 101
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate"), "html", null, true);
                yield " (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), "html", null, true);
                yield " / ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["durationTrans"] ?? null)), "html", null, true);
                yield ")</td>
                                    <td class=\"text-nowrap text-end\">";
                // line 102
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["realHourlyRate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                yield "</td>
                                </tr>
                                ";
                // line 104
                if ((($context["revenueTotal"] ?? null) != 0.0)) {
                    // line 105
                    yield "                                    ";
                    $context["revenueHourlyRate"] = (($context["revenueTotal"] ?? null) / $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "duration", [], "any", false, false, false, 105)));
                    // line 106
                    yield "                                    <tr>
                                        <td>";
                    // line 107
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate"), "html", null, true);
                    yield " (";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("profit"), "html", null, true);
                    yield " / ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["durationTrans"] ?? null)), "html", null, true);
                    yield ")</td>
                                        <td class=\"text-nowrap text-end\">";
                    // line 108
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["revenueHourlyRate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                                    </tr>
                                ";
                }
                // line 111
                yield "                            ";
            }
            // line 112
            yield "                        ";
        }
        // line 113
        yield "                        ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 113) > 0)) {
            // line 114
            yield "                            ";
            $context["totalPercentReached"] = 100;
            // line 115
            yield "                            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 115) > 0)) {
                // line 116
                yield "                                ";
                $context["totalPercentReached"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 116) / (CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 116) / 100));
                // line 117
                yield "                            ";
            }
            // line 118
            yield "                            <tr>
                                <th colspan=\"2\" class=\"text-nowrap text-end\">
                                    ";
            // line 120
            if ((($context["totalPercentReached"] ?? null) < 100)) {
                // line 121
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsedLeft", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["totalPercentReached"] ?? null), 2), "%left%" => $this->extensions['App\Twig\LocaleFormatExtensions']->money((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 121) - CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 121)), ($context["currency"] ?? null))]), "html", null, true);
                yield "
                                    ";
            } else {
                // line 123
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.percentUsed", ["%percent%" => $this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["totalPercentReached"] ?? null), 2)]), "html", null, true);
                yield "
                                    ";
            }
            // line 125
            yield "                                </th>
                            </tr>
                        ";
        }
        // line 128
        yield "                    </table>
                </div>
                <div class=\"col-12 col-md-6 order-0 order-md-1 p-3\">
                    ";
        // line 131
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 131) > 0)) {
            // line 132
            yield "                        <div class=\"mb-3\">";
            yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar", $context, 132, $this->getSourceContext())->macro_progressbar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 132), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 132), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), (($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 132), ($context["currency"] ?? null)) . " / ") . $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "budget", [], "any", false, false, false, 132), ($context["currency"] ?? null)))]);
            yield "</div>
                    ";
        }
        // line 134
        yield "                    <div class=\"mb-3\">";
        yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar", $context, 134, $this->getSourceContext())->macro_progressbar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 134), CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "internalRate", [], "any", false, false, false, 134), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("costs"), (($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "internalRate", [], "any", false, false, false, 134), ($context["currency"] ?? null)) . " / ") . $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "rateBillable", [], "any", false, false, false, 134), ($context["currency"] ?? null)))]);
        yield "</div>
                </div>
            </div>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/budgets.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  562 => 134,  556 => 132,  554 => 131,  549 => 128,  544 => 125,  538 => 123,  532 => 121,  530 => 120,  526 => 118,  523 => 117,  520 => 116,  517 => 115,  514 => 114,  511 => 113,  508 => 112,  505 => 111,  499 => 108,  491 => 107,  488 => 106,  485 => 105,  483 => 104,  478 => 102,  470 => 101,  467 => 100,  464 => 99,  461 => 98,  455 => 95,  447 => 94,  444 => 93,  441 => 92,  438 => 91,  436 => 90,  431 => 88,  427 => 87,  421 => 84,  417 => 83,  412 => 80,  408 => 78,  402 => 76,  400 => 75,  395 => 73,  389 => 69,  382 => 68,  371 => 67,  366 => 66,  357 => 65,  350 => 64,  345 => 61,  343 => 63,  341 => 62,  334 => 61,  269 => 54,  263 => 52,  261 => 51,  256 => 48,  251 => 45,  245 => 43,  239 => 41,  237 => 40,  233 => 38,  230 => 37,  227 => 36,  224 => 35,  221 => 34,  219 => 33,  214 => 31,  210 => 30,  204 => 27,  200 => 26,  195 => 23,  191 => 21,  185 => 19,  183 => 18,  178 => 16,  172 => 12,  165 => 11,  154 => 10,  149 => 9,  140 => 8,  133 => 7,  128 => 4,  126 => 6,  124 => 5,  117 => 4,  55 => 61,  53 => 60,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/budgets.html.twig", "/opt/kimai/templates/embeds/budgets.html.twig");
    }
}
