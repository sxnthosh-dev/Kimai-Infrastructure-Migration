<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* default/_form.html.twig */
class __TwigTemplate_c7eeadda4021f51fac70229f8f8b9af6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'form_before' => [$this, 'block_form_before'],
            'form_body_outer' => [$this, 'block_form_body_outer'],
            'form_body_pre' => [$this, 'block_form_body_pre'],
            'form_body' => [$this, 'block_form_body'],
            'form_body_post' => [$this, 'block_form_body_post'],
            'submit_button' => [$this, 'block_submit_button'],
            'form_after' => [$this, 'block_form_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        if (array_key_exists("form_theme", $context)) {
            // line 2
            yield "    ";
            $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), [($context["form_theme"] ?? null)], true);
        }
        // line 4
        $context["bodyClasses"] = "card-body";
        // line 5
        if ((($tmp = (((array_key_exists("fullsize", $context) &&  !(null === $context["fullsize"]))) ? ($context["fullsize"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 6
            yield "    ";
            $context["bodyClasses"] = (($context["bodyClasses"] ?? null) . " p-0");
        }
        // line 8
        $context["_back"] = (((array_key_exists("back", $context) &&  !(($context["back"] ?? null) === false))) ? (($context["back"] ?? null)) : (false));
        // line 9
        $context["_reset"] = (((array_key_exists("reset", $context) && (($context["reset"] ?? null) === false))) ? (false) : (true));
        // line 10
        yield "<div class=\"card mb-3\">
    ";
        // line 11
        yield from $this->unwrap()->yieldBlock('form_before', $context, $blocks);
        // line 12
        yield "    ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ((array_key_exists("formStartOptions", $context)) ? (Twig\Extension\CoreExtension::default(($context["formStartOptions"] ?? null), [])) : ([])));
        yield "
    <div class=\"card-header\">
        <h3 class=\"card-title\">
            ";
        // line 15
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
        yield "
            ";
        // line 16
        if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 16), "docu_chapter", [], "any", true, true, false, 16) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 16), "docu_chapter", [], "any", false, false, false, 16)))) {
            // line 17
            yield "                <a class=\"form-help\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->documentationLink(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 17), "docu_chapter", [], "any", false, false, false, 17), "form"), "html", null, true);
            yield "\" target=\"_blank\">?</a>
            ";
        }
        // line 19
        yield "        </h3>
    </div>
    <div class=\"";
        // line 21
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["bodyClasses"] ?? null), "html", null, true);
        yield "\">
        ";
        // line 22
        yield from $this->unwrap()->yieldBlock('form_body_outer', $context, $blocks);
        // line 32
        yield "    </div>
    <div class=\"card-footer\">
        ";
        // line 34
        yield from $this->unwrap()->yieldBlock('submit_button', $context, $blocks);
        // line 37
        yield "        ";
        if ( !(($context["_back"] ?? null) === false)) {
            // line 38
            yield "            <a href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_back"] ?? null), "html", null, true);
            yield "\" class=\"btn btn-link\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("back"), "html", null, true);
            yield "</a>
        ";
        }
        // line 40
        yield "        ";
        if ( !(($context["_reset"] ?? null) === false)) {
            // line 41
            yield "            <input type=\"reset\" value=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.reset"), "html", null, true);
            yield "\" class=\"btn btn-link pull-right\" />
        ";
        }
        // line 43
        yield "    </div>
    ";
        // line 44
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
    ";
        // line 45
        yield from $this->unwrap()->yieldBlock('form_after', $context, $blocks);
        // line 46
        yield "</div>";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_outer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_body_pre', $context, $blocks);
        // line 26
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_body', $context, $blocks);
        // line 29
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_body_post', $context, $blocks);
        // line 31
        yield "        ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_pre(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "                ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
            ";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "                ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
            ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_post(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 30
        yield "            ";
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_submit_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 35
        yield "            <input type=\"submit\" data-loading-text=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((array_key_exists("submit_button", $context)) ? (Twig\Extension\CoreExtension::default(($context["submit_button"] ?? null), "action.save")) : ("action.save"))), "html", null, true);
        yield "…\" value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((array_key_exists("submit_button", $context)) ? (Twig\Extension\CoreExtension::default(($context["submit_button"] ?? null), "action.save")) : ("action.save"))), "html", null, true);
        yield "\" class=\"btn btn-primary\" />
        ";
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  232 => 45,  222 => 35,  215 => 34,  210 => 30,  203 => 29,  195 => 27,  188 => 26,  180 => 24,  173 => 23,  168 => 31,  165 => 29,  162 => 26,  159 => 23,  152 => 22,  142 => 11,  137 => 46,  135 => 45,  131 => 44,  128 => 43,  122 => 41,  119 => 40,  111 => 38,  108 => 37,  106 => 34,  102 => 32,  100 => 22,  96 => 21,  92 => 19,  86 => 17,  84 => 16,  80 => 15,  73 => 12,  71 => 11,  68 => 10,  66 => 9,  64 => 8,  60 => 6,  58 => 5,  56 => 4,  52 => 2,  50 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form.html.twig", "/opt/kimai/templates/default/_form.html.twig");
    }
}
