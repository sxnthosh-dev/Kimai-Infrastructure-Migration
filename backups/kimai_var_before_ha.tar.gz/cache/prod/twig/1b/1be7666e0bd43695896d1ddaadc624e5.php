<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* default/_form_delete.html.twig */
class __TwigTemplate_ec0e0b512523cf3e74fa477d6a54e441 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("default/_form_delete.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["boxtype" => "danger"]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form_delete.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form_delete.html.twig", "/opt/kimai/templates/default/_form_delete.html.twig");
    }
}


/* default/_form_delete.html.twig */
class __TwigTemplate_ec0e0b512523cf3e74fa477d6a54e441___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_before' => [$this, 'block_box_before'],
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
            'form_body' => [$this, 'block_form_body'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_after' => [$this, 'block_box_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        yield "        ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield "
    ";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("title", $context)) ? (Twig\Extension\CoreExtension::default(($context["title"] ?? null), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("confirm.delete"))) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("confirm.delete"))), "html", null, true);
        yield "
    ";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "        ";
        yield from $this->unwrap()->yieldBlock('form_body', $context, $blocks);
        // line 23
        yield "    ";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "            ";
        if (array_key_exists("delete_item_name", $context)) {
            // line 11
            yield "                <p><strong>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["delete_item_name"] ?? null), "html", null, true);
            yield "</strong></p>
            ";
        }
        // line 13
        yield "            ";
        if ((($context["used"] ?? null) === false)) {
            // line 14
            yield "                ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete.not_in_use"), "html", null, true);
            yield "
                <div class=\"d-none\">
                    ";
            // line 16
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
                </div>
            ";
        } else {
            // line 19
            yield "                <p>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["message"] ?? null), "html", null, true);
            yield "</p>
                ";
            // line 20
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
            ";
        }
        // line 21
        yield "            
        ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "        <input type=\"submit\" value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete"), "html", null, true);
        yield "\" class=\"btn btn-danger\" />
        ";
        // line 26
        if ((($tmp = ($context["back"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 27
            yield "            <a href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["back"] ?? null), "html", null, true);
            yield "\" class=\"btn btn-link\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("back"), "html", null, true);
            yield "</a>
        ";
        }
        // line 29
        yield "    ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "        ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form_delete.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  242 => 31,  235 => 30,  230 => 29,  222 => 27,  220 => 26,  215 => 25,  208 => 24,  202 => 21,  197 => 20,  192 => 19,  186 => 16,  180 => 14,  177 => 13,  171 => 11,  168 => 10,  161 => 9,  156 => 23,  153 => 9,  146 => 8,  138 => 6,  131 => 5,  123 => 3,  116 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form_delete.html.twig", "/opt/kimai/templates/default/_form_delete.html.twig");
    }
}
