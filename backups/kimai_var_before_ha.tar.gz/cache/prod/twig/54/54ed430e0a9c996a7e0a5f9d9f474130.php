<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/card_nav_header.html.twig */
class __TwigTemplate_cd0cbde24aa2a7a056bcd8439904e4e0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'card_header_class' => [$this, 'block_card_header_class'],
            'card_nav_before' => [$this, 'block_card_nav_before'],
            'card_nav_after' => [$this, 'block_card_nav_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["_tabs"] = (((array_key_exists("tabs", $context) &&  !(null === $context["tabs"]))) ? ($context["tabs"]) : (false));
        // line 3
        $context["_bottom"] = ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = (((array_key_exists("bottom", $context) &&  !(null === $context["bottom"]))) ? ($context["bottom"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 4
        $context["_manualContent"] = (((array_key_exists("manualContent", $context) &&  !(null === $context["manualContent"]))) ? ($context["manualContent"]) : (false));
        // line 5
        $context["_navType"] = (((array_key_exists("navType", $context) &&  !(null === $context["navType"]))) ? ($context["navType"]) : ("tabs"));
        // line 6
        yield "
";
        // line 8
        yield "<div class=\"";
        if ( !(($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "card-header";
        }
        yield " ";
        yield from $this->unwrap()->yieldBlock('card_header_class', $context, $blocks);
        yield "\">
    <ul
            class=\"nav nav-";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_navType"] ?? null), "html", null, true);
        yield " ";
        if ((($tmp = ($context["_bottom"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "nav-tabs-bottom";
        }
        yield " ";
        if ( !(($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "card-header-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_navType"] ?? null), "html", null, true);
        }
        yield "\"
            ";
        // line 11
        if ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "role=\"tablist\"";
        }
        // line 12
        yield "    >
        ";
        // line 13
        yield from $this->unwrap()->yieldBlock('card_nav_before', $context, $blocks);
        // line 14
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["_items"] ?? null));
        foreach ($context['_seq'] as $context["key"] => $context["item"]) {
            // line 15
            yield "
            ";
            // line 17
            yield "            ";
            $context["_id"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 17);
            // line 18
            yield "            ";
            $context["_name"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "name", [], "any", false, false, false, 18)) : (""));
            // line 19
            yield "
            ";
            // line 21
            yield "            ";
            $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 21)) : (false));
            // line 22
            yield "            ";
            $context["_disabled"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", true, true, false, 22) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 22)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 22)) : (false));
            // line 23
            yield "            ";
            if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 23)) {
                // line 24
                yield "                ";
                // line 25
                yield "                ";
                // line 26
                yield "                ";
                $context["_href"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", false, false, false, 26);
                // line 27
                yield "            ";
            } else {
                // line 28
                yield "                ";
                $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 28)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 28)) : (("#tabs-" . CoreExtension::getAttribute($this->env, $this->source, $context["item"], "id", [], "any", false, false, false, 28))));
                // line 29
                yield "            ";
            }
            // line 30
            yield "            ";
            $context["_raw"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "raw", [], "any", false, false, false, 30)) : (false));
            // line 31
            yield "
            <li
                    class=\"nav-item\"
                    ";
            // line 34
            if ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "role=\"presentation\"";
            }
            // line 35
            yield "            >
                <a
                        class=\"nav-link ";
            // line 37
            if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "active";
            }
            yield " ";
            if ((($tmp = ($context["_disabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "disabled";
            }
            yield "\"
                        href=\"";
            // line 38
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
            yield "\"
                        ";
            // line 39
            if ((($tmp = ($context["_disabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "tabindex=\"-1\" aria-disabled=\"true\"";
            }
            // line 40
            yield "                        ";
            if ((($tmp = ($context["_tabs"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 41
                yield "                            ";
                if ((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "aria-selected=\"true\"";
                }
                // line 42
                yield "                            role=\"tab\"
                        ";
            }
            // line 44
            yield "                        ";
            // line 45
            yield "                        ";
            if ((( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 45) &&  !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "url", [], "any", true, true, false, 45)) &&  !(($tmp = ($context["_manualContent"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                yield "data-bs-toggle=\"tab\"";
            }
            // line 46
            yield "                >
                    ";
            // line 47
            if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 48
                yield "                        ";
                yield (string) ($context["_name"] ?? null);
                yield "
                    ";
            } else {
                // line 50
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_name"] ?? null), "html", null, true);
                yield "
                    ";
            }
            // line 52
            yield "                </a>
            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['key'], $context['item'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 55
        yield "        ";
        yield from $this->unwrap()->yieldBlock('card_nav_after', $context, $blocks);
        // line 56
        yield "    </ul>
</div>

";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 55
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_nav_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/card_nav_header.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  241 => 55,  231 => 13,  221 => 8,  213 => 56,  210 => 55,  201 => 52,  195 => 50,  189 => 48,  187 => 47,  184 => 46,  179 => 45,  177 => 44,  173 => 42,  168 => 41,  165 => 40,  161 => 39,  157 => 38,  147 => 37,  143 => 35,  139 => 34,  134 => 31,  131 => 30,  128 => 29,  125 => 28,  122 => 27,  119 => 26,  117 => 25,  115 => 24,  112 => 23,  109 => 22,  106 => 21,  103 => 19,  100 => 18,  97 => 17,  94 => 15,  89 => 14,  87 => 13,  84 => 12,  80 => 11,  67 => 10,  57 => 8,  54 => 6,  52 => 5,  50 => 4,  48 => 3,  46 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/card_nav_header.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/card_nav_header.html.twig");
    }
}
