<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_by_user_data.html.twig */
class __TwigTemplate_97ccdbab4187d30244c12cffd75449d9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'upper_left' => [$this, 'block_upper_left'],
            'period_name' => [$this, 'block_period_name'],
            'column_classes_customer_total' => [$this, 'block_column_classes_customer_total'],
            'column_classes_project' => [$this, 'block_column_classes_project'],
            'column_classes_activity' => [$this, 'block_column_classes_activity'],
            'column_classes_total' => [$this, 'block_column_classes_total'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 1)->unwrap();
        // line 2
        $context["absoluteDuration"] = 0;
        // line 3
        $context["absoluteInternalRate"] = 0;
        // line 4
        $context["absoluteRate"] = 0;
        // line 5
        $context["totalsDuration"] = [];
        // line 6
        $context["totalsInternalRate"] = [];
        // line 7
        $context["totalsRate"] = [];
        // line 8
        $context["with_links"] = ((array_key_exists("with_links", $context)) ? (($context["with_links"] ?? null)) : (false));
        // line 9
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 10
            yield "    ";
            $context["dataTypeTitle"] = "stats.amountTotal";
        } elseif ((        // line 11
($context["dataType"] ?? null) == "internalRate")) {
            // line 12
            yield "    ";
            $context["dataTypeTitle"] = "internalRate";
        } else {
            // line 14
            yield "    ";
            $context["dataTypeTitle"] = "stats.durationTotal";
        }
        // line 16
        $context["columns"] = 0;
        // line 17
        $context["totalCurrency"] = false;
        // line 18
        $context["filter_options"] = ["begin" => ($context["begin"] ?? null), "end" => ($context["end"] ?? null)];
        // line 19
        $context["filter_route"] = "timesheet";
        // line 20
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_other_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 21
            yield "    ";
            $context["filter_route"] = "admin_timesheet";
            // line 22
            yield "    ";
            $context["filter_options"] = Twig\Extension\CoreExtension::merge(($context["filter_options"] ?? null), ["user" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 22)]);
        }
        // line 24
        yield "<table class=\"table table-hover dataTable\">
    <thead>
        <tr>
            <th>";
        // line 27
        yield from $this->unwrap()->yieldBlock('upper_left', $context, $blocks);
        yield "</th>
            <th class=\"text-center reportDataTypeTitle\">";
        // line 28
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
        yield "</th>
            ";
        // line 29
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "dateTimes", [], "any", false, false, false, 29));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
            // line 30
            yield "                ";
            yield from $this->unwrap()->yieldBlock('period_name', $context, $blocks);
            // line 33
            yield "                ";
            $context["columns"] = (($context["columns"] ?? null) + 1);
            // line 34
            yield "                ";
            $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate($context["column"]);
            // line 35
            yield "                ";
            $context["totalsDuration"] = Twig\Extension\CoreExtension::merge(($context["totalsDuration"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
            // line 36
            yield "                ";
            $context["totalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["totalsInternalRate"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
            // line 37
            yield "                ";
            $context["totalsRate"] = Twig\Extension\CoreExtension::merge(($context["totalsRate"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
            // line 38
            yield "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 39
        yield "        </tr>
    </thead>
    <tbody>
    ";
        // line 42
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["rows"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["customerId"] => $context["data"]) {
            // line 43
            yield "        ";
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["data"], "customer", [], "any", false, false, false, 43), "currency", [], "any", false, false, false, 43);
            // line 44
            yield "        ";
            if ((($context["totalCurrency"] ?? null) === false)) {
                // line 45
                yield "            ";
                $context["totalCurrency"] = ($context["currency"] ?? null);
                // line 46
                yield "        ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source, $context["data"], "customer", [], "any", false, false, false, 46) != ($context["totalCurrency"] ?? null))) {
                // line 47
                yield "            ";
                $context["totalCurrency"] = null;
                // line 48
                yield "        ";
            }
            // line 49
            yield "        ";
            $context["customerTotalsDuration"] = [];
            // line 50
            yield "        ";
            $context["customerTotalsInternalRate"] = [];
            // line 51
            yield "        ";
            $context["customerTotalsRate"] = [];
            // line 52
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "dateTimes", [], "any", false, false, false, 52));
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 53
                yield "            ";
                $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate($context["column"]);
                // line 54
                yield "            ";
                $context["customerTotalsDuration"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsDuration"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
                // line 55
                yield "            ";
                $context["customerTotalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsInternalRate"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
                // line 56
                yield "            ";
                $context["customerTotalsRate"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsRate"] ?? null), [ (string)($context["dateKey"] ?? null) => 0]);
                // line 57
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['column'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 58
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["data"], "projects", [], "any", false, false, false, 58));
            foreach ($context['_seq'] as $context["_key"] => $context["project"]) {
                // line 59
                yield "            ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["project"], "data", [], "any", false, false, false, 59), "data", [], "any", false, false, false, 59));
                foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                    // line 60
                    yield "                ";
                    $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "date", [], "any", false, false, false, 60));
                    // line 61
                    yield "                ";
                    $context["customerTotalsDuration"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsDuration"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v0 = ($context["customerTotalsDuration"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 61))]);
                    // line 62
                    yield "                ";
                    $context["customerTotalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsInternalRate"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v2 = ($context["customerTotalsInternalRate"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 62))]);
                    // line 63
                    yield "                ";
                    $context["customerTotalsRate"] = Twig\Extension\CoreExtension::merge(($context["customerTotalsRate"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v4 = ($context["customerTotalsRate"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[(($_v5 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v5 : $_v5)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 63))]);
                    // line 64
                    yield "            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['column'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 65
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['project'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 66
            yield "        <tr class=\"summary\">
            <td>";
            // line 67
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 67, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["data"], "customer", [], "any", false, false, false, 67)]);
            yield "</td>
            <td class=\"text-center total\">
                ";
            // line 69
            if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "<a href=\"";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_search_filter", $context, 69, $this->getSourceContext())->macro_search_filter(...[($context["filter_route"] ?? null), Twig\Extension\CoreExtension::merge(($context["filter_options"] ?? null), ["customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["data"], "customer", [], "any", false, false, false, 69), "id", [], "any", false, false, false, 69)])]);
                yield "\">";
            }
            // line 70
            yield "                ";
            if ((($context["dataType"] ?? null) == "rate")) {
                // line 71
                yield "                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["data"], "rate", [], "any", false, false, false, 71), ($context["currency"] ?? null)), "html", null, true);
                yield "
                ";
            } elseif ((            // line 72
($context["dataType"] ?? null) == "internalRate")) {
                // line 73
                yield "                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["data"], "internalRate", [], "any", false, false, false, 73), ($context["currency"] ?? null)), "html", null, true);
                yield "
                ";
            } else {
                // line 75
                yield "                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["data"], "duration", [], "any", false, false, false, 75), ($context["decimal"] ?? null)), "html", null, true);
                yield "
                ";
            }
            // line 77
            yield "                ";
            if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "</a>";
            }
            // line 78
            yield "            </td>
            ";
            // line 79
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "dateTimes", [], "any", false, false, false, 79));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                // line 80
                yield "                ";
                $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate($context["column"]);
                // line 81
                yield "                <td class=\"text-nowrap text-center day-total ";
                yield from $this->unwrap()->yieldBlock('column_classes_customer_total', $context, $blocks);
                yield "\">
                    ";
                // line 82
                if (((((($_v6 = ($context["customerTotalsRate"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[(($_v7 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v7 : $_v7)] ?? null) : null) > 0) || ((($_v8 = ($context["customerTotalsInternalRate"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8[(($_v9 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v9 : $_v9)] ?? null) : null) > 0)) || ((($_v10 = ($context["customerTotalsDuration"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10[(($_v11 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v11 : $_v11)] ?? null) : null) > 0))) {
                    // line 83
                    yield "                        ";
                    if ((($context["dataType"] ?? null) == "rate")) {
                        // line 84
                        yield "                            <strong>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v12 = ($context["customerTotalsRate"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12[(($_v13 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v13 : $_v13)] ?? null) : null), ($context["currency"] ?? null)), "html", null, true);
                        yield "</strong>
                        ";
                    } elseif ((                    // line 85
($context["dataType"] ?? null) == "internalRate")) {
                        // line 86
                        yield "                            <strong>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v14 = ($context["customerTotalsInternalRate"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14[(($_v15 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v15 : $_v15)] ?? null) : null), ($context["currency"] ?? null)), "html", null, true);
                        yield "</strong>
                        ";
                    } else {
                        // line 88
                        yield "                            <strong>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration((($_v16 = ($context["customerTotalsDuration"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16[(($_v17 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v17 : $_v17)] ?? null) : null), ($context["decimal"] ?? null)), "html", null, true);
                        yield "</strong>
                        ";
                    }
                    // line 90
                    yield "                    ";
                }
                // line 91
                yield "                </td>
            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 93
            yield "        </tr>
        ";
            // line 94
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["data"], "projects", [], "any", false, false, false, 94));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["project"]) {
                // line 95
                yield "            ";
                $context["absoluteDuration"] = (($context["absoluteDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["project"], "duration", [], "any", false, false, false, 95));
                // line 96
                yield "            ";
                $context["absoluteInternalRate"] = (($context["absoluteInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["project"], "internalRate", [], "any", false, false, false, 96));
                // line 97
                yield "            ";
                $context["absoluteRate"] = (($context["absoluteRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["project"], "rate", [], "any", false, false, false, 97));
                // line 98
                yield "            <tr class=\"project\">
                <td class=\"text-nowrap\">
                    <strong>";
                // line 100
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 100, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, $context["project"], "project", [], "any", false, false, false, 100)]);
                yield "</strong>
                </td>
                <td class=\"text-nowrap text-center total\">
                    ";
                // line 103
                if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "<a href=\"";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_search_filter", $context, 103, $this->getSourceContext())->macro_search_filter(...[($context["filter_route"] ?? null), Twig\Extension\CoreExtension::merge(($context["filter_options"] ?? null), ["project" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["project"], "project", [], "any", false, false, false, 103), "id", [], "any", false, false, false, 103)])]);
                    yield "\">";
                }
                // line 104
                if ((($context["dataType"] ?? null) == "rate")) {
                    // line 105
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "rate", [], "any", false, false, false, 105), ($context["currency"] ?? null)), "html", null, true);
                } elseif ((                // line 106
($context["dataType"] ?? null) == "internalRate")) {
                    // line 107
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "internalRate", [], "any", false, false, false, 107), ($context["currency"] ?? null)), "html", null, true);
                } else {
                    // line 109
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "duration", [], "any", false, false, false, 109), ($context["decimal"] ?? null)), "html", null, true);
                }
                // line 111
                if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "</a>";
                }
                // line 112
                yield "                </td>
                ";
                // line 113
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["project"], "data", [], "any", false, false, false, 113), "data", [], "any", false, false, false, 113));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                    // line 114
                    yield "                    ";
                    $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "date", [], "any", false, false, false, 114));
                    // line 115
                    yield "                    <td class=\"text-nowrap text-center day-total ";
                    yield from $this->unwrap()->yieldBlock('column_classes_project', $context, $blocks);
                    yield "\">
                        ";
                    // line 116
                    if ((((CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 116) != 0) || (CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 116) != 0)) || (CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 116) != 0))) {
                        // line 117
                        yield "                            ";
                        if ((($context["dataType"] ?? null) == "rate")) {
                            // line 118
                            yield "                                ";
                            $context["totalsRate"] = Twig\Extension\CoreExtension::merge(($context["totalsRate"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v18 = ($context["totalsRate"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18[(($_v19 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v19 : $_v19)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 118))]);
                            // line 119
                            yield "                                <strong>";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 119), ($context["currency"] ?? null)), "html", null, true);
                            yield "</strong>
                            ";
                        } elseif ((                        // line 120
($context["dataType"] ?? null) == "internalRate")) {
                            // line 121
                            yield "                                ";
                            $context["totalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["totalsInternalRate"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v20 = ($context["totalsInternalRate"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20[(($_v21 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v21 : $_v21)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 121))]);
                            // line 122
                            yield "                                <strong>";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 122), ($context["currency"] ?? null)), "html", null, true);
                            yield "</strong>
                            ";
                        } else {
                            // line 124
                            yield "                                ";
                            $context["totalsDuration"] = Twig\Extension\CoreExtension::merge(($context["totalsDuration"] ?? null), [ (string)($context["dateKey"] ?? null) => ((($_v22 = ($context["totalsDuration"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22[(($_v23 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v23 : $_v23)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 124))]);
                            // line 125
                            yield "                                <strong>";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 125), ($context["decimal"] ?? null)), "html", null, true);
                            yield "</strong>
                            ";
                        }
                        // line 127
                        yield "                        ";
                    }
                    // line 128
                    yield "                    </td>
                ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 130
                yield "            </tr>
            ";
                // line 131
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["project"], "activities", [], "any", false, false, false, 131));
                foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
                    // line 132
                    yield "                <tr class=\"activity\">
                    <td class=\"text-nowrap\">
                        ";
                    // line 134
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 134, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "activity", [], "any", false, false, false, 134)]);
                    yield "
                    </td>
                    <td class=\"text-nowrap text-center\">
                        ";
                    // line 137
                    if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield "<a href=\"";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_search_filter", $context, 137, $this->getSourceContext())->macro_search_filter(...[($context["filter_route"] ?? null), Twig\Extension\CoreExtension::merge(($context["filter_options"] ?? null), ["activity" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "activity", [], "any", false, false, false, 137), "id", [], "any", false, false, false, 137)])]);
                        yield "\">";
                    }
                    // line 138
                    yield "                        ";
                    if ((($context["dataType"] ?? null) == "rate")) {
                        // line 139
                        yield "                            ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "rate", [], "any", false, false, false, 139), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                        ";
                    } elseif ((                    // line 140
($context["dataType"] ?? null) == "internalRate")) {
                        // line 141
                        yield "                            ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "internalRate", [], "any", false, false, false, 141), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                        ";
                    } else {
                        // line 143
                        yield "                            ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "duration", [], "any", false, false, false, 143), ($context["decimal"] ?? null)), "html", null, true);
                        yield "
                        ";
                    }
                    // line 145
                    yield "                        ";
                    if ((($tmp = ($context["with_links"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        yield "</a>";
                    }
                    // line 146
                    yield "                    </td>
                    ";
                    // line 147
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "data", [], "any", false, false, false, 147), "data", [], "any", false, false, false, 147));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
                        // line 148
                        yield "                        <td class=\"text-nowrap text-center day-total ";
                        yield from $this->unwrap()->yieldBlock('column_classes_activity', $context, $blocks);
                        yield "\">
                            ";
                        // line 149
                        if ((((CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 149) != 0) || (CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 149) != 0)) || (CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 149) != 0))) {
                            // line 150
                            yield "                                ";
                            if ((($context["dataType"] ?? null) == "rate")) {
                                // line 151
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "rate", [], "any", false, false, false, 151), ($context["currency"] ?? null)), "html", null, true);
                                yield "
                                ";
                            } elseif ((                            // line 152
($context["dataType"] ?? null) == "internalRate")) {
                                // line 153
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "internalRate", [], "any", false, false, false, 153), ($context["currency"] ?? null)), "html", null, true);
                                yield "
                                ";
                            } else {
                                // line 155
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["column"], "duration", [], "any", false, false, false, 155), ($context["decimal"] ?? null)), "html", null, true);
                                yield "
                                ";
                            }
                            // line 157
                            yield "                            ";
                        }
                        // line 158
                        yield "                        </td>
                    ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 160
                    yield "                </tr>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['activity'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 162
                yield "        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['project'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 163
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['customerId'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 164
        yield "    </tbody>
    ";
        // line 165
        if ((($context["totalCurrency"] ?? null) === false)) {
            // line 166
            yield "        ";
            $context["totalCurrency"] = null;
            // line 167
            yield "    ";
        }
        // line 168
        yield "    <tfoot>
        <tr class=\"summary\">
            <td>";
        // line 170
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
        yield "</td>
            <td class=\"text-nowrap text-center total\">
                ";
        // line 172
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 173
            yield "                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["absoluteRate"] ?? null), ($context["totalCurrency"] ?? null)), "html", null, true);
            yield "
                ";
        } elseif ((        // line 174
($context["dataType"] ?? null) == "internalRate")) {
            // line 175
            yield "                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["absoluteInternalRate"] ?? null), ($context["totalCurrency"] ?? null)), "html", null, true);
            yield "
                ";
        } else {
            // line 177
            yield "                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["absoluteDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                ";
        }
        // line 179
        yield "            </td>
            ";
        // line 180
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["period"] ?? null), "dateTimes", [], "any", false, false, false, 180));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
            // line 181
            yield "                ";
            $context["dateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate($context["column"]);
            // line 182
            yield "                <td class=\"text-nowrap text-center day-total ";
            yield from $this->unwrap()->yieldBlock('column_classes_total', $context, $blocks);
            yield "\">
                    ";
            // line 183
            if ((($context["dataType"] ?? null) == "rate")) {
                // line 184
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v24 = ($context["totalsRate"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24[(($_v25 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v25 : $_v25)] ?? null) : null), ($context["totalCurrency"] ?? null)), "html", null, true);
                yield "
                    ";
            } elseif ((            // line 185
($context["dataType"] ?? null) == "internalRate")) {
                // line 186
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v26 = ($context["totalsInternalRate"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26[(($_v27 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v27 : $_v27)] ?? null) : null), ($context["totalCurrency"] ?? null)), "html", null, true);
                yield "
                    ";
            } else {
                // line 188
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration((($_v28 = ($context["totalsDuration"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28[(($_v29 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v29 : $_v29)] ?? null) : null), ($context["decimal"] ?? null)), "html", null, true);
                yield "
                    ";
            }
            // line 190
            yield "                </td>
            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 192
        yield "        </tr>
    </tfoot>
</table>
";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_upper_left(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(App\Utils\StringHelper::sanitizeDDE(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 27)), "html", null, true);
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "                    <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["column"] ?? null)), "html", null, true);
        yield "</th>
                ";
        yield from [];
    }

    // line 81
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_customer_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 115
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_project(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 148
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 182
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_by_user_data.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  848 => 182,  838 => 148,  828 => 115,  818 => 81,  810 => 31,  803 => 30,  792 => 27,  784 => 192,  768 => 190,  762 => 188,  756 => 186,  754 => 185,  749 => 184,  747 => 183,  742 => 182,  739 => 181,  722 => 180,  719 => 179,  713 => 177,  707 => 175,  705 => 174,  700 => 173,  698 => 172,  693 => 170,  689 => 168,  686 => 167,  683 => 166,  681 => 165,  678 => 164,  663 => 163,  648 => 162,  640 => 160,  624 => 158,  621 => 157,  615 => 155,  609 => 153,  607 => 152,  602 => 151,  599 => 150,  597 => 149,  592 => 148,  575 => 147,  572 => 146,  567 => 145,  561 => 143,  555 => 141,  553 => 140,  548 => 139,  545 => 138,  539 => 137,  533 => 134,  529 => 132,  525 => 131,  522 => 130,  506 => 128,  503 => 127,  497 => 125,  494 => 124,  488 => 122,  485 => 121,  483 => 120,  478 => 119,  475 => 118,  472 => 117,  470 => 116,  465 => 115,  462 => 114,  445 => 113,  442 => 112,  438 => 111,  435 => 109,  432 => 107,  430 => 106,  428 => 105,  426 => 104,  420 => 103,  414 => 100,  410 => 98,  407 => 97,  404 => 96,  401 => 95,  384 => 94,  381 => 93,  365 => 91,  362 => 90,  356 => 88,  350 => 86,  348 => 85,  343 => 84,  340 => 83,  338 => 82,  333 => 81,  330 => 80,  313 => 79,  310 => 78,  305 => 77,  299 => 75,  293 => 73,  291 => 72,  286 => 71,  283 => 70,  277 => 69,  272 => 67,  269 => 66,  262 => 65,  255 => 64,  252 => 63,  249 => 62,  246 => 61,  243 => 60,  238 => 59,  233 => 58,  226 => 57,  223 => 56,  220 => 55,  217 => 54,  214 => 53,  209 => 52,  206 => 51,  203 => 50,  200 => 49,  197 => 48,  194 => 47,  191 => 46,  188 => 45,  185 => 44,  182 => 43,  165 => 42,  160 => 39,  145 => 38,  142 => 37,  139 => 36,  136 => 35,  133 => 34,  130 => 33,  127 => 30,  110 => 29,  106 => 28,  102 => 27,  97 => 24,  93 => 22,  90 => 21,  88 => 20,  86 => 19,  84 => 18,  82 => 17,  80 => 16,  76 => 14,  72 => 12,  70 => 11,  67 => 10,  65 => 9,  63 => 8,  61 => 7,  59 => 6,  57 => 5,  55 => 4,  53 => 3,  51 => 2,  49 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_by_user_data.html.twig", "/opt/kimai/templates/reporting/report_by_user_data.html.twig");
    }
}
