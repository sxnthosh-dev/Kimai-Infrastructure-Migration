<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/layout.html.twig */
class __TwigTemplate_93dad34ab8f1f6bc67b0ba418b240afb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_title' => [$this, 'block_page_title'],
            'page_actions' => [$this, 'block_page_actions'],
            'main' => [$this, 'block_main'],
            'profile_intro' => [$this, 'block_profile_intro'],
            'user_title_box_attributes' => [$this, 'block_user_title_box_attributes'],
            'profile_content' => [$this, 'block_profile_content'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["actions"] = $this->macros["actions"] = $this->load("user/actions.html.twig", 2)->unwrap();
        // line 3
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("users"), "html", null, true);
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $macros["actions"]->getTemplateForMacro("macro_user", $context, 6, $this->getSourceContext())->macro_user(...[($context["user"] ?? null), ($context["tab"] ?? null)]);
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "    <div class=\"row\">
        <div class=\"col-xs-12\">
            ";
        // line 11
        yield from $this->unwrap()->yieldBlock('profile_intro', $context, $blocks);
        // line 37
        yield "            ";
        yield from $this->unwrap()->yieldBlock('profile_content', $context, $blocks);
        // line 38
        yield "        </div>
    </div>
";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_profile_intro(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "                <div class=\"card mb-3\">
                    <div class=\"card-body box-user-profile\">
                        <div class=\"row row-sm-2 align-items-center\">
                            <div class=\"col-auto\" data-toggle=\"tooltip\" title=\"";
        // line 15
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("id"), "html", null, true);
        yield ": ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 15), "html", null, true);
        yield "\">
                                ";
        // line 16
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 16, $this->getSourceContext())->macro_user_avatar(...[($context["user"] ?? null), false, "avatar-lg"]);
        yield "
                            </div>
                            <div class=\"col\" style=\"min-width: 100px\"";
        // line 18
        yield from $this->unwrap()->yieldBlock('user_title_box_attributes', $context, $blocks);
        yield ">
                                <h4 class=\"card-title m-0\">";
        // line 19
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_username", $context, 19, $this->getSourceContext())->macro_username(...[($context["user"] ?? null)]);
        yield "</h4>
                                ";
        // line 20
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "title", [], "any", false, false, false, 20))) {
            // line 21
            yield "                                <div class=\"text-body-secondary\">
                                    ";
            // line 22
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "title", [], "any", false, false, false, 22), "html", null, true);
            yield "
                                </div>
                                ";
        }
        // line 25
        yield "                            </div>
                            <div class=\"col-auto text-end mt-2 mt-sm-1\" id=\"profile-buttons\">
                                ";
        // line 27
        $macros["_v0"] = $this->load("@theme/components/buttons.html.twig", 27)->unwrap();
        // line 28
        yield "                                ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 28) == ($context["user"] ?? null))) {
            // line 29
            yield "                                ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_link_button", $context, 29, $this->getSourceContext())->macro_link_button(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("notifications"), "javascript:notificationStatus()", "fas fa-bell", "default"]);
            yield "
                                ";
        }
        // line 31
        yield "                                ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_link_button", $context, 31, $this->getSourceContext())->macro_link_button(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("email"), ("mailto:" . CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "email", [], "any", false, false, false, 31)), "mail", "default"]);
        yield "
                            </div>
                        </div>
                    </div>
                </div>
            ";
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_title_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_profile_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 42
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 43
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 44
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 44) == ($context["user"] ?? null))) {
            // line 45
            yield "    <script>
        function notificationStatus()
        {
            const notification = window.kimai.getPlugin(\x27notification\x27);
            if (!notification.isSupported()) {
                notification.request((result) => {
                    if (result === false) {
                        window.kimai.getPlugin(\x27alert\x27).info(\x27";
            // line 52
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("notifications.denied"), "js"), "html", null, true);
            yield "\x27);
                    } else if (result === true) {
                        notification.notify(null, \x27";
            // line 54
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("notifications.welcome"), "js"), "html", null, true);
            yield "\x27);
                    }
                    buttonStatusCheck(window.kimai);
                });
            } else {
                notification.notify(null, \x27";
            // line 59
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("notifications.welcome"), "js"), "html", null, true);
            yield "\x27);
            }
        }

        function buttonStatusCheck(kimai)
        {
            const button = document.querySelector(\x27div#profile-buttons a\x27);
            const icon = button.querySelector(\x27i\x27);
            const notification = kimai.getPlugin(\x27notification\x27);

            if (notification.isSupported()) {
                icon.classList.remove(\x27fa-bell-slash\x27);
                icon.classList.add(\x27fa-bell\x27);
                icon.classList.remove(\x27text-danger\x27);
                icon.classList.add(\x27text-success\x27);
            } else {
                icon.classList.remove(\x27fa-bell\x27);
                icon.classList.add(\x27fa-bell-slash\x27);
                icon.classList.remove(\x27text-success\x27);
                icon.classList.add(\x27text-danger\x27);
            }
        }

        document.addEventListener(\x27kimai.initialized\x27, function(event) {
            buttonStatusCheck(event.detail.kimai);
        });
    </script>
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  233 => 59,  225 => 54,  220 => 52,  211 => 45,  209 => 44,  204 => 43,  197 => 42,  187 => 37,  177 => 18,  165 => 31,  159 => 29,  156 => 28,  154 => 27,  150 => 25,  144 => 22,  141 => 21,  139 => 20,  135 => 19,  131 => 18,  126 => 16,  120 => 15,  115 => 12,  108 => 11,  101 => 38,  98 => 37,  96 => 11,  92 => 9,  85 => 8,  74 => 6,  63 => 5,  58 => 1,  56 => 3,  54 => 2,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/layout.html.twig", "/opt/kimai/templates/user/layout.html.twig");
    }
}
