<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/webloader.html.twig */
class __TwigTemplate_e1b48bcfd47e7353f61a19795deb3334 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_init_frontend_loader(...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $context["fdow"] = (( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 2))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 2), "firstDayOfWeek", [], "any", false, false, false, 2)) : ("monday"));
            // line 3
            yield "    ";
            $context["configurations"] = Twig\Extension\CoreExtension::merge($this->extensions['App\Twig\LocaleFormatExtensions']->getJavascriptConfiguration(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 3), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 3), "locale", [], "any", false, false, false, 3)), ["login" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login"), "direction" => (((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 5
($context["tabler_bundle"] ?? null), "rightToLeft", [], "any", false, false, false, 5)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("rtl") : ("ltr")), "first_dow_iso" => $this->extensions['App\Twig\Extensions']->getIsoDayByName(            // line 6
($context["fdow"] ?? null))]);
            // line 8
            yield "    <script type=\"text/javascript\">
        window.addEventListener(\x27load\x27, function() {
            const loader = new KimaiWebLoader(";
            // line 10
            yield (string) json_encode(($context["configurations"] ?? null));
            yield ",";
            yield (string) json_encode($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->getJavascriptTranslations());
            yield ");
            window.kimai = loader.getKimai();
        });
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/webloader.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  69 => 10,  65 => 8,  63 => 6,  62 => 5,  60 => 3,  57 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/webloader.html.twig", "/opt/kimai/templates/macros/webloader.html.twig");
    }
}
