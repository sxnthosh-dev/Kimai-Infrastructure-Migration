<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/security.html.twig */
class __TwigTemplate_0d066004ff5f3efdf86a16ecbd95bbce extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'html_start' => [$this, 'block_html_start'],
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body_start' => [$this, 'block_body_start'],
            'body_login_border' => [$this, 'block_body_login_border'],
            'body_class' => [$this, 'block_body_class'],
            'after_body_start' => [$this, 'block_after_body_start'],
            'page_before' => [$this, 'block_page_before'],
            'page_classes' => [$this, 'block_page_classes'],
            'container_before' => [$this, 'block_container_before'],
            'container_classes' => [$this, 'block_container_classes'],
            'logo_login' => [$this, 'block_logo_login'],
            'card_classes' => [$this, 'block_card_classes'],
            'login_box' => [$this, 'block_login_box'],
            'login_box_msg' => [$this, 'block_login_box_msg'],
            'login_box_error' => [$this, 'block_login_box_error'],
            'login_form' => [$this, 'block_login_form'],
            'login_form_start' => [$this, 'block_login_form_start'],
            'password_forgotten' => [$this, 'block_password_forgotten'],
            'password_show' => [$this, 'block_password_show'],
            'remember_me' => [$this, 'block_remember_me'],
            'csrf_token' => [$this, 'block_csrf_token'],
            'login_form_end' => [$this, 'block_login_form_end'],
            'login_social_auth' => [$this, 'block_login_social_auth'],
            'login_actions' => [$this, 'block_login_actions'],
            'registration' => [$this, 'block_registration'],
            'container_after' => [$this, 'block_container_after'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!doctype html";
        yield from $this->unwrap()->yieldBlock('html_start', $context, $blocks);
        yield ">
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 2), "html", null, true);
        yield "\"";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 2)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " dir=\"rtl\"";
        }
        yield " data-bs-theme=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->theme(), "html", null, true);
        yield "\" data-bs-theme-base=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeBase", [], "method", false, false, false, 2), "html", null, true);
        yield "\" data-bs-theme-radius=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeRadius", [], "method", false, false, false, 2), "html", null, true);
        yield "\" data-bs-theme-primary=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemePrimary", [], "method", false, false, false, 2), "html", null, true);
        yield "\">
<head>
    ";
        // line 4
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 7
        yield "    <title>";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>
    ";
        // line 8
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 15
        yield "</head>
<body";
        // line 16
        yield from $this->unwrap()->yieldBlock('body_start', $context, $blocks);
        yield " class=\"antialiased ";
        yield from $this->unwrap()->yieldBlock('body_login_border', $context, $blocks);
        yield " d-flex flex-column ";
        yield from $this->unwrap()->yieldBlock('body_class', $context, $blocks);
        yield "\">
";
        // line 17
        yield from $this->unwrap()->yieldBlock('after_body_start', $context, $blocks);
        // line 18
        yield from $this->unwrap()->yieldBlock('page_before', $context, $blocks);
        // line 19
        yield "<div class=\"";
        yield from $this->unwrap()->yieldBlock('page_classes', $context, $blocks);
        yield "\">
    ";
        // line 20
        yield from $this->unwrap()->yieldBlock('container_before', $context, $blocks);
        // line 21
        yield "    <div class=\"";
        yield from $this->unwrap()->yieldBlock('container_classes', $context, $blocks);
        yield "\">
        <div class=\"text-center mb-4\">
            <h1>";
        // line 23
        yield from $this->unwrap()->yieldBlock('logo_login', $context, $blocks);
        yield "</h1>
        </div>

        <div class=\"";
        // line 26
        yield from $this->unwrap()->yieldBlock('card_classes', $context, $blocks);
        yield "\">
            ";
        // line 27
        yield from $this->unwrap()->yieldBlock('login_box', $context, $blocks);
        // line 140
        yield "
            ";
        // line 141
        yield from $this->unwrap()->yieldBlock('login_social_auth', $context, $blocks);
        // line 158
        yield "        </div>

        ";
        // line 160
        yield from $this->unwrap()->yieldBlock('login_actions', $context, $blocks);
        // line 171
        yield "    </div>
    ";
        // line 172
        yield from $this->unwrap()->yieldBlock('container_after', $context, $blocks);
        // line 173
        yield "</div>

";
        // line 175
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 178
        yield "</body>
</html>
";
        yield from [];
    }

    // line 1
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_html_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "        ";
        yield from $this->load("@Tabler/includes/html_head.html.twig", 5)->unwrap()->yield($context);
        // line 6
        yield "    ";
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Sign In", [], "TablerBundle"), "html", null, true);
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "        ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 10
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler-rtl.css"), "html", null, true);
            yield "\">
        ";
        } else {
            // line 12
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.css"), "html", null, true);
            yield "\">
        ";
        }
        // line 14
        yield "    ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_login_border(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "border-top-wide border-primary";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "page page-center";
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "container container-tight py-4";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_logo_login(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Tabler";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "card card-md";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 28
        yield "            <div class=\"card-body\">
                <h2 class=\"card-title text-center mb-4\">";
        // line 29
        yield from $this->unwrap()->yieldBlock('login_box_msg', $context, $blocks);
        yield "</h2>
                ";
        // line 30
        yield from $this->unwrap()->yieldBlock('login_box_error', $context, $blocks);
        // line 35
        yield "                ";
        yield from $this->unwrap()->yieldBlock('login_form', $context, $blocks);
        // line 138
        yield "            </div>
            ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box_msg(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box_error(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "                    ";
        if ((($tmp = ((array_key_exists("error", $context)) ? (Twig\Extension\CoreExtension::default(($context["error"] ?? null), false)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 32
            yield "                        <div class=\"alert alert-important alert-danger\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["error"] ?? null), "messageKey", [], "any", false, false, false, 32), CoreExtension::getAttribute($this->env, $this->source, ($context["error"] ?? null), "messageData", [], "any", false, false, false, 32), "security"), "html", null, true);
            yield "</div>
                    ";
        }
        // line 34
        yield "                ";
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "                    <form action=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_login_check"));
        yield "\" method=\"post\" autocomplete=\"off\" class=\"login-box-body security-login\">
                    ";
        // line 37
        yield from $this->unwrap()->yieldBlock('login_form_start', $context, $blocks);
        // line 38
        yield "                        <div class=\"mb-3\">
                            <label for=\"username\" class=\"form-label\">";
        // line 39
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Username", [], "TablerBundle"), "html", null, true);
        yield "</label>
                            <input autocomplete=\"username\" type=\"text\" id=\"username\" name=\"_username\" tabindex=\"10\" class=\"form-control\" placeholder=\"";
        // line 40
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Username", [], "TablerBundle"), "html", null, true);
        yield "\" value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("last_username", $context)) ? (Twig\Extension\CoreExtension::default(($context["last_username"] ?? null), "")) : ("")), "html", null, true);
        yield "\" required=\"required\">
                        </div>
                        <div class=\"mb-3\">
                            <label for=\"password\" class=\"form-label\">
                                ";
        // line 44
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Password", [], "TablerBundle"), "html", null, true);
        yield "
                                ";
        // line 45
        yield from $this->unwrap()->yieldBlock('password_forgotten', $context, $blocks);
        // line 52
        yield "                            </label>
                            <div class=\"input-group input-group-flat\">
                                <input autocomplete=\"new-password\" id=\"password\" name=\"_password\" type=\"password\" tabindex=\"20\" class=\"form-control\" placeholder=\"";
        // line 54
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Password", [], "TablerBundle"), "html", null, true);
        yield "\" required=\"required\">
                                ";
        // line 55
        yield from $this->unwrap()->yieldBlock('password_show', $context, $blocks);
        // line 119
        yield "                            </div>
                        </div>
                        ";
        // line 121
        yield from $this->unwrap()->yieldBlock('remember_me', $context, $blocks);
        // line 129
        yield "                        <div class=\"form-footer\">
                            <button type=\"submit\" tabindex=\"40\" class=\"btn btn-primary w-100\">";
        // line 130
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Sign In", [], "TablerBundle"), "html", null, true);
        yield "</button>
                        </div>
                        ";
        // line 132
        yield from $this->unwrap()->yieldBlock('csrf_token', $context, $blocks);
        // line 135
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('login_form_end', $context, $blocks);
        // line 136
        yield "                    </form>
                ";
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_password_forgotten(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        yield "                                    ";
        if (($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_password_reset") != "tabler_password_reset")) {
            // line 47
            yield "                                        <span class=\"form-label-description\">
                                            <a href=\"";
            // line 48
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_password_reset"));
            yield "\" tabindex=\"100\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("I forgot my password", [], "TablerBundle"), "html", null, true);
            yield "</a>
                                        </span>
                                    ";
        }
        // line 51
        yield "                                ";
        yield from [];
    }

    // line 55
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_password_show(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 56
        yield "                                <span class=\"input-group-text\">
                                    <a
                                            href=\"#\" class=\"link-secondary\"
                                            data-show-title=\"";
        // line 59
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Show password", [], "TablerBundle"), "html", null, true);
        yield "\"
                                            data-hide-title=\"";
        // line 60
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Hide password", [], "TablerBundle"), "html", null, true);
        yield "\"
                                            data-bs-toggle=\"tooltip\" title=\"";
        // line 61
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Show password", [], "TablerBundle"), "html", null, true);
        yield "\"
                                            onclick=\"toggleShowPasswordInput()\"
                                    >
                                        <span>
                                            ";
        // line 66
        yield "                                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"icon icon-1\">
                                               <path d=\"M10 12a2 2 0 1 0 4 0a2 2 0 0 0 -4 0\"></path>
                                               <path d=\"M21 12c-2.4 4 -5.4 6 -9 6c-3.6 0 -6.6 -2 -9 -6c2.4 -4 5.4 -6 9 -6c3.6 0 6.6 2 9 6\"></path>
                                            </svg>
                                        </span>

                                        <span hidden>
                                            ";
        // line 74
        yield "                                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" class=\"icon icon-tabler icons-tabler-outline icon-tabler-eye-off\">
                                                <path stroke=\"none\" d=\"M0 0h24v24H0z\" fill=\"none\" />
                                                <path d=\"M10.585 10.587a2 2 0 0 0 2.829 2.828\" />
                                                <path d=\"M16.681 16.673a8.717 8.717 0 0 1 -4.681 1.327c-3.6 0 -6.6 -2 -9 -6c1.272 -2.12 2.712 -3.678 4.32 -4.674m2.86 -1.146a9.055 9.055 0 0 1 1.82 -.18c3.6 0 6.6 2 9 6c-.666 1.11 -1.379 2.067 -2.138 2.87\" />
                                                <path d=\"M3 3l18 18\" />
                                            </svg>
                                        </span>
                                    </a>
                                </span>
                                <script>
                                    function toggleShowPasswordInput() {
                                        const input = document.querySelector(\x27input[name=\"_password\"]\x27);
                                        if (!input) {
                                            return;
                                        }

                                        const a = input.parentElement.querySelector(\x27.input-group-text a\x27);
                                        let tooltipEl = null;
                                        if (a.hasAttribute(\x27aria-describedBy\x27)) {
                                            tooltipEl = document.getElementById(a.getAttribute(\x27aria-describedBy\x27));
                                        }
                                        const svgs = input.parentElement.querySelectorAll(\x27.input-group-text svg\x27);

                                        let title = \x27\x27;
                                        if (input.type === \x27password\x27) {
                                            title = a.getAttribute(\x27data-hide-title\x27);
                                            input.type = \x27text\x27;
                                            svgs[0].parentElement.hidden = true;
                                            svgs[1].parentElement.hidden = false;
                                        } else {
                                            title = a.getAttribute(\x27data-show-title\x27);
                                            input.type = \x27password\x27;
                                            svgs[0].parentElement.hidden = false;
                                            svgs[1].parentElement.hidden = true;
                                        }

                                        a.ariaLabel = title;
                                        a.title = title;
                                        a.setAttribute(\x27data-bs-original-title\x27, title);
                                        if (tooltipEl !== null) {
                                            tooltipEl.querySelector(\x27.tooltip-inner\x27).innerText = title;
                                        }
                                    }
                                </script>
                                ";
        yield from [];
    }

    // line 121
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_remember_me(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 122
        yield "                        <div class=\"mb-3\">
                            <label class=\"form-check\">
                                <input id=\"remember_me\" tabindex=\"30\" name=\"_remember_me\" type=\"checkbox\" class=\"form-check-input\">
                                <span class=\"form-check-label\">";
        // line 125
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Remember Me", [], "TablerBundle"), "html", null, true);
        yield "</span>
                            </label>
                        </div>
                        ";
        yield from [];
    }

    // line 132
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_csrf_token(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 133
        yield "                            <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
        yield "\"/>
                        ";
        yield from [];
    }

    // line 135
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 141
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_social_auth(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 142
        yield "            <div class=\"hr-text\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("or", [], "TablerBundle"), "html", null, true);
        yield "</div>
            <div class=\"card-body\">
                <div class=\"row\">
                    <div class=\"col\">
                        <a href=\"#\" class=\"btn btn-white w-100\">
                            <i class=\"icon fab fa-github text-github\"></i> Github
                        </a>
                    </div>
                    <div class=\"col\">
                        <a href=\"#\" class=\"btn btn-white w-100\">
                            <i class=\"icon fab fa-twitter text-twitter\"></i> Twitter
                        </a>
                    </div>
                </div>
            </div>
            ";
        yield from [];
    }

    // line 160
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 161
        yield "            ";
        yield from $this->unwrap()->yieldBlock('registration', $context, $blocks);
        // line 170
        yield "        ";
        yield from [];
    }

    // line 161
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_registration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 162
        yield "                ";
        if (($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_registration") != "tabler_registration")) {
            // line 163
            yield "                    <div class=\"text-center text-body-secondary mt-3\">
                        <a href=\"";
            // line 164
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_registration"));
            yield "\">
                            ";
            // line 165
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Register a new account", [], "TablerBundle"), "html", null, true);
            yield "
                        </a>
                    </div>
                ";
        }
        // line 169
        yield "            ";
        yield from [];
    }

    // line 172
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 175
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 176
        yield "    <script src=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.js"), "html", null, true);
        yield "\"></script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/security.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  722 => 176,  715 => 175,  705 => 172,  700 => 169,  693 => 165,  689 => 164,  686 => 163,  683 => 162,  676 => 161,  671 => 170,  668 => 161,  661 => 160,  639 => 142,  632 => 141,  622 => 135,  614 => 133,  607 => 132,  598 => 125,  593 => 122,  586 => 121,  537 => 74,  528 => 66,  521 => 61,  517 => 60,  513 => 59,  508 => 56,  501 => 55,  496 => 51,  488 => 48,  485 => 47,  482 => 46,  475 => 45,  465 => 37,  459 => 136,  456 => 135,  454 => 132,  449 => 130,  446 => 129,  444 => 121,  440 => 119,  438 => 55,  434 => 54,  430 => 52,  428 => 45,  424 => 44,  415 => 40,  411 => 39,  408 => 38,  406 => 37,  401 => 36,  394 => 35,  389 => 34,  383 => 32,  380 => 31,  373 => 30,  363 => 29,  357 => 138,  354 => 35,  352 => 30,  348 => 29,  345 => 28,  338 => 27,  327 => 26,  316 => 23,  305 => 21,  295 => 20,  284 => 19,  274 => 18,  264 => 17,  235 => 16,  230 => 14,  224 => 12,  218 => 10,  215 => 9,  208 => 8,  197 => 7,  192 => 6,  189 => 5,  182 => 4,  172 => 1,  165 => 178,  163 => 175,  159 => 173,  157 => 172,  154 => 171,  152 => 160,  148 => 158,  146 => 141,  143 => 140,  141 => 27,  137 => 26,  131 => 23,  125 => 21,  123 => 20,  118 => 19,  116 => 18,  114 => 17,  106 => 16,  103 => 15,  101 => 8,  96 => 7,  94 => 4,  77 => 2,  72 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/security.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/security.html.twig");
    }
}
