<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/collapsible.html.twig */
class __TwigTemplate_8c1f34c4a123f863eae2812f3f281368 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_class' => [$this, 'block_box_class'],
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 2
        return "@Tabler/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["fullsize"] = true;
        // line 3
        $macros["_v0"] = $this->macros["_v0"] = $this->load("@Tabler/components/accordion.html.twig", 3)->unwrap();
        // line 8
        $context["item"] = Twig\Extension\CoreExtension::merge(["title" => ((        $this->unwrap()->hasBlock("title", $context, $blocks)) ? (        $this->unwrap()->renderBlock("title", $context, $blocks)) : ("")), "body" => ((        $this->unwrap()->hasBlock("body", $context, $blocks)) ? (        $this->unwrap()->renderBlock("body", $context, $blocks)) : ("")), "bodyClasses" => "", "options" => ["open" => (((        // line 12
array_key_exists("open", $context) &&  !(null === $context["open"]))) ? ($context["open"]) : (false)), "bodyExtraClass" => (((($tmp = (((array_key_exists("border", $context) &&  !(null === $context["border"]))) ? ($context["border"]) : (true))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("border-top pt-3") : (""))]], (((        // line 13
array_key_exists("item", $context) &&  !(null === $context["item"]))) ? ($context["item"]) : ([])));
        // line 15
        $context["options"] = Twig\Extension\CoreExtension::merge(["flush" => (((array_key_exists("flush", $context) &&  !(null === $context["flush"]))) ? ($context["flush"]) : (false))], (((array_key_exists("options", $context) &&  !(null === $context["options"]))) ? ($context["options"]) : ([])));
        // line 2
        $this->parent = $this->load("@Tabler/embeds/card.html.twig", 2);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "border-0";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_accordion", $context, 18, $this->getSourceContext())->macro_accordion(...[[($context["item"] ?? null)], ($context["options"] ?? null)]);
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/collapsible.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  93 => 18,  86 => 17,  76 => 6,  65 => 5,  60 => 2,  58 => 15,  56 => 13,  55 => 12,  54 => 8,  52 => 3,  50 => 1,  43 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/collapsible.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/collapsible.html.twig");
    }
}
