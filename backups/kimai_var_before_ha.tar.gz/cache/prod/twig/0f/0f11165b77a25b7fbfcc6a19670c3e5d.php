<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/navbar_user.html.twig */
class __TwigTemplate_e100370f51f2a33b225ba2a29c681d01 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["user"] = null;
        // line 2
        $context["links"] = null;
        // line 3
        $context["userdetails"] = $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getUserDetails();
        // line 4
        if ( !(null === ($context["userdetails"] ?? null))) {
            // line 5
            yield "    ";
            $context["user"] = CoreExtension::getAttribute($this->env, $this->source, ($context["userdetails"] ?? null), "user", [], "any", false, false, false, 5);
            // line 6
            yield "    ";
            $context["links"] = CoreExtension::getAttribute($this->env, $this->source, ($context["userdetails"] ?? null), "links", [], "any", false, false, false, 6);
            // line 7
            yield "    ";
            $context["showLogoutLink"] = CoreExtension::getAttribute($this->env, $this->source, ($context["userdetails"] ?? null), "showLogoutLink", [], "any", false, false, false, 7);
        }
        // line 9
        if ( !(null === ($context["user"] ?? null))) {
            // line 10
            yield "    <div class=\"nav-item dropdown\">
        <a href=\"#\" class=\"nav-link d-flex lh-1 p-0 px-2\" data-bs-toggle=\"dropdown\" aria-label=\"";
            // line 11
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Open personal menu", [], "TablerBundle"), "html", null, true);
            yield "\">
            ";
            // line 12
            $macros["macro"] = $this->macros["macro"] = $this->load("@Tabler/components/avatar.html.twig", 12)->unwrap();
            // line 13
            yield "            ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", true, true, false, 13) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 13)))) {
                // line 14
                yield "                ";
                yield (string) $macros["macro"]->getTemplateForMacro("macro_avatar", $context, 14, $this->getSourceContext())->macro_avatar(...[["imageUrl" => $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 14)), "size" => "sm"]]);
                yield "
            ";
            } else {
                // line 16
                yield "                ";
                $macros["macro_image"] = $this->macros["macro_image"] = $this->load("@Tabler/components/avatar_image.html.twig", 16)->unwrap();
                // line 17
                yield "                ";
                yield (string) $macros["macro"]->getTemplateForMacro("macro_avatar", $context, 17, $this->getSourceContext())->macro_avatar(...[["content" => $macros["macro_image"]->getTemplateForMacro("macro_avatar_image", $context, 17, $this->getSourceContext())->macro_avatar_image(...[($context["user"] ?? null)]), "size" => "sm"]]);
                yield "
            ";
            }
            // line 19
            yield "            ";
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isCondensedUserMenu", [], "method", false, false, false, 19)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 20
                yield "                <div class=\"d-none d-xl-block ps-2\">
                    <div>";
                // line 21
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "name", [], "any", false, false, false, 21), "html", null, true);
                yield "</div>
                    ";
                // line 22
                if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "title", [], "any", false, false, false, 22))) {
                    // line 23
                    yield "                        <div class=\"mt-1 small text-body-secondary\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "title", [], "any", false, false, false, 23), "html", null, true);
                    yield "</div>
                    ";
                }
                // line 25
                yield "                </div>
            ";
            }
            // line 27
            yield "        </a>

        <div class=\"dropdown-menu dropdown-menu-end dropdown-menu-arrow\">
            ";
            // line 30
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["links"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["link"]) {
                // line 31
                yield "                ";
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["link"], "route", [], "any", false, false, false, 31))) {
                    // line 32
                    yield "                    <a href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias(CoreExtension::getAttribute($this->env, $this->source, $context["link"], "route", [], "any", false, false, false, 32)), CoreExtension::getAttribute($this->env, $this->source, $context["link"], "routeArgs", [], "any", false, false, false, 32)), "html", null, true);
                    yield "\" class=\"dropdown-item\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["link"], "label", [], "any", false, false, false, 32)), "html", null, true);
                    yield "</a>
                ";
                } else {
                    // line 34
                    yield "                    <a href=\"#\" class=\"dropdown-item\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["link"], "label", [], "any", false, false, false, 34)), "html", null, true);
                    yield "</a>
                ";
                }
                // line 36
                yield "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['link'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 37
            yield "            ";
            if ((($tmp = ($context["showLogoutLink"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 38
                yield "                <div class=\"dropdown-divider\"></div>
                <a href=\"";
                // line 39
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\LogoutUrlExtension']->getLogoutPath(), "html", null, true);
                yield "\" class=\"dropdown-item\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Sign out", [], "TablerBundle"), "html", null, true);
                yield "</a>
            ";
            }
            // line 41
            yield "        </div>
    </div>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/navbar_user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  158 => 41,  151 => 39,  148 => 38,  145 => 37,  138 => 36,  132 => 34,  124 => 32,  121 => 31,  117 => 30,  112 => 27,  108 => 25,  102 => 23,  100 => 22,  96 => 21,  93 => 20,  90 => 19,  84 => 17,  81 => 16,  75 => 14,  72 => 13,  70 => 12,  66 => 11,  63 => 10,  61 => 9,  57 => 7,  54 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/navbar_user.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/navbar_user.html.twig");
    }
}
