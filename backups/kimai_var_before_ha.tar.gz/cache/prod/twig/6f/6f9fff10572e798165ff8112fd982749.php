<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/datatables.html.twig */
class __TwigTemplate_b6dc394e22170025518ad99a0d087023 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "
";
        // line 5
        yield "
";
        // line 9
        yield "
";
        // line 13
        yield "
";
        // line 17
        yield "
";
        // line 91
        yield "
";
        // line 159
        yield "
";
        // line 240
        yield "
";
        // line 244
        yield "
";
        // line 275
        yield "
";
        // line 280
        yield "
";
        yield from [];
    }

    // line 2
    public function macro_configuration($dataTable = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "dataTable" => $dataTable,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_data_table_column_modal", $context, 3, $this->getSourceContext())->macro_data_table_column_modal(...[CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getTableName", [], "method", false, false, false, 3), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getColumns", [], "method", false, false, false, 3)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 6
    public function macro_header($dataTable = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "dataTable" => $dataTable,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 7
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_datatable_header", $context, 7, $this->getSourceContext())->macro_datatable_header(...[CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getTableName", [], "method", false, false, false, 7), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getColumns", [], "method", false, false, false, 7), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getQuery", [], "method", false, false, false, 7), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getOptions", [], "method", false, false, false, 7)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 10
    public function macro_footer($dataTable = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "dataTable" => $dataTable,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 11
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_data_table_footer", $context, 11, $this->getSourceContext())->macro_data_table_footer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getPagination", [], "method", false, false, false, 11), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getPaginationRoute", [], "method", false, false, false, 11), CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getBatchForm", [], "method", false, false, false, 11)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 14
    public function macro_class($dataTable = null, $column = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "dataTable" => $dataTable,
            "column" => $column,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 15
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\DatatableExtensions']->getDatatableColumnClass(CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getTableName", [], "method", false, false, false, 15), ($context["column"] ?? null)), "html", null, true);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 19
    public function macro_actions($dataTable = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "dataTable" => $dataTable,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 20
            yield "    <div class=\"btn-list\">
    ";
            // line 21
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "hasConfiguration", [], "method", false, false, false, 21)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 22
                yield "        <a class=\"btn btn-icon\" href=\"#\" data-bs-toggle=\"modal\" data-bs-target=\"#modal_";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getTableName", [], "method", false, false, false, 22), "html", null, true);
                yield "\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("modal.columns.title"), "html", null, true);
                yield "\">
            ";
                // line 23
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("columns", true);
                yield "
        </a>
    ";
            }
            // line 26
            yield "    ";
            $context["form"] = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getSearchForm", [], "method", false, false, false, 26);
            // line 27
            yield "    ";
            if ( !(null === ($context["form"] ?? null))) {
                // line 28
                yield "        ";
                $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/search.html.twig"], true);
                // line 29
                yield "        ";
                $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "order", [], "any", false, false, false, 29), ["form/vertical.html.twig"], true);
                // line 30
                yield "        ";
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["class" => "searchform"]]);
                yield "
        ";
                // line 31
                $context["searchTerm"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "searchTerm", [], "any", false, false, false, 31), 'widget');
                // line 32
                yield "        ";
                $context["orderHasError"] = ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderBy", [], "any", false, false, false, 32), "vars", [], "any", false, false, false, 32), "errors", [], "any", false, false, false, 32)) > 0) || (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "order", [], "any", false, false, false, 32), "vars", [], "any", false, false, false, 32), "errors", [], "any", false, false, false, 32)) > 0));
                // line 33
                yield "        ";
                $context["orderBy"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderBy", [], "any", false, false, false, 33), 'widget');
                // line 34
                yield "        ";
                $context["order"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "order", [], "any", false, false, false, 34), 'widget');
                // line 35
                yield "        ";
                $context["filterCount"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "getQuery", [], "method", false, false, false, 35), "countFilter", [], "method", false, false, false, 35);
                // line 36
                yield "        <div class=\"input-group inline-search position-static\">
            <button type=\"button\" class=\"btn dropdown-toggle\" data-bs-toggle=\"dropdown\" data-bs-auto-close=\"false\" aria-haspopup=\"true\" aria-expanded=\"false\" id=\"search-dropdown-btn\" title=\"";
                // line 37
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("search_filter"), "html", null, true);
                yield "\">
                ";
                // line 38
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("filter", true);
                yield "
                ";
                // line 39
                if ((($context["filterCount"] ?? null) > 0)) {
                    yield "<span class=\"badge badge-notification bg-primary text-primary-fg ms-1 d-none d-sm-inline\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["filterCount"] ?? null), "html", null, true);
                    yield "</span>";
                }
                // line 40
                yield "            </button>
            <div class=\"dropdown-menu p-3 search-dropdown\" data-popper-placement=\"bottom-start\" aria-labelledby=\"search-dropdown-btn\">
                ";
                // line 42
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
                yield "
                <div class=\"mb-2 row ";
                // line 43
                if ((($tmp = ($context["orderHasError"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield " is-invalid";
                }
                yield " \">
                    ";
                // line 44
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderBy", [], "any", false, false, false, 44), 'label');
                yield "
                    <div class=\"col-sm-4 col-xs-6\">
                        ";
                // line 46
                yield (string) ($context["orderBy"] ?? null);
                yield "
                        ";
                // line 47
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderBy", [], "any", false, false, false, 47), 'errors');
                yield "
                    </div>
                    <div class=\"col-sm-4 col-xs-6\">
                        ";
                // line 50
                yield (string) ($context["order"] ?? null);
                yield "
                        ";
                // line 51
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "order", [], "any", false, false, false, 51), 'errors');
                yield "
                    </div>
                </div>
                <div class=\"row mt-3\">
                    <div class=\"col-12 text-end\">
                        <button type=\"submit\" class=\"btn btn-primary\">";
                // line 56
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("search"), "html", null, true);
                yield "</button>
                    </div>
                </div>
            </div>
            ";
                // line 60
                yield (string) ($context["searchTerm"] ?? null);
                yield "
            <span class=\"input-group-text\">
                ";
                // line 62
                $context["bookmarkToken"] = $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("search");
                // line 63
                yield "                ";
                $context["searchBtnClass"] = "btn btn-icon btn-sm btn-ghost-secondary p-1";
                // line 64
                yield "                <input type=\"hidden\" name=\"_token\" value=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["bookmarkToken"] ?? null), "html", null, true);
                yield "\">
                <button type=\"submit\" class=\"";
                // line 65
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["searchBtnClass"] ?? null), "html", null, true);
                yield "\" data-toggle=\"tooltip\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("search"), "html", null, true);
                yield "\">
                    ";
                // line 66
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("search");
                yield "
                </button>

                ";
                // line 69
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 69), "data", [], "any", false, false, false, 69), "bookmark", [], "any", false, false, false, 69)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 70
                    yield "                <a class=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["searchBtnClass"] ?? null), "html", null, true);
                    yield " text-yellow\" href=\"?_token=";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["bookmarkToken"] ?? null), "html", null, true);
                    yield "&removeDefaultQuery=";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 70), "data", [], "any", false, false, false, 70), "bookmark", [], "any", false, false, false, 70), "name", [], "any", false, false, false, 70), "html", null, true);
                    yield "\" data-toggle=\"tooltip\" title=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("remove_default"), "html", null, true);
                    yield "\" id=\"removeDefaultQuery\">
                    ";
                    // line 71
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("bookmarked");
                    yield "
                </a>
                ";
                } elseif ((                // line 73
($context["filterCount"] ?? null) > 0)) {
                    // line 74
                    yield "                <button class=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["searchBtnClass"] ?? null), "html", null, true);
                    yield "\" type=\"submit\" id=\"setDefaultQuery\" name=\"setDefaultQuery\" data-toggle=\"tooltip\" title=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("set_as_default"), "html", null, true);
                    yield "\">
                    ";
                    // line 75
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("bookmark");
                    yield "
                </button>
                ";
                }
                // line 78
                yield "
                ";
                // line 79
                if (((($context["filterCount"] ?? null) > 0) &&  !(($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 79), "data", [], "any", false, false, false, 79), "isBookmarkSearch", [], "method", false, false, false, 79)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    // line 80
                    yield "                    <a class=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["searchBtnClass"] ?? null), "html", null, true);
                    yield " text-orange\" href=\"";
                    yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 80), "attributes", [], "any", false, false, false, 80), "get", ["_route"], "method", false, false, false, 80));
                    yield "\" data-toggle=\"tooltip\" title=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("remove_filter"), "html", null, true);
                    yield "\">
                        ";
                    // line 81
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("cancel");
                    yield "
                    </a>
                ";
                }
                // line 84
                yield "            </span>
        </div>
        <input type=\"hidden\" name=\"performSearch\" value=\"performSearch\" />
        ";
                // line 87
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
                yield "
    ";
            }
            // line 89
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 92
    public function macro_data_table_column_modal($name = null, $columns = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "name" => $name,
            "columns" => $columns,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 93
            $context["visibility"] = $this->extensions['App\Twig\DatatableExtensions']->initializeDatatable(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 93), CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 93), ($context["name"] ?? null), ($context["columns"] ?? null));
            // line 94
            yield "<div class=\"modal\" data-bs-backdrop=\"static\" id=\"modal_";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
            yield "\" data-column-visibility=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
            yield "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"data_table_modal_label\">
    <div class=\"modal-dialog modal-lg\" role=\"document\">
        <div class=\"modal-content\">
            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"data_table_modal_label\">";
            // line 98
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("modal.columns.title"), "html", null, true);
            yield "</h5>
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"";
            // line 99
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
            yield "\"></button>
            </div>
            <div class=\"modal-body\">
                <form name=\"";
            // line 102
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
            yield "_visibility\" method=\"post\" action=\"";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bookmark_save_datatable");
            yield "\" class=\"mb-3\">
                    <div class=\"row mb-3\">
                        <div class=\"col-12\">
                            <label class=\"form-label\">";
            // line 105
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("modal.columns.label"), "html", null, true);
            yield "</label>
                            <div class=\"form-selectgroup form-selectgroup-pills\">";
            // line 107
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
            foreach ($context['_seq'] as $context["title"] => $context["headerOptions"]) {
                // line 108
                $context["translationDomain"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", true, true, false, 108) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", false, false, false, 108)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", false, false, false, 108)) : ("messages"));
                // line 109
                yield "                                    ";
                if ( !is_iterable($context["headerOptions"])) {
                    // line 110
                    yield "                                        ";
                    $context["headerOptions"] = ["class" => $context["headerOptions"]];
                    // line 111
                    yield "                                    ";
                }
                // line 112
                yield "                                    ";
                if ((CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "title", [], "any", true, true, false, 112) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "title", [], "any", false, false, false, 112)))) {
                    // line 113
                    yield "                                        ";
                    $context["headerTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "title", [], "any", false, false, false, 113), [], ($context["translationDomain"] ?? null));
                    // line 114
                    yield "                                    ";
                } else {
                    // line 115
                    yield "                                        ";
                    $context["headerTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["title"], [], ($context["translationDomain"] ?? null));
                    // line 116
                    yield "                                    ";
                }
                // line 117
                yield "                                    ";
                if (!CoreExtension::inFilter("alwaysVisible", CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "class", [], "any", false, false, false, 117))) {
                    // line 118
                    yield "                                        <label class=\"form-selectgroup-item\">
                                            <input class=\"form-selectgroup-input\" type=\"checkbox\" id=\"column_";
                    // line 119
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["title"], "html", null, true);
                    yield "\" name=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["title"], "html", null, true);
                    yield "\">
                                            <span class=\"form-selectgroup-label\">";
                    // line 120
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["headerTitle"] ?? null), "html", null, true);
                    yield "</span>
                                        </label>
                                    ";
                }
                // line 123
                yield "                                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['title'], $context['headerOptions'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 124
            yield "                            </div>
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-12\">
                            <label class=\"form-label\">";
            // line 129
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("modal.columns.profile"), "html", null, true);
            yield "</label>
                            <div class=\"form-selectgroup\">
                                <label class=\"form-selectgroup-item\">
                                    <input type=\"radio\" name=\"datatable_profile\" value=\"";
            // line 132
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::PROFILE_DESKTOP"), "html", null, true);
            yield "\" class=\"form-selectgroup-input\" data-href=\"";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bookmark_profile");
            yield "\"";
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 132), "get", [Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::SESSION_PROFILE"), ""], "method", false, false, false, 132) == "")) {
                yield " checked=\"checked\"";
            }
            yield ">
                                    <span class=\"form-selectgroup-label\">
                                        ";
            // line 134
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("desktop"), "html", null, true);
            yield "
                                    </span>
                                </label>
                                <label class=\"form-selectgroup-item\">
                                    <input type=\"radio\" name=\"datatable_profile\" value=\"";
            // line 138
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::PROFILE_MOBILE"), "html", null, true);
            yield "\" class=\"form-selectgroup-input\" data-href=\"";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bookmark_profile");
            yield "\"";
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 138), "get", [Twig\Extension\CoreExtension::constant("\\App\\Utils\\ProfileManager::SESSION_PROFILE"), ""], "method", false, false, false, 138) == "mobile")) {
                yield " checked=\"checked\"";
            }
            yield ">
                                    <span class=\"form-selectgroup-label\">
                                        ";
            // line 140
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("mobile"), "html", null, true);
            yield "
                                    </span>
                                </label>
                            </div>
                        </div>
                    </div>
                    <input type=\"hidden\" name=\"datatable_name\" value=\"";
            // line 146
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
            yield "\" />
                    <input type=\"hidden\" name=\"datatable_token\" value=\"";
            // line 147
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken(Twig\Extension\CoreExtension::constant("\\App\\Controller\\BookmarkController::DATATABLE_TOKEN")), "html", null, true);
            yield "\" />
                </form>
            </div>
            <div class=\"modal-footer\">
                <button type=\"submit\" formaction=\"";
            // line 151
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("bookmark_delete");
            yield "\" class=\"btn btn-outline-danger me-auto\" data-type=\"reset\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.reset"), "html", null, true);
            yield "</button>
                <button type=\"submit\" class=\"btn btn-primary\" data-type=\"save\">";
            // line 152
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
            yield "</button>
                <button type=\"button\" class=\"btn\" data-bs-dismiss=\"modal\">";
            // line 153
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
            yield "</button>
            </div>
        </div>
    </div>
</div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 160
    public function macro_datatable_header($tableName = null, $columns = null, $query = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "tableName" => $tableName,
            "columns" => $columns,
            "query" => $query,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 161
            yield "    ";
            $context["visibility"] = $this->extensions['App\Twig\DatatableExtensions']->initializeDatatable(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 161), CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 161), ($context["tableName"] ?? null), ($context["columns"] ?? null));
            // line 162
            yield "    ";
            if ( !(null === ($context["query"] ?? null))) {
                // line 163
                yield "        ";
                $context["orderBy"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "orderBy", [], "any", true, true, false, 163)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "orderBy", [], "any", false, false, false, 163), CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "orderBy", [], "any", false, false, false, 163))) : (CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "orderBy", [], "any", false, false, false, 163)));
                // line 164
                yield "        ";
                $context["order"] = Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "order", [], "any", false, false, false, 164));
                // line 165
                yield "    ";
            } else {
                // line 166
                yield "        ";
                $context["orderBy"] = false;
                // line 167
                yield "        ";
                $context["order"] = false;
                // line 168
                yield "    ";
            }
            // line 169
            yield "    ";
            $context["reloadEvent"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "reload", [], "any", true, true, false, 169)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "reload", [], "any", false, false, false, 169), "")) : (""));
            // line 170
            yield "    ";
            $context["boxClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "boxClass", [], "any", true, true, false, 170) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "boxClass", [], "any", false, false, false, 170)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "boxClass", [], "any", false, false, false, 170)) : ("card data_table"));
            // line 171
            yield "    ";
            $context["columnModal"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "columnConfig", [], "any", true, true, false, 171) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "columnConfig", [], "any", false, false, false, 171)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "columnConfig", [], "any", false, false, false, 171)) : (true));
            // line 172
            yield "    ";
            $context["responsive"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "responsive", [], "any", true, true, false, 172) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "responsive", [], "any", false, false, false, 172)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "responsive", [], "any", false, false, false, 172)) : (false));
            // line 173
            yield "    ";
            $context["sticky"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "sticky", [], "any", true, true, false, 173) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "sticky", [], "any", false, false, false, 173)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "sticky", [], "any", false, false, false, 173)) : (true));
            // line 174
            yield "    ";
            $context["contextMenuId"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "contextMenuId", [], "any", true, true, false, 174)) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "contextMenuId", [], "any", false, false, false, 174)) : ((("datatable_" . ($context["tableName"] ?? null)) . "_contextmenu")));
            // line 175
            yield "
    <div class=\"";
            // line 176
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["boxClass"] ?? null), "html", null, true);
            yield " datatable_";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tableName"] ?? null), "html", null, true);
            yield "\">
        <div class=\"card-body p-0";
            // line 177
            if ((($tmp = ($context["responsive"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " table-responsive";
            }
            yield "\">
            <div class=\"dataTables_wrapper form-inline\">
                <div id=\"";
            // line 179
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["contextMenuId"] ?? null), "html", null, true);
            yield "\" class=\"dropdown-menu d-none\"></div>
                <table class=\"table table-hover dataTable\" role=\"grid\" data-reload-event=\"kimai.reset_column_visibility ";
            // line 180
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["reloadEvent"] ?? null), "html", null, true);
            yield "\" data-context-menu=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["contextMenuId"] ?? null), "html", null, true);
            yield "\">
                    <thead";
            // line 181
            if ((($tmp = ($context["sticky"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " class=\"sticky-top\"";
            }
            yield ">
                        <tr>";
            // line 183
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
            foreach ($context['_seq'] as $context["title"] => $context["headerOptions"]) {
                // line 184
                $context["isActions"] = ( !Twig\Extension\CoreExtension::testEmpty($context["title"]) && ($context["title"] == "actions"));
                // line 185
                yield "                            ";
                if ( !is_iterable($context["headerOptions"])) {
                    // line 186
                    yield "                                ";
                    $context["headerOptions"] = ["class" => $context["headerOptions"]];
                    // line 187
                    yield "                            ";
                }
                // line 188
                yield "                            ";
                if ( !CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "orderBy", [], "any", true, true, false, 188)) {
                    // line 189
                    yield "                                ";
                    if ((($context["orderBy"] ?? null) === false)) {
                        // line 190
                        yield "                                    ";
                        $context["headerOptions"] = Twig\Extension\CoreExtension::merge($context["headerOptions"], ["orderBy" => false]);
                        // line 191
                        yield "                                ";
                    } else {
                        // line 192
                        yield "                                    ";
                        $context["headerOptions"] = Twig\Extension\CoreExtension::merge($context["headerOptions"], ["orderBy" => $context["title"]]);
                        // line 193
                        yield "                                ";
                    }
                    // line 194
                    yield "                            ";
                }
                // line 195
                yield "                            ";
                $context["headerClass"] = $this->getTemplateForMacro("macro_data_table_column_class", $context, 195, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["title"]]);
                // line 196
                yield "                            ";
                if ((($context["title"] != "actions") &&  !(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "orderBy", [], "any", false, false, false, 196) === false))) {
                    // line 197
                    yield "                                ";
                    if ((($context["orderBy"] ?? null) == CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "orderBy", [], "any", false, false, false, 197))) {
                        // line 198
                        yield "                                    ";
                        $context["headerClass"] = ((($context["headerClass"] ?? null) . " sortable sorting_") . ($context["order"] ?? null));
                        // line 199
                        yield "                                    ";
                        if ((($context["order"] ?? null) == "asc")) {
                            // line 200
                            yield "                                        ";
                            $context["ariaSort"] = "ascending";
                            // line 201
                            yield "                                    ";
                        } else {
                            // line 202
                            yield "                                        ";
                            $context["ariaSort"] = "descending";
                            // line 203
                            yield "                                    ";
                        }
                        // line 204
                        yield "                                ";
                    } else {
                        // line 205
                        yield "                                    ";
                        $context["headerClass"] = (($context["headerClass"] ?? null) . " sortable sorting");
                        // line 206
                        yield "                                ";
                    }
                    // line 207
                    yield "                            ";
                }
                // line 208
                yield "                            ";
                $context["headerTitle"] = "";
                // line 209
                yield "                            ";
                $context["translationDomain"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", true, true, false, 209) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", false, false, false, 209)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "translation_domain", [], "any", false, false, false, 209)) : ("messages"));
                // line 210
                yield "                            ";
                if (CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "title", [], "any", true, true, false, 210)) {
                    // line 211
                    yield "                                ";
                    $context["headerTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "title", [], "any", false, false, false, 211), [], ($context["translationDomain"] ?? null));
                    // line 212
                    yield "                            ";
                } elseif (( !Twig\Extension\CoreExtension::testEmpty($context["title"]) &&  !(($tmp = ($context["isActions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    // line 213
                    yield "                                ";
                    $context["headerTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["title"], [], ($context["translationDomain"] ?? null));
                    // line 214
                    yield "                            ";
                }
                // line 215
                yield "                            ";
                if ((($tmp = ($context["isActions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 216
                    yield "                                ";
                    $context["headerClass"] = (($context["headerClass"] ?? null) . " text-center");
                    // line 217
                    yield "                            ";
                }
                // line 218
                yield "                            <th data-field=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["title"], "html", null, true);
                yield "\" ";
                if ( !(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "orderBy", [], "any", false, false, false, 218) === false)) {
                    yield "data-order=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "orderBy", [], "any", false, false, false, 218), "html", null, true);
                    yield "\" ";
                }
                yield "class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["headerClass"] ?? null), "html", null, true);
                yield "\"";
                if (array_key_exists("ariaSort", $context)) {
                    yield " aria-sort=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["ariaSort"] ?? null), "html", null, true);
                    yield "\"";
                }
                yield ">
                            ";
                // line 219
                if ((( !Twig\Extension\CoreExtension::testEmpty($context["title"]) && ($context["title"] == "actions")) &&  !(($context["columnModal"] ?? null) === false))) {
                    // line 220
                    yield "
                                <a class=\"link-secondary\" href=\"#\" data-bs-toggle=\"modal\" data-bs-target=\"#modal_";
                    // line 221
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tableName"] ?? null), "html", null, true);
                    yield "\">
                                    ";
                    // line 222
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("columns", true);
                    yield "
                                </a>

                            ";
                } else {
                    // line 226
                    yield "                                ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "batchUpdate", [], "any", true, true, false, 226)) {
                        // line 227
                        yield "                                    <input type=\"checkbox\" id=\"multi_update_all_";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tableName"] ?? null), "html", null, true);
                        yield "\" class=\"multi_update_all multiupdater form-check-input m-0 align-middle\" title=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("batch_table_checkbox_all"), "html", null, true);
                        yield "\">
                                ";
                    }
                    // line 229
                    yield "                                ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["headerTitle"] ?? null), "html", null, true);
                    yield "
                                ";
                    // line 230
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "html_after", [], "any", true, true, false, 230)) {
                        // line 231
                        yield "                                    ";
                        yield (string) CoreExtension::getAttribute($this->env, $this->source, $context["headerOptions"], "html_after", [], "any", false, false, false, 231);
                        yield "
                                ";
                    }
                    // line 233
                    yield "                            ";
                }
                // line 234
                yield "                            </th>";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['title'], $context['headerOptions'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 236
            yield "</tr>
                    </thead>
                    <tbody>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 241
    public function macro_data_table_column_class($name = null, $columns = null, $column = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "name" => $name,
            "columns" => $columns,
            "column" => $column,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 242
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\DatatableExtensions']->getDatatableColumnClass(($context["name"] ?? null), ($context["column"] ?? null)), "html", null, true);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 245
    public function macro_data_table_footer($entries = null, $route = null, $multi_update_form = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "entries" => $entries,
            "route" => $route,
            "multi_update_form" => $multi_update_form,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 246
            yield "                </tbody>
            </table>
        </div>
    </div>
    ";
            // line 250
            if ((( !Twig\Extension\CoreExtension::testEmpty(($context["route"] ?? null)) &&  !(null === ($context["entries"] ?? null))) ||  !(null === ($context["multi_update_form"] ?? null)))) {
                // line 251
                yield "    <div class=\"card-footer d-flex align-items-center\">
        ";
                // line 252
                if ( !(null === ($context["multi_update_form"] ?? null))) {
                    // line 253
                    yield "            ";
                    yield (string)                     $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["multi_update_form"] ?? null), 'form_start', ["attr" => ["class" => "multi_update_form", "style" => "display:none", "data-question" => "%action%"]]);
                    yield "
                ";
                    // line 254
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["multi_update_form"] ?? null), "children", [], "any", false, false, false, 254));
                    foreach ($context['_seq'] as $context["_key"] => $context["formChild"]) {
                        // line 255
                        yield "                    ";
                        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["formChild"], 'widget');
                        yield "
                ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['formChild'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 257
                    yield "            ";
                    yield (string)                     $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["multi_update_form"] ?? null), 'form_end');
                    yield "
        ";
                }
                // line 259
                yield "        ";
                if (( !Twig\Extension\CoreExtension::testEmpty(($context["route"] ?? null)) &&  !(null === ($context["entries"] ?? null)))) {
                    // line 260
                    yield "            <p class=\"d-none d-sm-block m-0 text-body-secondary multi_update_form_hide\">
                ";
                    // line 261
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("pagination", ["%start%" => CoreExtension::getAttribute($this->env, $this->source, ($context["entries"] ?? null), "getCurrentPageOffsetStart", [], "method", false, false, false, 261), "%end%" => CoreExtension::getAttribute($this->env, $this->source, ($context["entries"] ?? null), "getCurrentPageOffsetEnd", [], "method", false, false, false, 261), "%total%" => CoreExtension::getAttribute($this->env, $this->source, ($context["entries"] ?? null), "getNbResults", [], "method", false, false, false, 261)]), "html", null, true);
                    yield "
            </p>
            ";
                    // line 263
                    $context["options"] = ["css_container_class" => "pagination m-0 ms-auto d-print-none"];
                    // line 264
                    yield "            ";
                    if (is_iterable(($context["route"] ?? null))) {
                        // line 265
                        yield "                ";
                        $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ($context["route"] ?? null));
                        // line 266
                        yield "            ";
                    } else {
                        // line 267
                        yield "                ";
                        $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["routeName" => ($context["route"] ?? null)]);
                        // line 268
                        yield "            ";
                    }
                    // line 269
                    yield "            ";
                    yield (string) $this->extensions['App\Twig\PaginationExtension']->renderPagination(($context["entries"] ?? null), ($context["options"] ?? null));
                    yield "
        ";
                }
                // line 271
                yield "    </div>
    ";
            }
            // line 273
            yield "</div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 276
    public function macro_datatable_meta_column($entry = null, $field = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "entry" => $entry,
            "field" => $field,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 277
            yield "    ";
            $macros["_v0"] = $this->load("macros/widgets.html.twig", 277)->unwrap();
            // line 278
            yield "    ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_meta_field_value", $context, 278, $this->getSourceContext())->macro_meta_field_value(...[($context["entry"] ?? null), ($context["field"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 281
    public function macro_datatable_multiupdate_row($id = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "id" => $id,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 282
            yield "    <input type=\"checkbox\" name=\"id\" value=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\" class=\"multi_update_single multiupdater form-check-input m-0 align-middle\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("batch_table_checkbox"), "html", null, true);
            yield "\">
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/datatables.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  996 => 282,  984 => 281,  975 => 278,  972 => 277,  959 => 276,  952 => 273,  948 => 271,  942 => 269,  939 => 268,  936 => 267,  933 => 266,  930 => 265,  927 => 264,  925 => 263,  920 => 261,  917 => 260,  914 => 259,  908 => 257,  898 => 255,  894 => 254,  889 => 253,  887 => 252,  884 => 251,  882 => 250,  876 => 246,  862 => 245,  856 => 242,  842 => 241,  833 => 236,  826 => 234,  823 => 233,  817 => 231,  815 => 230,  810 => 229,  802 => 227,  799 => 226,  792 => 222,  788 => 221,  785 => 220,  783 => 219,  764 => 218,  761 => 217,  758 => 216,  755 => 215,  752 => 214,  749 => 213,  746 => 212,  743 => 211,  740 => 210,  737 => 209,  734 => 208,  731 => 207,  728 => 206,  725 => 205,  722 => 204,  719 => 203,  716 => 202,  713 => 201,  710 => 200,  707 => 199,  704 => 198,  701 => 197,  698 => 196,  695 => 195,  692 => 194,  689 => 193,  686 => 192,  683 => 191,  680 => 190,  677 => 189,  674 => 188,  671 => 187,  668 => 186,  665 => 185,  663 => 184,  659 => 183,  653 => 181,  647 => 180,  643 => 179,  636 => 177,  630 => 176,  627 => 175,  624 => 174,  621 => 173,  618 => 172,  615 => 171,  612 => 170,  609 => 169,  606 => 168,  603 => 167,  600 => 166,  597 => 165,  594 => 164,  591 => 163,  588 => 162,  585 => 161,  570 => 160,  558 => 153,  554 => 152,  548 => 151,  541 => 147,  537 => 146,  528 => 140,  517 => 138,  510 => 134,  499 => 132,  493 => 129,  486 => 124,  479 => 123,  473 => 120,  467 => 119,  464 => 118,  461 => 117,  458 => 116,  455 => 115,  452 => 114,  449 => 113,  446 => 112,  443 => 111,  440 => 110,  437 => 109,  435 => 108,  431 => 107,  427 => 105,  419 => 102,  413 => 99,  409 => 98,  399 => 94,  397 => 93,  384 => 92,  377 => 89,  372 => 87,  367 => 84,  361 => 81,  352 => 80,  350 => 79,  347 => 78,  341 => 75,  334 => 74,  332 => 73,  327 => 71,  316 => 70,  314 => 69,  308 => 66,  302 => 65,  297 => 64,  294 => 63,  292 => 62,  287 => 60,  280 => 56,  272 => 51,  268 => 50,  262 => 47,  258 => 46,  253 => 44,  247 => 43,  243 => 42,  239 => 40,  233 => 39,  229 => 38,  225 => 37,  222 => 36,  219 => 35,  216 => 34,  213 => 33,  210 => 32,  208 => 31,  203 => 30,  200 => 29,  197 => 28,  194 => 27,  191 => 26,  185 => 23,  178 => 22,  176 => 21,  173 => 20,  161 => 19,  155 => 15,  142 => 14,  133 => 11,  121 => 10,  112 => 7,  100 => 6,  91 => 3,  79 => 2,  73 => 280,  70 => 275,  67 => 244,  64 => 240,  61 => 159,  58 => 91,  55 => 17,  52 => 13,  49 => 9,  46 => 5,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/datatables.html.twig", "/opt/kimai/templates/macros/datatables.html.twig");
    }
}
