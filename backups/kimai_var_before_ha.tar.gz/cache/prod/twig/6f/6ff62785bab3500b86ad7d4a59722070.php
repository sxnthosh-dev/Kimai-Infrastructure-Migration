<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* about/license.html.twig */
class __TwigTemplate_9a6c4132a65e9aaa01d1560b0e692187 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["badge"] = $this->macros["badge"] = $this->load("@theme/components/badge.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    <div class=\"row row-cards mb-3\">
        <div class=\"col-lg-4\">
            <div class=\"card\">
                <div class=\"card-body card_intro p-4 text-center\">

                    <img src=\"";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("apple-touch-icon.png"), "html", null, true);
        yield "\" class=\"avatar avatar-2xl mb-3 avatar-rounded\" alt=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::SOFTWARE"), "html", null, true);
        yield "\">

                    <h3 class=\"m-0 mb-1\">
                        <a href=\"";
        // line 13
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE"), "html", null, true);
        yield "\" target=\"_blank\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::SOFTWARE"), "html", null, true);
        yield "</a>
                    </h3>
                    <div class=\"text-body-secondary\">
                        ";
        // line 16
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::VERSION"), "html", null, true);
        yield "
                    </div>
                </div>
                <div class=\"d-flex\">
                    <a href=\"";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->documentationLink(""), "html", null, true);
        yield "\" target=\"_blank\" class=\"card-btn\">
                        <i class=\"me-2 text-body-secondary ";
        // line 21
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("help", false), "html", null, true);
        yield "\"></i>
                        ";
        // line 22
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("help"), "html", null, true);
        yield "
                    </a>
                    <a href=\"";
        // line 24
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::GITHUB"), "html", null, true);
        yield "discussions\" target=\"_blank\" class=\"card-btn\">
                        <i class=\"me-2 text-body-secondary ";
        // line 25
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("fab fa-github", false), "html", null, true);
        yield "\"></i>
                        ";
        // line 26
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("support"), "html", null, true);
        yield "
                    </a>
                </div>
                <div class=\"d-flex\">
                    <a href=\"";
        // line 30
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE"), "html", null, true);
        yield "\" target=\"_blank\" class=\"card-btn\">
                        <i class=\"me-2 text-body-secondary ";
        // line 31
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("home", false), "html", null, true);
        yield "\"></i>
                        ";
        // line 32
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("homepage"), "html", null, true);
        yield "
                    </a>
                    <a href=\"";
        // line 34
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE"), "html", null, true);
        yield "/donate/\" target=\"_blank\" class=\"card-btn\">
                        <i class=\"me-2 text-body-secondary ";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("fas fa-hand-holding-heart", false), "html", null, true);
        yield "\"></i>
                        ";
        // line 36
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("donate"), "html", null, true);
        yield "
                    </a>
                </div>
                <div class=\"card-footer\">
                    Made with ♥ by <a href=\"https://www.kevinpapst.de/\">Kevin Papst</a> and <a href=\"";
        // line 40
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("App\\Constants::GITHUB"), "html", null, true);
        yield "graphs/contributors\" target=\"_blank\">great contributors</a>.
                </div>
            </div>
        </div>
        <div class=\"col-lg-8\">
            ";
        // line 45
        yield from $this->load("about/license.html.twig", 45, 1)->unwrap()->yield($context);
        // line 74
        yield "        </div>
    </div>
    <div class=\"row row-cards mb-3\">
        <div class=\"col-lg-8\">
            <div class=\"card card-lg\">
                <div class=\"card-body card_license\">
                    <div class=\"markdown\">
                        <h3>License</h3>
                        <div style=\"white-space: pre\">";
        // line 82
        yield (string) Twig\Extension\CoreExtension::replace(Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["license"] ?? null), "html", null, true)), ["<br />" => ""]);
        yield "</div>
                    </div>
                </div>
            </div>
        </div>
        <div class=\"col-lg-4\">
            <div class=\"card\">
                <div class=\"card-body card_details\">
                    <div class=\"d-flex align-items-center mb-3\">
                        <div class=\"me-3\">
                            <i class=\"fa-2x fas fa-balance-scale\"></i>
                        </div>
                        <div>
                            <small class=\"text-body-secondary\">";
        // line 95
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("\\App\\Constants::SOFTWARE"), "html", null, true);
        yield " is licensed under the</small>
                            <h3 class=\"lh-1\">GNU Affero General Public License v3.0</h3>
                        </div>
                    </div>
                    <div class=\"text-body-secondary mb-3\">
                        Permissions of this strongest copyleft license are conditioned on making available complete source code of licensed works and modifications,
                        which include larger works using a licensed work, under the same license.
                        Copyright and license notices must be preserved. Contributors provide an express grant of patent rights.
                        When a modified version is used to provide a service over a network, the complete source code of the modified version must be made available.
                    </div>
                    <h4>Permissions</h4>
                    <ul class=\"list-unstyled space-y-1\">
                        <li><i class=\"";
        // line 107
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
        yield " text-green\"></i> Commercial use</li>
                        <li><i class=\"";
        // line 108
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
        yield " text-green\"></i> Modification</li>
                        <li><i class=\"";
        // line 109
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
        yield " text-green\"></i> Distribution</li>
                        <li><i class=\"";
        // line 110
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
        yield " text-green\"></i> Patent use</li>
                        <li><i class=\"";
        // line 111
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
        yield " text-green\"></i> Private use</li>
                    </ul>
                    <h4>Limitations</h4>
                    <ul class=\"list-unstyled space-y-1\">
                        <li><i class=\"";
        // line 115
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("failure", false), "html", null, true);
        yield " text-red\"></i> Liability</li>
                        <li><i class=\"";
        // line 116
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("failure", false), "html", null, true);
        yield " text-red\"></i> Warranty</li>
                    </ul>
                    <h4>Conditions</h4>
                    <ul class=\"list-unstyled space-y-1\">
                        <li><i class=\"";
        // line 120
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("details", false), "html", null, true);
        yield " text-blue\"></i> Disclose source</li>
                        <li><i class=\"";
        // line 121
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("details", false), "html", null, true);
        yield " text-blue\"></i> License and copyright notice</li>
                        <li><i class=\"";
        // line 122
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("details", false), "html", null, true);
        yield " text-blue\"></i> Network use is distribution</li>
                        <li><i class=\"";
        // line 123
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("details", false), "html", null, true);
        yield " text-blue\"></i> Same license</li>
                        <li><i class=\"";
        // line 124
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("details", false), "html", null, true);
        yield " text-blue\"></i> State changes</li>
                    </ul>
                </div>
                <div class=\"card-footer\">
                    This is not legal advice. Learn more about this licenses at
                    <a href=\"https://choosealicense.com/licenses/agpl-3.0/\" target=\"_blank\">choosealicense.com</a> and
                    <a href=\"https://www.gnu.org/licenses/agpl-3.0.en.html\" target=\"_blank\">GNU</a>.
                </div>
            </div>
        </div>
    </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "about/license.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  249 => 124,  245 => 123,  241 => 122,  237 => 121,  233 => 120,  226 => 116,  222 => 115,  215 => 111,  211 => 110,  207 => 109,  203 => 108,  199 => 107,  184 => 95,  168 => 82,  158 => 74,  156 => 45,  148 => 40,  141 => 36,  137 => 35,  133 => 34,  128 => 32,  124 => 31,  120 => 30,  113 => 26,  109 => 25,  105 => 24,  100 => 22,  96 => 21,  92 => 20,  85 => 16,  77 => 13,  69 => 10,  62 => 5,  55 => 4,  50 => 1,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "about/license.html.twig", "/opt/kimai/templates/about/license.html.twig");
    }
}


/* about/license.html.twig */
class __TwigTemplate_9a6c4132a65e9aaa01d1560b0e692187___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 45
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 45);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 46
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Credits";
        yield from [];
    }

    // line 47
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "credits_card";
        yield from [];
    }

    // line 48
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 49
        yield "                    <p>
                        The following amazing software libraries were used when creating Kimai. It wouldn\x27t be possible without them.
                        My biggest thanks go out to the authors 👍
                    </p>
                    <ul>
                        <li>Bootstrap: <a href=\"https://getbootstrap.com\" target=\"_blank\">https://getbootstrap.com</a></li>
                        <li>Chart.js: <a href=\"https://www.chartjs.org\" target=\"_blank\">https://www.chartjs.org</a></li>
                        <li>Doctrine: <a href=\"https://www.doctrine-project.org\" target=\"_blank\">https://www.doctrine-project.org</a></li>
                        <li>FontAwesome: <a href=\"https://fontawesome.com\" target=\"_blank\">https://fontawesome.com</a></li>
                        <li>FullCalendar: <a href=\"https://fullcalendar.io\" target=\"_blank\">https://fullcalendar.io</a></li>
                        <li>gridstack.js: <a href=\"https://gridstackjs.com\" target=\"_blank\">https://gridstackjs.com</a></li>
                        <li>Litepicker: <a href=\"https://litepicker.com/\" target=\"_blank\">https://litepicker.com/</a></li>
                        <li>Luxon: <a href=\"https://moment.github.io/luxon/\" target=\"_blank\">https://moment.github.io/luxon/</a></li>
                        <li>MPDF <a href=\"https://mpdf.github.io\" target=\"_blank\">https://mpdf.github.io</a></li>
                        <li>PHPOffice: <a href=\"https://github.com/PHPOffice\" target=\"_blank\">https://github.com/PHPOffice</a></li>
                        <li>Symfony: <a href=\"https://symfony.com\" target=\"_blank\">https://symfony.com</a></li>
                        <li>Tabler: <a href=\"https://tabler.io\" target=\"_blank\">https://tabler.io</a></li>
                        <li>Tom Select: <a href=\"https://tom-select.js.org/\" target=\"_blank\">https://tom-select.js.org/</a></li>
                        <li>Twig: <a href=\"https://twig.symfony.com\" target=\"_blank\">https://twig.symfony.com</a></li>
                    </ul>
                ";
        yield from [];
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 71
        yield "                    Apologies to all projects that I forgot to mention. Please feel free and send a PR to fix that!
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "about/license.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  394 => 71,  387 => 70,  362 => 49,  355 => 48,  344 => 47,  333 => 46,  322 => 45,  249 => 124,  245 => 123,  241 => 122,  237 => 121,  233 => 120,  226 => 116,  222 => 115,  215 => 111,  211 => 110,  207 => 109,  203 => 108,  199 => 107,  184 => 95,  168 => 82,  158 => 74,  156 => 45,  148 => 40,  141 => 36,  137 => 35,  133 => 34,  128 => 32,  124 => 31,  120 => 30,  113 => 26,  109 => 25,  105 => 24,  100 => 22,  96 => 21,  92 => 20,  85 => 16,  77 => 13,  69 => 10,  62 => 5,  55 => 4,  50 => 1,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "about/license.html.twig", "/opt/kimai/templates/about/license.html.twig");
    }
}
