<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* partials/logo_login.html.twig */
class __TwigTemplate_efffd0454a0f05ed22dd79c5c1478c50 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["logo"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.logo");
        // line 2
        $context["company"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.company");
        // line 3
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["logo"] ?? null))) {
            // line 4
            yield "    <img src=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["logo"] ?? null), "html", null, true);
            yield "\" style=\"max-width: 300px;\">
";
        } elseif ( !Twig\Extension\CoreExtension::testEmpty(        // line 5
($context["company"] ?? null))) {
            // line 6
            yield "    <p>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["company"] ?? null), "html", null, true);
            yield "</p>
";
        } elseif ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source,         // line 7
($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 7))) {
            // line 8
            yield "    <img alt=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle(), "html", null, true);
            yield "\" style=\"max-width: 150px;\"
         src=\"";
            // line 9
            if (CoreExtension::inFilter("://", CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 9))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 9), "html", null, true);
            } else {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 9)), "html", null, true);
            }
            yield "\">
";
        } else {
            // line 11
            yield "    <p>";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle();
            yield "</p>
";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "partials/logo_login.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  77 => 11,  68 => 9,  63 => 8,  61 => 7,  56 => 6,  54 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "partials/logo_login.html.twig", "/opt/kimai/templates/partials/logo_login.html.twig");
    }
}
