<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* page_setup.html.twig */
class __TwigTemplate_fb81eff20089cc3e612fc839a91cf881 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'table_actions' => [$this, 'block_table_actions'],
            'form_addon' => [$this, 'block_form_addon'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_table_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        // line 6
        yield "    ";
        if ((array_key_exists("page_setup", $context) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "hasPaginationForm", [], "method", false, false, false, 6)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 7
            yield "        <div class=\"btn-list\">
            ";
            // line 8
            $context["form"] = CoreExtension::getAttribute($this->env, $this->source, ($context["page_setup"] ?? null), "getPaginationForm", [], "method", false, false, false, 8);
            // line 9
            yield "            ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["onchange" => "this.submit()"]]);
            yield "
            <div class=\"btn-list w-100 flex-nowrap\">
                ";
            // line 11
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", true, true, false, 11)) {
                // line 12
                yield "                    ";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 12), 'widget');
                yield "
                ";
            }
            // line 14
            yield "                ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", true, true, false, 14)) {
                // line 15
                yield "                    ";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 15), 'widget');
                yield "
                ";
            } elseif ((            // line 16
array_key_exists("user", $context) && (CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 16) != ($context["user"] ?? null)))) {
                // line 17
                yield "                    ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_username", $context, 17, $this->getSourceContext())->macro_username(...[($context["user"] ?? null)]);
                yield "
                ";
            }
            // line 19
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["form"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 20
                yield "                    ";
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["field"], "rendered", [], "any", false, false, false, 20)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 21
                    yield "                        ";
                    yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["field"], 'widget');
                    yield "
                    ";
                }
                // line 23
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 24
            yield "                ";
            yield from $this->unwrap()->yieldBlock('form_addon', $context, $blocks);
            // line 25
            yield "            </div>
            ";
            // line 26
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
            yield "
        </div>
    ";
        }
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_addon(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "page_setup.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  139 => 24,  130 => 26,  127 => 25,  124 => 24,  117 => 23,  111 => 21,  108 => 20,  103 => 19,  97 => 17,  95 => 16,  90 => 15,  87 => 14,  81 => 12,  79 => 11,  73 => 9,  71 => 8,  68 => 7,  65 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "page_setup.html.twig", "/opt/kimai/templates/page_setup.html.twig");
    }
}
