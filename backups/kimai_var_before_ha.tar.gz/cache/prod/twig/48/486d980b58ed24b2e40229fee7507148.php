<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* embeds/teams.html.twig */
class __TwigTemplate_a567293c5c16c0d1c2b3f2f01750c01d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["options"] = ["teams" =>         // line 3
($context["teams"] ?? null), "route_create" => ((        // line 4
array_key_exists("route_create", $context)) ? (Twig\Extension\CoreExtension::default(($context["route_create"] ?? null), null)) : (null)), "route_edit" => ((        // line 5
array_key_exists("route_edit", $context)) ? (Twig\Extension\CoreExtension::default(($context["route_edit"] ?? null), null)) : (null)), "empty_message" => ((        // line 6
array_key_exists("empty_message", $context)) ? (Twig\Extension\CoreExtension::default(($context["empty_message"] ?? null), "team.visibility_global")) : ("team.visibility_global"))];
        // line 9
        yield from $this->load("embeds/teams.html.twig", 9, 1)->unwrap()->yield(CoreExtension::toArray(($context["options"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/teams.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  49 => 9,  47 => 6,  46 => 5,  45 => 4,  44 => 3,  43 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/teams.html.twig", "/opt/kimai/templates/embeds/teams.html.twig");
    }
}


/* embeds/teams.html.twig */
class __TwigTemplate_a567293c5c16c0d1c2b3f2f01750c01d___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_tools' => [$this, 'block_box_tools'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_title' => [$this, 'block_box_title'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 10)->unwrap();
        // line 9
        $this->parent = $this->load("@theme/embeds/card.html.twig", 9);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        ";
        if (( !(null === ($context["route_create"] ?? null)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_team")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 13
            yield "            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 13, $this->getSourceContext())->macro_card_tool_button(...["create", ["title" => "team.create_default", "translation_domain" => "teams", "url" =>             // line 16
($context["route_create"] ?? null), "class" => "modal-ajax-form open-edit"]]);
            // line 18
            yield "
        ";
        }
        // line 20
        yield "        ";
        if ( !(null === ($context["route_edit"] ?? null))) {
            // line 21
            yield "            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 21, $this->getSourceContext())->macro_card_tool_button(...["edit", ["class" => "modal-ajax-form open-edit", "title" => "edit", "url" => ($context["route_edit"] ?? null)]]);
            yield "
        ";
        }
        // line 23
        yield "    ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"team_listing_box\"";
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("permissions"), "html", null, true);
        yield "
        ";
        // line 27
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["teams"] ?? null)) > 0)) {
            yield "<small class=\"text-body-secondary d-none d-sm-inline ms-1\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team.visibility_restricted", [], "teams"), "html", null, true);
            yield "</small>";
        }
        // line 28
        yield "    ";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["teams"] ?? null)) > 0)) {
            yield "p-0";
        }
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "        ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["teams"] ?? null)) > 0)) {
            // line 32
            yield "            ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_team_list", $context, 32, $this->getSourceContext())->macro_team_list(...[($context["teams"] ?? null), ["name_class" => "w-min"]]);
            yield "
        ";
        } else {
            // line 34
            yield "            <div class=\"comment\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((array_key_exists("empty_message", $context)) ? (Twig\Extension\CoreExtension::default(($context["empty_message"] ?? null), "team.visibility_global")) : ("team.visibility_global")), [], "teams"), "html", null, true);
            yield "</div>
        ";
        }
        // line 36
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/teams.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  225 => 36,  219 => 34,  213 => 32,  210 => 31,  203 => 30,  190 => 29,  185 => 28,  179 => 27,  174 => 26,  167 => 25,  156 => 24,  151 => 23,  145 => 21,  142 => 20,  138 => 18,  136 => 16,  134 => 13,  131 => 12,  124 => 11,  119 => 9,  117 => 10,  49 => 9,  47 => 6,  46 => 5,  45 => 4,  44 => 3,  43 => 2,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/teams.html.twig", "/opt/kimai/templates/embeds/teams.html.twig");
    }
}
