<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/error.html.twig */
class __TwigTemplate_e5988e7ac04f4e3ad3dc6ea797d97023 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'page_content' => [$this, 'block_page_content'],
            'error_code' => [$this, 'block_error_code'],
            'error_title' => [$this, 'block_error_title'],
            'error_subtitle' => [$this, 'block_error_subtitle'],
            'error_actions' => [$this, 'block_error_actions'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@Tabler/fullpage.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@Tabler/fullpage.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["status_text"] ?? null), [], "TablerBundle"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    ";
        $context["errorTitleKey"] = (("http_error_" . ($context["status_code"] ?? null)) . ".title");
        // line 7
        yield "    ";
        $context["errorTitleTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorTitleKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
        // line 8
        yield "    ";
        if ((($context["errorTitleKey"] ?? null) == ($context["errorTitleTrans"] ?? null))) {
            // line 9
            yield "        ";
            $context["errorTitleKey"] = "http_error.title";
            // line 10
            yield "        ";
            $context["errorTitleTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorTitleKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
            // line 11
            yield "    ";
        }
        // line 12
        yield "
    ";
        // line 13
        $context["errorMessageKey"] = (("http_error_" . ($context["status_code"] ?? null)) . ".description");
        // line 14
        yield "    ";
        $context["errorMessageTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorMessageKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
        // line 15
        yield "    ";
        if ((($context["errorMessageKey"] ?? null) == ($context["errorMessageTrans"] ?? null))) {
            // line 16
            yield "        ";
            $context["errorMessageKey"] = "http_error.description";
            // line 17
            yield "        ";
            $context["errorMessageTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorMessageKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
            // line 18
            yield "    ";
        }
        // line 19
        yield "
    ";
        // line 20
        $context["errorSuggestionKey"] = (("http_error_" . ($context["status_code"] ?? null)) . ".suggestion");
        // line 21
        yield "    ";
        $context["errorSuggestionTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorSuggestionKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
        // line 22
        yield "    ";
        if ((($context["errorSuggestionKey"] ?? null) == ($context["errorSuggestionTrans"] ?? null))) {
            // line 23
            yield "        ";
            $context["errorSuggestionKey"] = "http_error.suggestion";
            // line 24
            yield "        ";
            $context["errorSuggestionTrans"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["errorSuggestionKey"] ?? null), ["%status_code%" => ($context["status_code"] ?? null)], "TablerBundle");
            // line 25
            yield "    ";
        }
        // line 26
        yield "
    ";
        // line 27
        if (((($context["errorSuggestionKey"] ?? null) != ($context["errorSuggestionTrans"] ?? null)) && (($context["errorMessageKey"] ?? null) != ($context["errorMessageTrans"] ?? null)))) {
            // line 28
            yield "        ";
            $context["errorTitleTrans"] = ($context["errorMessageTrans"] ?? null);
            // line 29
            yield "        ";
            $context["errorMessageTrans"] = ($context["errorSuggestionTrans"] ?? null);
            // line 30
            yield "    ";
        }
        // line 31
        yield "
    <div class=\"container container-tight py-4\">
        <div class=\"empty\">
            <div class=\"empty-header\">";
        // line 34
        yield from $this->unwrap()->yieldBlock('error_code', $context, $blocks);
        yield "</div>
            <p class=\"empty-title\">
                ";
        // line 36
        yield from $this->unwrap()->yieldBlock('error_title', $context, $blocks);
        // line 43
        yield "            </p>
            <p class=\"empty-subtitle text-body-secondary\">
                ";
        // line 45
        yield from $this->unwrap()->yieldBlock('error_subtitle', $context, $blocks);
        // line 48
        yield "            </p>
            <div class=\"empty-action\">
                ";
        // line 50
        yield from $this->unwrap()->yieldBlock('error_actions', $context, $blocks);
        // line 54
        yield "            </div>
        </div>
    </div>
";
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_error_code(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["status_code"] ?? null), "html", null, true);
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_error_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 37
        yield "                    ";
        if ((($context["errorTitleKey"] ?? null) != ($context["errorTitleTrans"] ?? null))) {
            // line 38
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["errorTitleTrans"] ?? null), "html", null, true);
            yield "
                    ";
        } else {
            // line 40
            yield "                        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["status_text"] ?? null), "html", null, true);
            yield "
                    ";
        }
        // line 42
        yield "                ";
        yield from [];
    }

    // line 45
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_error_subtitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 46
        yield "                    ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["errorMessageTrans"] ?? null), "html", null, true);
        yield "
                ";
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_error_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 51
        yield "                    ";
        $macros["_v0"] = $this->load("@Tabler/components/buttons.html.twig", 51)->unwrap();
        // line 52
        yield "                    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_link_button", $context, 52, $this->getSourceContext())->macro_link_button(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Take me home", [], "TablerBundle"), $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_welcome")), "back"]);
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/error.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  242 => 52,  239 => 51,  232 => 50,  224 => 46,  217 => 45,  212 => 42,  206 => 40,  200 => 38,  197 => 37,  190 => 36,  179 => 34,  171 => 54,  169 => 50,  165 => 48,  163 => 45,  159 => 43,  157 => 36,  152 => 34,  147 => 31,  144 => 30,  141 => 29,  138 => 28,  136 => 27,  133 => 26,  130 => 25,  127 => 24,  124 => 23,  121 => 22,  118 => 21,  116 => 20,  113 => 19,  110 => 18,  107 => 17,  104 => 16,  101 => 15,  98 => 14,  96 => 13,  93 => 12,  90 => 11,  87 => 10,  84 => 9,  81 => 8,  78 => 7,  75 => 6,  68 => 5,  57 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/error.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/error.html.twig");
    }
}
