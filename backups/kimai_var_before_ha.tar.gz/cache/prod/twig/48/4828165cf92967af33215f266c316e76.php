<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/security_cover.html.twig */
class __TwigTemplate_908f6c58b5dfdba5378193bd44aa64f8 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'body_login_border' => [$this, 'block_body_login_border'],
            'page_classes' => [$this, 'block_page_classes'],
            'container_before' => [$this, 'block_container_before'],
            'login_border' => [$this, 'block_login_border'],
            'container_classes' => [$this, 'block_container_classes'],
            'card_classes' => [$this, 'block_card_classes'],
            'container_after' => [$this, 'block_container_after'],
            'before_cover' => [$this, 'block_before_cover'],
            'cover_classes' => [$this, 'block_cover_classes'],
            'cover_style' => [$this, 'block_cover_style'],
            'cover_url' => [$this, 'block_cover_url'],
            'after_cover' => [$this, 'block_after_cover'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@Tabler/security.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@Tabler/security.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_login_border(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "row g-0 flex-fill";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "<div class=\"col-12 col-lg-6 col-xl-4 ";
        yield from $this->unwrap()->yieldBlock('login_border', $context, $blocks);
        yield " d-flex flex-column justify-content-center\">
    ";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_border(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "border-top-wide border-primary";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "container container-tight my-5 px-lg-5";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "</div>

<div class=\"col-12 col-lg-6 col-xl-8 d-none d-lg-block\">
    ";
        // line 16
        yield from $this->unwrap()->yieldBlock('before_cover', $context, $blocks);
        // line 17
        yield "    <div class=\"";
        yield from $this->unwrap()->yieldBlock('cover_classes', $context, $blocks);
        yield "\" style=\"";
        yield from $this->unwrap()->yieldBlock('cover_style', $context, $blocks);
        yield "\"></div>
    ";
        // line 18
        yield from $this->unwrap()->yieldBlock('after_cover', $context, $blocks);
        // line 19
        yield "</div>
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_before_cover(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cover_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "bg-cover h-100 min-vh-100";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cover_style(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "background-image: url(";
        yield from $this->unwrap()->yieldBlock('cover_url', $context, $blocks);
        yield ")";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_cover_url(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getSecurityCoverUrl", [], "method", false, false, false, 17), "html", null, true);
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_cover(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/security_cover.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  202 => 18,  169 => 17,  159 => 16,  153 => 19,  151 => 18,  144 => 17,  142 => 16,  137 => 13,  130 => 12,  120 => 10,  109 => 9,  91 => 6,  84 => 5,  73 => 4,  63 => 3,  52 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/security_cover.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/security_cover.html.twig");
    }
}
