<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/widgets.html.twig */
class __TwigTemplate_53fc4e1d82015549ace5ef9e866bc6a0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 92
        yield "
";
        // line 96
        yield "
";
        // line 110
        yield "
";
        // line 114
        yield "
";
        // line 118
        yield "
";
        // line 122
        yield "
";
        // line 142
        yield "
";
        // line 148
        yield "
";
        // line 156
        yield "
";
        // line 178
        yield "
";
        // line 197
        yield "
";
        // line 205
        yield "
";
        // line 210
        yield "
";
        // line 215
        yield "
";
        // line 225
        yield "
";
        // line 229
        yield "
";
        // line 237
        yield "
";
        // line 245
        yield "
";
        // line 249
        yield "
";
        // line 253
        yield "
";
        // line 257
        yield "
";
        // line 262
        yield "
";
        // line 277
        yield "
";
        // line 282
        yield "
";
        // line 287
        yield "
";
        // line 294
        yield "
";
        // line 298
        yield "
";
        // line 304
        yield "
";
        // line 308
        yield "
";
        // line 314
        yield "
";
        // line 325
        yield "
";
        // line 333
        yield "
";
        // line 384
        yield "
";
        // line 422
        yield "
";
        // line 433
        yield "
";
        // line 441
        yield "
";
        // line 449
        yield "
";
        // line 463
        yield "
";
        // line 471
        yield "
";
        // line 485
        yield "
";
        // line 493
        yield "
";
        // line 507
        yield "
";
        // line 515
        yield "
";
        // line 529
        yield "
";
        // line 544
        yield "
";
        // line 552
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_duration($timesheet = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "timesheet" => $timesheet,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "<span";
            // line 3
            if (((($tmp = ($context["options"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 3))) {
                yield " data-replacer=\"duration\" data-title=\"true\"";
            }
            // line 4
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["timesheet"] ?? null), "end", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " data-since=\"";
                yield (string) (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["timesheet"] ?? null), "begin", [], "any", false, false, false, 4))) ? ("") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["timesheet"] ?? null), "begin", [], "any", false, false, false, 4), "format", [Twig\Extension\CoreExtension::constant("DATE_ISO8601")], "method", false, false, false, 4), "html", null, true)));
                yield "\"";
            }
            // line 6
            yield "    class=\"duration ";
            if (((($tmp = ($context["options"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", true, true, false, 6))) {
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", false, false, false, 6), "html", null, true);
            }
            yield "\">";
            // line 7
            yield (string) (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["timesheet"] ?? null), "begin", [], "any", false, false, false, 7))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(0), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["timesheet"] ?? null)), "html", null, true)));
            // line 8
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 11
    public function macro_duration_seconds($seconds = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "seconds" => $seconds,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 12
            yield "<span";
            // line 13
            if (((($tmp = ($context["options"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 13))) {
                yield " data-replacer=\"duration\" data-title=\"true\" ";
            }
            // line 14
            if ((((($tmp = ($context["options"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "active", [], "any", true, true, false, 14)) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "active", [], "any", false, false, false, 14)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                yield " data-since=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $this->extensions['App\Twig\LocaleFormatExtensions']->createDate((("- " . ($context["seconds"] ?? null)) . " seconds")), "format", [Twig\Extension\CoreExtension::constant("DATE_ISO8601")], "method", false, false, false, 14), "html", null, true);
                yield "\" ";
            }
            // line 16
            yield "    class=\"duration ";
            if (((($tmp = ($context["options"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", true, true, false, 16))) {
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", false, false, false, 16), "html", null, true);
            }
            yield "\">";
            // line 17
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["seconds"] ?? null)), "html", null, true);
            // line 18
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 21
    public function macro_search_filter($route = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "route" => $route,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 22
            $context["opts"] = ["performSearch" => 1];
            // line 23
            yield "    ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "begin", [], "any", true, true, false, 23) && CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "end", [], "any", true, true, false, 23))) {
                // line 24
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["daterange" => (($this->extensions['App\Twig\Extensions']->formatReportDate(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "begin", [], "any", false, false, false, 24)) . " - ") . $this->extensions['App\Twig\Extensions']->formatReportDate(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "end", [], "any", false, false, false, 24)))]);
                // line 25
                yield "    ";
            }
            // line 26
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "customer", [], "any", true, true, false, 26)) {
                // line 27
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["customers[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "customer", [], "any", false, false, false, 27)]);
                // line 28
                yield "    ";
            }
            // line 29
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "project", [], "any", true, true, false, 29)) {
                // line 30
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["projects[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "project", [], "any", false, false, false, 30)]);
                // line 31
                yield "    ";
            }
            // line 32
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "activity", [], "any", true, true, false, 32)) {
                // line 33
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["activities[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "activity", [], "any", false, false, false, 33)]);
                // line 34
                yield "    ";
            }
            // line 35
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "user", [], "any", true, true, false, 35)) {
                // line 36
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["users[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "user", [], "any", false, false, false, 36)]);
                // line 37
                yield "    ";
            }
            // line 38
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "preview", [], "any", true, true, false, 38)) {
                // line 39
                yield "        ";
                $context["opts"] = Twig\Extension\CoreExtension::merge(($context["opts"] ?? null), ["preview" => CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "preview", [], "any", false, false, false, 39)]);
                // line 40
                yield "    ";
            }
            // line 41
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route"] ?? null), ($context["opts"] ?? null)), "html", null, true);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 44
    public function macro_page_actions($actions = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "actions" => $actions,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 45
            $context["btnClasses"] = "";
            // line 46
            yield "    <div class=\"page-actions\">
        <div class=\"pa-desktop d-none d-sm-inline-flex btn-list\">
        ";
            // line 48
            yield (string) $this->getTemplateForMacro("macro_actions", $context, 48, $this->getSourceContext())->macro_actions(...[($context["actions"] ?? null), ["large" => true, "button_class" => ($context["btnClasses"] ?? null)]]);
            yield "
        </div>
        <div class=\"pa-mobile d-inline-flex d-sm-none btn-list\">
            ";
            // line 51
            yield (string) $this->getTemplateForMacro("macro_table_actions", $context, 51, $this->getSourceContext())->macro_table_actions(...[($context["actions"] ?? null), "btn btn-icon"]);
            yield "
        </div>
    </div>";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 56
    public function macro_actions($actions = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "actions" => $actions,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 57
            $context["large"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "large", [], "any", true, true, false, 57) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "large", [], "any", false, false, false, 57)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "large", [], "any", false, false, false, 57)) : (true));
            // line 58
            yield "    ";
            $context["btnClasses"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "button_class", [], "any", true, true, false, 58) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "button_class", [], "any", false, false, false, 58)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "button_class", [], "any", false, false, false, 58)) : ("btn-primary"));
            // line 59
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["actions"] ?? null));
            foreach ($context['_seq'] as $context["icon"] => $context["values"]) {
                // line 60
                yield "        ";
                if (CoreExtension::inFilter("help", $context["icon"])) {
                    // line 61
                    yield "            ";
                    $context["help"] = $context["values"];
                    // line 62
                    yield "        ";
                } elseif ((CoreExtension::inFilter("divider", $context["icon"]) && (null === $context["values"]))) {
                    // line 63
                    yield "            ";
                    // line 64
                    yield "        ";
                } else {
                    // line 65
                    yield "            ";
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", true, true, false, 65) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", false, false, false, 65)) > 0))) {
                        // line 66
                        yield "                <div class=\"dropdown";
                        if (CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", true, true, false, 66)) {
                            yield " ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", false, false, false, 66), "html", null, true);
                        }
                        yield "\">
                    <button type=\"button\" class=\"btn ";
                        // line 67
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["btnClasses"] ?? null), "html", null, true);
                        yield " dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                        ";
                        // line 68
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon($context["icon"], true);
                        if ((($tmp = ($context["large"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            yield " ";
                            yield (string) ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "any", true, true, false, 68)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "any", false, false, false, 68)), "html", null, true)) : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["icon"]), "html", null, true)));
                        }
                        // line 69
                        yield "                    </button>
                    <div class=\"dropdown-menu\">";
                        // line 71
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", false, false, false, 71));
                        foreach ($context['_seq'] as $context["icon"] => $context["values"]) {
                            // line 72
                            yield "                            ";
                            $context["values"] = Twig\Extension\CoreExtension::merge($context["values"], ["class" => ((("dropdown-item action-" . $context["icon"]) . " ") . ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", true, true, false, 72)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", false, false, false, 72), "")) : ("")))]);
                            // line 73
                            yield "                            ";
                            yield (string) $this->getTemplateForMacro("macro_action_button", $context, 73, $this->getSourceContext())->macro_action_button(...[false, $context["values"], false]);
                            yield "
                        ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['icon'], $context['values'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent);
                        $context += $_parent;
                        // line 75
                        yield "                    </div>
                </div>
            ";
                    } else {
                        // line 78
                        yield "                ";
                        $context["values"] = Twig\Extension\CoreExtension::merge($context["values"], ["combined" => ($context["large"] ?? null), "class" => ((((($context["btnClasses"] ?? null) . " action-") . $context["icon"]) . " ") . ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", true, true, false, 78)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", false, false, false, 78), "")) : ("")))]);
                        // line 79
                        yield "                ";
                        yield (string) $this->getTemplateForMacro("macro_action_button", $context, 79, $this->getSourceContext())->macro_action_button(...[$context["icon"], $context["values"]]);
                        yield "
            ";
                    }
                    // line 81
                    yield "        ";
                }
                // line 82
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['icon'], $context['values'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 85
    public function macro_label_boolean($visible = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "visible" => $visible,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 86
            yield "    ";
            if ((($tmp = ($context["visible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 87
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_label", $context, 87, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("yes"), "success"]);
                yield "
    ";
            } else {
                // line 89
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_label", $context, 89, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("no"), "default"]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 93
    public function macro_label_visible($visible = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "visible" => $visible,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 94
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_boolean", $context, 94, $this->getSourceContext())->macro_label_boolean(...[($context["visible"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 97
    public function macro_label_role($role = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "role" => $role,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 98
            yield "    ";
            $context["color"] = "primary";
            // line 99
            yield "    ";
            if ((($context["role"] ?? null) == "ROLE_SUPER_ADMIN")) {
                // line 100
                yield "        ";
                $context["color"] = "danger";
                // line 101
                yield "    ";
            } elseif ((($context["role"] ?? null) == "ROLE_ADMIN")) {
                // line 102
                yield "        ";
                $context["color"] = "warning";
                // line 103
                yield "    ";
            } elseif ((($context["role"] ?? null) == "ROLE_TEAMLEAD")) {
                // line 104
                yield "        ";
                $context["color"] = "success";
                // line 105
                yield "    ";
            } elseif ((($context["role"] ?? null) == "ROLE_USER")) {
                // line 106
                yield "        ";
                $context["color"] = "gray";
                // line 107
                yield "    ";
            }
            // line 108
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label", $context, 108, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["role"] ?? null)), ($context["color"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 111
    public function macro_username($user = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 112
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 112), "html", null, true);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 115
    public function macro_label_user($user = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 116
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color", $context, 116, $this->getSourceContext())->macro_label_color(...[CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 116), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 116), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 116))]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 119
    public function macro_label_team($team = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "team" => $team,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 120
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color", $context, 120, $this->getSourceContext())->macro_label_color(...[CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "name", [], "any", false, false, false, 120), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "color", [], "any", false, false, false, 120), CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "name", [], "any", false, false, false, 120))]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 123
    public function macro_user_avatar($user = null, $tooltip = null, $class = null, $badge = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "tooltip" => $tooltip,
            "class" => $class,
            "badge" => $badge,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 124
            yield "    ";
            $context["avatar"] = null;
            // line 125
            yield "    ";
            if (( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 125)) && (($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "themeAllowAvatarUrls")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 126
                yield "        ";
                $context["avatar"] = $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 126), "avatars");
                // line 127
                yield "    ";
            }
            // line 128
            yield "    ";
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "enabled", [], "any", false, false, false, 128)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 129
                yield "        ";
                $context["badge"] = "danger";
                // line 130
                yield "    ";
            }
            // line 131
            yield "    ";
            $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 131), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 131));
            // line 132
            yield "    <span class=\"avatar ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\"";
            // line 133
            if ( !(($context["tooltip"] ?? null) === false)) {
                yield " data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("tooltip", $context)) ? (Twig\Extension\CoreExtension::default(($context["tooltip"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 133))) : (CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 133))), "html", null, true);
                yield "\"";
            }
            // line 134
            if ( !(null === ($context["avatar"] ?? null))) {
                // line 135
                yield "            style=\"background-image: url(";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar"] ?? null), "html", null, true);
                yield ")\">&nbsp;
        ";
            } else {
                // line 137
                yield "            style=\"background-color: ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                yield "; color: ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(($context["color"] ?? null)), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "initials", [], "any", false, false, false, 137), "html", null, true);
                yield "
        ";
            }
            // line 139
            if ( !(null === ($context["badge"] ?? null))) {
                yield "<span class=\"badge bg-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["badge"] ?? null), "html", null, true);
                yield "\"></span>";
            }
            // line 140
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 143
    public function macro_avatar($initials = null, $color = null, $tooltip = null, $class = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "initials" => $initials,
            "color" => $color,
            "tooltip" => $tooltip,
            "class" => $class,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 144
            yield "    ";
            $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(($context["color"] ?? null), ($context["initials"] ?? null));
            // line 145
            yield "    <span class=\"avatar ";
            yield (string) (((array_key_exists("class", $context) &&  !(null === $context["class"]))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["class"], "html", null, true)) : (""));
            yield "\" style=\"background-color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
            yield "; color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(($context["color"] ?? null)), "html", null, true);
            yield "\"";
            // line 146
            if ( !(($context["tooltip"] ?? null) === null)) {
                yield " data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tooltip"] ?? null), "html", null, true);
                yield "\"";
            }
            yield ">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["initials"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 149
    public function macro_avatar_deleted($tooltip = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "tooltip" => $tooltip,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 150
            yield "    ";
            $context["initials"] = (((array_key_exists("tooltip", $context) &&  !(null === $context["tooltip"]))) ? ($context["tooltip"]) : ("??"));
            // line 151
            yield "    ";
            $context["tooltip"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("deleted");
            // line 152
            yield "    ";
            $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(null, ($context["initials"] ?? null));
            // line 153
            yield "    <span class=\"avatar ";
            yield (string) (((array_key_exists("class", $context) &&  !(null === $context["class"]))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["class"], "html", null, true)) : (""));
            yield "\" style=\"background-color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
            yield "; color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(($context["color"] ?? null)), "html", null, true);
            yield "\"";
            // line 154
            if ( !(($context["tooltip"] ?? null) === null)) {
                yield " data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tooltip"] ?? null), "html", null, true);
                yield "\"";
            }
            yield ">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["initials"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 160
    public function macro_label_activity($activity = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "activity" => $activity,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 161
            yield "    ";
            $context["inherit"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", true, true, false, 161) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", false, false, false, 161)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", false, false, false, 161)) : (true));
            // line 162
            yield "    ";
            $context["isVisible"] = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "visible", [], "any", false, false, false, 162);
            // line 163
            yield "    ";
            $context["color"] = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "color", [], "any", false, false, false, 163);
            // line 164
            yield "    ";
            if (((Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null)) && (($tmp = ($context["inherit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 164)))) {
                // line 165
                yield "        ";
                $context["color"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, true, false, 165), "color", [], "any", true, true, false, 165) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 165), "color", [], "any", false, false, false, 165)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 165), "color", [], "any", false, false, false, 165)) : (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 165), "customer", [], "any", false, false, false, 165), "color", [], "any", false, false, false, 165)));
                // line 166
                yield "    ";
            }
            // line 167
            yield "    ";
            if (Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null))) {
                // line 168
                yield "        ";
                $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(($context["color"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "name", [], "any", false, false, false, 168));
                // line 169
                yield "    ";
            }
            // line 170
            yield "    ";
            if (((($tmp = ($context["isVisible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 170)))) {
                // line 171
                yield "        ";
                $context["isVisible"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 171), "visible", [], "any", false, false, false, 171);
                // line 172
                yield "        ";
                if (((($tmp = ($context["isVisible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 172), "customer", [], "any", false, false, false, 172)))) {
                    // line 173
                    yield "            ";
                    $context["isVisible"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 173), "customer", [], "any", false, false, false, 173), "visible", [], "any", false, false, false, 173);
                    // line 174
                    yield "        ";
                }
                // line 175
                yield "    ";
            }
            // line 176
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 176, $this->getSourceContext())->macro_label_color_dot(...["activity", ($context["isVisible"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "name", [], "any", false, false, false, 176), null, ($context["color"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 182
    public function macro_label_project($project = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 183
            yield "    ";
            $context["inherit"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", true, true, false, 183) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", false, false, false, 183)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "inherit", [], "any", false, false, false, 183)) : (true));
            // line 184
            yield "    ";
            $context["isVisible"] = false;
            // line 185
            yield "    ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visible", [], "any", false, false, false, 185)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 185), "visible", [], "any", false, false, false, 185)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 186
                yield "        ";
                $context["isVisible"] = true;
                // line 187
                yield "    ";
            }
            // line 188
            yield "    ";
            $context["color"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "color", [], "any", false, false, false, 188);
            // line 189
            yield "    ";
            if ((Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null)) && (($tmp = ($context["inherit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 190
                yield "        ";
                $context["color"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 190), "color", [], "any", false, false, false, 190);
                // line 191
                yield "    ";
            }
            // line 192
            yield "    ";
            if (Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null))) {
                // line 193
                yield "        ";
                $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(($context["color"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "name", [], "any", false, false, false, 193));
                // line 194
                yield "    ";
            }
            // line 195
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 195, $this->getSourceContext())->macro_label_color_dot(...["project", ($context["isVisible"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "name", [], "any", false, false, false, 195), null, ($context["color"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 198
    public function macro_label_customer($customer = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "customer" => $customer,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 199
            yield "    ";
            $context["color"] = CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "color", [], "any", false, false, false, 199);
            // line 200
            yield "    ";
            if (Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null))) {
                // line 201
                yield "        ";
                $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(($context["color"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "name", [], "any", false, false, false, 201));
                // line 202
                yield "    ";
            }
            // line 203
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 203, $this->getSourceContext())->macro_label_color_dot(...["customer", CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visible", [], "any", false, false, false, 203), CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "name", [], "any", false, false, false, 203), null, ($context["color"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 207
    public function macro_label_name($label = null, $color = null, $isVisible = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "label" => $label,
            "color" => $color,
            "isVisible" => $isVisible,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 208
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 208, $this->getSourceContext())->macro_label_color_dot(...["color", ($context["isVisible"] ?? null), ($context["label"] ?? null), null, ($context["color"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 212
    public function macro_label_dot($label = null, $color = null, $isVisible = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "label" => $label,
            "color" => $color,
            "isVisible" => $isVisible,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 213
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 213, $this->getSourceContext())->macro_label_color_dot(...["color", ($context["isVisible"] ?? null), ($context["label"] ?? null), null, $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(($context["color"] ?? null), ($context["label"] ?? null))]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 217
    public function macro_label_color_dot($type = null, $isVisible = null, $name = null, $url = null, $color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "isVisible" => $isVisible,
            "name" => $name,
            "url" => $url,
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 218
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) {
                yield "<a href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
                yield "\">";
            }
            // line 219
            yield "    <span class=\"pe-1 label-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["type"] ?? null), "html", null, true);
            yield (string) (((($context["isVisible"] ?? null) === false)) ? (" label-invisible") : (""));
            yield "\">
        <span class=\"badge me-1\" ";
            // line 220
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["color"] ?? null))) {
                yield " style=\"background-color:";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                yield "\"";
            }
            yield "></span>";
            // line 221
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["name"] ?? null), "html", null, true);
            // line 222
            yield "</span>";
            // line 223
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["url"] ?? null))) {
                yield "</a>";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 226
    public function macro_badge_team_access($teams = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "teams" => $teams,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 227
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_badge_counted", $context, 227, $this->getSourceContext())->macro_badge_counted(...[Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["teams"] ?? null))]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 230
    public function macro_badge_counted($amount = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "amount" => $amount,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 231
            yield "    ";
            if ((($context["amount"] ?? null) > 0)) {
                // line 232
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_badge_counter", $context, 232, $this->getSourceContext())->macro_badge_counter(...[($context["amount"] ?? null), null, "primary"]);
                yield "
    ";
            } else {
                // line 234
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_badge_counter", $context, 234, $this->getSourceContext())->macro_badge_counter(...[0, null, "secondary"]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 238
    public function macro_badge_counter($count = null, $url = null, $type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "count" => $count,
            "url" => $url,
            "type" => $type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 239
            yield "    ";
            if ( !(null === ($context["url"] ?? null))) {
                // line 240
                yield "        <a href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
                yield "\">";
                yield (string) $this->getTemplateForMacro("macro_badge_type", $context, 240, $this->getSourceContext())->macro_badge_type(...[($context["count"] ?? null), ((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default(($context["type"] ?? null), "blue")) : ("blue"))]);
                yield "</a>
    ";
            } else {
                // line 242
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_badge_type", $context, 242, $this->getSourceContext())->macro_badge_type(...[($context["count"] ?? null), ((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default(($context["type"] ?? null), "blue")) : ("blue"))]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 246
    public function macro_label($title = null, $type = null, $tooltip = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "title" => $title,
            "type" => $type,
            "tooltip" => $tooltip,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 247
            yield "    <span ";
            if ((($tmp = ($context["tooltip"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tooltip"] ?? null), "html", null, true);
                yield "\" ";
            }
            yield "class=\"badge bg-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default(($context["type"] ?? null), "success")) : ("success")), "html", null, true);
            yield " text-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default(($context["type"] ?? null), "success")) : ("success")), "html", null, true);
            yield "-fg\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 250
    public function macro_label_color($title = null, $color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "title" => $title,
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 251
            yield "    <span class=\"badge\" style=\"background-color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->defaultColor(($context["color"] ?? null)), "html", null, true);
            yield ";color: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor($this->extensions['App\Twig\Extensions']->defaultColor(($context["color"] ?? null))), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 254
    public function macro_badge($title = null, $color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "title" => $title,
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 255
            yield "    <span class=\"badge\"";
            if ( !(null === ($context["color"] ?? null))) {
                yield " style=\"background-color:";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                yield "; color:";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(($context["color"] ?? null)), "html", null, true);
                yield "\"";
            }
            yield ">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 258
    public function macro_badge_type($title = null, $type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "title" => $title,
            "type" => $type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 259
            yield "    ";
            $context["class"] = (( !Twig\Extension\CoreExtension::testEmpty(($context["type"] ?? null))) ? ((((("bg-" . ($context["type"] ?? null)) . " text-") . ($context["type"] ?? null)) . "-fg")) : (""));
            // line 260
            yield "    <span class=\"badge ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "</span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 263
    public function macro_form_errors($form = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "form" => $form,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 264
            yield "    ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 264), "errors", [], "any", false, false, false, 264)) > 0)) {
                // line 265
                yield "        ";
                $context["message"] = "";
                // line 266
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 266), "errors", [], "any", false, false, false, 266));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["error"]) {
                    // line 267
                    yield "            ";
                    $context["message"] = (($context["message"] ?? null) . CoreExtension::getAttribute($this->env, $this->source, $context["error"], "message", [], "any", false, false, false, 267));
                    // line 268
                    yield "            ";
                    if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 268)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 269
                        yield "                ";
                        $context["message"] = (($context["message"] ?? null) . "<br>");
                        // line 270
                        yield "            ";
                    }
                    // line 271
                    yield "        ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['error'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 272
                yield "        ";
                if ((($context["message"] ?? null) != "")) {
                    // line 273
                    yield "            ";
                    yield (string) $this->getTemplateForMacro("macro_alert", $context, 273, $this->getSourceContext())->macro_alert(...["danger", ($context["message"] ?? null)]);
                    yield "
        ";
                }
                // line 275
                yield "    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 278
    public function macro_alert($type = null, $description = null, $title = null, $icon = null, $dismissible = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "description" => $description,
            "title" => $title,
            "icon" => $icon,
            "dismissible" => $dismissible,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 279
            yield "    ";
            $macros["_v0"] = $this->load("@theme/components/alert.html.twig", 279)->unwrap();
            // line 280
            yield "    ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 280, $this->getSourceContext())->macro_alert(...[["type" => ($context["type"] ?? null), "description" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["description"] ?? null)), "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "icon" => ($context["icon"] ?? null), "dismissible" => ($context["dismissible"] ?? null), "important" => true]]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 283
    public function macro_callout($type = null, $description = null, $title = null, $icon = null, $important = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "description" => $description,
            "title" => $title,
            "icon" => $icon,
            "important" => $important,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 284
            yield "    ";
            $macros["_v1"] = $this->load("@theme/components/alert.html.twig", 284)->unwrap();
            // line 285
            yield "    ";
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_alert", $context, 285, $this->getSourceContext())->macro_alert(...[["type" => ((array_key_exists("type", $context)) ? (Twig\Extension\CoreExtension::default(($context["type"] ?? null), "danger")) : ("danger")), "description" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["description"] ?? null)), "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "icon" => ($context["icon"] ?? null), "dismissible" => false, "important" => (((array_key_exists("important", $context) &&  !(null === $context["important"]))) ? ($context["important"]) : (true))]]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 288
    public function macro_table_actions($actions = null, $class = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "actions" => $actions,
            "class" => $class,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 289
            yield "    ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["actions"] ?? null)) >= 1)) {
                // line 290
                yield "        ";
                $macros["macro"] = $this->load("@theme/components/actions.html.twig", 290)->unwrap();
                // line 291
                yield "        ";
                yield (string) $macros["macro"]->getTemplateForMacro("macro_actions", $context, 291, $this->getSourceContext())->macro_actions(...[($context["actions"] ?? null), ["class" => ((array_key_exists("class", $context)) ? (Twig\Extension\CoreExtension::default(($context["class"] ?? null), "btn-sm")) : ("btn-sm")), "translationDomain" => "actions"]]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 295
    public function macro_card_tool_visibility($tableName = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "tableName" => $tableName,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 296
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_card_tool_button", $context, 296, $this->getSourceContext())->macro_card_tool_button(...["visibility", ["modal" => ("#modal_" . ($context["tableName"] ?? null))]]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 299
    public function macro_card_tool_button($icon = null, $values = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "icon" => $icon,
            "values" => $values,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 300
            yield "    ";
            $macros["macro"] = $this->load("@theme/components/buttons.html.twig", 300)->unwrap();
            // line 301
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge(($context["values"] ?? null), ["tooltip_attr" => "data-toggle"]);
            // line 302
            yield "    ";
            yield (string) $macros["macro"]->getTemplateForMacro("macro_action_cardtoolbutton", $context, 302, $this->getSourceContext())->macro_action_cardtoolbutton(...[($context["icon"] ?? null), ($context["values"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 305
    public function macro_card_tool_create($create_url = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "create_url" => $create_url,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 306
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_card_tool_button", $context, 306, $this->getSourceContext())->macro_card_tool_button(...["create", ["url" => ($context["create_url"] ?? null), "class" => "modal-ajax-form open-edit", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create")]]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 309
    public function macro_action_button($icon = null, $values = null, $type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "icon" => $icon,
            "values" => $values,
            "type" => $type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 310
            yield "    ";
            $macros["macro"] = $this->load("@theme/components/button.html.twig", 310)->unwrap();
            // line 311
            yield "    ";
            $context["values"] = Twig\Extension\CoreExtension::merge((((array_key_exists("values", $context) &&  !(null === $context["values"]))) ? ($context["values"]) : ([])), ["tooltip_attr" => "data-toggle"]);
            // line 312
            yield "    ";
            yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 312, $this->getSourceContext())->macro_button(...[($context["icon"] ?? null), ($context["values"] ?? null), ($context["type"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 315
    public function macro_tag_list($taglist = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "taglist" => $taglist,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 316
            yield "    <div class=\"tags-list\">
    ";
            // line 317
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["taglist"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
                // line 318
                yield "        <span class=\"tag\">
            <span class=\"legend\" style=\"background-color: ";
                // line 319
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, $context["tag"], "color", [], "any", false, false, false, 319), CoreExtension::getAttribute($this->env, $this->source, $context["tag"], "name", [], "any", false, false, false, 319)), "html", null, true);
                yield "\"></span>
            ";
                // line 320
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["tag"], "name", [], "any", false, false, false, 320), "html", null, true);
                yield "
        </span>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['tag'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 323
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 326
    public function macro_meta_field_value($entity = null, $field = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "entity" => $entity,
            "field" => $field,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 327
            yield "    ";
            $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "metaField", [CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "name", [], "any", false, false, false, 327)], "method", false, false, false, 327);
            // line 328
            yield "    ";
            if ( !(null === ($context["metaField"] ?? null))) {
                // line 329
                yield "        ";
                $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "merge", [($context["field"] ?? null)], "method", false, false, false, 329);
                // line 330
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_form_type_value", $context, 330, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "type", [], "any", false, false, false, 330), CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 330), ($context["entity"] ?? null)]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 334
    public function macro_form_type_value($type = null, $value = null, $entity = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "value" => $value,
            "entity" => $entity,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 335
            yield "    ";
            if ((CoreExtension::inFilter("ColorPickerType", ($context["type"] ?? null)) || CoreExtension::inFilter("ColorChoiceType", ($context["type"] ?? null)))) {
                // line 336
                yield "        ";
                if ( !Twig\Extension\CoreExtension::testEmpty(($context["value"] ?? null))) {
                    // line 337
                    yield "            ";
                    yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 337, $this->getSourceContext())->macro_label_color_dot(...["color", true, ($context["value"] ?? null), null, ($context["value"] ?? null)]);
                    yield "
        ";
                }
                // line 339
                yield "    ";
            } elseif (CoreExtension::inFilter("DurationType", ($context["type"] ?? null))) {
                // line 340
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif ((CoreExtension::inFilter("YesNoType",             // line 341
($context["type"] ?? null)) || CoreExtension::inFilter("CheckboxType", ($context["type"] ?? null)))) {
                // line 342
                yield "        ";
                yield (string) $this->getTemplateForMacro("macro_label_boolean", $context, 342, $this->getSourceContext())->macro_label_boolean(...[($context["value"] ?? null)]);
                yield "
    ";
            } elseif (CoreExtension::inFilter("DatePickerType",             // line 343
($context["type"] ?? null))) {
                // line 344
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("DateTimePickerType",             // line 345
($context["type"] ?? null))) {
                // line 346
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("CountryType",             // line 347
($context["type"] ?? null))) {
                // line 348
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("CurrencyType",             // line 349
($context["type"] ?? null))) {
                // line 350
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCurrencyName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("LanguageType",             // line 351
($context["type"] ?? null))) {
                // line 352
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getLocaleName(($context["value"] ?? null)), "html", null, true);
                yield "
    ";
            } elseif (CoreExtension::inFilter("TagsType",             // line 353
($context["type"] ?? null))) {
                // line 354
                yield "        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::split($this->env->getCharset(), ($context["value"] ?? null), ","));
                foreach ($context['_seq'] as $context["_key"] => $context["tag"]) {
                    // line 355
                    yield "            ";
                    if ( !Twig\Extension\CoreExtension::testEmpty($context["tag"])) {
                        // line 356
                        yield "                ";
                        yield (string) $this->getTemplateForMacro("macro_badge", $context, 356, $this->getSourceContext())->macro_badge(...[$context["tag"], $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(null, $context["tag"])]);
                        yield "
            ";
                    }
                    // line 358
                    yield "        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['tag'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 359
                yield "    ";
            } elseif (CoreExtension::inFilter("MoneyType", ($context["type"] ?? null))) {
                // line 360
                yield "        ";
                $context["classname"] = $this->extensions['App\Twig\Extensions']->getClassName(($context["entity"] ?? null));
                // line 361
                yield "        ";
                if ((null === ($context["classname"] ?? null))) {
                    // line 362
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 363
($context["classname"] ?? null) == "App\\Entity\\Timesheet")) {
                    // line 364
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 364), "customer", [], "any", false, false, false, 364), "currency", [], "any", false, false, false, 364)), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 365
($context["classname"] ?? null) == "App\\Entity\\Customer")) {
                    // line 366
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "currency", [], "any", false, false, false, 366)), "html", null, true);
                    yield "
        ";
                } elseif ((                // line 367
($context["classname"] ?? null) == "App\\Entity\\Project")) {
                    // line 368
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "customer", [], "any", false, false, false, 368), "currency", [], "any", false, false, false, 368)), "html", null, true);
                    yield "
        ";
                } elseif (((                // line 369
($context["classname"] ?? null) == "App\\Entity\\Activity") &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 369)))) {
                    // line 370
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entity"] ?? null), "project", [], "any", false, false, false, 370), "customer", [], "any", false, false, false, 370), "currency", [], "any", false, false, false, 370)), "html", null, true);
                    yield "
        ";
                } else {
                    // line 372
                    yield "            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                    yield "
        ";
                }
                // line 374
                yield "    ";
            } elseif (CoreExtension::inFilter("TextareaType", ($context["type"] ?? null))) {
                // line 375
                yield "        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true));
                yield "
    ";
            } elseif (CoreExtension::inFilter("EmailType",             // line 376
($context["type"] ?? null))) {
                // line 377
                yield "        <a href=\"mailto:";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "</a>
    ";
            } elseif (CoreExtension::inFilter("UrlType",             // line 378
($context["type"] ?? null))) {
                // line 379
                yield "        <a href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "\" target=\"_blank\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "</a>
    ";
            } else {
                // line 381
                yield "        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["value"] ?? null), "html", null, true);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 385
    public function macro_team_list($teams = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "teams" => $teams,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 386
            yield "    ";
            $context["showTitle"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "array", true, true, false, 386) &&  !(null === (($_v2 = ($context["options"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["title"] ?? null) : null)))) ? ((($_v3 = ($context["options"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["title"] ?? null) : null)) : (true));
            // line 387
            yield "    ";
            $context["collapseAt"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "collapse", [], "array", true, true, false, 387) &&  !(null === (($_v4 = ($context["options"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["collapse"] ?? null) : null)))) ? ((($_v5 = ($context["options"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["collapse"] ?? null) : null)) : (12));
            // line 388
            yield "    ";
            $context["nameClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "name_class", [], "array", true, true, false, 388) &&  !(null === (($_v6 = ($context["options"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["name_class"] ?? null) : null)))) ? ((($_v7 = ($context["options"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["name_class"] ?? null) : null)) : (""));
            // line 389
            yield "    ";
            $context["viewTeam"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_team");
            // line 390
            yield "    <table class=\"table table-hover dataTable\" role=\"grid\">
        ";
            // line 391
            if ((($tmp = ($context["showTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 392
                yield "        <thead>
            <tr>
                <th class=\"hw-min\">";
                // line 394
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team"), "html", null, true);
                yield "</th>
                <th class=\"d-none d-sm-table-cell\">";
                // line 395
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team.member", [], "teams"), "html", null, true);
                yield "</th>
            </tr>
        </thead>
        ";
            }
            // line 399
            yield "        <tbody>
        ";
            // line 400
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["teams"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "name", [], "any", false, false, false, 400) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "name", [], "any", false, false, false, 400)); }));
            foreach ($context['_seq'] as $context["_key"] => $context["team"]) {
                // line 401
                yield "            ";
                $context["members"] = Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, $context["team"], "members", [], "any", false, false, false, 401), function ($__m__) use ($context, $macros) { $context["m"] = $__m__; return CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["m"] ?? null), "user", [], "any", false, false, false, 401), "enabled", [], "any", false, false, false, 401); });
                // line 402
                yield "            ";
                $context["class"] = "avatar-rounded";
                // line 403
                yield "            <tr";
                if (((($tmp = ($context["viewTeam"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", $context["team"])) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    yield " class=\"modal-ajax-form open-edit\" data-href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_team_member", ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["team"], "id", [], "any", false, false, false, 403)]), "html", null, true);
                    yield "\"";
                }
                yield ">
                <td class=\"";
                // line 404
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["nameClass"] ?? null), "html", null, true);
                yield "\">
                    ";
                // line 405
                yield (string) $this->getTemplateForMacro("macro_label_color_dot", $context, 405, $this->getSourceContext())->macro_label_color_dot(...["color", true, CoreExtension::getAttribute($this->env, $this->source, $context["team"], "name", [], "any", false, false, false, 405), null, $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, $context["team"], "color", [], "any", false, false, false, 405), CoreExtension::getAttribute($this->env, $this->source, $context["team"], "name", [], "any", false, false, false, 405))]);
                yield "
                </td>
                <td class=\"d-none d-sm-table-cell avatars avatar-list avatar-list-stacked\">
                    ";
                // line 408
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["members"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "teamlead", [], "any", false, false, false, 408) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "teamlead", [], "any", false, false, false, 408)); }));
                foreach ($context['_seq'] as $context["_key"] => $context["member"]) {
                    // line 409
                    yield "                        ";
                    $context["user"] = CoreExtension::getAttribute($this->env, $this->source, $context["member"], "user", [], "any", false, false, false, 409);
                    // line 410
                    yield "                        ";
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["member"], "teamlead", [], "any", false, false, false, 410)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 411
                        yield "                            ";
                        yield (string) $this->getTemplateForMacro("macro_user_avatar", $context, 411, $this->getSourceContext())->macro_user_avatar(...[($context["user"] ?? null), (($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("teamlead") . ": ") . CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 411)), (($context["class"] ?? null) . " teamlead"), "info"]);
                        yield "
                        ";
                    } else {
                        // line 413
                        yield "                            ";
                        yield (string) $this->getTemplateForMacro("macro_user_avatar", $context, 413, $this->getSourceContext())->macro_user_avatar(...[($context["user"] ?? null), null, ($context["class"] ?? null)]);
                        yield "
                        ";
                    }
                    // line 415
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['member'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 416
                yield "                </td>
            </tr>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['team'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 419
            yield "        </tbody>
    </table>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 423
    public function macro_nothing_found($events = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "events" => $events,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 424
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_callout", $context, 424, $this->getSourceContext())->macro_callout(...["info", "error.no_entries_found", null, "info", false]);
            yield "
    ";
            // line 425
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["events"] ?? null))) {
                // line 426
                yield "    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27";
                // line 428
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["events"] ?? null), "html", null, true);
                yield "\x27);
        });
    </script>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 438
    public function macro_class_customer_row($customer = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "customer" => $customer,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 439
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visible", [], "any", false, false, false, 439)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "bg-orange-lt";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 446
    public function macro_class_tag_row($tag = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "tag" => $tag,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 447
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tag"] ?? null), "visible", [], "any", false, false, false, 447)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "bg-orange-lt";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 454
    public function macro_customer_row_attr($customer = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "customer" => $customer,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 455
            $context["class"] = $this->getTemplateForMacro("macro_class_customer_row", $context, 455, $this->getSourceContext())->macro_class_customer_row(...[($context["customer"] ?? null), ($context["now"] ?? null)]);
            // line 456
            yield "    ";
            $context["dataHref"] = "";
            // line 457
            yield "    ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", ($context["customer"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 458
                yield "        ";
                $context["class"] = (($context["class"] ?? null) . " alternative-link open-edit");
                // line 459
                yield "        ";
                $context["dataHref"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 459)]);
                // line 460
                yield "    ";
            }
            // line 461
            yield "class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["dataHref"] ?? null), "html", null, true);
            yield "\"
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 468
    public function macro_class_project_row($project = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 469
            if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visible", [], "any", false, false, false, 469)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 469)) && (CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 469) < ($context["now"] ?? null))))) {
                yield "bg-orange-lt";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 476
    public function macro_project_row_attr($project = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 477
            $context["class"] = $this->getTemplateForMacro("macro_class_project_row", $context, 477, $this->getSourceContext())->macro_class_project_row(...[($context["project"] ?? null), ($context["now"] ?? null)]);
            // line 478
            yield "    ";
            $context["dataHref"] = "";
            // line 479
            yield "    ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 480
                yield "        ";
                $context["class"] = (($context["class"] ?? null) . " alternative-link open-edit");
                // line 481
                yield "        ";
                $context["dataHref"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("project_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 481)]);
                // line 482
                yield "    ";
            }
            // line 483
            yield "class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["dataHref"] ?? null), "html", null, true);
            yield "\"
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 490
    public function macro_class_activity_row($activity = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "activity" => $activity,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 491
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "visible", [], "any", false, false, false, 491)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "bg-orange-lt";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 498
    public function macro_activity_row_attr($activity = null, $now = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "activity" => $activity,
            "now" => $now,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 499
            $context["class"] = $this->getTemplateForMacro("macro_class_activity_row", $context, 499, $this->getSourceContext())->macro_class_activity_row(...[($context["activity"] ?? null), ($context["now"] ?? null)]);
            // line 500
            yield "    ";
            $context["dataHref"] = "";
            // line 501
            yield "    ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", ($context["activity"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 502
                yield "        ";
                $context["class"] = (($context["class"] ?? null) . " alternative-link open-edit");
                // line 503
                yield "        ";
                $context["dataHref"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activity_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "id", [], "any", false, false, false, 503)]);
                // line 504
                yield "    ";
            }
            // line 505
            yield "class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["dataHref"] ?? null), "html", null, true);
            yield "\"
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 512
    public function macro_class_user_row($user = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 513
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "enabled", [], "any", false, false, false, 513)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "bg-orange-lt";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 520
    public function macro_user_row_attr($user = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 521
            $context["class"] = $this->getTemplateForMacro("macro_class_user_row", $context, 521, $this->getSourceContext())->macro_class_user_row(...[($context["user"] ?? null)]);
            // line 522
            yield "    ";
            $context["dataHref"] = "";
            // line 523
            yield "    ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", ($context["user"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 524
                yield "        ";
                $context["class"] = (($context["class"] ?? null) . " alternative-link open-edit");
                // line 525
                yield "        ";
                $context["dataHref"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_profile", ["username" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "username", [], "any", false, false, false, 525)]);
                // line 526
                yield "    ";
            }
            // line 527
            yield "class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["dataHref"] ?? null), "html", null, true);
            yield "\"
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 531
    public function macro_short_stats_row($stats = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "stats" => $stats,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 532
            yield "    <div class=\"row\">
        ";
            // line 533
            $context["colLength"] = (12 / Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["stats"] ?? null)));
            // line 534
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["stats"] ?? null));
            foreach ($context['_seq'] as $context["title"] => $context["value"]) {
                // line 535
                yield "        <div class=\"col-sm-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["colLength"] ?? null), "html", null, true);
                yield " border-right\">
            <div class=\"description-block\">
                <h5 class=\"description-header\">";
                // line 537
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                yield "</h5>
                <span class=\"description-text\">";
                // line 538
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["title"], "html", null, true);
                yield "</span>
            </div>
        </div>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['title'], $context['value'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 542
            yield "    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 545
    public function macro_page_reloader($events = null, $full_reload = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "events" => $events,
            "full_reload" => $full_reload,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 546
            yield "    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27";
            // line 548
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["events"] ?? null), "html", null, true);
            yield "\x27, ";
            if ((($context["full_reload"] ?? null) === true)) {
                yield "true";
            } else {
                yield "false";
            }
            yield ");
        });
    </script>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 553
    public function macro_work_times_result($should = null, $actual = null, $decimal = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "should" => $should,
            "actual" => $actual,
            "decimal" => $decimal,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 554
            yield "    ";
            $context["result"] = (($context["actual"] ?? null) - ($context["should"] ?? null));
            // line 555
            yield "    ";
            if ((($context["result"] ?? null) == 0)) {
                // line 556
                yield "        <span class=\"work_time_exact\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["result"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                yield "</span>
    ";
            } elseif (((            // line 557
($context["should"] ?? null) == 0) && (($context["actual"] ?? null) > 0))) {
                // line 558
                yield "        <span class=\"work_time_positive text-green\">+";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["actual"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                yield "</span>
    ";
            } elseif ((            // line 559
($context["result"] ?? null) < 0)) {
                // line 560
                yield "        <span class=\"work_time_negative text-red\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["result"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                yield "</span>
    ";
            } else {
                // line 562
                yield "        <span class=\"work_time_positive text-green\">+";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["result"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                yield "</span>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/widgets.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  2328 => 562,  2322 => 560,  2320 => 559,  2315 => 558,  2313 => 557,  2308 => 556,  2305 => 555,  2302 => 554,  2288 => 553,  2272 => 548,  2268 => 546,  2255 => 545,  2248 => 542,  2237 => 538,  2233 => 537,  2227 => 535,  2222 => 534,  2220 => 533,  2217 => 532,  2205 => 531,  2194 => 527,  2191 => 526,  2188 => 525,  2185 => 524,  2182 => 523,  2179 => 522,  2177 => 521,  2165 => 520,  2157 => 513,  2145 => 512,  2134 => 505,  2131 => 504,  2128 => 503,  2125 => 502,  2122 => 501,  2119 => 500,  2117 => 499,  2104 => 498,  2096 => 491,  2083 => 490,  2072 => 483,  2069 => 482,  2066 => 481,  2063 => 480,  2060 => 479,  2057 => 478,  2055 => 477,  2042 => 476,  2034 => 469,  2021 => 468,  2010 => 461,  2007 => 460,  2004 => 459,  2001 => 458,  1998 => 457,  1995 => 456,  1993 => 455,  1980 => 454,  1972 => 447,  1960 => 446,  1952 => 439,  1939 => 438,  1928 => 428,  1924 => 426,  1922 => 425,  1917 => 424,  1905 => 423,  1897 => 419,  1888 => 416,  1881 => 415,  1875 => 413,  1869 => 411,  1866 => 410,  1863 => 409,  1859 => 408,  1853 => 405,  1849 => 404,  1840 => 403,  1837 => 402,  1834 => 401,  1830 => 400,  1827 => 399,  1820 => 395,  1816 => 394,  1812 => 392,  1810 => 391,  1807 => 390,  1804 => 389,  1801 => 388,  1798 => 387,  1795 => 386,  1782 => 385,  1772 => 381,  1764 => 379,  1762 => 378,  1755 => 377,  1753 => 376,  1748 => 375,  1745 => 374,  1739 => 372,  1733 => 370,  1731 => 369,  1726 => 368,  1724 => 367,  1719 => 366,  1717 => 365,  1712 => 364,  1710 => 363,  1705 => 362,  1702 => 361,  1699 => 360,  1696 => 359,  1689 => 358,  1683 => 356,  1680 => 355,  1675 => 354,  1673 => 353,  1668 => 352,  1666 => 351,  1661 => 350,  1659 => 349,  1654 => 348,  1652 => 347,  1647 => 346,  1645 => 345,  1640 => 344,  1638 => 343,  1633 => 342,  1631 => 341,  1626 => 340,  1623 => 339,  1617 => 337,  1614 => 336,  1611 => 335,  1597 => 334,  1587 => 330,  1584 => 329,  1581 => 328,  1578 => 327,  1565 => 326,  1558 => 323,  1548 => 320,  1544 => 319,  1541 => 318,  1537 => 317,  1534 => 316,  1522 => 315,  1513 => 312,  1510 => 311,  1507 => 310,  1493 => 309,  1484 => 306,  1472 => 305,  1463 => 302,  1460 => 301,  1457 => 300,  1444 => 299,  1435 => 296,  1423 => 295,  1413 => 291,  1410 => 290,  1407 => 289,  1394 => 288,  1385 => 285,  1382 => 284,  1366 => 283,  1357 => 280,  1354 => 279,  1338 => 278,  1331 => 275,  1325 => 273,  1322 => 272,  1307 => 271,  1304 => 270,  1301 => 269,  1298 => 268,  1295 => 267,  1277 => 266,  1274 => 265,  1271 => 264,  1259 => 263,  1248 => 260,  1245 => 259,  1232 => 258,  1215 => 255,  1202 => 254,  1189 => 251,  1176 => 250,  1157 => 247,  1143 => 246,  1133 => 242,  1125 => 240,  1122 => 239,  1108 => 238,  1098 => 234,  1092 => 232,  1089 => 231,  1077 => 230,  1068 => 227,  1056 => 226,  1048 => 223,  1046 => 222,  1044 => 221,  1037 => 220,  1031 => 219,  1025 => 218,  1009 => 217,  1000 => 213,  986 => 212,  977 => 208,  963 => 207,  954 => 203,  951 => 202,  948 => 201,  945 => 200,  942 => 199,  930 => 198,  921 => 195,  918 => 194,  915 => 193,  912 => 192,  909 => 191,  906 => 190,  903 => 189,  900 => 188,  897 => 187,  894 => 186,  891 => 185,  888 => 184,  885 => 183,  872 => 182,  863 => 176,  860 => 175,  857 => 174,  854 => 173,  851 => 172,  848 => 171,  845 => 170,  842 => 169,  839 => 168,  836 => 167,  833 => 166,  830 => 165,  827 => 164,  824 => 163,  821 => 162,  818 => 161,  805 => 160,  791 => 154,  783 => 153,  780 => 152,  777 => 151,  774 => 150,  762 => 149,  748 => 146,  740 => 145,  737 => 144,  722 => 143,  715 => 140,  709 => 139,  699 => 137,  693 => 135,  691 => 134,  685 => 133,  681 => 132,  678 => 131,  675 => 130,  672 => 129,  669 => 128,  666 => 127,  663 => 126,  660 => 125,  657 => 124,  642 => 123,  633 => 120,  621 => 119,  612 => 116,  600 => 115,  594 => 112,  582 => 111,  573 => 108,  570 => 107,  567 => 106,  564 => 105,  561 => 104,  558 => 103,  555 => 102,  552 => 101,  549 => 100,  546 => 99,  543 => 98,  531 => 97,  522 => 94,  510 => 93,  500 => 89,  494 => 87,  491 => 86,  479 => 85,  468 => 82,  465 => 81,  459 => 79,  456 => 78,  451 => 75,  441 => 73,  438 => 72,  434 => 71,  431 => 69,  425 => 68,  421 => 67,  413 => 66,  410 => 65,  407 => 64,  405 => 63,  402 => 62,  399 => 61,  396 => 60,  392 => 59,  389 => 58,  387 => 57,  374 => 56,  365 => 51,  359 => 48,  355 => 46,  353 => 45,  341 => 44,  335 => 41,  332 => 40,  329 => 39,  326 => 38,  323 => 37,  320 => 36,  317 => 35,  314 => 34,  311 => 33,  308 => 32,  305 => 31,  302 => 30,  299 => 29,  296 => 28,  293 => 27,  290 => 26,  287 => 25,  284 => 24,  281 => 23,  279 => 22,  266 => 21,  259 => 18,  257 => 17,  250 => 16,  244 => 14,  240 => 13,  238 => 12,  225 => 11,  218 => 8,  216 => 7,  209 => 6,  203 => 4,  199 => 3,  197 => 2,  184 => 1,  178 => 552,  175 => 544,  172 => 529,  169 => 515,  166 => 507,  163 => 493,  160 => 485,  157 => 471,  154 => 463,  151 => 449,  148 => 441,  145 => 433,  142 => 422,  139 => 384,  136 => 333,  133 => 325,  130 => 314,  127 => 308,  124 => 304,  121 => 298,  118 => 294,  115 => 287,  112 => 282,  109 => 277,  106 => 262,  103 => 257,  100 => 253,  97 => 249,  94 => 245,  91 => 237,  88 => 229,  85 => 225,  82 => 215,  79 => 210,  76 => 205,  73 => 197,  70 => 178,  67 => 156,  64 => 148,  61 => 142,  58 => 122,  55 => 118,  52 => 114,  49 => 110,  46 => 96,  43 => 92,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/widgets.html.twig", "/opt/kimai/templates/macros/widgets.html.twig");
    }
}
