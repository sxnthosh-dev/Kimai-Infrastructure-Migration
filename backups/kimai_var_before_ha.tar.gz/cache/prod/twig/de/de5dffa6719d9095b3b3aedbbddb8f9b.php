<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/project_details.html.twig */
class __TwigTemplate_1a5ca9a319318828e2e3afe73cd8122d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'javascripts' => [$this, 'block_javascripts'],
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["charts"] = $this->macros["charts"] = $this->load("macros/charts.html.twig", 2)->unwrap();
        // line 3
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
        // line 5
        $context["tableName"] = ((array_key_exists("tableName", $context)) ? (Twig\Extension\CoreExtension::default(($context["tableName"] ?? null), "project_details_reporting")) : ("project_details_reporting"));
        // line 6
        $context["tableId"] = "project-details-form";
        // line 7
        $context["showMoneyBudget"] = ( !(null === ($context["project_details"] ?? null)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "project", [], "any", false, false, false, 7))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 8
        $context["showTimeBudget"] = ( !(null === ($context["project_details"] ?? null)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "project", [], "any", false, false, false, 8))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 9
        $context["view_revenue"] = ( !(null === ($context["project_details"] ?? null)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_rate_other_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 10
        $context["see_users"] = ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_other_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_other_reporting")) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 1
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "    ";
        yield from $this->yieldParentBlock("stylesheets", $context, $blocks);
        yield "
    ";
        // line 14
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("chart");
        yield "
";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "    ";
        yield from $this->yieldParentBlock("head", $context, $blocks);
        yield "
    ";
        // line 19
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("chart");
        yield "
";
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 24
        $context["options"] = ["label" => "duration", "title" => "name", "legend" => ["display" => false]];
        // line 25
        yield "    ";
        if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 26
            yield "        ";
            $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["footer" => "rate"]);
            // line 27
            yield "    ";
        }
        // line 28
        yield "    ";
        yield (string) $macros["charts"]->getTemplateForMacro("macro_doughnut_javascript", $context, 28, $this->getSourceContext())->macro_doughnut_javascript(...[($context["options"] ?? null)]);
        yield "
    ";
        // line 29
        yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_javascript", $context, 29, $this->getSourceContext())->macro_bar_javascript(...[["legend" => ["display" => false]]]);
        yield "
    <script type=\"text/javascript\">
        [].slice.call(document.querySelectorAll(\x27a[data-bs-toggle=\"tab\"]\x27)).forEach(function (triggerEl) {
            triggerEl.addEventListener(\x27shown.bs.tab\x27, function (event) {
                renderChart(event.target.dataset.chart);
            });
            ";
        // line 35
        if ( !(null === ($context["project"] ?? null))) {
            // line 36
            yield "            renderChart(\x27project";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 36), "html", null, true);
            yield "Budget\x27);
            ";
        }
        // line 38
        yield "        });

        function renderChart(chartName)
        {
            let found = false;

            for (const instance of Object.values(Chart.instances)) {
                if (instance.canvas.id === chartName) {
                    found = true;
                }
            }

            if (!found) {
                document.dispatchEvent(new Event(\x27render.\x27 + chartName))
            }
        }
    </script>
";
        yield from [];
    }

    // line 57
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 58
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 58), 'widget', ["label" => false, "placeholder" => "project"]);
        yield "
";
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 62
        yield "    ";
        $context["hasData"] = ( !(null === ($context["project"] ?? null)) &&  !(null === ($context["project_view"] ?? null)));
        // line 63
        yield "
    ";
        // line 64
        if ( !(($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 65
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 65, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
    ";
        } else {
            // line 67
            yield "        ";
            yield (string) $this->getTemplateForMacro("macro_project_details", $context, 67, $this->getSourceContext())->macro_project_details(...[($context["project"] ?? null), ($context["project_view"] ?? null), ($context["project_details"] ?? null), ($context["showMoneyBudget"] ?? null), ($context["showTimeBudget"] ?? null), ($context["view_revenue"] ?? null), ($context["see_users"] ?? null)]);
            yield "
        ";
            // line 68
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 68), "currency", [], "any", false, false, false, 68);
            // line 70
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::reverse($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "years", [], "any", false, false, false, 70)));
            foreach ($context['_seq'] as $context["_key"] => $context["yearStat"]) {
                // line 71
                yield "            ";
                $context["year"] = CoreExtension::getAttribute($this->env, $this->source, $context["yearStat"], "year", [], "any", false, false, false, 71);
                // line 72
                yield "            ";
                yield (string) $this->getTemplateForMacro("macro_duration_stat", $context, 72, $this->getSourceContext())->macro_duration_stat(...[($context["year"] ?? null), ($context["year"] ?? null), ($context["year"] ?? null), $this->extensions['App\Twig\LocaleFormatExtensions']->getMonthNames(), $context["yearStat"], CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "getYearActivities", [($context["year"] ?? null)], "method", false, false, false, 72), CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "userYears", [($context["year"] ?? null)], "method", false, false, false, 72), ($context["currency"] ?? null), ($context["view_revenue"] ?? null), ($context["see_users"] ?? null)]);
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['yearStat'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 74
            yield "    ";
        }
        yield from [];
    }

    // line 77
    public function macro_duration_stat($id = null, $title = null, $year = null, $labels = null, $yearStat = null, $activities = null, $users = null, $currency = null, $view_revenue = null, $see_users = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "id" => $id,
            "title" => $title,
            "year" => $year,
            "labels" => $labels,
            "yearStat" => $yearStat,
            "activities" => $activities,
            "users" => $users,
            "currency" => $currency,
            "view_revenue" => $view_revenue,
            "see_users" => $see_users,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 78
            yield "    ";
            $context["rates"] = [];
            // line 79
            yield "    ";
            $context["durations"] = [];
            // line 80
            yield "    ";
            $context["chartPrefix"] = ("chart" . ($context["id"] ?? null));
            // line 81
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(range(1, 12));
            foreach ($context['_seq'] as $context["_key"] => $context["monthNumber"]) {
                // line 82
                yield "        ";
                $context["rate"] = 0;
                // line 83
                yield "        ";
                $context["duration"] = 0;
                // line 84
                yield "        ";
                $context["month"] = CoreExtension::getAttribute($this->env, $this->source, ($context["yearStat"] ?? null), "month", [$context["monthNumber"]], "method", false, false, false, 84);
                // line 85
                yield "        ";
                if ( !(null === ($context["month"] ?? null))) {
                    // line 86
                    yield "            ";
                    $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, ($context["month"] ?? null), "totalRate", [], "any", false, false, false, 86);
                    // line 87
                    yield "            ";
                    $context["duration"] = CoreExtension::getAttribute($this->env, $this->source, ($context["month"] ?? null), "totalDuration", [], "any", false, false, false, 87);
                    // line 88
                    yield "        ";
                }
                // line 89
                yield "        ";
                $context["durations"] = Twig\Extension\CoreExtension::merge(($context["durations"] ?? null), [["label" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["duration"] ?? null)), "value" => $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(($context["duration"] ?? null))]]);
                // line 90
                yield "        ";
                $context["rates"] = Twig\Extension\CoreExtension::merge(($context["rates"] ?? null), [["label" => $this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null)), "value" => ($context["rate"] ?? null)]]);
                // line 91
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['monthNumber'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 93
            yield "<div class=\"card mb-3\">
        <div class=\"card-header\">
            <h3 class=\"card-title me-3\">
                ";
            // line 96
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
            yield "
            </h3>
            <ul class=\"nav nav-pills\" data-bs-toggle=\"tabs\">
                <li class=\"nav-item\"><a class=\"nav-link active\" data-chart=\"";
            // line 99
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
            yield "Duration\" href=\"#time-chart-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\" data-bs-toggle=\"tab\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTime"), "html", null, true);
            yield "</a></li>
                ";
            // line 100
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 101
                yield "                    <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "Rate\" href=\"#revenue-chart-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 103
            yield "                ";
            if ((($tmp = ($context["see_users"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 104
                yield "                <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "User\" href=\"#user-chart-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 106
            yield "                <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
            yield "Activity\" href=\"#activity-chart-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\" data-bs-toggle=\"tab\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
            yield "</a></li>
            </ul>
            <div class=\"card-actions\">
                ";
            // line 109
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counter", $context, 109, $this->getSourceContext())->macro_badge_counter(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["yearStat"] ?? null), "duration", [], "any", false, false, false, 109))]);
            yield "
                ";
            // line 110
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 111
                yield "                    ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counter", $context, 111, $this->getSourceContext())->macro_badge_counter(...[$this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["yearStat"] ?? null), "rate", [], "any", false, false, false, 111), ($context["currency"] ?? null))]);
                yield "
                ";
            }
            // line 113
            yield "            </div>
        </div>
        <div class=\"tab-content mt-2 p-2\">
            <div class=\"chart tab-pane active\" id=\"time-chart-";
            // line 116
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\">
                <div class=\"row\">
                    <div class=\"col-xs-12\">
                        ";
            // line 119
            yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_chart", $context, 119, $this->getSourceContext())->macro_bar_chart(...[(($context["chartPrefix"] ?? null) . "Duration"), ($context["labels"] ?? null), [($context["durations"] ?? null)], ["height" => "300px"]]);
            yield "
                    </div>
                </div>
            </div>
            ";
            // line 123
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 124
                yield "                <div class=\"chart tab-pane\" id=\"revenue-chart-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\">
                    <div class=\"row\">
                        <div class=\"col-xs-12\">
                            ";
                // line 127
                yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_chart", $context, 127, $this->getSourceContext())->macro_bar_chart(...[(($context["chartPrefix"] ?? null) . "Rate"), ($context["labels"] ?? null), [($context["rates"] ?? null)], ["height" => "300px", "renderEvent" => (("render." . ($context["chartPrefix"] ?? null)) . "Rate")]]);
                yield "
                        </div>
                    </div>
                </div>
            ";
            }
            // line 132
            yield "            <div class=\"chart tab-pane\" id=\"activity-chart-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
            yield "\">
                ";
            // line 133
            yield (string) $this->getTemplateForMacro("macro_activity_tab", $context, 133, $this->getSourceContext())->macro_activity_tab(...[($context["activities"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["yearStat"] ?? null), "duration", [], "any", false, false, false, 133), ($context["currency"] ?? null), ($context["chartPrefix"] ?? null), ($context["view_revenue"] ?? null)]);
            yield "
            </div>
            ";
            // line 135
            if ((($tmp = ($context["see_users"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 136
                yield "            <div class=\"chart tab-pane\" id=\"user-chart-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\">
                ";
                // line 137
                yield (string) $this->getTemplateForMacro("macro_user_tab", $context, 137, $this->getSourceContext())->macro_user_tab(...[($context["year"] ?? null), ($context["users"] ?? null)]);
                yield "
            </div>
            ";
            }
            // line 140
            yield "        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 144
    public function macro_user_tab($year = null, $userYearStats = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "year" => $year,
            "userYearStats" => $userYearStats,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 145
            yield "    <div class=\"row\">
        <div class=\"col-xs-12 table-responsive\">
            <table class=\"table table-hover dataTable\">
                <thead>
                <tr>
                    <th>";
            // line 150
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("username"), "html", null, true);
            yield "</th>
                    <th></th>
                    ";
            // line 152
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable($this->extensions['App\Twig\LocaleFormatExtensions']->getMonthNames());
            foreach ($context['_seq'] as $context["_key"] => $context["monthName"]) {
                // line 153
                yield "                        <th class=\"text-center\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["monthName"], "html", null, true);
                yield "</th>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['monthName'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 155
            yield "                </tr>
                </thead>
                <tbody>
                ";
            // line 158
            $context["yearTotal"] = 0;
            // line 159
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["userYearStats"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "duration", [], "any", false, false, false, 159) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "duration", [], "any", false, false, false, 159)); }));
            foreach ($context['_seq'] as $context["_key"] => $context["userYearStat"]) {
                // line 160
                yield "                    ";
                $context["user"] = CoreExtension::getAttribute($this->env, $this->source, $context["userYearStat"], "user", [], "any", false, false, false, 160);
                // line 161
                yield "                    ";
                $context["userYear"] = CoreExtension::getAttribute($this->env, $this->source, $context["userYearStat"], "year", [], "any", false, false, false, 161);
                // line 162
                yield "                    ";
                $context["userTotal"] = CoreExtension::getAttribute($this->env, $this->source, $context["userYearStat"], "duration", [], "any", false, false, false, 162);
                // line 163
                yield "                    ";
                $context["yearTotal"] = (($context["yearTotal"] ?? null) + ($context["userTotal"] ?? null));
                // line 164
                yield "                    <tr>
                        <td class=\"text-nowrap\">
                            ";
                // line 166
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_dot", $context, 166, $this->getSourceContext())->macro_label_dot(...[CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 166), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 166)]);
                yield "
                        </td>
                        <th class=\"text-nowrap text-center total\">
                            ";
                // line 169
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["userTotal"] ?? null)), "html", null, true);
                yield "
                        </th>
                        ";
                // line 171
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(range(1, 12));
                foreach ($context['_seq'] as $context["_key"] => $context["monthNumber"]) {
                    // line 172
                    yield "                            ";
                    $context["month"] = CoreExtension::getAttribute($this->env, $this->source, ($context["userYear"] ?? null), "getMonth", [$context["monthNumber"]], "method", false, false, false, 172);
                    // line 173
                    yield "                            <td class=\"text-nowrap text-center\">
                                ";
                    // line 174
                    if ( !(null === ($context["month"] ?? null))) {
                        // line 175
                        yield "                                    ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["month"] ?? null), "totalDuration", [], "any", false, false, false, 175)), "html", null, true);
                        yield "
                                ";
                    }
                    // line 177
                    yield "                            </td>
                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['monthNumber'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 179
                yield "                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['userYearStat'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 181
            yield "                </tbody>
                <tfoot>
                <tr class=\"summary\">
                    <td></td>
                    <td class=\"text-nowrap text-center total\">
                        ";
            // line 186
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["yearTotal"] ?? null)), "html", null, true);
            yield "
                    </td>
                    ";
            // line 188
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(range(1, 12));
            foreach ($context['_seq'] as $context["_key"] => $context["monthNumber"]) {
                // line 189
                yield "                        ";
                $context["total"] = 0;
                // line 190
                yield "                        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["userYearStats"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["userYearStat"]) {
                    // line 191
                    yield "                            ";
                    $context["month"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["userYearStat"], "year", [], "any", false, false, false, 191), "getMonth", [$context["monthNumber"]], "method", false, false, false, 191);
                    // line 192
                    yield "                            ";
                    if ( !(null === ($context["month"] ?? null))) {
                        // line 193
                        yield "                                ";
                        $context["total"] = (($context["total"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, ($context["month"] ?? null), "duration", [], "any", false, false, false, 193));
                        // line 194
                        yield "                            ";
                    }
                    // line 195
                    yield "                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['userYearStat'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 196
                yield "                        <td class=\"text-nowrap text-center total\">
                        ";
                // line 197
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["total"] ?? null)), "html", null, true);
                yield "
                        </td>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['monthNumber'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 200
            yield "                </tr>
                </tfoot>
            </table>
        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 214
    public function macro_activity_tab($activities = null, $totalDuration = null, $currency = null, $chartPrefix = null, $view_revenue = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "activities" => $activities,
            "totalDuration" => $totalDuration,
            "currency" => $currency,
            "chartPrefix" => $chartPrefix,
            "view_revenue" => $view_revenue,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 215
            yield "    ";
            $context["dataset"] = [];
            // line 216
            yield "    ";
            $context["labels"] = [];
            // line 217
            yield "    <div class=\"row\">
        <div class=\"col-xs-12 col-sm-9 col-md-8 col-lg-6\">
            <table class=\"table table-hover dataTable\">
                <thead>
                    <tr>
                        <th></th>
                        <th class=\"text-nowrap text-end\">";
            // line 223
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
            yield "</th>
                        ";
            // line 224
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 225
                yield "                        <th class=\"text-nowrap text-end\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
                yield "</th>
                        <th class=\"text-nowrap text-end\">";
                // line 226
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.amountTotal"), "html", null, true);
                yield "</th>
                        ";
            }
            // line 228
            yield "                        <th></th>
                    </tr>
                </thead>
                <tbody>
                ";
            // line 232
            $context["totalRate"] = 0.0;
            // line 233
            yield "                ";
            $context["billable"] = 0;
            // line 234
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["activities"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "duration", [], "any", false, false, false, 234) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "duration", [], "any", false, false, false, 234)); }));
            foreach ($context['_seq'] as $context["_key"] => $context["stat"]) {
                // line 235
                yield "                    ";
                $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "rate", [], "any", false, false, false, 235);
                // line 236
                yield "                    ";
                $context["totalRate"] = (($context["totalRate"] ?? null) + ($context["rate"] ?? null));
                // line 237
                yield "                    ";
                $context["billable"] = (($context["billable"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "rateBillable", [], "any", false, false, false, 237));
                // line 238
                yield "                    ";
                $context["dataset"] = Twig\Extension\CoreExtension::merge(($context["dataset"] ?? null), [["value" => CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "duration", [], "any", false, false, false, 238), "name" => CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "name", [], "any", false, false, false, 238), "color" => $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "activity", [], "any", false, false, false, 238), "color", [], "any", false, false, false, 238), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "activity", [], "any", false, false, false, 238), "name", [], "any", false, false, false, 238)), "duration" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "duration", [], "any", false, false, false, 238)), "rate" => $this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null))]]);
                // line 239
                yield "                    ";
                $context["percentage"] = 0;
                // line 240
                yield "                    ";
                if (((($context["totalDuration"] ?? null) > 0) && (CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "duration", [], "any", false, false, false, 240) > 0))) {
                    // line 241
                    yield "                        ";
                    $context["percentage"] = (100 / (($context["totalDuration"] ?? null) / CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "duration", [], "any", false, false, false, 241)));
                    // line 242
                    yield "                    ";
                }
                // line 243
                yield "                    <tr>
                        <td>";
                // line 244
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 244, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "activity", [], "any", false, false, false, 244), ["inherit" => false, "random" => true]]);
                yield "</td>
                        <td class=\"text-nowrap text-end\">";
                // line 245
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "duration", [], "any", false, false, false, 245)), "html", null, true);
                yield "</td>
                        ";
                // line 246
                if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 247
                    yield "                        <td class=\"text-nowrap text-end\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "rateBillable", [], "any", false, false, false, 247), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                        <td class=\"text-nowrap text-end\">";
                    // line 248
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["stat"], "rate", [], "any", false, false, false, 248), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                        ";
                }
                // line 250
                yield "                        <td class=\"text-nowrap text-end\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentage"] ?? null), 1), "html", null, true);
                yield " %</td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['stat'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 253
            yield "                </tbody>
                <tfoot>
                <tr class=\"summary\">
                    <td></td>
                    <td class=\"text-nowrap text-end\">";
            // line 257
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null)), "html", null, true);
            yield "</td>
                    ";
            // line 258
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 259
                yield "                    <td class=\"text-nowrap text-end\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["billable"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                yield "</td>
                    <td class=\"text-nowrap text-end\">";
                // line 260
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalRate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                yield "</td>
                    ";
            }
            // line 262
            yield "                    <td></td>
                </tr>
                </tfoot>
            </table>
        </div>
        <div class=\"col-xs-12 col-sm-3 col-md-4 col-lg-6\">
            ";
            // line 268
            $context["chartOptions"] = ["height" => (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["dataset"] ?? null)) > 12)) ? ("600px") : ("300px")), "renderEvent" => (("render." . ($context["chartPrefix"] ?? null)) . "Activity")];
            // line 269
            yield "            ";
            yield (string) $macros["charts"]->getTemplateForMacro("macro_doughnut_chart", $context, 269, $this->getSourceContext())->macro_doughnut_chart(...[(($context["chartPrefix"] ?? null) . "Activity"), ($context["labels"] ?? null), ($context["dataset"] ?? null), ($context["chartOptions"] ?? null)]);
            yield "
        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 279
    public function macro_project_details($project = null, $project_view = null, $project_details = null, $showMoneyBudget = null, $showTimeBudget = null, $view_revenue = null, $see_users = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "project" => $project,
            "project_view" => $project_view,
            "project_details" => $project_details,
            "showMoneyBudget" => $showMoneyBudget,
            "showTimeBudget" => $showTimeBudget,
            "view_revenue" => $view_revenue,
            "see_users" => $see_users,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 280
            yield "    ";
            $context["activities"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "activities", [], "any", false, false, false, 280);
            // line 281
            yield "    ";
            $context["years"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "years", [], "any", false, false, false, 281);
            // line 282
            yield "    ";
            $macros["progress"] = $this->load("macros/progressbar.html.twig", 282)->unwrap();
            // line 283
            yield "    ";
            $macros["widgets"] = $this->load("macros/widgets.html.twig", 283)->unwrap();
            // line 284
            yield "    ";
            $macros["charts"] = $this->load("macros/charts.html.twig", 284)->unwrap();
            // line 285
            yield "    ";
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 285), "currency", [], "any", false, false, false, 285);
            // line 286
            yield "    ";
            $context["chartPrefix"] = ("project" . CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 286));
            // line 288
            $context["labels"] = [];
            // line 289
            yield "    ";
            $context["rates"] = [];
            // line 290
            yield "    ";
            $context["durations"] = [];
            // line 291
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["years"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["year"]) {
                // line 292
                yield "        ";
                $context["labels"] = Twig\Extension\CoreExtension::merge(($context["labels"] ?? null), [CoreExtension::getAttribute($this->env, $this->source, $context["year"], "year", [], "any", false, false, false, 292)]);
                // line 293
                yield "        ";
                $context["rates"] = Twig\Extension\CoreExtension::merge(($context["rates"] ?? null), [["label" => $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "rate", [], "any", false, false, false, 293), ($context["currency"] ?? null)), "value" => CoreExtension::getAttribute($this->env, $this->source, $context["year"], "rate", [], "any", false, false, false, 293)]]);
                // line 294
                yield "        ";
                $context["durations"] = Twig\Extension\CoreExtension::merge(($context["durations"] ?? null), [["label" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "duration", [], "any", false, false, false, 294)), "value" => $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, $context["year"], "duration", [], "any", false, false, false, 294))]]);
                // line 295
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['year'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 296
            $context["showTotalDurationChart"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 296) > 0) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["years"] ?? null)) > 1));
            // line 297
            yield "    ";
            $context["showTotalRevenueChart"] = (((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "rateTotal", [], "any", false, false, false, 297) > 0)) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["years"] ?? null)) > 1));
            // line 298
            yield "
    <div class=\"card mb-3\">
        <div class=\"card-header\">
            <h3 class=\"card-title me-3\">
                ";
            // line 302
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 302, $this->getSourceContext())->macro_label_project(...[($context["project"] ?? null), ["inherit" => false]]);
            yield "
            </h3>
            <ul class=\"nav nav-pills\" data-bs-toggle=\"tabs\">
                <li class=\"nav-item\"><a class=\"nav-link active\" href=\"#details-chart\" data-bs-toggle=\"tab\">";
            // line 305
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("report_project_details", [], "reporting"), "html", null, true);
            yield "</a></li>
                ";
            // line 306
            if ((($tmp = ($context["showTotalDurationChart"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 307
                yield "                    <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "Duration\" href=\"#time-chart\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.workingTime"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 309
            yield "                ";
            if ((($tmp = ($context["showTotalRevenueChart"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 310
                yield "                    <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "Rate\" href=\"#revenue-chart\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("revenue"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 312
            yield "                ";
            if (((($tmp = ($context["see_users"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "userStats", [], "any", false, false, false, 312)) > 0))) {
                // line 313
                yield "                    <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "User\" href=\"#user-chart\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 315
            yield "                ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["activities"] ?? null))) {
                // line 316
                yield "                    <li class=\"nav-item\"><a class=\"nav-link\" data-chart=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chartPrefix"] ?? null), "html", null, true);
                yield "Activity\" href=\"#activity-chart\" data-bs-toggle=\"tab\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
                yield "</a></li>
                ";
            }
            // line 318
            yield "            </ul>
            <div class=\"card-actions\">
                ";
            // line 320
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counter", $context, 320, $this->getSourceContext())->macro_badge_counter(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 320))]);
            yield "
                ";
            // line 321
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 322
                yield "                    ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counter", $context, 322, $this->getSourceContext())->macro_badge_counter(...[$this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "rateTotal", [], "any", false, false, false, 322), ($context["currency"] ?? null))]);
                yield "
                ";
            }
            // line 324
            yield "            </div>
        </div>
        <div class=\"tab-content mt-2 p-2 ps-3\">
            <div class=\"chart tab-pane active\" id=\"details-chart\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-sm-6 col-md-7 col-lg-7 col-xl-6 col-xxl-5\">
                        <div class=\"datagrid\" style=\"--tblr-datagrid-item-width: 12rem\">
                            <div class=\"datagrid-item\" ";
            // line 331
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_customer_row_attr", $context, 331, $this->getSourceContext())->macro_customer_row_attr(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 331)]);
            yield ">
                                <div class=\"datagrid-title\">
                                    ";
            // line 333
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
            yield "
                                </div>
                                <div class=\"datagrid-content\">
                                    ";
            // line 336
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 336, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 336)]);
            yield "
                                </div>
                            </div>
                            <div class=\"datagrid-item\" ";
            // line 339
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 339, $this->getSourceContext())->macro_project_row_attr(...[($context["project"] ?? null)]);
            yield ">
                                <div class=\"datagrid-title\">
                                    ";
            // line 341
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
            yield "
                                </div>
                                <div class=\"datagrid-content\">
                                    ";
            // line 344
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 344, $this->getSourceContext())->macro_label_project(...[($context["project"] ?? null)]);
            yield "
                                </div>
                            </div>
                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
            // line 349
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal"), "html", null, true);
            yield "
                                </div>
                                <div class=\"datagrid-content\">";
            // line 351
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 351)), "html", null, true);
            yield "</div>
                            </div>
                            ";
            // line 353
            if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 354
                yield "                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
                // line 356
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.amountTotal"), "html", null, true);
                yield "
                                </div>
                                <div class=\"datagrid-content\">";
                // line 358
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "rateTotal", [], "any", false, false, false, 358), ($context["currency"] ?? null)), "html", null, true);
                yield "</div>
                            </div>
                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
                // line 362
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
                yield "
                                </div>
                                <div class=\"datagrid-content\">";
                // line 364
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "billableRate", [], "any", false, false, false, 364), ($context["currency"] ?? null)), "html", null, true);
                yield "</div>
                            </div>
                            ";
            }
            // line 367
            yield "                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
            // line 369
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("last_record"), "html", null, true);
            yield "
                                </div>
                                <div class=\"datagrid-content\">
                                    ";
            // line 372
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "lastRecord", [], "any", false, false, false, 372))) {
                // line 373
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "lastRecord", [], "any", false, false, false, 373)), "html", null, true);
                yield "
                                    ";
            } else {
                // line 375
                yield "                                        &ndash;
                                    ";
            }
            // line 377
            yield "                                </div>
                            </div>
                            ";
            // line 379
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_export")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 380
                yield "                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
                // line 382
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_exported"), "html", null, true);
                yield "
                                </div>
                                <div class=\"datagrid-content\">
                                    <a href=\"";
                // line 385
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export", ["customers[]" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 385), "id", [], "any", false, false, false, 385), "projects[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 385), "daterange" => "", "preview" => true]), "html", null, true);
                yield "\">
                                        ";
                // line 386
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "notExportedDuration", [], "any", false, false, false, 386)), "html", null, true);
                yield "
                                    </a>
                                </div>
                            </div>
                            ";
            }
            // line 391
            yield "                            ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_invoice")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 392
                yield "                            <div class=\"datagrid-item\">
                                <div class=\"datagrid-title\">
                                    ";
                // line 394
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_invoiced"), "html", null, true);
                yield "
                                </div>
                                <div class=\"datagrid-content\">
                                    <a href=\"";
                // line 397
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice", ["customers[]" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 397), "id", [], "any", false, false, false, 397), "projects[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 397), "daterange" => ""]), "html", null, true);
                yield "\">
                                        ";
                // line 398
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "notExportedRate", [], "any", false, false, false, 398), ($context["currency"] ?? null)), "html", null, true);
                yield "
                                    </a>
                                </div>
                            </div>
                            ";
            }
            // line 403
            yield "                        </div>
                    </div>
                    <div class=\"col-xs-12 col-sm-6 col-md-5 col-lg-5 col-xl-6 col-xxl-7\">
                        ";
            // line 406
            if ((((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 406)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || ((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 406)) && $tmp instanceof Markup ? (string) $tmp : $tmp)))) {
                // line 407
                yield "                            ";
                $macros["_v0"] = $this->load("project/charts.html.twig", 407)->unwrap();
                // line 408
                yield "                            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_project_budget", $context, 408, $this->getSourceContext())->macro_project_budget(...[($context["project"] ?? null), ($context["project_details"] ?? null), ($context["chartPrefix"] ?? null)]);
                yield "
                        ";
            }
            // line 410
            yield "                    </div>
                </div>
                ";
            // line 412
            if ((((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 412)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || ((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 412)) && $tmp instanceof Markup ? (string) $tmp : $tmp)))) {
                // line 413
                yield "                    ";
                $context["budgetStats"] = CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "budgetStatisticModel", [], "any", false, false, false, 413);
                // line 414
                yield "                    <div class=\"row\">
                        <div class=\"col-xs-12\">
                            <table class=\"table table-borderless\">
                                ";
                // line 417
                if (((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasTimeBudget", [], "method", false, false, false, 417)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    // line 418
                    yield "                                    <tr>
                                        <th class=\"w-min\">
                                            ";
                    // line 420
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget"), "html", null, true);
                    yield "
                                            ";
                    // line 421
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStats"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 421)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 422
                        yield "                                                (";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
                        yield ")
                                            ";
                    }
                    // line 424
                    yield "                                        </th>
                                        <td>
                                            ";
                    // line 426
                    yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_timebudget", $context, 426, $this->getSourceContext())->macro_progressbar_timebudget(...[($context["budgetStats"] ?? null)]);
                    yield "
                                        </td>
                                    </tr>
                                ";
                }
                // line 430
                yield "                                ";
                if (((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 430)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                    // line 431
                    yield "                                    <tr>
                                        <th class=\"w-min\">
                                            ";
                    // line 433
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget"), "html", null, true);
                    yield "
                                            ";
                    // line 434
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStats"] ?? null), "isMonthlyBudget", [], "method", false, false, false, 434)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 435
                        yield "                                                (";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budgetType_month"), "html", null, true);
                        yield ")
                                            ";
                    }
                    // line 437
                    yield "                                        </th>
                                        <td>
                                            ";
                    // line 439
                    yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_budget", $context, 439, $this->getSourceContext())->macro_progressbar_budget(...[($context["budgetStats"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 439), "currency", [], "any", false, false, false, 439)]);
                    yield "
                                        </td>
                                    </tr>
                                ";
                }
                // line 443
                yield "                            </table>
                        </div>
                    </div>
                ";
            }
            // line 447
            yield "
            </div>
            ";
            // line 449
            if ((($tmp = ($context["showTotalDurationChart"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 450
                yield "            <div class=\"chart tab-pane\" id=\"time-chart\">
                ";
                // line 451
                yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_chart", $context, 451, $this->getSourceContext())->macro_bar_chart(...[(($context["chartPrefix"] ?? null) . "Duration"), ($context["labels"] ?? null), [($context["durations"] ?? null)], ["height" => "300px", "renderEvent" => (("render." . ($context["chartPrefix"] ?? null)) . "Duration")]]);
                yield "
            </div>
            ";
                // line 453
                if ((($tmp = ($context["showTotalRevenueChart"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 454
                    yield "            <div class=\"chart tab-pane\" id=\"revenue-chart\">
                ";
                    // line 455
                    yield (string) $macros["charts"]->getTemplateForMacro("macro_bar_chart", $context, 455, $this->getSourceContext())->macro_bar_chart(...[(($context["chartPrefix"] ?? null) . "Rate"), ($context["labels"] ?? null), [($context["rates"] ?? null)], ["height" => "300px", "renderEvent" => (("render." . ($context["chartPrefix"] ?? null)) . "Rate")]]);
                    yield "
            </div>
            ";
                }
                // line 458
                yield "            ";
            }
            // line 459
            yield "            ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["activities"] ?? null))) {
                // line 460
                yield "            <div class=\"chart tab-pane\" id=\"activity-chart\">
                ";
                // line 461
                yield (string) $this->getTemplateForMacro("macro_activity_tab", $context, 461, $this->getSourceContext())->macro_activity_tab(...[($context["activities"] ?? null), CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 461), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 461), "currency", [], "any", false, false, false, 461), ($context["chartPrefix"] ?? null), ($context["view_revenue"] ?? null)]);
                yield "
            </div>
            ";
            }
            // line 464
            yield "            ";
            if (((($tmp = ($context["see_users"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "userStats", [], "any", false, false, false, 464)) > 0))) {
                // line 465
                yield "            <div class=\"chart tab-pane\" id=\"user-chart\">
                <div class=\"row\">
                    <div class=\"col-xs-12 col-sm-9 col-md-8 col-lg-6\">
                        <table class=\"table table-hover dataTable\">
                            <thead>
                            <tr>
                                <th></th>
                                <th class=\"text-nowrap text-end\">";
                // line 472
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
                yield "</th>
                                ";
                // line 473
                if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 474
                    yield "                                <th class=\"text-nowrap text-end\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
                    yield "</th>
                                <th class=\"text-nowrap text-end\">";
                    // line 475
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.amountTotal"), "html", null, true);
                    yield "</th>
                                ";
                }
                // line 477
                yield "                                <th></th>
                            </tr>
                            </thead>
                            <tbody>
                            ";
                // line 481
                $context["rateTotal"] = 0;
                // line 482
                yield "                            ";
                $context["rateTotalBillable"] = 0;
                // line 483
                yield "                            ";
                $context["totalDuration"] = 0;
                // line 484
                yield "                            ";
                $context["datasets"] = [];
                // line 485
                yield "                            ";
                $context["labels"] = [];
                // line 486
                yield "                            ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["project_details"] ?? null), "userStats", [], "any", false, false, false, 486), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "duration", [], "any", false, false, false, 486) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "duration", [], "any", false, false, false, 486)); }));
                foreach ($context['_seq'] as $context["_key"] => $context["userStat"]) {
                    // line 487
                    yield "                                ";
                    $context["user"] = CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "user", [], "any", false, false, false, 487);
                    // line 488
                    yield "                                ";
                    $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 488), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 488));
                    // line 489
                    yield "                                ";
                    $context["rateTotal"] = (($context["rateTotal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "rate", [], "any", false, false, false, 489));
                    // line 490
                    yield "                                ";
                    $context["rateTotalBillable"] = (($context["rateTotalBillable"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "rateBillable", [], "any", false, false, false, 490));
                    // line 491
                    yield "                                ";
                    $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 491));
                    // line 492
                    yield "                                ";
                    $context["datasets"] = Twig\Extension\CoreExtension::merge(($context["datasets"] ?? null), [["name" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 492), "duration" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 492)), "value" => CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 492), "color" => ($context["color"] ?? null), "rate" => $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "rate", [], "any", false, false, false, 492), ($context["currency"] ?? null))]]);
                    // line 493
                    yield "                                ";
                    $context["percentage"] = 0;
                    // line 494
                    yield "                                ";
                    if (((CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 494) > 0) && (CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 494) > 0))) {
                        // line 495
                        yield "                                    ";
                        $context["percentage"] = (100 / (CoreExtension::getAttribute($this->env, $this->source, ($context["project_view"] ?? null), "durationTotal", [], "any", false, false, false, 495) / CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 495)));
                        // line 496
                        yield "                                ";
                    }
                    // line 497
                    yield "                                <tr>
                                    <td>
                                        ";
                    // line 499
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_dot", $context, 499, $this->getSourceContext())->macro_label_dot(...[CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 499), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 499)]);
                    yield "
                                    </th>
                                    <td class=\"text-nowrap text-end\">
                                        ";
                    // line 502
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "duration", [], "any", false, false, false, 502)), "html", null, true);
                    yield "
                                    </td>
                                    ";
                    // line 504
                    if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 505
                        yield "                                    <td class=\"text-nowrap text-end\">
                                        ";
                        // line 506
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "rateBillable", [], "any", false, false, false, 506), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                                    </td>
                                    <td class=\"text-nowrap text-end\">
                                        ";
                        // line 509
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["userStat"], "rate", [], "any", false, false, false, 509), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                                    </td>
                                    ";
                    }
                    // line 512
                    yield "                                    <td class=\"text-nowrap text-end\">
                                        ";
                    // line 513
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber(($context["percentage"] ?? null), 1), "html", null, true);
                    yield " %
                                    </td>
                                </tr>
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['userStat'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 517
                yield "                            </tbody>
                            <tfoot>
                                <tr class=\"summary\">
                                    <td></td>
                                    <td class=\"text-nowrap text-end total\">";
                // line 521
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null)), "html", null, true);
                yield "</td>
                                    ";
                // line 522
                if ((($tmp = ($context["view_revenue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 523
                    yield "                                    <td class=\"text-nowrap text-end total\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateTotalBillable"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                                    <td class=\"text-nowrap text-end total\">";
                    // line 524
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateTotal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                                    ";
                }
                // line 526
                yield "                                    <td></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class=\"col-xs-12 col-sm-3 col-md-4 col-lg-6\">
                        ";
                // line 532
                $context["chartOptions"] = ["height" => (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["datasets"] ?? null)) > 12)) ? ("600px") : ("300px")), "renderEvent" => (("render." . ($context["chartPrefix"] ?? null)) . "User")];
                // line 533
                yield "                        ";
                yield (string) $macros["charts"]->getTemplateForMacro("macro_doughnut_chart", $context, 533, $this->getSourceContext())->macro_doughnut_chart(...[(($context["chartPrefix"] ?? null) . "User"), ($context["labels"] ?? null), ($context["datasets"] ?? null), ($context["chartOptions"] ?? null)]);
                yield "
                    </div>
                </div>
            </div>
            ";
            }
            // line 538
            yield "        </div>
    </div>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project_details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1400 => 538,  1391 => 533,  1389 => 532,  1381 => 526,  1376 => 524,  1371 => 523,  1369 => 522,  1365 => 521,  1359 => 517,  1348 => 513,  1345 => 512,  1339 => 509,  1333 => 506,  1330 => 505,  1328 => 504,  1323 => 502,  1317 => 499,  1313 => 497,  1310 => 496,  1307 => 495,  1304 => 494,  1301 => 493,  1298 => 492,  1295 => 491,  1292 => 490,  1289 => 489,  1286 => 488,  1283 => 487,  1278 => 486,  1275 => 485,  1272 => 484,  1269 => 483,  1266 => 482,  1264 => 481,  1258 => 477,  1253 => 475,  1248 => 474,  1246 => 473,  1242 => 472,  1233 => 465,  1230 => 464,  1224 => 461,  1221 => 460,  1218 => 459,  1215 => 458,  1209 => 455,  1206 => 454,  1204 => 453,  1199 => 451,  1196 => 450,  1194 => 449,  1190 => 447,  1184 => 443,  1177 => 439,  1173 => 437,  1167 => 435,  1165 => 434,  1161 => 433,  1157 => 431,  1154 => 430,  1147 => 426,  1143 => 424,  1137 => 422,  1135 => 421,  1131 => 420,  1127 => 418,  1125 => 417,  1120 => 414,  1117 => 413,  1115 => 412,  1111 => 410,  1105 => 408,  1102 => 407,  1100 => 406,  1095 => 403,  1087 => 398,  1083 => 397,  1077 => 394,  1073 => 392,  1070 => 391,  1062 => 386,  1058 => 385,  1052 => 382,  1048 => 380,  1046 => 379,  1042 => 377,  1038 => 375,  1032 => 373,  1030 => 372,  1024 => 369,  1020 => 367,  1014 => 364,  1009 => 362,  1002 => 358,  997 => 356,  993 => 354,  991 => 353,  986 => 351,  981 => 349,  973 => 344,  967 => 341,  962 => 339,  956 => 336,  950 => 333,  945 => 331,  936 => 324,  930 => 322,  928 => 321,  924 => 320,  920 => 318,  912 => 316,  909 => 315,  901 => 313,  898 => 312,  890 => 310,  887 => 309,  879 => 307,  877 => 306,  873 => 305,  867 => 302,  861 => 298,  858 => 297,  856 => 296,  849 => 295,  846 => 294,  843 => 293,  840 => 292,  835 => 291,  832 => 290,  829 => 289,  827 => 288,  824 => 286,  821 => 285,  818 => 284,  815 => 283,  812 => 282,  809 => 281,  806 => 280,  788 => 279,  777 => 269,  775 => 268,  767 => 262,  762 => 260,  757 => 259,  755 => 258,  751 => 257,  745 => 253,  734 => 250,  729 => 248,  724 => 247,  722 => 246,  718 => 245,  714 => 244,  711 => 243,  708 => 242,  705 => 241,  702 => 240,  699 => 239,  696 => 238,  693 => 237,  690 => 236,  687 => 235,  682 => 234,  679 => 233,  677 => 232,  671 => 228,  666 => 226,  661 => 225,  659 => 224,  655 => 223,  647 => 217,  644 => 216,  641 => 215,  625 => 214,  614 => 200,  604 => 197,  601 => 196,  594 => 195,  591 => 194,  588 => 193,  585 => 192,  582 => 191,  577 => 190,  574 => 189,  570 => 188,  565 => 186,  558 => 181,  550 => 179,  542 => 177,  536 => 175,  534 => 174,  531 => 173,  528 => 172,  524 => 171,  519 => 169,  513 => 166,  509 => 164,  506 => 163,  503 => 162,  500 => 161,  497 => 160,  492 => 159,  490 => 158,  485 => 155,  475 => 153,  471 => 152,  466 => 150,  459 => 145,  446 => 144,  438 => 140,  432 => 137,  427 => 136,  425 => 135,  420 => 133,  415 => 132,  407 => 127,  400 => 124,  398 => 123,  391 => 119,  385 => 116,  380 => 113,  374 => 111,  372 => 110,  368 => 109,  357 => 106,  347 => 104,  344 => 103,  334 => 101,  332 => 100,  324 => 99,  318 => 96,  313 => 93,  306 => 91,  303 => 90,  300 => 89,  297 => 88,  294 => 87,  291 => 86,  288 => 85,  285 => 84,  282 => 83,  279 => 82,  274 => 81,  271 => 80,  268 => 79,  265 => 78,  244 => 77,  238 => 74,  228 => 72,  225 => 71,  221 => 70,  219 => 68,  214 => 67,  208 => 65,  206 => 64,  203 => 63,  200 => 62,  193 => 61,  185 => 58,  178 => 57,  156 => 38,  150 => 36,  148 => 35,  139 => 29,  134 => 28,  131 => 27,  128 => 26,  125 => 25,  123 => 24,  118 => 23,  111 => 22,  104 => 19,  99 => 18,  92 => 17,  85 => 14,  80 => 13,  73 => 12,  68 => 1,  66 => 10,  64 => 9,  62 => 8,  60 => 7,  58 => 6,  56 => 5,  54 => 3,  52 => 2,  45 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project_details.html.twig", "/opt/kimai/templates/reporting/project_details.html.twig");
    }
}
