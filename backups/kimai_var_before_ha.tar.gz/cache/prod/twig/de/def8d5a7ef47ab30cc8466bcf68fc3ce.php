<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-counter-money.html.twig */
class __TwigTemplate_81f40e9c943ba0bb22ff9166649b8410 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'widget_data' => [$this, 'block_widget_data'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "widget/widget-counter.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("widget/widget-counter.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_widget_data(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        if (Twig\Extension\CoreExtension::testEmpty(($context["data"] ?? null))) {
            // line 5
            yield "        ";
            $context["data"] = [null => 0.0];
            // line 6
            yield "    ";
        }
        // line 7
        yield "    ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["data"] ?? null)) > 1)) {
            // line 8
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["currency"] => $context["revenue"]) {
                // line 9
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 9, $this->getSourceContext())->macro_label(...[$this->extensions['App\Twig\LocaleFormatExtensions']->money($context["revenue"], ((true) ? (Twig\Extension\CoreExtension::default($context["currency"], ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", true, true, false, 9)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", false, false, false, 9), null)) : (null)))) : (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", true, true, false, 9)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", false, false, false, 9), null)) : (null))))), CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 9)]);
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['currency'], $context['revenue'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 11
            yield "    ";
        } else {
            // line 12
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
            foreach ($context['_seq'] as $context["currency"] => $context["revenue"]) {
                // line 13
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money($context["revenue"], ((true) ? (Twig\Extension\CoreExtension::default($context["currency"], ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", true, true, false, 13)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", false, false, false, 13), null)) : (null)))) : (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", true, true, false, 13)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "currency", [], "any", false, false, false, 13), null)) : (null))))), "html", null, true);
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['currency'], $context['revenue'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 15
            yield "    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-counter-money.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  107 => 15,  97 => 13,  92 => 12,  89 => 11,  79 => 9,  74 => 8,  71 => 7,  68 => 6,  65 => 5,  62 => 4,  55 => 3,  50 => 1,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-counter-money.html.twig", "/opt/kimai/templates/widget/widget-counter-money.html.twig");
    }
}
