<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* contract/status.html.twig */
class __TwigTemplate_91ab7e4f742bfa695c446f2db3f11449 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_addon' => [$this, 'block_form_addon'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "page_setup.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("page_setup.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_addon(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 5), "contract_links", "index", ["year" => ($context["year"] ?? null), "user" => ($context["user"] ?? null)]);
        // line 6
        yield "    ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_actions", $context, 6, $this->getSourceContext())->macro_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 6), ["button_class" => "", "large" => false]]);
        yield "
";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "
    ";
        // line 11
        if ( !(($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 12
            yield "        ";
            $context["warningMsg"] = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
                // line 13
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times_should.none_configured"), "html", null, true);
                yield "
            ";
                // line 14
                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("contract", ($context["user"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 15
                    yield "                <a href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_profile_contract", ["username" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "getUserIdentifier", [], "method", false, false, false, 15)]), "html", null, true);
                    yield "\" class=\"alert-link\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"), "html", null, true);
                    yield "</a>
            ";
                }
                // line 17
                yield "        ";
                yield from [];
            })())) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 18
            yield "        ";
            $macros["_v0"] = $this->load("@theme/components/alert.html.twig", 18)->unwrap();
            // line 19
            yield "        ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 19, $this->getSourceContext())->macro_alert(...[["type" => "info", "description" => ($context["warningMsg"] ?? null), "important" => true]]);
            yield "
    ";
        }
        // line 21
        yield "
    ";
        // line 22
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["summaries"] ?? null)) > 0)) {
            // line 23
            yield "        ";
            yield from $this->load("contract/status.html.twig", 23, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
            // line 91
            yield "    ";
        }
        // line 92
        yield "
    ";
        // line 93
        if (array_key_exists("year", $context)) {
            // line 94
            yield "        ";
            yield from $this->load("contract/status.html.twig", 94, 2)->unwrap()->yield(CoreExtension::merge($context, ["id" => "working_time_detail_box", "border" => false, "item" => ["options" => ["bodyExtraClass" => "border-top", "open" => true], "bodyClasses" => "p-0 table-responsive"]]));
            // line 230
            yield "    ";
        }
        // line 231
        yield "
    ";
        // line 232
        if ((($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 233
            yield "        ";
            $context["expectedWeekTimes"] = 0;
            // line 234
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["days"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
                // line 235
                yield "            ";
                $context["expectedWeekTimes"] = (($context["expectedWeekTimes"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["day"], "duration", [], "any", false, false, false, 235));
                // line 236
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 237
            yield "
        ";
            // line 238
            yield from $this->load("contract/status.html.twig", 238, 3)->unwrap()->yield(CoreExtension::merge($context, ["id" => "work_contract_should_preview", "border" => false, "item" => ["options" => ["bodyExtraClass" => "border-top"]]]));
            // line 262
            yield "    ";
        }
        // line 263
        yield "
    ";
        // line 264
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["boxes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["controller"]) {
            // line 265
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller($context["controller"], ["year" => ($context["year"] ?? null), "boxConfiguration" => ($context["box_configuration"] ?? null)]));
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['controller'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 267
        yield "
";
        yield from [];
    }

    // line 270
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 271
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        function toggleDays()
        {
            document.querySelectorAll(\x27table#working_times_details .contractDay\x27).forEach(
                element => {
                    element.classList.toggle(\x27d-none\x27);
                }
            );
            const icon = document.querySelector(\x27#toggleDaysIcon i\x27);
            icon.classList.toggle(\x27fa-eye\x27);
            icon.classList.toggle(\x27fa-eye-slash\x27);
        }

        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.workingTimesUpdate\x27, true);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  201 => 271,  194 => 270,  188 => 267,  178 => 265,  174 => 264,  171 => 263,  168 => 262,  166 => 238,  163 => 237,  156 => 236,  153 => 235,  148 => 234,  145 => 233,  143 => 232,  140 => 231,  137 => 230,  134 => 94,  132 => 93,  129 => 92,  126 => 91,  123 => 23,  121 => 22,  118 => 21,  112 => 19,  109 => 18,  105 => 17,  97 => 15,  95 => 14,  90 => 13,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "contract/status.html.twig", "/opt/kimai/templates/contract/status.html.twig");
    }
}


/* contract/status.html.twig */
class __TwigTemplate_91ab7e4f742bfa695c446f2db3f11449___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body_classes' => [$this, 'block_box_body_classes'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 23
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        $macros["_v1"] = $this->macros["_v1"] = $this->load("macros/status.html.twig", 24)->unwrap();
        // line 25
        $macros["_v2"] = $this->macros["_v2"] = $this->load("macros/widgets.html.twig", 25)->unwrap();
        // line 23
        $this->parent = $this->load("@theme/embeds/card.html.twig", 23);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
        yield "
                ";
        // line 28
        yield (string) $macros["_v1"]->getTemplateForMacro("macro_status_duration", $context, 28, $this->getSourceContext())->macro_status_duration(...[$macros["_v2"]->getTemplateForMacro("macro_work_times_result", $context, 28, $this->getSourceContext())->macro_work_times_result(...[CoreExtension::getAttribute($this->env, $this->source, ($context["summaries"] ?? null), "expectedTime", [], "any", false, false, false, 28), CoreExtension::getAttribute($this->env, $this->source, ($context["summaries"] ?? null), "actualTime", [], "any", false, false, false, 28), ($context["decimal"] ?? null)])]);
        yield "
            ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "card-table table-responsive";
        yield from [];
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 32
        yield "                <table class=\"table table-vcenter table-hover dataTable\">
                    <thead>
                    <tr>
                        <th></th>
                        <th class=\"text-end total\">";
        // line 36
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
        yield "</th>
                        ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["year"] ?? null), "months", [], "any", false, false, false, 37));
        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
            // line 38
            yield "                            <th class=\"text-end\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 38)), "html", null, true);
            yield "</th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 40
        yield "                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 43
        $context["monthTotalShould"] = ["_01" => 0, "_02" => 0, "_03" => 0, "_04" => 0, "_05" => 0, "_06" => 0, "_07" => 0, "_08" => 0, "_09" => 0, "_10" => 0, "_11" => 0, "_12" => 0];
        // line 44
        yield "                    ";
        $context["monthTotalIs"] = ["_01" => 0, "_02" => 0, "_03" => 0, "_04" => 0, "_05" => 0, "_06" => 0, "_07" => 0, "_08" => 0, "_09" => 0, "_10" => 0, "_11" => 0, "_12" => 0];
        // line 45
        yield "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["summaries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["summary"]) {
            // line 46
            yield "                        <tr>
                            <td>";
            // line 47
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "title", [], "any", false, false, false, 47)), "html", null, true);
            yield "</td>
                            <td class=\"text-end total\">
                                ";
            // line 49
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "expectedTime", [], "any", false, false, false, 49) > 0)) {
                // line 50
                yield "                                    ";
                yield (string) $macros["_v2"]->getTemplateForMacro("macro_work_times_result", $context, 50, $this->getSourceContext())->macro_work_times_result(...[CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "expectedTime", [], "any", false, false, false, 50), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "actualTime", [], "any", false, false, false, 50), ($context["decimal"] ?? null)]);
                yield "
                                ";
            } else {
                // line 52
                yield "                                    ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "actualTime", [], "any", false, false, false, 52), ($context["decimal"] ?? null)), "html", null, true);
                yield "
                                ";
            }
            // line 54
            yield "                            </td>
                            ";
            // line 55
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "months", [], "any", false, false, false, 55));
            foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
                // line 56
                yield "                                ";
                $context["monthShould"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "expectedTime", [], "any", false, false, false, 56);
                // line 57
                yield "                                ";
                $context["monthIs"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "actualTime", [], "any", false, false, false, 57);
                // line 58
                yield "                                ";
                $context["dateKey"] = ("_" . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 58), "format", ["m"], "method", false, false, false, 58));
                // line 59
                yield "                                ";
                $context["monthTotalShouldTmp"] = ((($_v3 = ($context["monthTotalShould"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[(($_v4 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v4 : $_v4)] ?? null) : null) + ($context["monthShould"] ?? null));
                // line 60
                yield "                                ";
                $context["monthTotalIsTmp"] = ((($_v5 = ($context["monthTotalIs"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5[(($_v6 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v6 : $_v6)] ?? null) : null) + ($context["monthIs"] ?? null));
                // line 61
                yield "                                ";
                $context["monthTotalShould"] = Twig\Extension\CoreExtension::merge(($context["monthTotalShould"] ?? null), [ (string)($context["dateKey"] ?? null) => ($context["monthTotalShouldTmp"] ?? null)]);
                // line 62
                yield "                                ";
                $context["monthTotalIs"] = Twig\Extension\CoreExtension::merge(($context["monthTotalIs"] ?? null), [ (string)($context["dateKey"] ?? null) => ($context["monthTotalIsTmp"] ?? null)]);
                // line 63
                yield "                                <td class=\"text-end\">
                                    ";
                // line 64
                if (((($context["now"] ?? null) < CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 64)) && (($context["monthShould"] ?? null) > 0))) {
                    // line 65
                    yield "                                        ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["monthShould"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                    yield "
                                    ";
                } else {
                    // line 67
                    yield "                                        ";
                    yield (string) $macros["_v2"]->getTemplateForMacro("macro_work_times_result", $context, 67, $this->getSourceContext())->macro_work_times_result(...[($context["monthShould"] ?? null), ($context["monthIs"] ?? null), ($context["decimal"] ?? null)]);
                    yield "
                                    ";
                }
                // line 69
                yield "                                </td>
                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 71
            yield "                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['summary'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 73
        yield "                    </tbody>
                    <tfoot>
                        <tr class=\"summary\">
                            <td>";
        // line 76
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
        yield "</td>
                            <td class=\"text-end total\">
                                ";
        // line 78
        yield (string) $macros["_v2"]->getTemplateForMacro("macro_work_times_result", $context, 78, $this->getSourceContext())->macro_work_times_result(...[CoreExtension::getAttribute($this->env, $this->source, ($context["summaries"] ?? null), "expectedTime", [], "any", false, false, false, 78), CoreExtension::getAttribute($this->env, $this->source, ($context["summaries"] ?? null), "actualTime", [], "any", false, false, false, 78), ($context["decimal"] ?? null)]);
        yield "
                            </td>
                            ";
        // line 80
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["year"] ?? null), "months", [], "any", false, false, false, 80));
        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
            // line 81
            yield "                                ";
            $context["dateKey"] = ("_" . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 81), "format", ["m"], "method", false, false, false, 81));
            // line 82
            yield "                                <td class=\"text-end\">
                                    ";
            // line 83
            yield (string) $macros["_v2"]->getTemplateForMacro("macro_work_times_result", $context, 83, $this->getSourceContext())->macro_work_times_result(...[(($_v7 = ($context["monthTotalShould"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7[(($_v8 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v8 : $_v8)] ?? null) : null), (($_v9 = ($context["monthTotalIs"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9[(($_v10 = ($context["dateKey"] ?? null)) instanceof \Stringable ? (string) $_v10 : $_v10)] ?? null) : null), ($context["decimal"] ?? null)]);
            yield "
                                </td>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 86
        yield "                        </tr>
                    </tfoot>
                </table>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  491 => 86,  481 => 83,  478 => 82,  475 => 81,  471 => 80,  466 => 78,  461 => 76,  456 => 73,  448 => 71,  440 => 69,  434 => 67,  428 => 65,  426 => 64,  423 => 63,  420 => 62,  417 => 61,  414 => 60,  411 => 59,  408 => 58,  405 => 57,  402 => 56,  398 => 55,  395 => 54,  389 => 52,  383 => 50,  381 => 49,  376 => 47,  373 => 46,  368 => 45,  365 => 44,  363 => 43,  358 => 40,  348 => 38,  344 => 37,  340 => 36,  334 => 32,  327 => 31,  316 => 30,  309 => 28,  304 => 27,  297 => 26,  292 => 23,  290 => 25,  288 => 24,  281 => 23,  201 => 271,  194 => 270,  188 => 267,  178 => 265,  174 => 264,  171 => 263,  168 => 262,  166 => 238,  163 => 237,  156 => 236,  153 => 235,  148 => 234,  145 => 233,  143 => 232,  140 => 231,  137 => 230,  134 => 94,  132 => 93,  129 => 92,  126 => 91,  123 => 23,  121 => 22,  118 => 21,  112 => 19,  109 => 18,  105 => 17,  97 => 15,  95 => 14,  90 => 13,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "contract/status.html.twig", "/opt/kimai/templates/contract/status.html.twig");
    }
}


/* contract/status.html.twig */
class __TwigTemplate_91ab7e4f742bfa695c446f2db3f11449___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 94
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 95
        $context["yearShould"] = 0;
        // line 96
        $context["yearIs"] = 0;
        // line 97
        $context["approved"] = 0;
        // line 98
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["year"] ?? null), "months", [], "any", false, false, false, 98));
        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
            // line 99
            yield "                ";
            $context["monthShould"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "expectedTime", [($context["now"] ?? null)], "method", false, false, false, 99);
            // line 100
            yield "                ";
            $context["monthIs"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "actualTime", [], "any", false, false, false, 100);
            // line 101
            yield "                ";
            $context["yearShould"] = (($context["yearShould"] ?? null) + ($context["monthShould"] ?? null));
            // line 102
            yield "                ";
            $context["yearIs"] = (($context["yearIs"] ?? null) + ($context["monthIs"] ?? null));
            // line 103
            yield "                ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "locked", [], "any", false, false, false, 103)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 104
                yield "                    ";
                $context["approved"] = (($context["approved"] ?? null) + 1);
                // line 105
                yield "                ";
            }
            // line 106
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 107
        $macros["_v11"] = $this->macros["_v11"] = $this->load("macros/widgets.html.twig", 107)->unwrap();
        // line 108
        $macros["_v12"] = $this->macros["_v12"] = $this->load("macros/status.html.twig", 108)->unwrap();
        // line 94
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 94);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 109
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 110
        yield "                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times"), "html", null, true);
        yield "
                ";
        // line 111
        if ((($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 112
            yield "                    &nbsp;
                    ";
            // line 113
            yield (string) $macros["_v12"]->getTemplateForMacro("macro_status_count", $context, 113, $this->getSourceContext())->macro_status_count(...[((($context["approved"] ?? null) . "/") . Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["year"] ?? null), "months", [], "any", false, false, false, 113)))]);
            yield "
                ";
        }
        // line 115
        yield "            ";
        yield from [];
    }

    // line 116
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 117
        yield "                <table id=\"working_times_details\" class=\"table table-vcenter table-hover dataTable\">
                    <thead>
                    <tr>
                        ";
        // line 120
        if ((($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 121
            yield "                        <th></th>
                        ";
        }
        // line 123
        yield "                        <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("month"), "html", null, true);
        yield "</th>
                        <th class=\"text-end total\">";
        // line 124
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
        yield "</th>
                        <th class=\"text-end hw-min\">";
        // line 125
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times_should"), "html", null, true);
        yield "</th>
                        <th class=\"text-end hw-min\">";
        // line 126
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times_is"), "html", null, true);
        yield "</th>
                        ";
        // line 127
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(range(1, 31));
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 128
            yield "                        <th class=\"text-end contractDay\">";
            if (($context["day"] < 10)) {
                yield "0";
            }
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["day"], "html", null, true);
            yield "</th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 130
        yield "                        <th class=\"actions\"></th>
                    </tr>
                    </thead>
                    <tbody>
                    ";
        // line 134
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["year"] ?? null), "months", [], "any", false, false, false, 134));
        foreach ($context['_seq'] as $context["_key"] => $context["month"]) {
            // line 135
            yield "                        ";
            $context["monthShould"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "expectedTime", [($context["now"] ?? null)], "method", false, false, false, 135);
            // line 136
            yield "                        ";
            $context["monthIs"] = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "actualTime", [], "any", false, false, false, 136);
            // line 137
            yield "                        <tr>
                            ";
            // line 138
            if ((($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 139
                yield "                            <td class=\"w-min\">
                                ";
                // line 140
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["month"], "locked", [], "any", false, false, false, 140)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 141
                    yield "                                    <i class=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("locked"), "html", null, true);
                    yield "\" data-toggle=\"tooltip\" title=\"";
                    if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["month"], "lockedBy", [], "any", false, false, false, 141))) {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["month"], "lockedBy", [], "any", false, false, false, 141), "displayName", [], "any", false, false, false, 141), "html", null, true);
                    } else {
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("deleted"), "html", null, true);
                    }
                    yield ": ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "lockDate", [], "any", false, false, false, 141)), "html", null, true);
                    yield "\"></i>
                                ";
                } else {
                    // line 143
                    yield "                                    <i class=\"bg-yellow-lt ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("unlocked"), "html", null, true);
                    yield "\"></i>
                                ";
                }
                // line 145
                yield "                            </td>
                            ";
            }
            // line 147
            yield "                            <td class=\"text-nowrap w-min\">
                                ";
            // line 148
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "month", [], "any", false, false, false, 148)), "html", null, true);
            yield "
                            </td>
                            <td class=\"text-end total w-min\">
                                ";
            // line 151
            yield (string) $macros["_v11"]->getTemplateForMacro("macro_work_times_result", $context, 151, $this->getSourceContext())->macro_work_times_result(...[($context["monthShould"] ?? null), ($context["monthIs"] ?? null), ($context["decimal"] ?? null)]);
            yield "
                            </td>
                            <td class=\"text-end w-min\">
                                ";
            // line 154
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["monthShould"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                            </td>
                            <td class=\"text-end  w-min\">
                                ";
            // line 157
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["monthIs"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
            yield "
                            </td>
                            ";
            // line 159
            $context["dayCount"] = 0;
            // line 160
            yield "                            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["month"], "days", [], "any", false, false, false, 160));
            foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
                // line 161
                yield "                                ";
                $context["style"] = null;
                // line 162
                yield "                                ";
                if ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 162), "expectedTime", [], "any", false, false, false, 162) > 0) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 162), "actualTime", [], "any", false, false, false, 162) == 0)) && (($context["now"] ?? null) > CoreExtension::getAttribute($this->env, $this->source, $context["day"], "day", [], "any", false, false, false, 162)))) {
                    // line 163
                    yield "                                    ";
                    $context["style"] = "missing";
                    // line 164
                    yield "                                ";
                } elseif ((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 164), "expectedTime", [], "any", false, false, false, 164) == 0) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 164), "actualTime", [], "any", false, false, false, 164) > 0)) && (($context["now"] ?? null) > CoreExtension::getAttribute($this->env, $this->source, $context["day"], "day", [], "any", false, false, false, 164)))) {
                    // line 165
                    yield "                                    ";
                    $context["style"] = "unexpected";
                    // line 166
                    yield "                                ";
                }
                // line 167
                yield "                                ";
                $context["statusTitle"] = null;
                // line 168
                yield "                                ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["day"], "hasAddons", [], "method", false, false, false, 168)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 169
                    yield "                                    ";
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "getAddons", [], "method", false, false, false, 169));
                    $context['loop'] = [
                      'parent' => $context['_parent'],
                      'index0' => 0,
                      'index'  => 1,
                      'first'  => true,
                    ];
                    if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                        $length = count($context['_seq']);
                        $context['loop']['revindex0'] = $length - 1;
                        $context['loop']['revindex'] = $length;
                        $context['loop']['length'] = $length;
                        $context['loop']['last'] = 1 === $length;
                    }
                    foreach ($context['_seq'] as $context["_key"] => $context["addon"]) {
                        // line 170
                        yield "                                        ";
                        $context["style"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "type", [], "any", true, true, false, 170) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "type", [], "any", false, false, false, 170)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "type", [], "any", false, false, false, 170)) : (($context["style"] ?? null)));
                        // line 171
                        yield "                                        ";
                        $context["statusTitle"] = ((((array_key_exists("statusTitle", $context) &&  !(null === $context["statusTitle"]))) ? ($context["statusTitle"]) : ("")) . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "title", [], "any", false, false, false, 171)));
                        // line 172
                        yield "                                        ";
                        if ((CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "visibleDuration", [], "any", false, false, false, 172) > 0)) {
                            // line 173
                            yield "                                            ";
                            $context["statusTitle"] = (((($context["statusTitle"] ?? null) . " (") . $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["addon"], "visibleDuration", [], "any", false, false, false, 173), ($context["decimal"] ?? null))) . ")");
                            // line 174
                            yield "                                        ";
                        }
                        // line 175
                        yield "                                        ";
                        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 175)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 176
                            yield "                                            ";
                            $context["statusTitle"] = (($context["statusTitle"] ?? null) . ", ");
                            // line 177
                            yield "                                        ";
                        }
                        // line 178
                        yield "                                    ";
                        ++$context['loop']['index0'];
                        ++$context['loop']['index'];
                        $context['loop']['first'] = false;
                        if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                            --$context['loop']['revindex0'];
                            --$context['loop']['revindex'];
                            $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                        }
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['addon'], $context['_parent'], $context['loop']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 179
                    yield "                                ";
                }
                // line 180
                yield "                                <td class=\"text-end contractDay text-nowrap";
                if ( !(null === ($context["style"] ?? null))) {
                    yield " bg-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["style"] ?? null), "html", null, true);
                }
                yield "\"";
                if ( !(null === ($context["statusTitle"] ?? null))) {
                    yield " data-toggle=\"tooltip\" data-placement=\"top\" title=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["statusTitle"] ?? null), "html", null, true);
                    yield "\"";
                }
                yield ">
                                    ";
                // line 181
                if (((((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 181), "expectedTime", [], "any", false, false, false, 181) != 0) || (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 181), "actualTime", [], "any", false, false, false, 181) != 0)) || (($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["day"], "hasAddons", [], "method", false, false, false, 181)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) && ((($context["now"] ?? null) > CoreExtension::getAttribute($this->env, $this->source, $context["day"], "day", [], "any", false, false, false, 181)) || (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 181), "actualTime", [], "any", false, false, false, 181) > 0)))) {
                    // line 182
                    yield "                                        ";
                    if (( !(null === ($context["style"] ?? null)) &&  !(null === ($context["statusTitle"] ?? null)))) {
                        // line 183
                        yield "                                            <i class=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon(($context["style"] ?? null)), "html", null, true);
                        yield " fa-xs\"></i>
                                        ";
                    }
                    // line 185
                    yield "                                        ";
                    if (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 185), "expectedTime", [], "any", false, false, false, 185) == 0) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 185), "actualTime", [], "any", false, false, false, 185) == 0))) {
                        // line 186
                        yield "                                            --:--
                                        ";
                    } else {
                        // line 188
                        yield "                                            ";
                        yield (string) $macros["_v11"]->getTemplateForMacro("macro_work_times_result", $context, 188, $this->getSourceContext())->macro_work_times_result(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 188), "expectedTime", [], "any", false, false, false, 188), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["day"], "workingTime", [], "any", false, false, false, 188), "actualTime", [], "any", false, false, false, 188), ($context["decimal"] ?? null)]);
                        yield "
                                        ";
                    }
                    // line 190
                    yield "                                    ";
                }
                // line 191
                yield "                                </td>
                                ";
                // line 192
                $context["dayCount"] = (($context["dayCount"] ?? null) + 1);
                // line 193
                yield "                            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 194
            yield "                            ";
            if ((($context["dayCount"] ?? null) < 31)) {
                // line 195
                yield "                                ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(range(1, (31 - ($context["dayCount"] ?? null))));
                foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
                    // line 196
                    yield "                                    <td class=\"contractDay\"></td>
                                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 198
                yield "                            ";
            }
            // line 199
            yield "                            <td class=\"actions\">
                                ";
            // line 200
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 200), "contract_month", "index", ["year" => ($context["year"] ?? null), "month" => $context["month"]]);
            // line 201
            yield "                                ";
            yield (string) $macros["_v11"]->getTemplateForMacro("macro_table_actions", $context, 201, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 201)]);
            yield "
                            </td>
                        </tr>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['month'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 205
        yield "                    </tbody>
                    <tfoot>
                        <tr class=\"summary\">
                            ";
        // line 208
        if ((($tmp = ($context["withWorkHourConfiguration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 209
            yield "                            <td></td>
                            ";
        }
        // line 211
        yield "                            <td></td>
                            <td class=\"text-end total\">
                                ";
        // line 213
        yield (string) $macros["_v11"]->getTemplateForMacro("macro_work_times_result", $context, 213, $this->getSourceContext())->macro_work_times_result(...[($context["yearShould"] ?? null), ($context["yearIs"] ?? null), ($context["decimal"] ?? null)]);
        yield "
                            </td>
                            <td class=\"text-end\">
                                ";
        // line 216
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["yearShould"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "
                            </td>
                            <td class=\"text-end\">
                                ";
        // line 219
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["yearIs"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "
                            </td>
                            ";
        // line 221
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(range(1, 31));
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 222
            yield "                                <td class=\"contractDay\"></td>
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 224
        yield "                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  986 => 224,  978 => 222,  974 => 221,  969 => 219,  963 => 216,  957 => 213,  953 => 211,  949 => 209,  947 => 208,  942 => 205,  930 => 201,  928 => 200,  925 => 199,  922 => 198,  914 => 196,  909 => 195,  906 => 194,  899 => 193,  897 => 192,  894 => 191,  891 => 190,  885 => 188,  881 => 186,  878 => 185,  872 => 183,  869 => 182,  867 => 181,  853 => 180,  850 => 179,  835 => 178,  832 => 177,  829 => 176,  826 => 175,  823 => 174,  820 => 173,  817 => 172,  814 => 171,  811 => 170,  793 => 169,  790 => 168,  787 => 167,  784 => 166,  781 => 165,  778 => 164,  775 => 163,  772 => 162,  769 => 161,  764 => 160,  762 => 159,  757 => 157,  751 => 154,  745 => 151,  739 => 148,  736 => 147,  732 => 145,  726 => 143,  712 => 141,  710 => 140,  707 => 139,  705 => 138,  702 => 137,  699 => 136,  696 => 135,  692 => 134,  686 => 130,  673 => 128,  669 => 127,  665 => 126,  661 => 125,  657 => 124,  652 => 123,  648 => 121,  646 => 120,  641 => 117,  634 => 116,  629 => 115,  624 => 113,  621 => 112,  619 => 111,  614 => 110,  607 => 109,  602 => 94,  600 => 108,  598 => 107,  591 => 106,  588 => 105,  585 => 104,  582 => 103,  579 => 102,  576 => 101,  573 => 100,  570 => 99,  566 => 98,  564 => 97,  562 => 96,  560 => 95,  553 => 94,  491 => 86,  481 => 83,  478 => 82,  475 => 81,  471 => 80,  466 => 78,  461 => 76,  456 => 73,  448 => 71,  440 => 69,  434 => 67,  428 => 65,  426 => 64,  423 => 63,  420 => 62,  417 => 61,  414 => 60,  411 => 59,  408 => 58,  405 => 57,  402 => 56,  398 => 55,  395 => 54,  389 => 52,  383 => 50,  381 => 49,  376 => 47,  373 => 46,  368 => 45,  365 => 44,  363 => 43,  358 => 40,  348 => 38,  344 => 37,  340 => 36,  334 => 32,  327 => 31,  316 => 30,  309 => 28,  304 => 27,  297 => 26,  292 => 23,  290 => 25,  288 => 24,  281 => 23,  201 => 271,  194 => 270,  188 => 267,  178 => 265,  174 => 264,  171 => 263,  168 => 262,  166 => 238,  163 => 237,  156 => 236,  153 => 235,  148 => 234,  145 => 233,  143 => 232,  140 => 231,  137 => 230,  134 => 94,  132 => 93,  129 => 92,  126 => 91,  123 => 23,  121 => 22,  118 => 21,  112 => 19,  109 => 18,  105 => 17,  97 => 15,  95 => 14,  90 => 13,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "contract/status.html.twig", "/opt/kimai/templates/contract/status.html.twig");
    }
}


/* contract/status.html.twig */
class __TwigTemplate_91ab7e4f742bfa695c446f2db3f11449___3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 238
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 239
        $macros["_v13"] = $this->macros["_v13"] = $this->load("macros/status.html.twig", 239)->unwrap();
        // line 238
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 238);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 240
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 241
        yield "                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times_should"), "html", null, true);
        yield "
                &nbsp;
                ";
        // line 243
        yield (string) $macros["_v13"]->getTemplateForMacro("macro_status_duration", $context, 243, $this->getSourceContext())->macro_status_duration(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["expectedWeekTimes"] ?? null))]);
        yield "
            ";
        yield from [];
    }

    // line 245
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 246
        yield "                <div class=\"datagrid\">
                    ";
        // line 247
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["days"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 248
            yield "                    <div class=\"datagrid-item\">
                        <div class=\"datagrid-title\">";
            // line 249
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dayName(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "date", [], "any", false, false, false, 249)), "html", null, true);
            yield "</div>
                        <div class=\"datagrid-content\">
                            ";
            // line 251
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["day"], "duration", [], "any", false, false, false, 251))) {
                // line 252
                yield "                                ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "duration", [], "any", false, false, false, 252)), "html", null, true);
                yield "
                            ";
            } else {
                // line 254
                yield "                                &ndash;
                            ";
            }
            // line 256
            yield "                        </div>
                    </div>
                    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['day'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 259
        yield "                </div>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "contract/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1126 => 259,  1117 => 256,  1113 => 254,  1107 => 252,  1105 => 251,  1100 => 249,  1097 => 248,  1093 => 247,  1090 => 246,  1083 => 245,  1076 => 243,  1070 => 241,  1063 => 240,  1058 => 238,  1056 => 239,  1049 => 238,  986 => 224,  978 => 222,  974 => 221,  969 => 219,  963 => 216,  957 => 213,  953 => 211,  949 => 209,  947 => 208,  942 => 205,  930 => 201,  928 => 200,  925 => 199,  922 => 198,  914 => 196,  909 => 195,  906 => 194,  899 => 193,  897 => 192,  894 => 191,  891 => 190,  885 => 188,  881 => 186,  878 => 185,  872 => 183,  869 => 182,  867 => 181,  853 => 180,  850 => 179,  835 => 178,  832 => 177,  829 => 176,  826 => 175,  823 => 174,  820 => 173,  817 => 172,  814 => 171,  811 => 170,  793 => 169,  790 => 168,  787 => 167,  784 => 166,  781 => 165,  778 => 164,  775 => 163,  772 => 162,  769 => 161,  764 => 160,  762 => 159,  757 => 157,  751 => 154,  745 => 151,  739 => 148,  736 => 147,  732 => 145,  726 => 143,  712 => 141,  710 => 140,  707 => 139,  705 => 138,  702 => 137,  699 => 136,  696 => 135,  692 => 134,  686 => 130,  673 => 128,  669 => 127,  665 => 126,  661 => 125,  657 => 124,  652 => 123,  648 => 121,  646 => 120,  641 => 117,  634 => 116,  629 => 115,  624 => 113,  621 => 112,  619 => 111,  614 => 110,  607 => 109,  602 => 94,  600 => 108,  598 => 107,  591 => 106,  588 => 105,  585 => 104,  582 => 103,  579 => 102,  576 => 101,  573 => 100,  570 => 99,  566 => 98,  564 => 97,  562 => 96,  560 => 95,  553 => 94,  491 => 86,  481 => 83,  478 => 82,  475 => 81,  471 => 80,  466 => 78,  461 => 76,  456 => 73,  448 => 71,  440 => 69,  434 => 67,  428 => 65,  426 => 64,  423 => 63,  420 => 62,  417 => 61,  414 => 60,  411 => 59,  408 => 58,  405 => 57,  402 => 56,  398 => 55,  395 => 54,  389 => 52,  383 => 50,  381 => 49,  376 => 47,  373 => 46,  368 => 45,  365 => 44,  363 => 43,  358 => 40,  348 => 38,  344 => 37,  340 => 36,  334 => 32,  327 => 31,  316 => 30,  309 => 28,  304 => 27,  297 => 26,  292 => 23,  290 => 25,  288 => 24,  281 => 23,  201 => 271,  194 => 270,  188 => 267,  178 => 265,  174 => 264,  171 => 263,  168 => 262,  166 => 238,  163 => 237,  156 => 236,  153 => 235,  148 => 234,  145 => 233,  143 => 232,  140 => 231,  137 => 230,  134 => 94,  132 => 93,  129 => 92,  126 => 91,  123 => 23,  121 => 22,  118 => 21,  112 => 19,  109 => 18,  105 => 17,  97 => 15,  95 => 14,  90 => 13,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  67 => 6,  64 => 5,  57 => 4,  52 => 1,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "contract/status.html.twig", "/opt/kimai/templates/contract/status.html.twig");
    }
}
