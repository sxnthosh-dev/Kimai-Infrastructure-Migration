<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/delete.html.twig */
class __TwigTemplate_8351c524dc4874ea393f544b938ec137 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "
    ";
        // line 6
        $context["inUse"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), "recordsTotal", [], "any", false, false, false, 6) > 0);
        // line 7
        yield "
    ";
        // line 8
        $context["params"] = ["%records%" => CoreExtension::getAttribute($this->env, $this->source,         // line 9
($context["stats"] ?? null), "recordsTotal", [], "any", false, false, false, 9), "%duration%" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source,         // line 10
($context["stats"] ?? null), "durationTotal", [], "any", false, false, false, 10))];
        // line 12
        yield "
    ";
        // line 13
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 13)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_delete_modal.html.twig") : ("default/_form_delete.html.twig")), ["message" => (($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete_warning.short_stats",         // line 14
($context["params"] ?? null)) . " ") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("admin_entity.delete_confirm")), "form" =>         // line 15
($context["form"] ?? null), "delete_item_name" => CoreExtension::getAttribute($this->env, $this->source,         // line 16
($context["user"] ?? null), "displayName", [], "any", false, false, false, 16), "used" =>         // line 17
($context["inUse"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user")]);
        // line 19
        yield "

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/delete.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  82 => 19,  80 => 17,  79 => 16,  78 => 15,  77 => 14,  76 => 13,  73 => 12,  71 => 10,  70 => 9,  69 => 8,  66 => 7,  64 => 6,  61 => 5,  54 => 4,  50 => 1,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/delete.html.twig", "/opt/kimai/templates/user/delete.html.twig");
    }
}
