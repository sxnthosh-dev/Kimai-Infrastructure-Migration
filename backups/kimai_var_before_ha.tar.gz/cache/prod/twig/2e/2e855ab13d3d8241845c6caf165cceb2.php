<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* timesheet/edit-default.html.twig */
class __TwigTemplate_225240390b92e5468c93fe343e3b201f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'timesheet_form' => [$this, 'block_timesheet_form'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->unwrap()->yieldBlock('timesheet_form', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_timesheet_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        yield "    ";
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 3
        yield "    ";
        yield from $this->load("timesheet/edit-default.html.twig", 3, 2)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/edit-default.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  58 => 3,  55 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/edit-default.html.twig", "/opt/kimai/templates/timesheet/edit-default.html.twig");
    }
}


/* timesheet/edit-default.html.twig */
class __TwigTemplate_225240390b92e5468c93fe343e3b201f___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(CoreExtension::getAttribute($this->env, $this->source, ($context["formOptions"] ?? null), "template", [], "any", false, false, false, 3), 3);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "begin_date", [], "any", true, true, false, 5)) {
            // line 6
            yield "                <div class=\"mb-3 row\">
                    <label class=\"col-form-label col-sm-2 required\" for=\"";
            // line 7
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 7), "name", [], "any", false, false, false, 7), "html", null, true);
            yield "_begin_date\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("begin"), "html", null, true);
            yield "</label>
                    <div class=\"col-sm-5\">
                        ";
            // line 9
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "begin_date", [], "any", false, false, false, 9), 'widget', ["label" => false]);
            yield "
                        ";
            // line 10
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "begin_date", [], "any", false, false, false, 10), 'errors', ["label" => false]);
            yield "
                    </div>
                    <div class=\"col-sm-5\">
                        ";
            // line 13
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "begin_time", [], "any", false, false, false, 13), 'widget', ["label" => false]);
            yield "
                        ";
            // line 14
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "begin_time", [], "any", false, false, false, 14), 'errors', ["label" => false]);
            yield "
                    </div>
                </div>
            ";
        }
        // line 18
        yield "            ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", true, true, false, 18) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", true, true, false, 18))) {
            // line 19
            yield "                <div class=\"mb-3 row\">
                    <label class=\"col-form-label col-sm-2\" for=\"";
            // line 20
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 20), "name", [], "any", false, false, false, 20), "html", null, true);
            yield "_duration\">
                        ";
            // line 21
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", true, true, false, 21)) {
                // line 22
                yield "                            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
                yield "
                            ";
                // line 23
                if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", true, true, false, 23)) {
                    yield " / ";
                }
                // line 24
                yield "                        ";
            }
            // line 25
            yield "                        ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", true, true, false, 25)) {
                // line 26
                yield "                            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("endtime"), "html", null, true);
                yield "
                        ";
            }
            // line 28
            yield "                    </label>
                    ";
            // line 29
            $context["size"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", true, true, false, 29) && CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", true, true, false, 29))) ? (5) : (10));
            // line 30
            yield "                    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", true, true, false, 30)) {
                // line 31
                yield "                    <div class=\"col-sm-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["size"] ?? null), "html", null, true);
                yield "\">
                        ";
                // line 32
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", false, false, false, 32), 'widget', ["label" => false]);
                yield "
                        ";
                // line 33
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", false, false, false, 33), 'errors', ["label" => false]);
                yield "
                    </div>
                    ";
            }
            // line 36
            yield "                    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", true, true, false, 36)) {
                // line 37
                yield "                    <div class=\"col-sm-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["size"] ?? null), "html", null, true);
                yield "\">
                        ";
                // line 38
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", false, false, false, 38), 'widget', ["label" => false]);
                yield "
                        ";
                // line 39
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end_time", [], "any", false, false, false, 39), 'errors', ["label" => false]);
                yield "
                    </div>
                    ";
            }
            // line 42
            yield "                </div>
            ";
        } else {
            // line 44
            yield "                ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", true, true, false, 44)) {
                // line 45
                yield "                    ";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", false, false, false, 45), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 45), "name", [], "any", false, false, false, 45)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "duration", [], "any", false, false, false, 45), "vars", [], "any", false, false, false, 45), "name", [], "any", false, false, false, 45))]]);
                yield "
                ";
            }
            // line 47
            yield "            ";
        }
        // line 48
        yield "
            ";
        // line 49
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "break", [], "any", true, true, false, 49)) {
            // line 50
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "break", [], "any", false, false, false, 50), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 50), "name", [], "any", false, false, false, 50)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "break", [], "any", false, false, false, 50), "vars", [], "any", false, false, false, 50), "name", [], "any", false, false, false, 50))]]);
            yield "
            ";
        }
        // line 52
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", true, true, false, 52)) {
            // line 53
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 53), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 53), "name", [], "any", false, false, false, 53)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 53), "vars", [], "any", false, false, false, 53), "name", [], "any", false, false, false, 53))]]);
            yield "
            ";
        }
        // line 55
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", true, true, false, 55)) {
            // line 56
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 56), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 56), "name", [], "any", false, false, false, 56)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 56), "vars", [], "any", false, false, false, 56), "name", [], "any", false, false, false, 56))]]);
            yield "
            ";
        }
        // line 58
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activity", [], "any", true, true, false, 58)) {
            // line 59
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activity", [], "any", false, false, false, 59), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 59), "name", [], "any", false, false, false, 59)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activity", [], "any", false, false, false, 59), "vars", [], "any", false, false, false, 59), "name", [], "any", false, false, false, 59))]]);
            yield "
            ";
        }
        // line 61
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", true, true, false, 61)) {
            // line 62
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", false, false, false, 62), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 62), "name", [], "any", false, false, false, 62)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "description", [], "any", false, false, false, 62), "vars", [], "any", false, false, false, 62), "name", [], "any", false, false, false, 62))]]);
            yield "
            ";
        }
        // line 64
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", true, true, false, 64)) {
            // line 65
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", false, false, false, 65), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 65), "name", [], "any", false, false, false, 65)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", false, false, false, 65), "vars", [], "any", false, false, false, 65), "name", [], "any", false, false, false, 65))]]);
            yield "
            ";
        }
        // line 67
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", true, true, false, 67)) {
            // line 68
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 68), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 68), "name", [], "any", false, false, false, 68)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 68), "vars", [], "any", false, false, false, 68), "name", [], "any", false, false, false, 68))]]);
            yield "
            ";
        }
        // line 70
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", true, true, false, 70)) {
            // line 71
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", false, false, false, 71), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 71), "name", [], "any", false, false, false, 71)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", false, false, false, 71), "vars", [], "any", false, false, false, 71), "name", [], "any", false, false, false, 71))]]);
            yield "
            ";
        }
        // line 73
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 73)) {
            // line 74
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 74), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 74), "name", [], "any", false, false, false, 74)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 74), "vars", [], "any", false, false, false, 74), "name", [], "any", false, false, false, 74))]]);
            yield "
            ";
        }
        // line 76
        yield "            ";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", true, true, false, 76) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 76)))) {
            // line 77
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 77), "children", [], "any", false, false, false, 77));
            foreach ($context['_seq'] as $context["_key"] => $context["meta"]) {
                // line 78
                yield "                    ";
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "vars", [], "any", false, false, false, 78), "data", [], "any", false, false, false, 78), "formTheme", [], "any", false, false, false, 78))) {
                    // line 79
                    yield "                        ";
                    $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme($context["meta"], [CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["meta"], "vars", [], "any", false, false, false, 79), "data", [], "any", false, false, false, 79), "formTheme", [], "any", false, false, false, 79)], true);
                    // line 80
                    yield "                    ";
                }
                // line 81
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['meta'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 82
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 82), 'row');
            yield "
            ";
        }
        // line 84
        yield "            ";
        if ((((((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", true, true, false, 84) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", true, true, false, 84)) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "internalRate", [], "any", true, true, false, 84)) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", true, true, false, 84)) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billableMode", [], "any", true, true, false, 84)) || CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", true, true, false, 84))) {
            // line 85
            yield "                ";
            yield from $this->load("timesheet/edit-default.html.twig", 85, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => "timesheet_extended_settings"]));
            // line 108
            yield "            ";
        }
        // line 109
        yield "
            ";
        // line 110
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/edit-default.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  374 => 110,  371 => 109,  368 => 108,  365 => 85,  362 => 84,  356 => 82,  349 => 81,  346 => 80,  343 => 79,  340 => 78,  335 => 77,  332 => 76,  326 => 74,  323 => 73,  317 => 71,  314 => 70,  308 => 68,  305 => 67,  299 => 65,  296 => 64,  290 => 62,  287 => 61,  281 => 59,  278 => 58,  272 => 56,  269 => 55,  263 => 53,  260 => 52,  254 => 50,  252 => 49,  249 => 48,  246 => 47,  240 => 45,  237 => 44,  233 => 42,  227 => 39,  223 => 38,  218 => 37,  215 => 36,  209 => 33,  205 => 32,  200 => 31,  197 => 30,  195 => 29,  192 => 28,  186 => 26,  183 => 25,  180 => 24,  176 => 23,  171 => 22,  169 => 21,  165 => 20,  162 => 19,  159 => 18,  152 => 14,  148 => 13,  142 => 10,  138 => 9,  131 => 7,  128 => 6,  125 => 5,  118 => 4,  58 => 3,  55 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/edit-default.html.twig", "/opt/kimai/templates/timesheet/edit-default.html.twig");
    }
}


/* timesheet/edit-default.html.twig */
class __TwigTemplate_225240390b92e5468c93fe343e3b201f___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 85
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 86
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 86)->unwrap();
        // line 85
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 85);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("extended_settings"), "html", null, true);
        yield from [];
    }

    // line 88
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 89
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", true, true, false, 89)) {
            // line 90
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", false, false, false, 90), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 90), "name", [], "any", false, false, false, 90)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fixedRate", [], "any", false, false, false, 90), "vars", [], "any", false, false, false, 90), "name", [], "any", false, false, false, 90))]]);
            yield "
                        ";
        }
        // line 92
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", true, true, false, 92)) {
            // line 93
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", false, false, false, 93), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 93), "name", [], "any", false, false, false, 93)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "hourlyRate", [], "any", false, false, false, 93), "vars", [], "any", false, false, false, 93), "name", [], "any", false, false, false, 93))]]);
            yield "
                        ";
        }
        // line 95
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "internalRate", [], "any", true, true, false, 95)) {
            // line 96
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "internalRate", [], "any", false, false, false, 96), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 96), "name", [], "any", false, false, false, 96)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "internalRate", [], "any", false, false, false, 96), "vars", [], "any", false, false, false, 96), "name", [], "any", false, false, false, 96))]]);
            yield "
                        ";
        }
        // line 98
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", true, true, false, 98)) {
            // line 99
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 99), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 99), "name", [], "any", false, false, false, 99)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 99), "vars", [], "any", false, false, false, 99), "name", [], "any", false, false, false, 99))]]);
            yield "
                        ";
        } elseif (CoreExtension::getAttribute($this->env, $this->source,         // line 100
($context["form"] ?? null), "billableMode", [], "any", true, true, false, 100)) {
            // line 101
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billableMode", [], "any", false, false, false, 101), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 101), "name", [], "any", false, false, false, 101)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billableMode", [], "any", false, false, false, 101), "vars", [], "any", false, false, false, 101), "name", [], "any", false, false, false, 101))]]);
            yield "
                        ";
        }
        // line 103
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", true, true, false, 103)) {
            // line 104
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 104), 'row', ["row_attr" => ["class" => ((("mb-3 " . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 104), "name", [], "any", false, false, false, 104)) . "_row_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 104), "vars", [], "any", false, false, false, 104), "name", [], "any", false, false, false, 104))]]);
            yield "
                        ";
        }
        // line 106
        yield "                    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "timesheet/edit-default.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  519 => 106,  513 => 104,  510 => 103,  504 => 101,  502 => 100,  497 => 99,  494 => 98,  488 => 96,  485 => 95,  479 => 93,  476 => 92,  470 => 90,  467 => 89,  460 => 88,  449 => 87,  444 => 85,  442 => 86,  435 => 85,  374 => 110,  371 => 109,  368 => 108,  365 => 85,  362 => 84,  356 => 82,  349 => 81,  346 => 80,  343 => 79,  340 => 78,  335 => 77,  332 => 76,  326 => 74,  323 => 73,  317 => 71,  314 => 70,  308 => 68,  305 => 67,  299 => 65,  296 => 64,  290 => 62,  287 => 61,  281 => 59,  278 => 58,  272 => 56,  269 => 55,  263 => 53,  260 => 52,  254 => 50,  252 => 49,  249 => 48,  246 => 47,  240 => 45,  237 => 44,  233 => 42,  227 => 39,  223 => 38,  218 => 37,  215 => 36,  209 => 33,  205 => 32,  200 => 31,  197 => 30,  195 => 29,  192 => 28,  186 => 26,  183 => 25,  180 => 24,  176 => 23,  171 => 22,  169 => 21,  165 => 20,  162 => 19,  159 => 18,  152 => 14,  148 => 13,  142 => 10,  138 => 9,  131 => 7,  128 => 6,  125 => 5,  118 => 4,  58 => 3,  55 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "timesheet/edit-default.html.twig", "/opt/kimai/templates/timesheet/edit-default.html.twig");
    }
}
