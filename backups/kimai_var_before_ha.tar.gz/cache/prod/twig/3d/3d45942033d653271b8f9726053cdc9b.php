<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* plugin/index.html.twig */
class __TwigTemplate_c8b78fb1ff3aa15cb0e18334beea52c3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "
    ";
        // line 7
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["plugins"] ?? null)) == 0)) {
            // line 8
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_callout", $context, 8, $this->getSourceContext())->macro_callout(...["warning", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("plugin.none_installed", [], "plugins")]);
            yield "
    ";
        } else {
            // line 10
            yield "        ";
            yield from $this->load("plugin/index.html.twig", 10, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
            // line 45
            yield "    ";
        }
        // line 46
        yield "
    ";
        // line 47
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["extensions"] ?? null)) > 0)) {
            // line 48
            yield "        ";
            yield from $this->load("plugin/index.html.twig", 48, 2)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
            // line 82
            yield "    ";
        }
        // line 83
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "plugin/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  92 => 83,  89 => 82,  86 => 48,  84 => 47,  81 => 46,  78 => 45,  75 => 10,  69 => 8,  67 => 7,  64 => 6,  57 => 5,  52 => 1,  50 => 3,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "plugin/index.html.twig", "/opt/kimai/templates/plugin/index.html.twig");
    }
}


/* plugin/index.html.twig */
class __TwigTemplate_c8b78fb1ff3aa15cb0e18334beea52c3___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 10
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 10);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("plugin.installed"), "html", null, true);
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "                ";
        $context["columns"] = ["name" => ["class" => "alwaysVisible w-25"], "description" => ["class" => "d-none d-md-table-cell"], "version" => ["class" => "text-center w-min"]];
        // line 18
        yield "
                ";
        // line 19
        $context["tableName"] = "plugins";
        // line 20
        yield "
                ";
        // line 21
        $macros["tables"] = $this->load("macros/datatables.html.twig", 21)->unwrap();
        // line 22
        yield "                ";
        $macros["widgets"] = $this->load("macros/widgets.html.twig", 22)->unwrap();
        // line 23
        yield "                ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 23, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), null, ["columnConfig" => false]]);
        yield "
                ";
        // line 24
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["plugins"] ?? null), function ($__p1__, $__p2__) use ($context, $macros) { $context["p1"] = $__p1__; $context["p2"] = $__p2__; return (Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["p1"] ?? null), "name", [], "any", false, false, false, 24)) <=> Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["p2"] ?? null), "name", [], "any", false, false, false, 24))); }));
        foreach ($context['_seq'] as $context["_key"] => $context["plugin"]) {
            // line 25
            yield "                    ";
            $context["pluginClass"] = "success";
            // line 26
            yield "                    <tr>
                        <td class=\"";
            // line 27
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 27, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "name"]);
            yield "\">
                            <a href=\"";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "metadata", [], "any", false, false, false, 28), "homepage", [], "any", false, false, false, 28), "html", null, true);
            yield "\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("homepage"), "html", null, true);
            yield "\" target=\"_blank\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "name", [], "any", false, false, false, 28), "html", null, true);
            yield "</a>
                        </td>
                        <td class=\"";
            // line 30
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 30, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "description"]);
            yield "\">
                            ";
            // line 31
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "metadata", [], "any", false, false, false, 31), "description", [], "any", false, false, false, 31), "html", null, true);
            yield "
                            ";
            // line 32
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["updates"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "id", [], "any", false, false, false, 32), [], "array", true, true, false, 32) && ((($_v0 = ($context["updates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "id", [], "any", false, false, false, 32)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) == true))) {
                // line 33
                yield "                                ";
                $context["pluginClass"] = "warning";
                // line 34
                yield "                                ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 34, $this->getSourceContext())->macro_alert(...["warning", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("update_available", ["%version%" => (($_v2 = (($_v3 = ($context["bundles"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[(($_v4 = CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "id", [], "any", false, false, false, 34)) instanceof \Stringable ? (string) $_v4 : $_v4)] ?? null) : null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["latest_release"] ?? null) : null)], "plugins")]);
                yield "
                            ";
            }
            // line 36
            yield "                        </td>
                        <td class=\"";
            // line 37
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 37, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "version"]);
            yield "\">
                            ";
            // line 38
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label", $context, 38, $this->getSourceContext())->macro_label(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "metadata", [], "any", false, false, false, 38), "version", [], "any", false, false, false, 38), ($context["pluginClass"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["plugin"], "id", [], "any", false, false, false, 38)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['plugin'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 42
        yield "                ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 42, $this->getSourceContext())->macro_data_table_footer(...[($context["plugins"] ?? null)]);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "plugin/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  262 => 42,  251 => 38,  247 => 37,  244 => 36,  238 => 34,  235 => 33,  233 => 32,  229 => 31,  225 => 30,  216 => 28,  212 => 27,  209 => 26,  206 => 25,  202 => 24,  197 => 23,  194 => 22,  192 => 21,  189 => 20,  187 => 19,  184 => 18,  181 => 13,  174 => 12,  163 => 11,  152 => 10,  92 => 83,  89 => 82,  86 => 48,  84 => 47,  81 => 46,  78 => 45,  75 => 10,  69 => 8,  67 => 7,  64 => 6,  57 => 5,  52 => 1,  50 => 3,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "plugin/index.html.twig", "/opt/kimai/templates/plugin/index.html.twig");
    }
}


/* plugin/index.html.twig */
class __TwigTemplate_c8b78fb1ff3aa15cb0e18334beea52c3___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 48
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 49
        $macros["_v5"] = $this->macros["_v5"] = $this->load("macros/widgets.html.twig", 49)->unwrap();
        // line 48
        $this->parent = $this->load("@theme/embeds/card.html.twig", 48);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("plugin.marketplace", [], "plugins"), "html", null, true);
        yield from [];
    }

    // line 51
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 52
        yield "                ";
        yield (string) $macros["_v5"]->getTemplateForMacro("macro_card_tool_button", $context, 52, $this->getSourceContext())->macro_card_tool_button(...["shop", ["title" => "shop", "translation_domain" => "plugins", "target" => "_blank", "url" => (Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE") . "/store/"), "icon" => false, "class" => "btn-primary"]]);
        yield "
            ";
        yield from [];
    }

    // line 54
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 55
        yield "                ";
        $context["columns"] = ["name" => ["class" => "alwaysVisible w-25"], "description" => ["class" => "d-none d-md-table-cell"], "shop" => ["class" => "w-min alwaysVisible"]];
        // line 60
        yield "
                ";
        // line 61
        $context["tableName"] = "extensions";
        // line 62
        yield "
                ";
        // line 63
        $macros["tables"] = $this->load("macros/datatables.html.twig", 63)->unwrap();
        // line 64
        yield "                ";
        $macros["widgets"] = $this->load("macros/widgets.html.twig", 64)->unwrap();
        // line 65
        yield "                ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 65, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), null, ["columnConfig" => false]]);
        yield "
                ";
        // line 66
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["extensions"] ?? null), function ($__e__) use ($context, $macros) { $context["e"] = $__e__; return ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["e"] ?? null), "bundle", [], "any", false, false, false, 66)) && !CoreExtension::inFilter(CoreExtension::getAttribute($this->env, $this->source, ($context["e"] ?? null), "bundle", [], "any", false, false, false, 66), ($context["installed"] ?? null))); }));
        foreach ($context['_seq'] as $context["_key"] => $context["extension"]) {
            // line 67
            yield "                    <tr>
                        <td class=\"";
            // line 68
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 68, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "name"]);
            yield "\">
                            <a href=\"";
            // line 69
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "url", [], "any", false, false, false, 69), "html", null, true);
            yield "\" title=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("homepage"), "html", null, true);
            yield "\" target=\"_blank\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "name", [], "any", false, false, false, 69), "html", null, true);
            yield "</a>
                        </td>
                        <td class=\"";
            // line 71
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 71, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "description"]);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "description", [], "any", false, false, false, 71), "html", null, true);
            yield "</td>
                        <td class=\"";
            // line 72
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 72, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "shop"]);
            yield "\">
                            ";
            // line 73
            if (((CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "buy", [], "any", true, true, false, 73) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "buy", [], "any", false, false, false, 73))) && ( !CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "minimum_version", [], "any", true, true, false, 73) || ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "minimum_version", [], "any", false, false, false, 73)) && (Twig\Extension\CoreExtension::constant("App\\Constants::VERSION") >= CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "minimum_version", [], "any", false, false, false, 73)))))) {
                // line 74
                yield "                                <a class=\"btn btn-icon btn-outline-secondary\" href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["extension"], "buy", [], "any", false, false, false, 74), "html", null, true);
                yield "\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("buy", [], "plugins"), "html", null, true);
                yield "\" target=\"_blank\">";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("shop");
                yield "</a>
                            ";
            }
            // line 76
            yield "                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['extension'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 79
        yield "                ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 79, $this->getSourceContext())->macro_data_table_footer(...[($context["plugins"] ?? null)]);
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "plugin/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  444 => 79,  435 => 76,  425 => 74,  423 => 73,  419 => 72,  413 => 71,  404 => 69,  400 => 68,  397 => 67,  393 => 66,  388 => 65,  385 => 64,  383 => 63,  380 => 62,  378 => 61,  375 => 60,  372 => 55,  365 => 54,  357 => 52,  350 => 51,  339 => 50,  334 => 48,  332 => 49,  325 => 48,  262 => 42,  251 => 38,  247 => 37,  244 => 36,  238 => 34,  235 => 33,  233 => 32,  229 => 31,  225 => 30,  216 => 28,  212 => 27,  209 => 26,  206 => 25,  202 => 24,  197 => 23,  194 => 22,  192 => 21,  189 => 20,  187 => 19,  184 => 18,  181 => 13,  174 => 12,  163 => 11,  152 => 10,  92 => 83,  89 => 82,  86 => 48,  84 => 47,  81 => 46,  78 => 45,  75 => 10,  69 => 8,  67 => 7,  64 => 6,  57 => 5,  52 => 1,  50 => 3,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "plugin/index.html.twig", "/opt/kimai/templates/plugin/index.html.twig");
    }
}
