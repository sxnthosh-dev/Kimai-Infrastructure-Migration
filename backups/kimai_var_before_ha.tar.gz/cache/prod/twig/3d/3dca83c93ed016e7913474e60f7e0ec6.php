<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/button.html.twig */
class __TwigTemplate_dd29098f50e5d8ec1c7d24c64fc9e313 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_button($icon = null, $values = null, $type = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "icon" => $icon,
            "values" => $values,
            "type" => $type,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["͜macros"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 4
            if ((($context["type"] ?? null) === false)) {
                // line 6
                $context["class"] = "";
            } elseif ((null ===             // line 7
($context["type"] ?? null))) {
                // line 8
                $context["class"] = "btn ";
            } else {
                // line 10
                $context["class"] = (("btn btn-" . ($context["type"] ?? null)) . " ");
            }
            // line 13
            $context["icon"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "icon", [], "any", true, true, false, 13) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "icon", [], "any", false, false, false, 13)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "icon", [], "any", false, false, false, 13)) : (($context["icon"] ?? null)));
            // line 14
            $context["disabled"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "disabled", [], "any", true, true, false, 14) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "disabled", [], "any", false, false, false, 14)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "disabled", [], "any", false, false, false, 14)) : (false));
            // line 15
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "url", [], "any", true, true, false, 15)) {
                // line 16
                $context["href"] = CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "url", [], "any", false, false, false, 16);
            } else {
                // line 18
                $context["href"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "href", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "href", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "href", [], "any", false, false, false, 18)) : ("#"));
            }
            // line 20
            $context["onclick"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "onclick", [], "any", true, true, false, 20) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "onclick", [], "any", false, false, false, 20)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "onclick", [], "any", false, false, false, 20)) : (null));
            // line 21
            $context["collapse"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "collapse", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "collapse", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "collapse", [], "any", false, false, false, 21)) : (null));
            // line 22
            $context["modal"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "modal", [], "any", true, true, false, 22) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "modal", [], "any", false, false, false, 22)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "modal", [], "any", false, false, false, 22)) : (null));
            // line 23
            $context["toggle"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "toggle", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "toggle", [], "any", false, false, false, 23)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "toggle", [], "any", false, false, false, 23)) : (null));
            // line 24
            $context["target"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "target", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "target", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "target", [], "any", false, false, false, 24)) : (null));
            // line 25
            $context["id"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "id", [], "any", true, true, false, 25) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "id", [], "any", false, false, false, 25)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "id", [], "any", false, false, false, 25)) : (null));
            // line 26
            $context["title"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "title", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "title", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "title", [], "any", false, false, false, 26)) : (null));
            // line 27
            $context["class"] = (($context["class"] ?? null) . ((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "class", [], "any", true, true, false, 27)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "class", [], "any", false, false, false, 27), "")) : ("")));
            // line 28
            $context["attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "attr", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "attr", [], "any", false, false, false, 28)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "attr", [], "any", false, false, false, 28)) : ([]));
            // line 29
            $context["forceTitle"] = ((($context["icon"] ?? null) === false) || (($tmp = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "combined", [], "any", true, true, false, 29) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "combined", [], "any", false, false, false, 29)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "combined", [], "any", false, false, false, 29)) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
            // line 30
            $context["badge"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badge", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badge", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badge", [], "any", false, false, false, 30)) : ((((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "label", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "label", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "label", [], "any", false, false, false, 30)) : (null))));
            // line 31
            $context["badge_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badgeColor", [], "any", true, true, false, 31) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badgeColor", [], "any", false, false, false, 31)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "badgeColor", [], "any", false, false, false, 31)) : ((((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "labelColor", [], "any", true, true, false, 31) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "labelColor", [], "any", false, false, false, 31)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "labelColor", [], "any", false, false, false, 31)) : ("yellow"))));
            // line 32
            $context["translation_domain"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_domain", [], "any", true, true, false, 32) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_domain", [], "any", false, false, false, 32)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_domain", [], "any", false, false, false, 32)) : ("messages"));
            // line 33
            $context["translation_params"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_params", [], "any", true, true, false, 33) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_params", [], "any", false, false, false, 33)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "translation_params", [], "any", false, false, false, 33)) : ([]));
            // line 34
            $context["isSubmit"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "buttonType", [], "any", true, true, false, 34) && (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "buttonType", [], "any", false, false, false, 34) == "submit"));
            // line 35
            $context["buttonType"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "buttonType", [], "any", true, true, false, 35) && ((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "buttonType", [], "any", false, false, false, 35) == "button") || (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "buttonType", [], "any", false, false, false, 35) == "submit")))) ? ("button") : ("a"));
            // line 36
            $context["tooltip"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip", [], "any", true, true, false, 36) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip", [], "any", false, false, false, 36)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip", [], "any", false, false, false, 36)) : (true));
            // line 37
            $context["accesskey"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "accesskey", [], "any", true, true, false, 37)) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "accesskey", [], "any", false, false, false, 37)) : (null));
            // line 39
            if (((((($context["type"] ?? null) != "link") &&  !(($context["icon"] ?? null) === false)) && ( !(($tmp = ($context["forceTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (null === ($context["badge"] ?? null)))) && (!(($context["type"] ?? null) === false)))) {
                // line 40
                $context["class"] = (($context["class"] ?? null) . " btn-icon");
            }
            // line 43
            if ((($context["disabled"] ?? null) === true)) {
                // line 44
                $context["class"] = (($context["class"] ?? null) . " disabled");
            }
            // line 47
            yield "<";
            yield (string) ($context["buttonType"] ?? null);
            yield " class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::trim(($context["class"] ?? null)), "html", null, true);
            yield "\"";
            // line 48
            if ((($context["buttonType"] ?? null) === "a")) {
                // line 49
                if ((($context["disabled"] ?? null) === true)) {
                    // line 50
                    yield "            aria-disabled=\"true\"";
                } else {
                    // line 52
                    yield "            href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["href"] ?? null), "html", null, true);
                    yield "\"
        ";
                }
            } else {
                // line 55
                if ((($context["disabled"] ?? null) === true)) {
                    yield " disabled=\"disabled\"";
                }
            }
            // line 57
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["id"] ?? null))) {
                yield " id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["id"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 58
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["toggle"] ?? null))) {
                yield " data-bs-toggle=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["toggle"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 59
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["modal"] ?? null))) {
                yield " data-bs-toggle=\"modal\" data-bs-target=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["modal"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 60
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["collapse"] ?? null))) {
                yield " data-bs-toggle=\"collapse\" data-bs-target=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["collapse"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 61
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["onclick"] ?? null))) {
                yield " onclick=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["onclick"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 62
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["target"] ?? null))) {
                yield " ";
                if ((($tmp = ($context["isSubmit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "formtarget";
                } else {
                    yield "target";
                }
                yield "=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["target"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 63
            if (((((($tmp = ($context["tooltip"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["forceTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) &&  !(null === ($context["title"] ?? null))) &&  !(($context["type"] ?? null) === false))) {
                yield " ";
                yield (string) (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip_attr", [], "any", true, true, false, 63) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip_attr", [], "any", false, false, false, 63)))) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "tooltip_attr", [], "any", false, false, false, 63), "html", null, true)) : ("data-bs-toggle"));
                yield "=\"tooltip\" data-bs-placement=\"top\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null), ($context["translation_params"] ?? null), ($context["translation_domain"] ?? null)), "html", null, true);
                yield "\"";
            }
            // line 64
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["accesskey"] ?? null))) {
                yield " accesskey=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["accesskey"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 65
            yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 65, $this->getSourceContext())->macro_attr_to_html(...[($context["attr"] ?? null)]);
            // line 66
            yield ">";
            // line 67
            if ( !(($context["icon"] ?? null) === false)) {
                // line 68
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["icon"] ?? null), (!CoreExtension::inFilter("btn-sm", ($context["class"] ?? null)) && !CoreExtension::inFilter("btn-lg", ($context["class"] ?? null))), ($context["icon"] ?? null));
            }
            // line 70
            if ((((($tmp = ($context["forceTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (($context["icon"] ?? null) === false)) &&  !(null === ($context["title"] ?? null)))) {
                // line 71
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null), ($context["translation_params"] ?? null), ($context["translation_domain"] ?? null)), "html", null, true);
            }
            // line 73
            if ( !(null === ($context["badge"] ?? null))) {
                // line 74
                yield "<span class=\"badge bg-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["badge_color"] ?? null), "html", null, true);
                yield " text-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["badge_color"] ?? null), "html", null, true);
                yield "-fg ";
                if (((($tmp = ($context["forceTitle"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(null === ($context["title"] ?? null)))) {
                    yield "ms-1";
                }
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["badge"] ?? null), "html", null, true);
                yield "</span>";
            }
            // line 76
            yield "</";
            yield (string) ($context["buttonType"] ?? null);
            yield ">
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/button.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  243 => 76,  230 => 74,  228 => 73,  225 => 71,  223 => 70,  220 => 68,  218 => 67,  216 => 66,  214 => 65,  208 => 64,  200 => 63,  188 => 62,  182 => 61,  176 => 60,  170 => 59,  164 => 58,  158 => 57,  153 => 55,  146 => 52,  143 => 50,  141 => 49,  139 => 48,  133 => 47,  130 => 44,  128 => 43,  125 => 40,  123 => 39,  121 => 37,  119 => 36,  117 => 35,  115 => 34,  113 => 33,  111 => 32,  109 => 31,  107 => 30,  105 => 29,  103 => 28,  101 => 27,  99 => 26,  97 => 25,  95 => 24,  93 => 23,  91 => 22,  89 => 21,  87 => 20,  84 => 18,  81 => 16,  79 => 15,  77 => 14,  75 => 13,  72 => 10,  69 => 8,  67 => 7,  65 => 6,  63 => 4,  60 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/button.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/button.html.twig");
    }
}
