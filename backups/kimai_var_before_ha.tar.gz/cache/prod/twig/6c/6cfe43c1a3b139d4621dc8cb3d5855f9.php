<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @!Tabler/includes/footer.html.twig */
class __TwigTemplate_31551111940c9c2905edbc728e0baebf extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"row text-center align-items-center flex-row-reverse\">
    <div class=\"col-lg-auto ms-lg-auto\">
        <ul class=\"list-inline list-inline-dots mb-0\">
            <li class=\"list-inline-item\"><a href=\"https://docs.tabler.io/\" class=\"link-secondary\">Documentation</a></li>
            <li class=\"list-inline-item\"><a href=\"https://github.com/tabler/tabler/blob/dev/LICENSE\" class=\"link-secondary\">License</a></li>
            <li class=\"list-inline-item\"><a href=\"https://github.com/tabler/tabler\" target=\"_blank\" class=\"link-secondary\" rel=\"noopener\">Source code</a></li>
            <li class=\"list-inline-item\"><a href=\"https://github.com/sponsors/codecalm\" target=\"_blank\" class=\"link-secondary\" rel=\"noopener\">Sponsor</a></li>
        </ul>
    </div>
    <div class=\"col-12 col-lg-auto mt-3 mt-lg-0\">
        <ul class=\"list-inline list-inline-dots mb-0\">
            <li class=\"list-inline-item\">
                Made with Tabler and Symfony 2021-2025.
                All rights reserved.
            </li>
            <li class=\"list-inline-item\">
                <a href=\"https://preview.tabler.io/changelog.html\" class=\"link-secondary\" rel=\"noopener\">v1.4.0</a>
            </li>
        </ul>
    </div>
</div>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@!Tabler/includes/footer.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@!Tabler/includes/footer.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/footer.html.twig");
    }
}
