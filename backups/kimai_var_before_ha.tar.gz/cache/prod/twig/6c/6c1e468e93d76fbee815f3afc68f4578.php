<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* security/unlock.html.twig */
class __TwigTemplate_51c66ecc8a0e00f5c1add911e506e2cc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'login_social_auth' => [$this, 'block_login_social_auth'],
            'password_forgotten' => [$this, 'block_password_forgotten'],
            'registration' => [$this, 'block_registration'],
            'login_box_msg' => [$this, 'block_login_box_msg'],
            'login_form' => [$this, 'block_login_form'],
            'unlock_title' => [$this, 'block_unlock_title'],
            'unlock_form' => [$this, 'block_unlock_form'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "security/login.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("security/login.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_social_auth(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_password_forgotten(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_registration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box_msg(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("security.unlock.title"), "html", null, true);
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "        <p class=\"text-body-secondary text-center mb-4\">
            ";
        // line 11
        yield from $this->unwrap()->yieldBlock('unlock_title', $context, $blocks);
        // line 12
        yield "        </p>
        <div class=\"mb-4 text-center\">
            ";
        // line 14
        $macros["_v0"] = $this->load("macros/widgets.html.twig", 14)->unwrap();
        // line 15
        yield "            ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_user_avatar", $context, 15, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 15), false, "avatar-xl mb-3"]);
        yield "
            <h3>";
        // line 16
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_username", $context, 16, $this->getSourceContext())->macro_username(...[CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 16)]);
        yield "</h3>
            ";
        // line 17
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 17), "title", [], "any", false, false, false, 17))) {
            // line 18
            yield "                <p class=\"text-body-secondary\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 18), "title", [], "any", false, false, false, 18), "html", null, true);
            yield "</p>
            ";
        }
        // line 20
        yield "        </div>
        ";
        // line 21
        yield from $this->unwrap()->yieldBlock('unlock_form', $context, $blocks);
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_unlock_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("security.unlock.intro"), "html", null, true);
        yield from [];
    }

    // line 21
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_unlock_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 22
        yield "            ";
        if ((($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "loginFormActive")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 23
            yield "            <form action=\"";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_login_check"));
            yield "\" method=\"post\" autocomplete=\"off\" class=\"login-box-body security-login\">
                <input type=\"hidden\" name=\"_remember_me\" value=\"on\">
                <input type=\"hidden\" name=\"_username\" value=\"";
            // line 25
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 25), "userIdentifier", [], "any", false, false, false, 25), "html", null, true);
            yield "\">
                <div class=\"mb-3\">
                    <div class=\"input-group input-group-flat\">
                        <input name=\"_password\" type=\"password\" tabindex=\"20\" class=\"form-control\" placeholder=\"";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Password", [], "TablerBundle"), "html", null, true);
            yield "\">
                    </div>
                </div>
                <div class=\"form-footer\">
                    <button type=\"submit\" tabindex=\"40\" class=\"btn btn-primary w-100\">
                        ";
            // line 33
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("unlocked", true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("security.unlock.button"), "html", null, true);
            yield "
                    </button>
                </div>
                <input type=\"hidden\" name=\"_csrf_token\" value=\"";
            // line 36
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("authenticate"), "html", null, true);
            yield "\"/>
            </form>
            ";
        }
        // line 39
        yield "            <a class=\"btn w-100 mt-2\" href=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("logout");
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("logout"), "html", null, true);
        yield "</a>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "security/unlock.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 39,  191 => 36,  183 => 33,  175 => 28,  169 => 25,  163 => 23,  160 => 22,  153 => 21,  142 => 11,  137 => 21,  134 => 20,  128 => 18,  126 => 17,  122 => 16,  117 => 15,  115 => 14,  111 => 12,  109 => 11,  106 => 10,  99 => 9,  88 => 7,  78 => 5,  68 => 4,  58 => 3,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "security/unlock.html.twig", "/opt/kimai/templates/security/unlock.html.twig");
    }
}
