<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* permission/permissions.html.twig */
class __TwigTemplate_2662472acbb3460077a4ed295a805085 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 2)->unwrap();
        // line 3
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "
    ";
        // line 7
        $context["roles"] = Twig\Extension\CoreExtension::reverse($this->env->getCharset(), ($context["roles"] ?? null));
        // line 8
        yield "    ";
        $context["columns"] = ["name" => "alwaysVisible"];
        // line 11
        yield "    ";
        $context["canEditPermissions"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("role_permissions");
        // line 12
        yield "    <div class=\"row g-2 mb-3\">
    ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["roles"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
            // line 14
            yield "        ";
            $context["class"] = "alwaysVisible text-center";
            // line 15
            yield "        ";
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 15) == "ROLE_SUPER_ADMIN")) {
                // line 16
                yield "            ";
                $context["class"] = (($context["class"] ?? null) . " bg-orange-lt");
                // line 17
                yield "        ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 17) == "ROLE_USER")) {
                // line 18
                yield "            ";
                $context["class"] = (($context["class"] ?? null) . " bg-green-lt");
                // line 19
                yield "        ";
            }
            // line 20
            yield "        ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 20) => ["class" => ($context["class"] ?? null)]]);
            // line 21
            yield "        ";
            $context["roleUsers"] = [];
            // line 22
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["users"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                // line 23
                yield "            ";
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["user"], "hasRole", [CoreExtension::getAttribute($this->env, $this->source, $context["role"], "getName", [], "method", false, false, false, 23)], "method", false, false, false, 23)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 24
                    yield "                ";
                    $context["roleUsers"] = Twig\Extension\CoreExtension::merge(($context["roleUsers"] ?? null), [$context["user"]]);
                    // line 25
                    yield "            ";
                }
                // line 26
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['user'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 27
            yield "
        ";
            // line 28
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["role"], "isUser", [], "method", false, false, false, 28)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 29
                yield "        <div class=\"col-xl-4 col-lg-6 col-md-6\">
            <div class=\"card h-100\">
                <div class=\"card-body\">
                    <div class=\"d-flex justify-content-between mb-2\">
                        <h4 class=\"card-title\">
                            <span ondblclick=\"navigator.clipboard.writeText(\x27";
                // line 34
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "getName", [], "method", false, false, false, 34), "html", null, true);
                yield "\x27);\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "getName", [], "method", false, false, false, 34), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "getName", [], "method", false, false, false, 34)), "html", null, true);
                yield "</span>
                            ";
                // line 35
                if (((($tmp = ($context["canEditPermissions"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && !CoreExtension::inFilter(CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 35), ($context["system_roles"] ?? null)))) {
                    // line 36
                    yield "                                &nbsp;
                                <a href=\"#\" data-href=\"";
                    // line 37
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_user_role", ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["role"], "id", [], "any", false, false, false, 37)]), "html", null, true);
                    yield "\" data-method=\"DELETE\"
                                   data-event=\"kimai.userRoleUpdate\" data-question=\"confirm.delete\"
                                   data-msg-error=\"action.delete.error\" data-msg-success=\"action.delete.success\"
                                   class=\"api-link\">";
                    // line 40
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("trash");
                    yield "</a>
                            ";
                }
                // line 42
                yield "                        </h4>
                        <div class=\"list-unstyled d-flex mb-0\">
                            ";
                // line 44
                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_user")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 45
                    yield "                                <a href=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user", ["role" => CoreExtension::getAttribute($this->env, $this->source, $context["role"], "getName", [], "method", false, false, false, 45)]), "html", null, true);
                    yield "\" class=\"fs-6 mb-1\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("amount"), "html", null, true);
                    yield ": ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["roleUsers"] ?? null)), "html", null, true);
                    yield "</a>
                            ";
                } else {
                    // line 47
                    yield "                                <span class=\"fs-6 mb-1\">Total ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["roleUsers"] ?? null)), "html", null, true);
                    yield " users</span>
                            ";
                }
                // line 49
                yield "                        </div>
                    </div>
                    <div class=\"d-flex justify-content-between align-items-end\">
                        <div class=\"list-unstyled d-flex align-items-center avatars avatar-list avatar-list-stacked mb-0\">
                            ";
                // line 53
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["roleUsers"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["user"]) {
                    // line 54
                    yield "                                ";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 54, $this->getSourceContext())->macro_user_avatar(...[$context["user"], CoreExtension::getAttribute($this->env, $this->source, $context["user"], "displayName", [], "any", false, false, false, 54), "avatar-rounded avatar-sm"]);
                    yield "
                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['user'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 56
                yield "                        </div>
                    </div>
                </div>
            </div>
        </div>
        ";
            }
            // line 62
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['role'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 63
        yield "    </div>

    ";
        // line 65
        $context["tableName"] = "user_admin_permissions";
        // line 66
        yield "
    ";
        // line 67
        yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 67, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), null, ["reload" => "kimai.userRoleUpdate"]]);
        yield "
    
    ";
        // line 69
        $context["colspan"] = (1 + Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["roles"] ?? null)));
        // line 70
        yield "
    ";
        // line 71
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sorted"] ?? null));
        foreach ($context['_seq'] as $context["title"] => $context["perms"]) {
            // line 72
            yield "        ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), $context["perms"]) > 0)) {
                // line 73
                yield "            <tr class=\"summary info\">
                <td colspan=\"";
                // line 74
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["colspan"] ?? null), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["title"], "html", null, true);
                yield "</td>
            </tr>
            ";
                // line 76
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), $context["perms"]));
                foreach ($context['_seq'] as $context["_key"] => $context["permission"]) {
                    // line 77
                    yield "                <tr>
                    <td>";
                    // line 78
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["permission"], "html", null, true);
                    yield "</td>
                    ";
                    // line 79
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["roles"] ?? null));
                    foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                        // line 80
                        yield "                        ";
                        $context["value"] = CoreExtension::getAttribute($this->env, $this->source, ($context["manager"] ?? null), "permission", [CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 80), $context["permission"]], "method", false, false, false, 80);
                        // line 81
                        yield "                        <td class=\"";
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 81, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 81)]);
                        yield "\">
                            ";
                        // line 83
                        yield "                            ";
                        if (((CoreExtension::getAttribute($this->env, $this->source, $context["role"], "name", [], "any", false, false, false, 83) == "ROLE_SUPER_ADMIN") && CoreExtension::inFilter($context["permission"], ($context["always_apply_superadmin"] ?? null)))) {
                            // line 84
                            yield "                                ";
                            if ((($tmp = ($context["value"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                // line 85
                                yield "                                    ";
                                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label", $context, 85, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("yes"), "warning"]);
                                yield "
                                ";
                            } else {
                                // line 87
                                yield "                                    <a class=\"togglePerm permOff\" href=\"#\" data-href=\"";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_permission_save", ["role" => CoreExtension::getAttribute($this->env, $this->source, $context["role"], "id", [], "any", false, false, false, 87), "name" => $context["permission"]]), "html", null, true);
                                yield "\">";
                                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label", $context, 87, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("no"), "danger"]);
                                yield "</a>
                                ";
                            }
                            // line 89
                            yield "                            ";
                        } else {
                            // line 90
                            yield "                                <a class=\"togglePerm ";
                            yield (string) (((($tmp = ($context["value"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("permOn") : ("permOff"));
                            yield "\" href=\"#\" data-href=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_user_permission_save", ["role" => CoreExtension::getAttribute($this->env, $this->source, $context["role"], "id", [], "any", false, false, false, 90), "name" => $context["permission"]]), "html", null, true);
                            yield "\">";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 90, $this->getSourceContext())->macro_label_boolean(...[($context["value"] ?? null)]);
                            yield "</a>
                            ";
                        }
                        // line 92
                        yield "                        </td>
                    ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['role'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 94
                    yield "                </tr>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['permission'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 96
                yield "        ";
            }
            // line 97
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['title'], $context['perms'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 98
        yield "
    ";
        // line 99
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 99, $this->getSourceContext())->macro_data_table_footer(...[]);
        yield "

    <div style=\"display: none\" id=\"permission-token\" data-value=\"";
        // line 101
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["token"] ?? null), "html", null, true);
        yield "\"></div>

";
        yield from [];
    }

    // line 105
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 106
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        function getPermissionToken() {
            return document.getElementById(\x27permission-token\x27).dataset[\x27value\x27];
        }
        function setPermissionToken(token) {
            document.getElementById(\x27permission-token\x27).dataset[\x27value\x27] = token;
        }

        document.addEventListener(\x27kimai.initialized\x27, (event) => {
            const FETCHER = event.detail.kimai.getPlugin(\x27fetch\x27);
            for (const element of document.querySelectorAll(\x27a.togglePerm\x27)) {
                element.addEventListener(\x27click\x27, (event) => {
                    event.stopPropagation();
                    event.preventDefault();

                    let target = event.target;
                    if (!target.matches(\x27a\x27)) {
                        target = target.parentNode;
                    }

                    let linkElement = target;
                    linkElement.innerHTML = \x27<i class=\"";
        // line 128
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("spinner"), "html", null, true);
        yield " fa-pulse\"></i>\x27;

                    const isActive = linkElement.classList.contains(\x27permOn\x27);
                    const url = linkElement.dataset[\x27href\x27];

                    /** @type {KimaiFetch} FETCHER */
                    const headers = new Headers();
                    headers.append(\x27Content-Type\x27, \x27application/json\x27);

                    // the CSRF token and the new value belong into the body and not into the URL
                    const payload = {token: getPermissionToken(), value: !isActive};
                    const options = {method: \x27POST\x27, headers: headers, body: JSON.stringify(payload)};

                    FETCHER.fetch(url, options)
                        .then(response => {
                            response.json().then(json => {
                                linkElement.classList.toggle(\x27permOn\x27);
                                linkElement.classList.toggle(\x27permOff\x27);
                                toggleLabel(linkElement, !isActive);
                                setPermissionToken(json.token);
                            });
                        })
                        .catch(error => {
                            kimai.getPlugin(\x27alert\x27).error(\x27action.update.error\x27);
                            toggleLabel(linkElement, isActive);
                        })
                    ;
                });
            }

            KimaiReloadPageWidget.create(\x27kimai.userRoleUpdate\x27, true);
        });

        function toggleLabel(element, showTrue) {
            if (showTrue) {
                element.innerHTML = \x27";
        // line 163
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::trim($macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 163, $this->getSourceContext())->macro_label_boolean(...[true])), "js"), "html", null, true);
        yield "\x27;
            } else {
                element.innerHTML = \x27";
        // line 165
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::trim($macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 165, $this->getSourceContext())->macro_label_boolean(...[false])), "js"), "html", null, true);
        yield "\x27;
            }
        }
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "permission/permissions.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  431 => 165,  426 => 163,  388 => 128,  362 => 106,  355 => 105,  347 => 101,  342 => 99,  339 => 98,  332 => 97,  329 => 96,  321 => 94,  313 => 92,  303 => 90,  300 => 89,  292 => 87,  286 => 85,  283 => 84,  280 => 83,  275 => 81,  272 => 80,  268 => 79,  264 => 78,  261 => 77,  257 => 76,  250 => 74,  247 => 73,  244 => 72,  240 => 71,  237 => 70,  235 => 69,  230 => 67,  227 => 66,  225 => 65,  221 => 63,  214 => 62,  206 => 56,  196 => 54,  192 => 53,  186 => 49,  180 => 47,  170 => 45,  168 => 44,  164 => 42,  159 => 40,  153 => 37,  150 => 36,  148 => 35,  140 => 34,  133 => 29,  131 => 28,  128 => 27,  121 => 26,  118 => 25,  115 => 24,  112 => 23,  107 => 22,  104 => 21,  101 => 20,  98 => 19,  95 => 18,  92 => 17,  89 => 16,  86 => 15,  83 => 14,  79 => 13,  76 => 12,  73 => 11,  70 => 8,  68 => 7,  65 => 6,  58 => 5,  53 => 1,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "permission/permissions.html.twig", "/opt/kimai/templates/permission/permissions.html.twig");
    }
}
