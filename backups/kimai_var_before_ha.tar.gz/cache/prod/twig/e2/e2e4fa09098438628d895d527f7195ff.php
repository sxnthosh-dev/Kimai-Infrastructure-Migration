<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* system-configuration/index.html.twig */
class __TwigTemplate_e95a6ad1b7d3591698884a8ade5d1f07 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "<div class=\"row\">

    <div class=\"col-12 col-xxl-2 col-md-3 mb-3 d-none d-md-block\">
        <div class=\"card sticky-xxl-top\">
            <div class=\"list-group list-group-flush\">
                ";
        // line 9
        $context["sorted"] = [];
        // line 10
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sections"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 11
            yield "                    ";
            $context["title"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 11), "translation", [], "any", false, false, false, 11), [], CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 11), "translationDomain", [], "any", false, false, false, 11));
            // line 12
            yield "                    ";
            if ((($context["title"] ?? null) == CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 12), "translation", [], "any", false, false, false, 12))) {
                // line 13
                yield "                        ";
                $context["title"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 13), "section", [], "any", false, false, false, 13));
                // line 14
                yield "                    ";
            }
            // line 15
            yield "                    ";
            $context["sorted"] = Twig\Extension\CoreExtension::merge(($context["sorted"] ?? null), [["name" => ($context["title"] ?? null), "id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 15), "section", [], "any", false, false, false, 15), "counter" => Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "form", [], "any", false, false, false, 15), "children", [], "any", false, false, false, 15), "configuration", [], "any", false, false, false, 15))]]);
            // line 16
            yield "                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['section'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 17
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["sorted"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "name", [], "any", false, false, false, 17) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "name", [], "any", false, false, false, 17)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 18
            yield "                    <a class=\"list-group-item d-flex ps-4 pe-4 p-lg-3 pb-md-2 pt-md-2\" href=\"#conf_";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["section"], "id", [], "any", false, false, false, 18), "html", null, true);
            yield "\">
                        ";
            // line 19
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["section"], "name", [], "any", false, false, false, 19), "html", null, true);
            yield "
                        <small class=\"text-body-secondary ms-auto\">";
            // line 20
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["section"], "counter", [], "any", false, false, false, 20), "html", null, true);
            yield "</small>
                    </a>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['section'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 23
        yield "            </div>
        </div>
    </div>

    <div class=\"col-12 col-xxl-10 col-md-9\">
        <div class=\"row\">
            <div class=\"col-12\">
                ";
        // line 30
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 30)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 31
        yield "        
                ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sections"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["section"]) {
            // line 33
            yield "                    ";
            $context["title"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 33), "translation", [], "any", false, false, false, 33), [], CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 33), "translationDomain", [], "any", false, false, false, 33));
            // line 34
            yield "                    ";
            if ((($context["title"] ?? null) == CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 34), "translation", [], "any", false, false, false, 34))) {
                // line 35
                yield "                        ";
                $context["title"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["section"], "model", [], "any", false, false, false, 35), "section", [], "any", false, false, false, 35));
                // line 36
                yield "                    ";
            }
            // line 37
            yield "                    ";
            yield from $this->load("system-configuration/index.html.twig", 37, 1)->unwrap()->yield(CoreExtension::merge($context, ["title" => ($context["title"] ?? null), "form" => CoreExtension::getAttribute($this->env, $this->source, $context["section"], "form", [], "any", false, false, false, 37)]));
            // line 51
            yield "                ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['section'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 52
        yield "            </div>
        </div>
    </div>

</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "system-configuration/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  180 => 52,  165 => 51,  162 => 37,  159 => 36,  156 => 35,  153 => 34,  150 => 33,  133 => 32,  130 => 31,  128 => 30,  119 => 23,  109 => 20,  105 => 19,  100 => 18,  95 => 17,  88 => 16,  85 => 15,  82 => 14,  79 => 13,  76 => 12,  73 => 11,  68 => 10,  66 => 9,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "system-configuration/index.html.twig", "/opt/kimai/templates/system-configuration/index.html.twig");
    }
}


/* system-configuration/index.html.twig */
class __TwigTemplate_e95a6ad1b7d3591698884a8ade5d1f07___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_before' => [$this, 'block_form_before'],
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 37
        return $this->load(($context["formEditTemplate"] ?? null), 37);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 38
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "<span id=\"conf_";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["section"] ?? null), "model", [], "any", false, false, false, 38), "section", [], "any", false, false, false, 38), "html", null, true);
        yield "\"></span>";
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 40
        yield "                            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 40), "configuration", [], "any", false, false, false, 40));
        foreach ($context['_seq'] as $context["_key"] => $context["pref"]) {
            // line 41
            yield "                                ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["pref"], "vars", [], "any", false, false, false, 41), "data", [], "any", false, false, false, 41), "formTheme", [], "any", false, false, false, 41))) {
                // line 42
                yield "                                    ";
                $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme($context["pref"], [CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["pref"], "vars", [], "any", false, false, false, 42), "data", [], "any", false, false, false, 42), "formTheme", [], "any", false, false, false, 42)], true);
                // line 43
                yield "                                ";
            }
            // line 44
            yield "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['pref'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 45
        yield "                            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 45), "configuration", [], "any", false, false, false, 45));
        foreach ($context['_seq'] as $context["_key"] => $context["pref"]) {
            // line 46
            yield "                                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["pref"], 'widget');
            yield "
                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['pref'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 48
        yield "                            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
                        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "system-configuration/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  310 => 48,  300 => 46,  295 => 45,  288 => 44,  285 => 43,  282 => 42,  279 => 41,  274 => 40,  267 => 39,  254 => 38,  244 => 37,  180 => 52,  165 => 51,  162 => 37,  159 => 36,  156 => 35,  153 => 34,  150 => 33,  133 => 32,  130 => 31,  128 => 30,  119 => 23,  109 => 20,  105 => 19,  100 => 18,  95 => 17,  88 => 16,  85 => 15,  82 => 14,  79 => 13,  76 => 12,  73 => 11,  68 => 10,  66 => 9,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "system-configuration/index.html.twig", "/opt/kimai/templates/system-configuration/index.html.twig");
    }
}
