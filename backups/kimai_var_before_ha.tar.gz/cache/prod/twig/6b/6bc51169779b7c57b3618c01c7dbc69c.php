<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/edit.html.twig */
class __TwigTemplate_530ff8c66d1d227c6d9e978d2a8b4af6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => (((null === CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["project"] ?? null), "id", [], "any", false, false, false, 6))) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create-project")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"))), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project")];
        // line 10
        yield "    ";
        yield from $this->load("project/edit.html.twig", 10, 2)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/edit.html.twig", "/opt/kimai/templates/project/edit.html.twig");
    }
}


/* project/edit.html.twig */
class __TwigTemplate_530ff8c66d1d227c6d9e978d2a8b4af6___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 11)->unwrap();
        // line 10
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "            <div class=\"row\">
                <div class=\"col-md-9\">
                    ";
        // line 15
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 15), 'row');
        yield "
                </div>
                <div class=\"col-md-3\">
                    ";
        // line 18
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "color", [], "any", false, false, false, 18), 'row');
        yield "
                </div>
            </div>
            ";
        // line 21
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "comment", [], "any", false, false, false, 21), 'row');
        yield "
            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 24
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 24), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 27
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "number", [], "any", false, false, false, 27), 'row');
        yield "
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    ";
        // line 32
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "start", [], "any", false, false, false, 32), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 35
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "end", [], "any", false, false, false, 35), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 38
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "lockedUntil", [], "any", false, false, false, 38), 'row');
        yield "
                </div>
            </div>
            ";
        // line 41
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", true, true, false, 41)) {
            // line 42
            yield "            <div class=\"row\">
                ";
            // line 43
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", true, true, false, 43)) {
                // line 44
                yield "                <div class=\"col-md-4\">
                    ";
                // line 45
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", false, false, false, 45), 'row');
                yield "
                </div>
                ";
            }
            // line 48
            yield "                ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", true, true, false, 48)) {
                // line 49
                yield "                <div class=\"col-md-4\">
                    ";
                // line 50
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", false, false, false, 50), 'row');
                yield "
                </div>
                ";
            }
            // line 53
            yield "                <div class=\"col-md-4\">
                    ";
            // line 54
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", false, false, false, 54), 'row');
            yield "
                </div>
            </div>
            ";
        }
        // line 58
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 58)) {
            // line 59
            yield "                <div class=\"row\">
                    <div class=\"col-12\">
                        ";
            // line 61
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 61), 'row');
            yield "
                    </div>
                </div>
            ";
        }
        // line 65
        yield "            ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 65, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), null]);
        yield "
            ";
        // line 66
        yield from $this->load("project/edit.html.twig", 66, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => "project_invoice_settings"]));
        // line 85
        yield "            <div class=\"row\">
                <div class=\"col-md-4\">
                    ";
        // line 87
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "visible", [], "any", false, false, false, 87), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 90
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 90), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 93
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "globalActivities", [], "any", false, false, false, 93), 'row');
        yield "
                </div>
            </div>
            ";
        // line 96
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  279 => 96,  273 => 93,  267 => 90,  261 => 87,  257 => 85,  255 => 66,  250 => 65,  243 => 61,  239 => 59,  236 => 58,  229 => 54,  226 => 53,  220 => 50,  217 => 49,  214 => 48,  208 => 45,  205 => 44,  203 => 43,  200 => 42,  198 => 41,  192 => 38,  186 => 35,  180 => 32,  172 => 27,  166 => 24,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/edit.html.twig", "/opt/kimai/templates/project/edit.html.twig");
    }
}


/* project/edit.html.twig */
class __TwigTemplate_530ff8c66d1d227c6d9e978d2a8b4af6___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 66
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 67
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 67)->unwrap();
        // line 68
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 68)->unwrap();
        // line 66
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 66);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoices"), "html", null, true);
        yield from [];
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 71
        yield "                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
        // line 73
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderNumber", [], "any", false, false, false, 73), 'row');
        yield "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 76
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "orderDate", [], "any", false, false, false, 76), 'row');
        yield "
                        </div>
                    </div>
                    ";
        // line 79
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", true, true, false, 79)) {
            // line 80
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", false, false, false, 80), 'row');
            yield "
                    ";
        }
        // line 82
        yield "                    ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 82, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), "invoice"]);
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  398 => 82,  392 => 80,  390 => 79,  384 => 76,  378 => 73,  374 => 71,  367 => 70,  356 => 69,  351 => 66,  349 => 68,  347 => 67,  340 => 66,  279 => 96,  273 => 93,  267 => 90,  261 => 87,  257 => 85,  255 => 66,  250 => 65,  243 => 61,  239 => 59,  236 => 58,  229 => 54,  226 => 53,  220 => 50,  217 => 49,  214 => 48,  208 => 45,  205 => 44,  203 => 43,  200 => 42,  198 => 41,  192 => 38,  186 => 35,  180 => 32,  172 => 27,  166 => 24,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/edit.html.twig", "/opt/kimai/templates/project/edit.html.twig");
    }
}
