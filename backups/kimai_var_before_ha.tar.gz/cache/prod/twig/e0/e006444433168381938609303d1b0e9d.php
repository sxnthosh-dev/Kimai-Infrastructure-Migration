<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* emails/layout.html.twig */
class __TwigTemplate_88793278016e129af1e828863d478358 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'no_answer' => [$this, 'block_no_answer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $_v0 = ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "
    <spacer size=\"32\"></spacer>

    <h5>";
            // line 5
            yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
            yield "</h5>

    <spacer size=\"32\"></spacer>

    ";
            // line 9
            yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
            // line 10
            yield "
    <spacer size=\"32\"></spacer>

    ";
            // line 13
            yield from $this->unwrap()->yieldBlock('no_answer', $context, $blocks);
            // line 14
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
        // line 1
        yield (string) Twig\Extra\CssInliner\CssInlinerExtension::inlineCss(Twig\Extra\Inky\InkyExtension::inky($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($_v0, "html", null, true)), Twig\Extension\CoreExtension::source($this->env, "emails/css/emails.css"));
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_no_answer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "<p><small>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("automated_email_dont_answer", [], "email"), "html", null, true);
        yield "</small></p>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "emails/layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  99 => 13,  89 => 9,  79 => 5,  74 => 1,  69 => 14,  67 => 13,  62 => 10,  60 => 9,  53 => 5,  48 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "emails/layout.html.twig", "/opt/kimai/templates/emails/layout.html.twig");
    }
}
