<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/layout_vertical.html.twig */
class __TwigTemplate_fca94c91c2088a90234e4a79ea167615 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'html_start' => [$this, 'block_html_start'],
            'head' => [$this, 'block_head'],
            'title' => [$this, 'block_title'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'body_start' => [$this, 'block_body_start'],
            'body_class' => [$this, 'block_body_class'],
            'after_body_start' => [$this, 'block_after_body_start'],
            'navbar' => [$this, 'block_navbar'],
            'sidebar_id' => [$this, 'block_sidebar_id'],
            'app_logo' => [$this, 'block_app_logo'],
            'navbar_brand_classes' => [$this, 'block_navbar_brand_classes'],
            'navbar_brand_class' => [$this, 'block_navbar_brand_class'],
            'navbar_menu_start' => [$this, 'block_navbar_menu_start'],
            'navbar_menu_end' => [$this, 'block_navbar_menu_end'],
            'header' => [$this, 'block_header'],
            'header_id' => [$this, 'block_header_id'],
            'navbar_search' => [$this, 'block_navbar_search'],
            'page_wrapper' => [$this, 'block_page_wrapper'],
            'page_wrapper_id' => [$this, 'block_page_wrapper_id'],
            'page_wrapper_class' => [$this, 'block_page_wrapper_class'],
            'page_header' => [$this, 'block_page_header'],
            'page_header_id' => [$this, 'block_page_header_id'],
            'page_header_class' => [$this, 'block_page_header_class'],
            'page_intro' => [$this, 'block_page_intro'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'page_pretitle' => [$this, 'block_page_pretitle'],
            'page_title' => [$this, 'block_page_title'],
            'page_subtitle' => [$this, 'block_page_subtitle'],
            'page_actions_class' => [$this, 'block_page_actions_class'],
            'page_actions' => [$this, 'block_page_actions'],
            'page_body' => [$this, 'block_page_body'],
            'page_content_before' => [$this, 'block_page_content_before'],
            'page_content_start' => [$this, 'block_page_content_start'],
            'page_content' => [$this, 'block_page_content'],
            'page_content_end' => [$this, 'block_page_content_end'],
            'page_content_after' => [$this, 'block_page_content_after'],
            'footer' => [$this, 'block_footer'],
            'footer_id' => [$this, 'block_footer_id'],
            'footer_class' => [$this, 'block_footer_class'],
            'javascripts' => [$this, 'block_javascripts'],
            'navbar_start' => [$this, 'block_navbar_start'],
            'navbar_notifications' => [$this, 'block_navbar_notifications'],
            'navbar_user' => [$this, 'block_navbar_user'],
            'navbar_end' => [$this, 'block_navbar_end'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "<!doctype html";
        yield from $this->unwrap()->yieldBlock('html_start', $context, $blocks);
        yield ">
<html lang=\"";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "locale", [], "any", false, false, false, 10), "html", null, true);
        yield "\"";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 10)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " dir=\"rtl\"";
        }
        yield " data-bs-theme=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->theme(), "html", null, true);
        yield "\" data-bs-theme-base=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeBase", [], "method", false, false, false, 10), "html", null, true);
        yield "\" data-bs-theme-radius=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemeRadius", [], "method", false, false, false, 10), "html", null, true);
        yield "\" data-bs-theme-primary=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getThemePrimary", [], "method", false, false, false, 10), "html", null, true);
        yield "\">
<head>
    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('head', $context, $blocks);
        // line 15
        yield "    <title>";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>
    ";
        // line 16
        yield from $this->unwrap()->yieldBlock('stylesheets', $context, $blocks);
        // line 23
        yield "</head>
<body";
        // line 24
        yield from $this->unwrap()->yieldBlock('body_start', $context, $blocks);
        yield " class=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->bodyClass("antialiased"), "html", null, true);
        yield " ";
        yield from $this->unwrap()->yieldBlock('body_class', $context, $blocks);
        yield "\">
";
        // line 25
        yield from $this->unwrap()->yieldBlock('after_body_start', $context, $blocks);
        // line 26
        yield "<div class=\"page\">
    ";
        // line 27
        $context["navbarStartContent"] =         $this->unwrap()->renderBlock("navbar_start", $context, $blocks);
        // line 28
        yield "    ";
        $context["navbarNotificationsContent"] =         $this->unwrap()->renderBlock("navbar_notifications", $context, $blocks);
        // line 29
        yield "    ";
        $context["navbarUserContent"] =         $this->unwrap()->renderBlock("navbar_user", $context, $blocks);
        // line 30
        yield "    ";
        $context["navbarEndContent"] =         $this->unwrap()->renderBlock("navbar_end", $context, $blocks);
        // line 31
        yield "
    ";
        // line 33
        yield "    ";
        yield from $this->unwrap()->yieldBlock('navbar', $context, $blocks);
        // line 55
        yield "
    ";
        // line 56
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 77
        yield "    ";
        // line 78
        yield "
    ";
        // line 79
        yield from $this->unwrap()->yieldBlock('page_wrapper', $context, $blocks);
        // line 140
        yield "</div>

";
        // line 142
        yield from $this->unwrap()->yieldBlock('javascripts', $context, $blocks);
        // line 145
        yield "</body>
</html>

";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_html_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "        ";
        yield from $this->load("@Tabler/includes/html_head.html.twig", 13)->unwrap()->yield($context);
        // line 14
        yield "    ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from         $this->unwrap()->yieldBlock("page_title", $context, $blocks);
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "        ";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isRightToLeft", [], "method", false, false, false, 17)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 18
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler-rtl.css"), "html", null, true);
            yield "\">
        ";
        } else {
            // line 20
            yield "            <link rel=\"stylesheet\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.css"), "html", null, true);
            yield "\">
        ";
        }
        // line 22
        yield "    ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_after_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "        <aside id=\"";
        yield from $this->unwrap()->yieldBlock('sidebar_id', $context, $blocks);
        yield "\" class=\"navbar navbar-vertical navbar-expand-lg\"";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isNavbarDark", [], "method", false, false, false, 34)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " data-bs-theme=\"dark\"";
        }
        yield ">
            <div class=\"";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbar-menu\">
                    <span class=\"navbar-toggler-icon\"></span>
                </button>
                ";
        // line 39
        yield from $this->unwrap()->yieldBlock('app_logo', $context, $blocks);
        // line 44
        yield "                <div class=\"navbar-nav flex-row d-lg-none\">
                    ";
        // line 45
        yield (string) $this->getTemplateForMacro("macro_navbar", $context, 45, $this->getSourceContext())->macro_navbar(...[($context["navbarStartContent"] ?? null), ($context["navbarNotificationsContent"] ?? null), ($context["navbarUserContent"] ?? null), ($context["navbarEndContent"] ?? null)]);
        yield "
                </div>
                <div id=\"navbar-menu\" class=\"collapse navbar-collapse\">
                    ";
        // line 48
        yield from $this->unwrap()->yieldBlock('navbar_menu_start', $context, $blocks);
        // line 49
        yield "                    ";
        yield from $this->load("@Tabler/includes/menu.html.twig", 49)->unwrap()->yield(CoreExtension::merge($context, ["layout_type" => "vertical", "navbar_class" => "pt-lg-3"]));
        // line 50
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('navbar_menu_end', $context, $blocks);
        // line 51
        yield "                </div>
            </div>
        </aside>
    ";
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_sidebar_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_app_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 40
        yield "                    <h1 class=\"";
        yield from $this->unwrap()->yieldBlock('navbar_brand_classes', $context, $blocks);
        yield "\">
                        ";
        // line 41
        yield from $this->load("@Tabler/includes/logo.html.twig", 41)->unwrap()->yield($context);
        // line 42
        yield "                    </h1>
                ";
        yield from [];
    }

    // line 40
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand ";
        yield from $this->unwrap()->yieldBlock('navbar_brand_class', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand-autodark";
        yield from [];
    }

    // line 48
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_menu_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 56
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 57
        yield "        ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "isCondensedNavbar", [], "method", false, false, false, 57)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 58
            yield "            <header id=\"";
            yield from $this->unwrap()->yieldBlock('header_id', $context, $blocks);
            yield "\" class=\"navbar navbar-expand-md d-none d-lg-flex d-print-none\">
                <div class=\"";
            // line 59
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
            yield "\">
                    <button class=\"navbar-toggler\" type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#navbar-menu\">
                        <span class=\"navbar-toggler-icon\"></span>
                    </button>

                    <div class=\"navbar-nav flex-row order-md-last\">
                        ";
            // line 65
            yield (string) $this->getTemplateForMacro("macro_navbar", $context, 65, $this->getSourceContext())->macro_navbar(...[($context["navbarStartContent"] ?? null), ($context["navbarNotificationsContent"] ?? null), ($context["navbarUserContent"] ?? null), ($context["navbarEndContent"] ?? null)]);
            yield "
                    </div>

                    <div class=\"collapse navbar-collapse\" id=\"navbar-menu\">
                        ";
            // line 69
            yield from $this->unwrap()->yieldBlock('navbar_search', $context, $blocks);
            // line 72
            yield "                    </div>
                </div>
            </header>
        ";
        }
        // line 76
        yield "    ";
        yield from [];
    }

    // line 58
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_search(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 70
        yield "                            ";
        yield from $this->load("@Tabler/includes/navbar_search.html.twig", 70)->unwrap()->yield($context);
        // line 71
        yield "                        ";
        yield from [];
    }

    // line 79
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 80
        yield "        <div id=\"";
        yield from $this->unwrap()->yieldBlock('page_wrapper_id', $context, $blocks);
        yield "\" class=\"page-wrapper ";
        yield from $this->unwrap()->yieldBlock('page_wrapper_class', $context, $blocks);
        yield "\">
            ";
        // line 81
        yield from $this->unwrap()->yieldBlock('page_header', $context, $blocks);
        // line 118
        yield "
            ";
        // line 119
        yield from $this->unwrap()->yieldBlock('page_body', $context, $blocks);
        // line 130
        yield "
            ";
        // line 131
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 138
        yield "        </div>
    ";
        yield from [];
    }

    // line 80
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_wrapper_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 81
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 82
        yield "                <div id=\"";
        yield from $this->unwrap()->yieldBlock('page_header_id', $context, $blocks);
        yield "\" class=\"page-header d-print-none ";
        yield from $this->unwrap()->yieldBlock('page_header_class', $context, $blocks);
        yield "\">
                    <div class=\"";
        // line 83
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        <div class=\"row align-items-center\">
                            <div class=\"col\">
                            ";
        // line 86
        yield from $this->unwrap()->yieldBlock('page_intro', $context, $blocks);
        // line 101
        yield "                            </div>
                            <div class=\"";
        // line 102
        yield from $this->unwrap()->yieldBlock('page_actions_class', $context, $blocks);
        yield "\">
                                ";
        // line 103
        yield from $this->unwrap()->yieldBlock('page_actions', $context, $blocks);
        // line 113
        yield "                            </div>
                        </div>
                    </div>
                </div>
            ";
        yield from [];
    }

    // line 82
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_header_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 86
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_intro(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 87
        yield "                                ";
        yield from $this->unwrap()->yieldBlock('breadcrumb', $context, $blocks);
        // line 92
        yield "                                <h2 class=\"page-title\">
                                    ";
        // line 93
        yield from $this->unwrap()->yieldBlock('page_title', $context, $blocks);
        // line 94
        yield "                                </h2>
                                ";
        // line 95
        yield from $this->unwrap()->yieldBlock('page_subtitle', $context, $blocks);
        // line 100
        yield "                            ";
        yield from [];
    }

    // line 87
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_breadcrumb(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 88
        yield "                                    <div class=\"page-pretitle\">
                                        ";
        // line 89
        yield from $this->unwrap()->yieldBlock('page_pretitle', $context, $blocks);
        // line 90
        yield "                                    </div>
                                ";
        yield from [];
    }

    // line 89
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_pretitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Overview";
        yield from [];
    }

    // line 93
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Dashboard";
        yield from [];
    }

    // line 95
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_subtitle(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 96
        yield "                                    <div class=\"text-body-secondary mt-1\">
                                        1-10 of 100
                                    </div>
                                ";
        yield from [];
    }

    // line 102
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "col-auto ms-auto d-print-none";
        yield from [];
    }

    // line 103
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 104
        yield "                                    <div class=\"btn-list\">
                                        <a href=\"#\" class=\"btn btn-white\">
                                            New view
                                        </a>
                                        <a href=\"#\" class=\"btn btn-primary d-none d-sm-inline-block\">
                                            Create new report
                                        </a>
                                    </div>
                                ";
        yield from [];
    }

    // line 119
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 120
        yield "                <div class=\"page-body\">
                    <div class=\"";
        // line 121
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        ";
        // line 122
        yield from $this->unwrap()->yieldBlock('page_content_before', $context, $blocks);
        // line 123
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_start', $context, $blocks);
        // line 124
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content', $context, $blocks);
        // line 125
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_end', $context, $blocks);
        // line 126
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('page_content_after', $context, $blocks);
        // line 127
        yield "                    </div>
                </div>
            ";
        yield from [];
    }

    // line 122
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 123
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "@Tabler/includes/flash_messages.html.twig");
        yield from [];
    }

    // line 124
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 125
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 126
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 131
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 132
        yield "                <footer id=\"";
        yield from $this->unwrap()->yieldBlock('footer_id', $context, $blocks);
        yield "\" class=\"footer footer-transparent d-print-none ";
        yield from $this->unwrap()->yieldBlock('footer_class', $context, $blocks);
        yield "\">
                    <div class=\"";
        // line 133
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->containerClass(""), "html", null, true);
        yield "\">
                        ";
        // line 134
        yield from $this->load("@Tabler/includes/footer.html.twig", 134)->unwrap()->yield($context);
        // line 135
        yield "                    </div>
                </footer>
            ";
        yield from [];
    }

    // line 132
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_footer_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 142
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 143
        yield "    <script src=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("bundles/tabler/tabler.js"), "html", null, true);
        yield "\"></script>
";
        yield from [];
    }

    // line 149
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) (((array_key_exists("navbar_start", $context) &&  !(null === $context["navbar_start"]))) ? ($context["navbar_start"]) : (""));
        yield from [];
    }

    // line 150
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_notifications(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 151
        yield "        ";
        if (array_key_exists("navbar_notifications", $context)) {
            // line 152
            yield "            ";
            yield (string) ($context["navbar_notifications"] ?? null);
            yield "
        ";
        } else {
            // line 154
            yield "            ";
            yield from $this->load("@Tabler/includes/navbar_notifications.html.twig", 154)->unwrap()->yield($context);
            // line 155
            yield "        ";
        }
        // line 156
        yield "    ";
        yield from [];
    }

    // line 157
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 158
        yield "        ";
        if (array_key_exists("navbar_user", $context)) {
            // line 159
            yield "            ";
            yield (string) ($context["navbar_user"] ?? null);
            yield "
        ";
        } else {
            // line 161
            yield "            ";
            yield from $this->load("@Tabler/includes/navbar_user.html.twig", 161)->unwrap()->yield($context);
            // line 162
            yield "        ";
        }
        // line 163
        yield "    ";
        yield from [];
    }

    // line 164
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) (((array_key_exists("navbar_end", $context) &&  !(null === $context["navbar_end"]))) ? ($context["navbar_end"]) : (""));
        yield from [];
    }

    // line 148
    public function macro_navbar($navbar_start = null, $navbar_notifications = null, $navbar_user = null, $navbar_end = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "navbar_start" => $navbar_start,
            "navbar_notifications" => $navbar_notifications,
            "navbar_user" => $navbar_user,
            "navbar_end" => $navbar_end,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 149
            yield "    ";
            yield from $this->unwrap()->yieldBlock('navbar_start', $context, $blocks);
            // line 150
            yield "    ";
            yield from $this->unwrap()->yieldBlock('navbar_notifications', $context, $blocks);
            // line 157
            yield "    ";
            yield from $this->unwrap()->yieldBlock('navbar_user', $context, $blocks);
            // line 164
            yield "    ";
            yield from $this->unwrap()->yieldBlock('navbar_end', $context, $blocks);
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/layout_vertical.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  928 => 164,  925 => 157,  922 => 150,  919 => 149,  904 => 148,  893 => 164,  888 => 163,  885 => 162,  882 => 161,  876 => 159,  873 => 158,  866 => 157,  861 => 156,  858 => 155,  855 => 154,  849 => 152,  846 => 151,  839 => 150,  828 => 149,  820 => 143,  813 => 142,  794 => 132,  787 => 135,  785 => 134,  781 => 133,  774 => 132,  767 => 131,  757 => 126,  747 => 125,  737 => 124,  726 => 123,  716 => 122,  709 => 127,  706 => 126,  703 => 125,  700 => 124,  697 => 123,  695 => 122,  691 => 121,  688 => 120,  681 => 119,  668 => 104,  661 => 103,  650 => 102,  642 => 96,  635 => 95,  624 => 93,  613 => 89,  607 => 90,  605 => 89,  602 => 88,  595 => 87,  590 => 100,  588 => 95,  585 => 94,  583 => 93,  580 => 92,  577 => 87,  570 => 86,  551 => 82,  542 => 113,  540 => 103,  536 => 102,  533 => 101,  531 => 86,  525 => 83,  518 => 82,  511 => 81,  492 => 80,  486 => 138,  484 => 131,  481 => 130,  479 => 119,  476 => 118,  474 => 81,  467 => 80,  460 => 79,  455 => 71,  452 => 70,  445 => 69,  435 => 58,  430 => 76,  424 => 72,  422 => 69,  415 => 65,  406 => 59,  401 => 58,  398 => 57,  391 => 56,  381 => 50,  371 => 48,  349 => 40,  343 => 42,  341 => 41,  336 => 40,  329 => 39,  319 => 34,  311 => 51,  308 => 50,  305 => 49,  303 => 48,  297 => 45,  294 => 44,  292 => 39,  285 => 35,  276 => 34,  269 => 33,  259 => 25,  240 => 24,  235 => 22,  229 => 20,  223 => 18,  220 => 17,  213 => 16,  202 => 15,  197 => 14,  194 => 13,  187 => 12,  177 => 9,  169 => 145,  167 => 142,  163 => 140,  161 => 79,  158 => 78,  156 => 77,  154 => 56,  151 => 55,  148 => 33,  145 => 31,  142 => 30,  139 => 29,  136 => 28,  134 => 27,  131 => 26,  129 => 25,  121 => 24,  118 => 23,  116 => 16,  111 => 15,  109 => 12,  92 => 10,  87 => 9,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/layout_vertical.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/layout_vertical.html.twig");
    }
}
