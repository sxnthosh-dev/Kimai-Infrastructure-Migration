<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* team/edit.html.twig */
class __TwigTemplate_e8deaa96586cb46c7f03094f8d72390a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "<div class=\"row\">
    <div class=\"col-md-6\">
        ";
        // line 7
        yield from $this->load("team/member-form.html.twig", 7)->unwrap()->yield($context);
        // line 8
        yield "    </div>
    <div class=\"col-md-6\">
        ";
        // line 10
        if ((array_key_exists("customerForm", $context) &&  !(null === ($context["customerForm"] ?? null)))) {
            // line 11
            yield "            ";
            yield from $this->load("team/edit.html.twig", 11, 1)->unwrap()->yield(CoreExtension::merge($context, ["collapsible" => true, "collapsed" => (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "customers", [], "any", false, false, false, 11)) == 0)]));
            // line 21
            yield "        ";
        }
        // line 22
        yield "
        ";
        // line 23
        if ((array_key_exists("projectForm", $context) &&  !(null === ($context["projectForm"] ?? null)))) {
            // line 24
            yield "            ";
            yield from $this->load("team/edit.html.twig", 24, 2)->unwrap()->yield(CoreExtension::merge($context, ["collapsible" => true, "collapsed" => (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "projects", [], "any", false, false, false, 24)) == 0)]));
            // line 34
            yield "        ";
        }
        // line 35
        yield "    </div>
</div>
";
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 40
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, (event) => {
            /** @type {KimaiAPI} API */
            const API = event.detail.kimai.getPlugin(\x27api\x27);

            const successHandle = (json) => {
                document.dispatchEvent(new CustomEvent(\x27kimai.reloadedContent\x27));
            };
            const errorHandle = (error) => {
                document.dispatchEvent(new CustomEvent(\x27kimai.reloadedContent\x27));
                API.handleError(\x27action.update.error\x27, error);
            };

            ";
        // line 54
        if ((array_key_exists("customerForm", $context) &&  !(null === ($context["customerForm"] ?? null)))) {
            // line 55
            yield "                document.getElementById(\x27team_customer_form\x27).addEventListener(\x27change\x27,
                    (event) => {
                        if (event.target.matches(\x27input[type=checkbox]\x27)) {
                            document.dispatchEvent(new CustomEvent(\x27kimai.reloadContent\x27));
                            const checkbox = event.target;
                            const customerId = checkbox.value;
                            if (checkbox.checked) {
                                API.post(
                                    \x27";
            // line 63
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post_team_customer", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "id", [], "any", false, false, false, 63), "customerId" => "000"]), "html", null, true);
            yield "\x27.replace(/000/, customerId),
                                    {},
                                    successHandle,
                                    errorHandle,
                                );
                            } else {
                                API.delete(
                                    \x27";
            // line 70
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_team_customer", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "id", [], "any", false, false, false, 70), "customerId" => "000"]), "html", null, true);
            yield "\x27.replace(/000/, customerId),
                                    successHandle,
                                    errorHandle,
                                );
                            }
                        }
                    }
                );
            ";
        }
        // line 79
        yield "
            ";
        // line 80
        if ((array_key_exists("projectForm", $context) &&  !(null === ($context["customerForm"] ?? null)))) {
            // line 81
            yield "                document.getElementById(\x27team_project_form\x27).addEventListener(\x27change\x27,
                    (event) => {
                        if (event.target.matches(\x27input[type=checkbox]\x27)) {
                            document.dispatchEvent(new CustomEvent(\x27kimai.reloadContent\x27));
                            const checkbox = event.target;
                            const projectId = checkbox.value;
                            if (checkbox.checked) {
                                API.post(
                                    \x27";
            // line 89
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("post_team_project", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "id", [], "any", false, false, false, 89), "projectId" => "000"]), "html", null, true);
            yield "\x27.replace(/000/, projectId),
                                    {},
                                    successHandle,
                                    errorHandle,
                                );
                            } else {
                                API.delete(
                                    \x27";
            // line 96
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_team_project", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "id", [], "any", false, false, false, 96), "projectId" => "000"]), "html", null, true);
            yield "\x27.replace(/000/, projectId),
                                    successHandle,
                                    errorHandle,
                                );
                            }
                        }
                    }
                );
            ";
        }
        // line 105
        yield "        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "team/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  194 => 105,  182 => 96,  172 => 89,  162 => 81,  160 => 80,  157 => 79,  145 => 70,  135 => 63,  125 => 55,  123 => 54,  105 => 40,  98 => 39,  91 => 35,  88 => 34,  85 => 24,  83 => 23,  80 => 22,  77 => 21,  74 => 11,  72 => 10,  68 => 8,  66 => 7,  62 => 5,  55 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "team/edit.html.twig", "/opt/kimai/templates/team/edit.html.twig");
    }
}


/* team/edit.html.twig */
class __TwigTemplate_e8deaa96586cb46c7f03094f8d72390a___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 11
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        $macros["_v0"] = $this->macros["_v0"] = $this->load("macros/status.html.twig", 12)->unwrap();
        // line 11
        $this->parent = $this->load("@theme/embeds/card.html.twig", 11);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 14
        yield "                    ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("teams.customer_access", [], "teams"), "html", null, true);
        yield "
                    ";
        // line 15
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_status_count", $context, 15, $this->getSourceContext())->macro_status_count(...[Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "customers", [], "any", false, false, false, 15))]);
        yield "
                ";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "                    ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["customerForm"] ?? null), 'form');
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "team/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  295 => 18,  288 => 17,  281 => 15,  276 => 14,  269 => 13,  264 => 11,  262 => 12,  255 => 11,  194 => 105,  182 => 96,  172 => 89,  162 => 81,  160 => 80,  157 => 79,  145 => 70,  135 => 63,  125 => 55,  123 => 54,  105 => 40,  98 => 39,  91 => 35,  88 => 34,  85 => 24,  83 => 23,  80 => 22,  77 => 21,  74 => 11,  72 => 10,  68 => 8,  66 => 7,  62 => 5,  55 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "team/edit.html.twig", "/opt/kimai/templates/team/edit.html.twig");
    }
}


/* team/edit.html.twig */
class __TwigTemplate_e8deaa96586cb46c7f03094f8d72390a___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 24
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        $macros["_v1"] = $this->macros["_v1"] = $this->load("macros/status.html.twig", 25)->unwrap();
        // line 24
        $this->parent = $this->load("@theme/embeds/card.html.twig", 24);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "                    ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("teams.project_access", [], "teams"), "html", null, true);
        yield "
                    ";
        // line 28
        yield (string) $macros["_v1"]->getTemplateForMacro("macro_status_count", $context, 28, $this->getSourceContext())->macro_status_count(...[Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["team"] ?? null), "projects", [], "any", false, false, false, 28))]);
        yield "
                ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "                    ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["projectForm"] ?? null), 'form');
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "team/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  397 => 31,  390 => 30,  383 => 28,  378 => 27,  371 => 26,  366 => 24,  364 => 25,  357 => 24,  295 => 18,  288 => 17,  281 => 15,  276 => 14,  269 => 13,  264 => 11,  262 => 12,  255 => 11,  194 => 105,  182 => 96,  172 => 89,  162 => 81,  160 => 80,  157 => 79,  145 => 70,  135 => 63,  125 => 55,  123 => 54,  105 => 40,  98 => 39,  91 => 35,  88 => 34,  85 => 24,  83 => 23,  80 => 22,  77 => 21,  74 => 11,  72 => 10,  68 => 8,  66 => 7,  62 => 5,  55 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "team/edit.html.twig", "/opt/kimai/templates/team/edit.html.twig");
    }
}
