<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/project/daterange.html.twig */
class __TwigTemplate_ef302aae1444ccefddefae5fafeae6ab extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main_before' => [$this, 'block_main_before'],
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 2)->unwrap();
        // line 4
        $context["columns"] = ["name" => ["class" => "alwaysVisible"]];
        // line 7
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_time", "project")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 8
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["timeBudget" => ["class" => "d-none d-md-table-cell", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget")]]);
        }
        // line 12
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_money", "project")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 13
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["budget" => ["class" => "d-none d-md-table-cell", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget")]]);
        }
        // line 17
        $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["duration" => ["class" => "text-center hw-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "columnClass" => "w-min"]]);
        // line 20
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_rate_other_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 21
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["revenue" => ["class" => "text-center hw-min", "columnClass" => "w-min"], "costs" => ["class" => "text-center hw-min", "columnClass" => "w-min"], "profit" => ["class" => "text-center hw-min", "columnClass" => "w-min"]]);
        }
        // line 27
        $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["actions" => ["class" => "actions alwaysVisible"]]);
        // line 30
        $context["tableName"] = "project_daterange_reporting";
        // line 31
        $context["queryValue"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 31), "query", [], "any", false, false, false, 31), "get", ["view"], "method", false, false, false, 31);
        // line 1
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "    ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_modal", $context, 34, $this->getSourceContext())->macro_data_table_column_modal(...[($context["tableName"] ?? null), ($context["columns"] ?? null)]);
        yield "
";
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 38
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "month", [], "any", false, false, false, 38), 'widget', ["label" => false]);
        yield "
    ";
        // line 39
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 39), 'widget', ["label" => false, "placeholder" => "customer"]);
        yield "
    <div class=\"dropdown\">
        <button type=\"button\" class=\"btn dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
            ";
        // line 42
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("filter", true);
        yield "
        </button>
        <ul class=\"dropdown-menu checkbox-menu\">
            ";
        // line 45
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", false, false, false, 45), "children", [], "any", false, false, false, 45));
        foreach ($context['_seq'] as $context["_key"] => $context["option"]) {
            // line 46
            yield "                <li class=\"dropdown-item\">
                    ";
            // line 47
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock($context["option"], 'widget');
            yield "
                </li>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['option'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 50
        yield "            <li class=\"dropdown-divider\"></li>
            <li class=\"dropdown-item\">
                ";
        // line 52
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "includeNoWork", [], "any", false, false, false, 52), 'widget');
        yield "
            </li>
        </ul>
        <button onclick=\"";
        // line 55
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "view", [], "any", false, false, false, 55), "vars", [], "any", false, false, false, 55), "id", [], "any", false, false, false, 55), "html", null, true);
        yield ".value = ";
        yield (string) (((($context["queryValue"] ?? null) == "1")) ? (0) : (1));
        yield "\" type=\"submit\"  class=\"btn btn-icon ";
        if ((($context["queryValue"] ?? null) != "1")) {
            yield "active";
        }
        yield "\">
            ";
        // line 56
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("collapse", true);
        yield "
        </button>
    </div>
";
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 62
        yield "
    ";
        // line 63
        $context["hasData"] = (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["entries"] ?? null)) > 0);
        // line 64
        yield "
    ";
        // line 65
        yield from $this->load("reporting/project/daterange.html.twig", 65, 1)->unwrap()->yield($context);
        // line 233
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project/daterange.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  187 => 233,  185 => 65,  182 => 64,  180 => 63,  177 => 62,  170 => 61,  161 => 56,  151 => 55,  145 => 52,  141 => 50,  131 => 47,  128 => 46,  124 => 45,  118 => 42,  112 => 39,  107 => 38,  100 => 37,  92 => 34,  85 => 33,  80 => 1,  78 => 31,  76 => 30,  74 => 27,  70 => 21,  68 => 20,  66 => 17,  62 => 13,  60 => 12,  56 => 8,  54 => 7,  52 => 4,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project/daterange.html.twig", "/opt/kimai/templates/reporting/project/daterange.html.twig");
    }
}


/* reporting/project/daterange.html.twig */
class __TwigTemplate_ef302aae1444ccefddefae5fafeae6ab___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 65
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 66
        $macros["progress"] = $this->macros["progress"] = $this->load("macros/progressbar.html.twig", 66)->unwrap();
        // line 67
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 67)->unwrap();
        // line 68
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 68)->unwrap();
        // line 69
        $macros["projectActions"] = $this->macros["projectActions"] = $this->load("project/actions.html.twig", 69)->unwrap();
        // line 65
        $this->parent = $this->load("@theme/embeds/card.html.twig", 65);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tableName"] ?? null), "html", null, true);
        yield "-box ";
        if ((($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "p-0";
        }
        yield from [];
    }

    // line 71
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 72
        yield "            ";
        if ( !(($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 73
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 73, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
            ";
        } else {
            // line 75
            yield "                ";
            yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 75, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), null, ["boxClass" => ""]]);
            yield "

                ";
            // line 77
            if ((($context["queryValue"] ?? null) != "1")) {
                // line 78
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["entries"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer", [], "any", false, false, false, 78), "name", [], "any", false, false, false, 78) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer", [], "any", false, false, false, 78), "name", [], "any", false, false, false, 78)); }));
                foreach ($context['_seq'] as $context["id"] => $context["mapping"]) {
                    // line 79
                    yield "                        ";
                    $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 79), "currency", [], "any", false, false, false, 79);
                    // line 80
                    yield "                        ";
                    $context["totalDuration"] = 0;
                    // line 81
                    yield "                        ";
                    $context["totalRevenue"] = 0;
                    // line 82
                    yield "                        ";
                    $context["totalCosts"] = 0;
                    // line 83
                    yield "
                        ";
                    // line 84
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 84));
                    foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                        // line 85
                        yield "                            ";
                        $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 85), "duration", [], "any", false, false, false, 85));
                        // line 86
                        yield "                            ";
                        $context["totalRevenue"] = (($context["totalRevenue"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 86), "rateBillable", [], "any", false, false, false, 86));
                        // line 87
                        yield "                            ";
                        $context["totalCosts"] = (($context["totalCosts"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 87), "internalRate", [], "any", false, false, false, 87));
                        // line 88
                        yield "                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 89
                    yield "                        ";
                    $context["totalProfit"] = (($context["totalRevenue"] ?? null) - ($context["totalCosts"] ?? null));
                    // line 90
                    yield "
                        <tr class=\"summary\">
                            ";
                    // line 92
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                    foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                        // line 93
                        yield "                                <td class=\"";
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 93, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["name"]]);
                        yield "\">
                                    ";
                        // line 94
                        if (($context["name"] == "name")) {
                            // line 95
                            yield "                                        ";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 95, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 95)]);
                            yield "
                                    ";
                        } elseif ((                        // line 96
$context["name"] == "duration")) {
                            // line 97
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 98
$context["name"] == "revenue")) {
                            // line 99
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalRevenue"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 100
$context["name"] == "costs")) {
                            // line 101
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalCosts"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 102
$context["name"] == "profit")) {
                            // line 103
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalProfit"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        }
                        // line 105
                        yield "                                </td>
                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 107
                    yield "                        </tr>
                        ";
                    // line 108
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 108), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "entity", [], "any", false, false, false, 108), "name", [], "any", false, false, false, 108) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "entity", [], "any", false, false, false, 108), "name", [], "any", false, false, false, 108)); }));
                    foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                        // line 109
                        yield "                            ";
                        $context["project"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "entity", [], "any", false, false, false, 109);
                        // line 110
                        yield "                            <tr ";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 110, $this->getSourceContext())->macro_project_row_attr(...[($context["project"] ?? null), ($context["queryEnd"] ?? null)]);
                        yield ">
                            ";
                        // line 111
                        $context['_parent'] = $context;
                        $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                        foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                            // line 112
                            yield "                                <td class=\"";
                            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 112, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["name"]]);
                            yield "\">
                                ";
                            // line 113
                            if (($context["name"] == "name")) {
                                // line 114
                                yield "                                    ";
                                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 114, $this->getSourceContext())->macro_label_project(...[($context["project"] ?? null)]);
                                yield "
                                ";
                            } elseif ((                            // line 115
$context["name"] == "duration")) {
                                // line 116
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 116), "duration", [], "any", false, false, false, 116)), "html", null, true);
                                yield "
                                ";
                            } elseif ((                            // line 117
$context["name"] == "revenue")) {
                                // line 118
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 118), "rateBillable", [], "any", false, false, false, 118), ($context["currency"] ?? null)), "html", null, true);
                                yield "
                                ";
                            } elseif ((                            // line 119
$context["name"] == "costs")) {
                                // line 120
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 120), "internalRate", [], "any", false, false, false, 120), ($context["currency"] ?? null)), "html", null, true);
                                yield "
                                ";
                            } elseif ((                            // line 121
$context["name"] == "profit")) {
                                // line 122
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 122), "rateBillable", [], "any", false, false, false, 122) - CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 122), "internalRate", [], "any", false, false, false, 122)), ($context["currency"] ?? null)), "html", null, true);
                                yield "
                                ";
                            } elseif ((                            // line 123
$context["name"] == "timeBudget")) {
                                // line 124
                                yield "                                    ";
                                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 125
                                    yield "                                        ";
                                    yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_timebudget", $context, 125, $this->getSourceContext())->macro_progressbar_timebudget(...[$context["entry"]]);
                                    yield "
                                    ";
                                }
                                // line 127
                                yield "                                ";
                            } elseif (($context["name"] == "budget")) {
                                // line 128
                                yield "                                    ";
                                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                    // line 129
                                    yield "                                        ";
                                    yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_budget", $context, 129, $this->getSourceContext())->macro_progressbar_budget(...[$context["entry"], ($context["currency"] ?? null)]);
                                    yield "
                                    ";
                                }
                                // line 131
                                yield "                                ";
                            } elseif (($context["name"] == "actions")) {
                                // line 132
                                yield "                                    ";
                                yield (string) $macros["projectActions"]->getTemplateForMacro("macro_project", $context, 132, $this->getSourceContext())->macro_project(...[($context["project"] ?? null), "custom", true, ["daterange" => $this->extensions['App\Twig\Extensions']->buildDateRange(($context["queryBegin"] ?? null), ($context["queryEnd"] ?? null))]]);
                                yield "
                                ";
                            }
                            // line 134
                            yield "                                </td>
                            ";
                        }
                        $_parent = $context['_parent'];
                        unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
                        $context = array_intersect_key($context, $_parent);
                        $context += $_parent;
                        // line 136
                        yield "                            </tr>
                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 138
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['id'], $context['mapping'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 139
                yield "                ";
            } else {
                // line 140
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["entries"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer", [], "any", false, false, false, 140), "name", [], "any", false, false, false, 140) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer", [], "any", false, false, false, 140), "name", [], "any", false, false, false, 140)); }));
                foreach ($context['_seq'] as $context["id"] => $context["mapping"]) {
                    // line 141
                    yield "                        ";
                    $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 141), "currency", [], "any", false, false, false, 141);
                    // line 142
                    yield "                        ";
                    $context["totalDuration"] = 0;
                    // line 143
                    yield "                        ";
                    $context["totalRevenue"] = 0;
                    // line 144
                    yield "                        ";
                    $context["totalCosts"] = 0;
                    // line 145
                    yield "
                        ";
                    // line 146
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 146));
                    foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                        // line 147
                        yield "                            ";
                        $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 147), "duration", [], "any", false, false, false, 147));
                        // line 148
                        yield "                            ";
                        $context["totalRevenue"] = (($context["totalRevenue"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 148), "rateBillable", [], "any", false, false, false, 148));
                        // line 149
                        yield "                            ";
                        $context["totalCosts"] = (($context["totalCosts"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 149), "internalRate", [], "any", false, false, false, 149));
                        // line 150
                        yield "                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 151
                    yield "                        ";
                    $context["totalProfit"] = (($context["totalRevenue"] ?? null) - ($context["totalCosts"] ?? null));
                    // line 152
                    yield "
                        <tr>
                            ";
                    // line 154
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                    foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                        // line 155
                        yield "                                <td class=\"";
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 155, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["name"]]);
                        yield "\">
                                    ";
                        // line 156
                        if (($context["name"] == "name")) {
                            // line 157
                            yield "                                        ";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 157, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 157)]);
                            yield "
                                    ";
                        } elseif ((                        // line 158
$context["name"] == "duration")) {
                            // line 159
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 160
$context["name"] == "revenue")) {
                            // line 161
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalRevenue"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 162
$context["name"] == "costs")) {
                            // line 163
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalCosts"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        } elseif ((                        // line 164
$context["name"] == "profit")) {
                            // line 165
                            yield "                                        ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalProfit"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                    ";
                        }
                        // line 167
                        yield "                                </td>
                            ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 169
                    yield "                        </tr>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['id'], $context['mapping'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 171
                yield "                ";
            }
            // line 172
            yield "
                ";
            // line 173
            $context["grandTotalDuration"] = 0;
            // line 174
            yield "                ";
            $context["grandTotalRevenue"] = 0;
            // line 175
            yield "                ";
            $context["grandTotalCosts"] = 0;
            // line 176
            yield "                ";
            $context["grandTotalProfit"] = 0;
            // line 177
            yield "                ";
            $context["currencyTotal"] = null;
            // line 178
            yield "
                ";
            // line 179
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
            foreach ($context['_seq'] as $context["id"] => $context["mapping"]) {
                // line 180
                yield "                    ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 180), "currency", [], "any", false, false, false, 180);
                // line 181
                yield "                    ";
                if ((null === ($context["currencyTotal"] ?? null))) {
                    // line 182
                    yield "                        ";
                    $context["currencyTotal"] = ($context["currency"] ?? null);
                    // line 183
                    yield "                    ";
                }
                // line 184
                yield "                    ";
                if ((($context["currency"] ?? null) != ($context["currencyTotal"] ?? null))) {
                    // line 185
                    yield "                        ";
                    $context["currencyTotal"] = false;
                    // line 186
                    yield "                    ";
                }
                // line 187
                yield "                    ";
                $context["totalDuration"] = 0;
                // line 188
                yield "                    ";
                $context["totalRevenue"] = 0;
                // line 189
                yield "                    ";
                $context["totalCosts"] = 0;
                // line 190
                yield "
                    ";
                // line 192
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 192));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 193
                    yield "                        ";
                    $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 193), "duration", [], "any", false, false, false, 193));
                    // line 194
                    yield "                        ";
                    $context["totalRevenue"] = (($context["totalRevenue"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 194), "rateBillable", [], "any", false, false, false, 194));
                    // line 195
                    yield "                        ";
                    $context["totalCosts"] = (($context["totalCosts"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "statistic", [], "any", false, false, false, 195), "internalRate", [], "any", false, false, false, 195));
                    // line 196
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 197
                yield "
                    ";
                // line 198
                $context["totalProfit"] = (($context["totalRevenue"] ?? null) - ($context["totalCosts"] ?? null));
                // line 199
                yield "
                    ";
                // line 201
                yield "                    ";
                $context["grandTotalDuration"] = (($context["grandTotalDuration"] ?? null) + ($context["totalDuration"] ?? null));
                // line 202
                yield "                    ";
                $context["grandTotalRevenue"] = (($context["grandTotalRevenue"] ?? null) + ($context["totalRevenue"] ?? null));
                // line 203
                yield "                    ";
                $context["grandTotalCosts"] = (($context["grandTotalCosts"] ?? null) + ($context["totalCosts"] ?? null));
                // line 204
                yield "                    ";
                $context["grandTotalProfit"] = (($context["grandTotalProfit"] ?? null) + ($context["totalProfit"] ?? null));
                // line 205
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['mapping'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 206
            yield "
                ";
            // line 207
            if ((($context["currencyTotal"] ?? null) === false)) {
                // line 208
                yield "                    ";
                $context["currencyTotal"] = null;
                // line 209
                yield "                ";
            }
            // line 210
            yield "
                <tr class=\"summary\">
                    ";
            // line 212
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
            foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                // line 213
                yield "                        <td class=\"";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 213, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["name"]]);
                yield "\">
                            ";
                // line 214
                if (($context["name"] == "name")) {
                    // line 215
                    yield "                                <strong>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
                    yield "</strong>
                            ";
                } elseif ((                // line 216
$context["name"] == "duration")) {
                    // line 217
                    yield "                                <strong>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["grandTotalDuration"] ?? null)), "html", null, true);
                    yield "</strong>
                            ";
                } elseif ((                // line 218
$context["name"] == "revenue")) {
                    // line 219
                    yield "                                <strong>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["grandTotalRevenue"] ?? null), ($context["currencyTotal"] ?? null)), "html", null, true);
                    yield "</strong>
                            ";
                } elseif ((                // line 220
$context["name"] == "costs")) {
                    // line 221
                    yield "                                <strong>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["grandTotalCosts"] ?? null), ($context["currencyTotal"] ?? null)), "html", null, true);
                    yield "</strong>
                            ";
                } elseif ((                // line 222
$context["name"] == "profit")) {
                    // line 223
                    yield "                                <strong>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["grandTotalProfit"] ?? null), ($context["currencyTotal"] ?? null)), "html", null, true);
                    yield "</strong>
                            ";
                }
                // line 225
                yield "                        </td>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 227
            yield "                </tr>

                ";
            // line 229
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 229, $this->getSourceContext())->macro_data_table_footer(...[($context["entries"] ?? null)]);
            yield "
            ";
        }
        // line 231
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project/daterange.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  816 => 231,  811 => 229,  807 => 227,  799 => 225,  793 => 223,  791 => 222,  786 => 221,  784 => 220,  779 => 219,  777 => 218,  772 => 217,  770 => 216,  765 => 215,  763 => 214,  758 => 213,  754 => 212,  750 => 210,  747 => 209,  744 => 208,  742 => 207,  739 => 206,  732 => 205,  729 => 204,  726 => 203,  723 => 202,  720 => 201,  717 => 199,  715 => 198,  712 => 197,  705 => 196,  702 => 195,  699 => 194,  696 => 193,  691 => 192,  688 => 190,  685 => 189,  682 => 188,  679 => 187,  676 => 186,  673 => 185,  670 => 184,  667 => 183,  664 => 182,  661 => 181,  658 => 180,  654 => 179,  651 => 178,  648 => 177,  645 => 176,  642 => 175,  639 => 174,  637 => 173,  634 => 172,  631 => 171,  623 => 169,  615 => 167,  609 => 165,  607 => 164,  602 => 163,  600 => 162,  595 => 161,  593 => 160,  588 => 159,  586 => 158,  581 => 157,  579 => 156,  574 => 155,  570 => 154,  566 => 152,  563 => 151,  556 => 150,  553 => 149,  550 => 148,  547 => 147,  543 => 146,  540 => 145,  537 => 144,  534 => 143,  531 => 142,  528 => 141,  523 => 140,  520 => 139,  513 => 138,  505 => 136,  497 => 134,  491 => 132,  488 => 131,  482 => 129,  479 => 128,  476 => 127,  470 => 125,  467 => 124,  465 => 123,  460 => 122,  458 => 121,  453 => 120,  451 => 119,  446 => 118,  444 => 117,  439 => 116,  437 => 115,  432 => 114,  430 => 113,  425 => 112,  421 => 111,  416 => 110,  413 => 109,  409 => 108,  406 => 107,  398 => 105,  392 => 103,  390 => 102,  385 => 101,  383 => 100,  378 => 99,  376 => 98,  371 => 97,  369 => 96,  364 => 95,  362 => 94,  357 => 93,  353 => 92,  349 => 90,  346 => 89,  339 => 88,  336 => 87,  333 => 86,  330 => 85,  326 => 84,  323 => 83,  320 => 82,  317 => 81,  314 => 80,  311 => 79,  306 => 78,  304 => 77,  298 => 75,  292 => 73,  289 => 72,  282 => 71,  267 => 70,  262 => 65,  260 => 69,  258 => 68,  256 => 67,  254 => 66,  247 => 65,  187 => 233,  185 => 65,  182 => 64,  180 => 63,  177 => 62,  170 => 61,  161 => 56,  151 => 55,  145 => 52,  141 => 50,  131 => 47,  128 => 46,  124 => 45,  118 => 42,  112 => 39,  107 => 38,  100 => 37,  92 => 34,  85 => 33,  80 => 1,  78 => 31,  76 => 30,  74 => 27,  70 => 21,  68 => 20,  66 => 17,  62 => 13,  60 => 12,  56 => 8,  54 => 7,  52 => 4,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project/daterange.html.twig", "/opt/kimai/templates/reporting/project/daterange.html.twig");
    }
}
