<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/badge.html.twig */
class __TwigTemplate_b6b3f90bb63b0da1cfb5e8e149ac7299 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_badge($options_or_text = null, $class = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options_or_text" => $options_or_text,
            "class" => $class,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 4
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 4)->unwrap();
            // line 5
            yield "
    ";
            // line 7
            yield "    ";
            if (is_iterable(($context["options_or_text"] ?? null))) {
                // line 8
                yield "        ";
                $context["options"] = ($context["options_or_text"] ?? null);
                // line 9
                yield "    ";
            } else {
                // line 10
                yield "        ";
                trigger_deprecation('', '', "Passing multiple parameters to \x27badge()\x27 Tabler macro is deprecated, use options object syntax."." in \"@Tabler/components/badge.html.twig\" at line 10.");
                // line 11
                yield "        ";
                $context["options"] = ["content" =>                 // line 12
($context["options_or_text"] ?? null), "extraClass" =>                 // line 13
($context["class"] ?? null)];
                // line 15
                yield "    ";
            }
            // line 16
            yield "
    ";
            // line 18
            yield "    ";
            $context["_content"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", false, false, false, 18)) : (""));
            // line 19
            yield "    ";
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 19) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 19)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 19)) : (""));
            // line 20
            yield "    ";
            $context["_outline"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "outline", [], "any", true, true, false, 20) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "outline", [], "any", false, false, false, 20)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "outline", [], "any", false, false, false, 20)) : (false)) === true);
            // line 21
            yield "    ";
            $context["_pill"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pill", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pill", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "pill", [], "any", false, false, false, 21)) : (false)) === true);
            // line 22
            yield "    ";
            $context["_dot"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dot", [], "any", true, true, false, 22) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dot", [], "any", false, false, false, 22)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "dot", [], "any", false, false, false, 22)) : (false)) === true);
            // line 23
            yield "    ";
            $context["_notification"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "notification", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "notification", [], "any", false, false, false, 23)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "notification", [], "any", false, false, false, 23)) : (false)) === true);
            // line 24
            yield "    ";
            $context["_blink"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "blink", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "blink", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "blink", [], "any", false, false, false, 24)) : (false)) === true);
            // line 25
            yield "    ";
            $context["_size"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", true, true, false, 25) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", false, false, false, 25)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", false, false, false, 25)) : (""));
            // line 26
            yield "    ";
            $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", false, false, false, 26)) : (""));
            // line 27
            yield "    ";
            $context["_iconOnly"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "iconOnly", [], "any", true, true, false, 27) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "iconOnly", [], "any", false, false, false, 27)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "iconOnly", [], "any", false, false, false, 27)) : (false)) === true);
            // line 28
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 28)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 28)) : (""));
            // line 29
            yield "    ";
            $context["_raw"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", true, true, false, 29) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 29)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 29)) : (false)) === true);
            // line 30
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 30)) : ([]));
            // line 31
            yield "
    ";
            // line 32
            $context["classes"] = ["badge"];
            // line 33
            yield "
    ";
            // line 35
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_color"] ?? null))) {
                // line 36
                yield "        ";
                if ((($tmp = ($context["_outline"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 37
                    yield "            ";
                    $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("text-" . ($context["_color"] ?? null))]);
                    // line 38
                    yield "        ";
                } else {
                    // line 39
                    yield "            ";
                    if ( !Twig\Extension\CoreExtension::testEmpty(($context["_content"] ?? null))) {
                        // line 40
                        yield "                ";
                        $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("bg-" . ($context["_color"] ?? null)), (("text-" . ($context["_color"] ?? null)) . "-fg")]);
                        // line 41
                        yield "            ";
                    } else {
                        // line 42
                        yield "                ";
                        $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("bg-" . ($context["_color"] ?? null))]);
                        // line 43
                        yield "            ";
                    }
                    // line 44
                    yield "        ";
                }
                // line 45
                yield "    ";
            }
            // line 46
            yield "
    ";
            // line 48
            yield "    ";
            if ((($tmp = ($context["_outline"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 49
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-outline"]);
                // line 50
                yield "    ";
            }
            // line 51
            yield "
    ";
            // line 53
            yield "    ";
            if ((($tmp = ($context["_pill"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 54
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-pill"]);
                // line 55
                yield "    ";
            }
            // line 56
            yield "
    ";
            // line 58
            yield "    ";
            if ((($tmp = ($context["_dot"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 59
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-dot"]);
                // line 60
                yield "    ";
            }
            // line 61
            yield "
    ";
            // line 63
            yield "    ";
            if ((($tmp = ($context["_notification"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 64
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-notification"]);
                // line 65
                yield "    ";
            }
            // line 66
            yield "
    ";
            // line 68
            yield "    ";
            if ((($tmp = ($context["_blink"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 69
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-blink"]);
                // line 70
                yield "    ";
            }
            // line 71
            yield "
    ";
            // line 73
            yield "    ";
            if ((($tmp = ($context["_iconOnly"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 74
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["badge-icononly"]);
                // line 75
                yield "    ";
            }
            // line 76
            yield "
    ";
            // line 78
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_size"] ?? null))) {
                // line 79
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("badge-" . ($context["_size"] ?? null))]);
                // line 80
                yield "    ";
            }
            // line 81
            yield "
    ";
            // line 83
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_extraClass"] ?? null))) {
                // line 84
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [($context["_extraClass"] ?? null)]);
                // line 85
                yield "    ";
            }
            // line 86
            yield "
    ";
            // line 87
            $context["classesStr"] = Twig\Extension\CoreExtension::join(($context["classes"] ?? null), " ");
            // line 88
            yield "    ";
            $context["content"] = (((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? (($context["_content"] ?? null)) : (($context["_content"] ?? null)));
            // line 89
            yield "
    ";
            // line 91
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_href"] ?? null))) {
                // line 92
                yield "        <a href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
                yield "\" class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classesStr"] ?? null), "html", null, true);
                yield "\" ";
                yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 92, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                yield ">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["content"] ?? null), "html", null, true);
                yield "</a>
    ";
            } else {
                // line 94
                yield "        <span class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classesStr"] ?? null), "html", null, true);
                yield "\" ";
                yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 94, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                yield ">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["content"] ?? null), "html", null, true);
                yield "</span>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/badge.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  290 => 94,  278 => 92,  275 => 91,  272 => 89,  269 => 88,  267 => 87,  264 => 86,  261 => 85,  258 => 84,  255 => 83,  252 => 81,  249 => 80,  246 => 79,  243 => 78,  240 => 76,  237 => 75,  234 => 74,  231 => 73,  228 => 71,  225 => 70,  222 => 69,  219 => 68,  216 => 66,  213 => 65,  210 => 64,  207 => 63,  204 => 61,  201 => 60,  198 => 59,  195 => 58,  192 => 56,  189 => 55,  186 => 54,  183 => 53,  180 => 51,  177 => 50,  174 => 49,  171 => 48,  168 => 46,  165 => 45,  162 => 44,  159 => 43,  156 => 42,  153 => 41,  150 => 40,  147 => 39,  144 => 38,  141 => 37,  138 => 36,  135 => 35,  132 => 33,  130 => 32,  127 => 31,  124 => 30,  121 => 29,  118 => 28,  115 => 27,  112 => 26,  109 => 25,  106 => 24,  103 => 23,  100 => 22,  97 => 21,  94 => 20,  91 => 19,  88 => 18,  85 => 16,  82 => 15,  80 => 13,  79 => 12,  77 => 11,  74 => 10,  71 => 9,  68 => 8,  65 => 7,  62 => 5,  59 => 4,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/badge.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/badge.html.twig");
    }
}
