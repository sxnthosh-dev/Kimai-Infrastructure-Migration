<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-dailyworkingtimechart.html.twig */
class __TwigTemplate_e8828d7fd9bc7cca2bb4457c09aa5743 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["type"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", true, true, false, 1)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "type", [], "any", false, false, false, 1), "bar")) : ("bar"));
        // line 2
        $context["chart_id"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 2);
        // line 3
        $context["backgroundColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.background_color");
        // line 4
        $context["gridColor"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.grid_color");
        // line 5
        $context["activities"] = CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "activities", [], "any", false, false, false, 5);
        // line 6
        $context["data"] = CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "data", [], "any", false, false, false, 6);
        // line 7
        yield "
<div class=\"chart\">
    <canvas id=\"";
        // line 9
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chart_id"] ?? null), "html", null, true);
        yield "\" style=\"height: ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "theme.chart.height"), "html", null, true);
        yield "px; width: 100%;\"></canvas>
</div>

<script type=\"text/javascript\">
    var myChart = null;

    var paintChart = function() {
        myChart = new Chart(
            document.getElementById(\x27";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["chart_id"] ?? null), "html", null, true);
        yield "\x27).getContext(\x272d\x27), {
                type: \x27";
        // line 18
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["type"] ?? null), "html", null, true);
        yield "\x27,
                data: {
                    labels: [
                        ";
        // line 21
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
            // line 22
            yield "\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "day", [], "any", false, false, false, 22), "d."), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->monthName(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "day", [], "any", false, false, false, 22), true), "html", null, true);
            yield "\x27
                        ";
            // line 23
            if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 23)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield ",";
            }
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['day'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 25
        yield "                    ],
                    datasets: [
                        ";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["activities"] ?? null));
        foreach ($context['_seq'] as $context["activityId"] => $context["activity"]) {
            // line 28
            $context["activityColor"] = Twig\Extension\CoreExtension::default($this->extensions['App\Twig\Extensions']->color(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "activity", [], "any", false, false, false, 28)), Twig\Extension\CoreExtension::default($this->extensions['App\Twig\Extensions']->color(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "project", [], "any", false, false, false, 28)), ($context["backgroundColor"] ?? null)));
            // line 29
            yield "                        ";
            $context["activityName"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "activity", [], "any", false, false, false, 29), "name", [], "any", false, false, false, 29);
            // line 30
            yield "                        {
                            label: \x27";
            // line 31
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["activityName"] ?? null), "html", null, true);
            yield "\x27,
                            backgroundColor: \x27";
            // line 32
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["activityColor"] ?? null), "html", null, true);
            yield "\x27,
                            borderColor: \x27#fff\x27,
                            borderWidth: 1,
                            data: [";
            // line 36
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
                // line 37
                $context["realDayData"] = null;
                // line 38
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "details", [], "any", false, false, false, 38));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 39
                    $context["loopId"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 39), "id", [], "any", false, false, false, 39) . "_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 39), "id", [], "any", false, false, false, 39));
                    // line 40
                    if ((($context["loopId"] ?? null) == $context["activityId"])) {
                        // line 41
                        $context["realDayData"] = $this->extensions['App\Twig\LocaleFormatExtensions']->durationChart(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 41));
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 44
                if ( !(null === ($context["realDayData"] ?? null))) {
                    // line 45
                    yield "\x27";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["realDayData"] ?? null), "html", null, true);
                    yield "\x27";
                } else {
                    // line 47
                    yield "0";
                }
                // line 49
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 49)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield ",";
                }
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['day'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 51
            yield "],
                            realData: [";
            // line 53
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["data"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["day"]) {
                // line 54
                $context["realDayData"] = null;
                // line 55
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "details", [], "any", false, false, false, 55));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 56
                    $context["loopId"] = ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 56), "id", [], "any", false, false, false, 56) . "_") . CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 56), "id", [], "any", false, false, false, 56));
                    // line 57
                    if ((($context["loopId"] ?? null) == $context["activityId"])) {
                        // line 58
                        $context["realDayData"] = ["duration" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 58)), "billable" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "totalDurationBillable", [], "any", false, false, false, 58)), "project" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 58), "name", [], "any", false, false, false, 58), "customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 58), "customer", [], "any", false, false, false, 58), "name", [], "any", false, false, false, 58), "activity" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 58), "name", [], "any", false, false, false, 58), "total" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["day"], "totalDuration", [], "any", false, false, false, 58))];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 61
                if ( !(null === ($context["realDayData"] ?? null))) {
                    // line 62
                    yield (string) json_encode(($context["realDayData"] ?? null));
                } else {
                    // line 64
                    yield "0";
                }
                // line 66
                if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 66)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield ",";
                }
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['day'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 68
            yield "]
                        },";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['activityId'], $context['activity'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 71
        yield "                    ]
                },
                options: {
                    maintainAspectRatio: true,
                    responsive: false,
                    barPercentage: 0.5,
                    categoryPercentage: 1.0,
                    scales: {
                        x: {
                            stacked: true,
                            gridLines: {
                                display: false
                            },
                        },
                        y: {
                            stacked: true,
                            ticks: {
                                beginAtZero: true
                            },
                            gridLines: {
                                display: true,
                                color: \x27";
        // line 92
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["gridColor"] ?? null), "html", null, true);
        yield "\x27,
                                lineWidth: 1
                            }
                        },
                    },
                    plugins: {
                        legend: {
                            display: false,
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                    return \x27 \x27 + tooltipData.duration + \x27: \x27 + tooltipData.activity;
                                },
                                beforeTitle: function(tooltipItems) {
                                    const tooltipItem = tooltipItems[0];
                                    const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                    return tooltipData.customer;
                                },
                                title: function(tooltipItems) {
                                    const tooltipItem = tooltipItems[0];
                                    const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                    return tooltipData.project;
                                },
                                afterTitle: function(tooltipItems) {
                                    return \x27 \x27;
                                },
                                footer: function(tooltipItems) {
                                    const tooltipItem = tooltipItems[0];
                                    const tooltipData = tooltipItem.dataset.realData[tooltipItem.dataIndex];
                                    return \x27";
        // line 123
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal"), "html", null, true);
        yield ": \x27 + tooltipData.total + \x27\\n";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
        yield ": \x27 + tooltipData.billable;
                                },
                                beforeFooter: function(tooltipItems) {
                                    return \x27 \x27;
                                },
                            },
                        }
                    },
                }
            }
        );
    };
    
    var destroyChart = function () {
        myChart.destroy();
    };

    ";
        // line 140
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "javascriptRequest", [], "any", false, false, false, 140)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 141
            yield "        paintChart();
    ";
        } else {
            // line 143
            yield "        if (document.getElementById(\x27dashboard-grid-container\x27) !== null) {
            document.addEventListener(\x27dashboard.initialized\x27, paintChart);
        } else {
            document.addEventListener(\x27kimai.initialized\x27, paintChart);
        }
    ";
        }
        // line 149
        yield "</script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-dailyworkingtimechart.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  375 => 149,  367 => 143,  363 => 141,  361 => 140,  339 => 123,  305 => 92,  282 => 71,  274 => 68,  257 => 66,  254 => 64,  251 => 62,  249 => 61,  241 => 58,  239 => 57,  237 => 56,  233 => 55,  231 => 54,  214 => 53,  211 => 51,  194 => 49,  191 => 47,  186 => 45,  184 => 44,  176 => 41,  174 => 40,  172 => 39,  168 => 38,  166 => 37,  149 => 36,  143 => 32,  139 => 31,  136 => 30,  133 => 29,  131 => 28,  127 => 27,  123 => 25,  106 => 23,  99 => 22,  82 => 21,  76 => 18,  72 => 17,  59 => 9,  55 => 7,  53 => 6,  51 => 5,  49 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-dailyworkingtimechart.html.twig", "/opt/kimai/templates/widget/widget-dailyworkingtimechart.html.twig");
    }
}
