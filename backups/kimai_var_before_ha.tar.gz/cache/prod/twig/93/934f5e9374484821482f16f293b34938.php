<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/renderer/timesheet.html.twig */
class __TwigTemplate_7390a804224f147a4ee4bcc2238af553 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v0 = ($context["invoice"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["invoice.language"] ?? null) : null), "html", null, true);
        yield "\">
<head>
    <meta charset=\"utf-8\">
    <meta content=\"width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no\" name=\"viewport\">
    <title>";
        // line 6
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v1 = ($context["invoice"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["invoice.number"] ?? null) : null), "html", null, true);
        yield "-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $this->extensions['Twig\Extra\String\StringExtension']->createUnicodeString(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 6)) ? (Twig\Extension\CoreExtension::default((($_v2 = ($context["invoice"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["customer.company"] ?? null) : null), (($_v3 = ($context["invoice"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["customer.name"] ?? null) : null))) : ((($_v4 = ($context["invoice"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["customer.name"] ?? null) : null)))), "snake", [], "any", false, false, false, 6), "html", null, true);
        yield "</title>
    <style>
        ";
        // line 8
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("invoice");
        yield "
    </style>
</head>
<body class=\"invoice_print\">
    <div class=\"wrapper\">
        <section class=\"invoice\">

            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <h2 class=\"page-header\">
                        <span contenteditable=\"true\">";
        // line 18
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v5 = ($context["invoice"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["template.title"] ?? null) : null), "html", null, true);
        yield "</span>
                    </h2>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-xs-12\">
                    <table class=\"table no-border table-sm\">
                        <tr>
                            <th class=\"ps-0\">";
        // line 27
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.from"), "html", null, true);
        yield "</th>
                            <td contenteditable=\"true\">
                                ";
        // line 29
        if (( !(($tmp = (($_v6 = ($context["invoice"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["user.see_others"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "user.display", [], "array", true, true, false, 29))) {
            // line 30
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v7 = ($context["invoice"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["user.display"] ?? null) : null), "html", null, true);
            yield "
                                ";
        } else {
            // line 32
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v8 = ($context["invoice"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["template.company"] ?? null) : null), "html", null, true);
            yield "
                                ";
        }
        // line 34
        yield "                            </td>
                        </tr>
                        <tr>
                            <th class=\"ps-0\">";
        // line 37
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</th>
                            <td contenteditable=\"true\">
                                ";
        // line 39
        if ((((($_v9 = ($context["invoice"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["invoice.first_month"] ?? null) : null) != (($_v10 = ($context["invoice"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["invoice.last_month"] ?? null) : null)) || ((($_v11 = ($context["invoice"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["invoice.first_year"] ?? null) : null) != (($_v12 = ($context["invoice"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["invoice.last_year"] ?? null) : null)))) {
            // line 40
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v13 = ($context["invoice"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["invoice.first"] ?? null) : null), "html", null, true);
            yield " - ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v14 = ($context["invoice"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["invoice.last"] ?? null) : null), "html", null, true);
            yield "
                                ";
        } else {
            // line 42
            yield "                                    ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v15 = ($context["invoice"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["invoice.last_month"] ?? null) : null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v16 = ($context["invoice"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["invoice.last_year"] ?? null) : null), "html", null, true);
            yield "
                                ";
        }
        // line 44
        yield "                            </td>
                        </tr>
                        <tr>
                            <th class=\"ps-0\">";
        // line 47
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                            <td contenteditable=\"true\">
                                ";
        // line 49
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v17 = ($context["invoice"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["customer.number"] ?? null) : null))) {
            // line 50
            yield "                                    [";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v18 = ($context["invoice"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["customer.number"] ?? null) : null), "html", null, true);
            yield "]
                                ";
        }
        // line 52
        yield "                                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v19 = ($context["invoice"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["customer.name"] ?? null) : null), "html", null, true);
        yield "
                                ";
        // line 53
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v20 = ($context["invoice"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20["customer.contact"] ?? null) : null))) {
            // line 54
            yield "                                    / ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v21 = ($context["invoice"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21["customer.contact"] ?? null) : null), "html", null, true);
            yield "
                                ";
        }
        // line 56
        yield "                            </td>
                        </tr>
                        ";
        // line 58
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "query.project.name", [], "array", true, true, false, 58)) {
            // line 59
            yield "                            <tr>
                                <th class=\"ps-0\">";
            // line 60
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
            yield "</th>
                                <td contenteditable=\"true\">
                                    ";
            // line 62
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v22 = ($context["invoice"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22["query.project.name"] ?? null) : null), "html", null, true);
            yield "
                                    ";
            // line 63
            if ( !Twig\Extension\CoreExtension::testEmpty((($_v23 = ($context["invoice"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23["query.project.order_number"] ?? null) : null))) {
                // line 64
                yield "                                        (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderNumber"), "html", null, true);
                yield ": ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v24 = ($context["invoice"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24["query.project.order_number"] ?? null) : null), "html", null, true);
                yield ")
                                    ";
            }
            // line 66
            yield "                                </td>
                            </tr>
                        ";
        }
        // line 69
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "query.activity.name", [], "array", true, true, false, 69)) {
            // line 70
            yield "                            <tr>
                                <th class=\"ps-0\">";
            // line 71
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
            yield "</th>
                                <td contenteditable=\"true\">
                                    ";
            // line 73
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v25 = ($context["invoice"] ?? null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25["query.activity.name"] ?? null) : null), "html", null, true);
            yield "
                                </td>
                            </tr>
                        ";
        }
        // line 77
        yield "                    </table>
                </div>
            </div>

            <div class=\"row invoice-items mt-2 mb-3\">
                <div class=\"col-xs-12 table-responsive\">
                    <table class=\"table table-striped\">
                        <thead>
                        <tr>
                            <th>";
        // line 86
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</th>
                            ";
        // line 87
        if ((($tmp = (($_v26 = ($context["invoice"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26["user.see_others"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 88
            yield "                                <th>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
            yield "</th>
                            ";
        }
        // line 90
        yield "                            <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
        yield "</th>
                            <th class=\"text-right\">";
        // line 91
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hours"), "html", null, true);
        yield "</th>
                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 95
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["timesheet"]) {
            // line 96
            yield "                            <tr>
                                <td>";
            // line 97
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v27 = $context["timesheet"]) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27["entry.begin"] ?? null) : null), "html", null, true);
            yield "</td>
                                ";
            // line 98
            if ((($tmp = (($_v28 = ($context["invoice"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28["user.see_others"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 99
                yield "                                    <td>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v29 = $context["timesheet"]) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29["entry.user_display"] ?? null) : null), "html", null, true);
                yield "</td>
                                ";
            }
            // line 101
            yield "                                <td contenteditable=\"true\">
                                    ";
            // line 102
            if ( !Twig\Extension\CoreExtension::testEmpty((($_v30 = $context["timesheet"]) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30["entry.description"] ?? null) : null))) {
                // line 103
                yield "                                        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v31 = $context["timesheet"]) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["entry.description"] ?? null) : null), "html", null, true));
                yield "
                                    ";
            } else {
                // line 105
                yield "                                        ";
                if (CoreExtension::getAttribute($this->env, $this->source, $context["timesheet"], "entry.activity", [], "array", true, true, false, 105)) {
                    // line 106
                    yield "                                            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v32 = $context["timesheet"]) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["entry.activity"] ?? null) : null), "html", null, true);
                    yield " /
                                        ";
                }
                // line 108
                yield "                                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v33 = $context["timesheet"]) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["entry.project"] ?? null) : null), "html", null, true);
                yield "
                                    ";
            }
            // line 110
            yield "                                </td>
                                <td class=\"text-right text-nowrap\">";
            // line 111
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v34 = $context["timesheet"]) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["entry.amount"] ?? null) : null), "html", null, true);
            yield "</td>
                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['timesheet'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 114
        yield "                        </tbody>
                        <tfoot>
                        <tr>
                            <th></th>
                            ";
        // line 118
        if ((($tmp = (($_v35 = ($context["invoice"] ?? null)) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["user.see_others"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 119
            yield "                                <th></th>
                            ";
        }
        // line 121
        yield "                            <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.total_working_time"), "html", null, true);
        yield "</th>
                            <th class=\"text-right text-nowrap\">";
        // line 122
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v36 = ($context["invoice"] ?? null)) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["invoice.duration_decimal"] ?? null) : null), "html", null, true);
        yield "</th>
                        </tr>
                        </tfoot>
                    </table>
                </div>
            </div>

            <div class=\"row\">
                <div class=\"col-xs-12\">
                    ";
        // line 131
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v37 = ($context["invoice"] ?? null)) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["template.payment_terms"] ?? null) : null))) {
            // line 132
            yield "                        <p class=\"lead\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("payment_terms"), "html", null, true);
            yield "</p>

                        <div class=\"paymentTerms\" contenteditable=\"true\" style=\"margin-bottom: 100px\">
                            ";
            // line 135
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v38 = ($context["invoice"] ?? null)) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["template.payment_terms"] ?? null) : null));
            yield "
                        </div>
                    ";
        }
        // line 138
        yield "
                    <div class=\"table-responsive\">
                        <p class=\"bt-1 pb-4 pt-1\">";
        // line 140
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.signature_user"), "html", null, true);
        yield "</p>
                        <p class=\"bt-1 pb-4 pt-1\">";
        // line 141
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.signature_customer"), "html", null, true);
        yield "</p>
                    </div>
                </div>
            </div>

        </section>
    </div>
</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/renderer/timesheet.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  359 => 141,  355 => 140,  351 => 138,  345 => 135,  338 => 132,  336 => 131,  324 => 122,  319 => 121,  315 => 119,  313 => 118,  307 => 114,  297 => 111,  294 => 110,  288 => 108,  282 => 106,  279 => 105,  273 => 103,  271 => 102,  268 => 101,  262 => 99,  260 => 98,  256 => 97,  253 => 96,  249 => 95,  242 => 91,  237 => 90,  231 => 88,  229 => 87,  225 => 86,  214 => 77,  207 => 73,  202 => 71,  199 => 70,  196 => 69,  191 => 66,  183 => 64,  181 => 63,  177 => 62,  172 => 60,  169 => 59,  167 => 58,  163 => 56,  157 => 54,  155 => 53,  150 => 52,  144 => 50,  142 => 49,  137 => 47,  132 => 44,  124 => 42,  116 => 40,  114 => 39,  109 => 37,  104 => 34,  98 => 32,  92 => 30,  90 => 29,  85 => 27,  73 => 18,  60 => 8,  53 => 6,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/renderer/timesheet.html.twig", "/opt/kimai/templates/invoice/renderer/timesheet.html.twig");
    }
}
