<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/pdf-layout.html.twig */
class __TwigTemplate_5c05ad77031d67895e90a1a27f5f83cc extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'document_title' => [$this, 'block_document_title'],
            'styles' => [$this, 'block_styles'],
            'pdf_footer' => [$this, 'block_pdf_footer'],
            'body_start' => [$this, 'block_body_start'],
            'summary' => [$this, 'block_summary'],
            'summary_header' => [$this, 'block_summary_header'],
            'title' => [$this, 'block_title'],
            'summary_head_row_start' => [$this, 'block_summary_head_row_start'],
            'summary_head_row_end' => [$this, 'block_summary_head_row_end'],
            'summary_customer_row_start' => [$this, 'block_summary_customer_row_start'],
            'summary_customer_row_end' => [$this, 'block_summary_customer_row_end'],
            'summary_project_row_start' => [$this, 'block_summary_project_row_start'],
            'summary_project_row_end' => [$this, 'block_summary_project_row_end'],
            'summary_customer_summary_row_start' => [$this, 'block_summary_customer_summary_row_start'],
            'summary_customer_summary_row_end' => [$this, 'block_summary_customer_summary_row_end'],
            'summary_summary_row_start' => [$this, 'block_summary_summary_row_start'],
            'summary_summary_row_end' => [$this, 'block_summary_summary_row_end'],
            'items' => [$this, 'block_items'],
            'items_header' => [$this, 'block_items_header'],
            'items_head_row_start' => [$this, 'block_items_head_row_start'],
            'items_head_row_end' => [$this, 'block_items_head_row_end'],
            'items_entry_row_start' => [$this, 'block_items_entry_row_start'],
            'date_begin' => [$this, 'block_date_begin'],
            'date_end' => [$this, 'block_date_end'],
            'description' => [$this, 'block_description'],
            'items_entry_row_end' => [$this, 'block_items_entry_row_end'],
            'items_summary' => [$this, 'block_items_summary'],
            'items_summary_row_start' => [$this, 'block_items_summary_row_start'],
            'items_summary_row_end' => [$this, 'block_items_summary_row_end'],
            'body_end' => [$this, 'block_body_end'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["showUserColumn"] = (((array_key_exists("showUserColumn", $context) &&  !(null === $context["showUserColumn"]))) ? ($context["showUserColumn"]) : (true));
        // line 2
        $context["showInternalRate"] = (((array_key_exists("showInternalRate", $context) &&  !(null === $context["showInternalRate"]))) ? ($context["showInternalRate"]) : (false));
        // line 3
        $context["showRateColumn"] = (((array_key_exists("showRateColumn", $context) &&  !(null === $context["showRateColumn"]))) ? ($context["showRateColumn"]) : ($this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_rate_other_timesheet")));
        // line 4
        $context["showHourlyRateColumn"] = ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = (((array_key_exists("showHourlyRateColumn", $context) &&  !(null === $context["showHourlyRateColumn"]))) ? ($context["showHourlyRateColumn"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 5
        $context["showSummaryHourlyRate"] = ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = (((array_key_exists("showSummaryHourlyRate", $context) &&  !(null === $context["showSummaryHourlyRate"]))) ? ($context["showSummaryHourlyRate"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp));
        // line 6
        $context["showRateBudget"] = (((array_key_exists("showRateBudget", $context) &&  !(null === $context["showRateBudget"]))) ? ($context["showRateBudget"]) : (false));
        // line 7
        $context["showTimeBudget"] = (((array_key_exists("showTimeBudget", $context) &&  !(null === $context["showTimeBudget"]))) ? ($context["showTimeBudget"]) : (false));
        // line 8
        $context["showCustomerSummary"] = (((array_key_exists("showCustomerSummary", $context) &&  !(null === $context["showCustomerSummary"]))) ? ($context["showCustomerSummary"]) : (true));
        // line 9
        $context["showTotalSummary"] = (((array_key_exists("showTotalSummary", $context) &&  !(null === $context["showTotalSummary"]))) ? ($context["showTotalSummary"]) : (true));
        // line 10
        $context["showDateTimeShort"] = (((array_key_exists("showDateTimeShort", $context) &&  !(null === $context["showDateTimeShort"]))) ? ($context["showDateTimeShort"]) : (false));
        // line 11
        $context["showPageBreak"] = (((array_key_exists("showPageBreak", $context) &&  !(null === $context["showPageBreak"]))) ? ($context["showPageBreak"]) : (true));
        // line 12
        $context["now"] = $this->extensions['App\Twig\LocaleFormatExtensions']->createDate("now", CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 12));
        // line 13
        $context["decimal"] = (((array_key_exists("decimal", $context) &&  !(null === $context["decimal"]))) ? ($context["decimal"]) : (false));
        // line 15
        if ((array_key_exists("query", $context) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "user", [], "any", false, false, false, 15)))) {
            // line 16
            yield "    ";
            $context["showUserColumn"] = false;
            // line 17
            yield "    ";
            // line 18
            yield "    ";
            $context["showRateColumn"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_rate_own_timesheet");
        }
        // line 20
        $context["summaryColumns"] = ["customer", "project"];
        // line 21
        if ((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 22
            yield "    ";
            $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["timeBudget"]);
        }
        // line 24
        if ((($tmp = ($context["showRateBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 25
            yield "    ";
            $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["budget"]);
        }
        // line 27
        if ((($tmp = ($context["showSummaryHourlyRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 28
            yield "    ";
            $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["hourlyRate"]);
        }
        // line 30
        $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["duration"]);
        // line 31
        if ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 32
            yield "    ";
            if ((($tmp = ($context["showInternalRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 33
                yield "        ";
                $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["internalRate"]);
                // line 34
                yield "    ";
            }
            // line 35
            yield "    ";
            $context["summaryColumns"] = Twig\Extension\CoreExtension::merge(($context["summaryColumns"] ?? null), ["rate"]);
        }
        // line 37
        yield "<html";
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", true, true, false, 37) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 37)))) {
            yield " lang=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 37), "locale", [], "any", false, false, false, 37), "html", null, true);
            yield "\"";
        }
        yield ">
<head>
    <title>";
        // line 39
        yield from $this->unwrap()->yieldBlock('document_title', $context, $blocks);
        yield "</title>
";
        // line 40
        yield from $this->unwrap()->yieldBlock('styles', $context, $blocks);
        // line 45
        yield "</head>
<body>
";
        // line 47
        yield from $this->unwrap()->yieldBlock('pdf_footer', $context, $blocks);
        // line 73
        yield from $this->unwrap()->yieldBlock('body_start', $context, $blocks);
        // line 74
        yield from $this->unwrap()->yieldBlock('summary', $context, $blocks);
        // line 228
        yield from $this->unwrap()->yieldBlock('items', $context, $blocks);
        // line 345
        yield from $this->unwrap()->yieldBlock('body_end', $context, $blocks);
        // line 346
        yield "</body>
</html>
";
        yield from [];
    }

    // line 39
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_document_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export"), "html", null, true);
        yield from [];
    }

    // line 40
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_styles(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 41
        yield "    <style>
        ";
        // line 42
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("export-pdf");
        yield "
    </style>
";
        yield from [];
    }

    // line 47
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_pdf_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 48
        yield "<!--mpdf
<htmlpagefooter name=\"myfooter\">
<table style=\"border-top: 1px solid #000000; font-size: 9pt; padding-top: 3mm; width: 100%\">
<tr>
    <td align=\"left\">
    ";
        // line 53
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.page_of", ["%page%" => "{PAGENO}", "%pages%" => "{nb}"]), "html", null, true);
        yield "
    ";
        // line 54
        if ((( !(($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && array_key_exists("query", $context)) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "user", [], "any", false, false, false, 54)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 55
            yield "        &ndash;
        ";
            // line 56
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "user", [], "any", false, false, false, 56), "displayName", [], "any", false, false, false, 56), "html", null, true);
            yield "
    ";
        }
        // line 58
        yield "    </td>
    <td align=\"right\">
    ";
        // line 60
        $context["company"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.company");
        // line 61
        yield "    ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["company"] ?? null))) {
            // line 62
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["company"] ?? null), "html", null, true);
            yield " &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["now"] ?? null)), "html", null, true);
            yield "
    ";
        } else {
            // line 64
            yield "        ";
            yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.date_copyright", ["%date%" => $this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["now"] ?? null)), "%kimai%" => (((("<a href=\"" . Twig\Extension\CoreExtension::constant("App\\Constants::HOMEPAGE")) . "\">") . Twig\Extension\CoreExtension::constant("App\\Constants::SOFTWARE")) . "</a>")]);
            yield "
    ";
        }
        // line 66
        yield "    </td>
</tr>
</table>
</htmlpagefooter>
<sethtmlpagefooter name=\"myfooter\" value=\"on\" />
mpdf-->
";
        yield from [];
    }

    // line 73
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 75
        yield "    ";
        yield from $this->unwrap()->yieldBlock('summary_header', $context, $blocks);
        // line 85
        yield "    <table class=\"items\">
        <thead>
        <tr>
            ";
        // line 88
        yield from $this->unwrap()->yieldBlock('summary_head_row_start', $context, $blocks);
        // line 89
        yield "            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
            // line 90
            yield "                ";
            if (($context["summaryColumn"] == "customer")) {
                // line 91
                yield "                    <th>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
                yield "</th>
                ";
            } elseif ((            // line 92
$context["summaryColumn"] == "project")) {
                // line 93
                yield "                    <th>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
                yield "</th>
                ";
            } else {
                // line 95
                yield "                    <th class=\"center\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["summaryColumn"]), "html", null, true);
                yield "</th>
                ";
            }
            // line 97
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 98
        yield "            ";
        yield from $this->unwrap()->yieldBlock('summary_head_row_end', $context, $blocks);
        // line 99
        yield "        </tr>
        </thead>
        <tbody>
        ";
        // line 102
        $context["customer"] = null;
        // line 103
        yield "        ";
        $context["customerDuration"] = 0;
        // line 104
        yield "        ";
        $context["customerRate"] = 0;
        // line 105
        yield "        ";
        $context["customerInternalRate"] = 0;
        // line 106
        yield "        ";
        $context["customerCurrency"] = null;
        // line 107
        yield "        ";
        $context["customerCount"] = 0;
        // line 108
        yield "        ";
        $context["multiCurrency"] = false;
        // line 109
        yield "        ";
        $context["totalDuration"] = 0;
        // line 110
        yield "        ";
        $context["totalInternalRate"] = 0;
        // line 111
        yield "        ";
        $context["totalRate"] = 0;
        // line 112
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["summaries"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["id"] => $context["summary"]) {
            // line 113
            yield "            <!-- CONTENT_PART -->
            ";
            // line 114
            $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 114));
            // line 115
            yield "            ";
            $context["totalInternalRate"] = (($context["totalInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 115));
            // line 116
            yield "            ";
            $context["totalRate"] = (($context["totalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 116));
            // line 117
            yield "            ";
            if (( !(null === ($context["customerCurrency"] ?? null)) &&  !(($context["customerCurrency"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 117)))) {
                // line 118
                yield "                ";
                $context["multiCurrency"] = true;
                // line 119
                yield "            ";
            }
            // line 120
            yield "            ";
            if ((($context["customer"] ?? null) === null)) {
                // line 121
                yield "                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 121);
                // line 122
                yield "                ";
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 122);
                // line 123
                yield "            ";
            }
            // line 124
            yield "            ";
            if ( !(($context["customer"] ?? null) === CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 124))) {
                // line 125
                yield "                <tr class=\"summary\">
                    ";
                // line 126
                yield from $this->unwrap()->yieldBlock('summary_customer_row_start', $context, $blocks);
                // line 127
                yield "                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                    // line 128
                    yield "                        ";
                    if (($context["summaryColumn"] == "duration")) {
                        // line 129
                        yield "                            <td class=\"totals duration\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 130
$context["summaryColumn"] == "internalRate")) {
                        // line 131
                        yield "                            <td class=\"totals cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                        yield "</td>
                        ";
                    } elseif ((                    // line 132
$context["summaryColumn"] == "rate")) {
                        // line 133
                        yield "                            <td class=\"totals cost\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                        yield "</td>
                        ";
                    } else {
                        // line 135
                        yield "                            <td></td>
                        ";
                    }
                    // line 137
                    yield "                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 138
                yield "                    ";
                yield from $this->unwrap()->yieldBlock('summary_customer_row_end', $context, $blocks);
                // line 139
                yield "                </tr>
                ";
                // line 140
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 140);
                // line 141
                yield "                ";
                $context["customer"] = CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 141);
                // line 142
                yield "                ";
                $context["customerDuration"] = 0;
                // line 143
                yield "                ";
                $context["customerRate"] = 0;
                // line 144
                yield "                ";
                $context["customerInternalRate"] = 0;
                // line 145
                yield "                ";
                $context["customerCount"] = 0;
                // line 146
                yield "            ";
            }
            // line 147
            yield "            <tr class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::cycle(["odd", "even"], ($context["customerCount"] ?? null)), "html", null, true);
            yield "\">
                ";
            // line 148
            yield from $this->unwrap()->yieldBlock('summary_project_row_start', $context, $blocks);
            // line 149
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                // line 150
                yield "                    ";
                if (($context["summaryColumn"] == "customer")) {
                    // line 151
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "customer", [], "any", false, false, false, 151), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 152
$context["summaryColumn"] == "project")) {
                    // line 153
                    yield "                        <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "project", [], "any", false, false, false, 153), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 154
$context["summaryColumn"] == "timeBudget")) {
                    // line 155
                    yield "                        <td class=\"center\">
                            ";
                    // line 156
                    if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 156) && (CoreExtension::getAttribute($this->env, $this->source, (($_v0 = ($context["budgets"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = $context["id"]) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null), "time_left", [], "any", false, false, false, 156) > 0))) {
                        // line 157
                        yield "                                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, (($_v2 = ($context["budgets"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = $context["id"]) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null), "time_left", [], "any", false, false, false, 157), ($context["decimal"] ?? null)), "html", null, true);
                        yield "
                            ";
                    }
                    // line 159
                    yield "                        </td>
                    ";
                } elseif ((                // line 160
$context["summaryColumn"] == "budget")) {
                    // line 161
                    yield "                        <td class=\"center\">
                            ";
                    // line 162
                    if ((CoreExtension::getAttribute($this->env, $this->source, ($context["budgets"] ?? null), $context["id"], [], "array", true, true, false, 162) && (CoreExtension::getAttribute($this->env, $this->source, (($_v4 = ($context["budgets"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[(($_v5 = $context["id"]) instanceof \Stringable ? (string) $_v5 : $_v5)] ?? null) : null), "money_left", [], "any", false, false, false, 162) > 0))) {
                        // line 163
                        yield "                                ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, (($_v6 = ($context["budgets"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6[(($_v7 = $context["id"]) instanceof \Stringable ? (string) $_v7 : $_v7)] ?? null) : null), "money_left", [], "any", false, false, false, 163), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 163)), "html", null, true);
                        yield "
                            ";
                    }
                    // line 165
                    yield "                        </td>
                    ";
                } elseif ((                // line 166
$context["summaryColumn"] == "hourlyRate")) {
                    // line 167
                    yield "                        ";
                    $context["summaryHourlyRate"] = (CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 167) / 3600);
                    // line 168
                    yield "                        <td class=\"cost\">";
                    yield (string) (((($context["summaryHourlyRate"] ?? null) > 0)) ? ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 168) / ($context["summaryHourlyRate"] ?? null)), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 168)), "html", null, true)) : (""));
                    yield "</td>
                    ";
                } elseif ((                // line 169
$context["summaryColumn"] == "duration")) {
                    // line 170
                    yield "                        <td class=\"duration\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 170), ($context["decimal"] ?? null)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 171
$context["summaryColumn"] == "internalRate")) {
                    // line 172
                    yield "                        <td class=\"cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 172), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 172)), "html", null, true);
                    yield "</td>
                    ";
                } elseif ((                // line 173
$context["summaryColumn"] == "rate")) {
                    // line 174
                    yield "                        <td class=\"cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 174), CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "currency", [], "any", false, false, false, 174)), "html", null, true);
                    yield "</td>
                    ";
                }
                // line 176
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 177
            yield "                ";
            yield from $this->unwrap()->yieldBlock('summary_project_row_end', $context, $blocks);
            // line 178
            yield "            </tr>
            ";
            // line 179
            $context["customerDuration"] = (($context["customerDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "duration", [], "any", false, false, false, 179));
            // line 180
            yield "            ";
            $context["customerRate"] = (($context["customerRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate", [], "any", false, false, false, 180));
            // line 181
            yield "            ";
            $context["customerInternalRate"] = (($context["customerInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["summary"], "rate_internal", [], "any", false, false, false, 181));
            // line 182
            yield "            ";
            $context["customerCount"] = (($context["customerCount"] ?? null) + 1);
            // line 183
            yield "        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['summary'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 184
        yield "        ";
        if (((($tmp = ($context["showCustomerSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($context["customer"] ?? null) === null))) {
            // line 185
            yield "        <tr class=\"summary\">
            ";
            // line 186
            yield from $this->unwrap()->yieldBlock('summary_customer_summary_row_start', $context, $blocks);
            // line 187
            yield "            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                // line 188
                yield "                ";
                if (($context["summaryColumn"] == "duration")) {
                    // line 189
                    yield "                    <td class=\"totals duration\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["customerDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } elseif ((                // line 190
$context["summaryColumn"] == "internalRate")) {
                    // line 191
                    yield "                    <td class=\"totals cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } elseif ((                // line 192
$context["summaryColumn"] == "rate")) {
                    // line 193
                    yield "                    <td class=\"totals cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["customerRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } else {
                    // line 195
                    yield "                    <td></td>
                ";
                }
                // line 197
                yield "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 198
            yield "            ";
            yield from $this->unwrap()->yieldBlock('summary_customer_summary_row_end', $context, $blocks);
            // line 199
            yield "        </tr>
        ";
        }
        // line 201
        yield "        ";
        if (((($tmp = ($context["showTotalSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["multiCurrency"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 202
            yield "        <tr class=\"";
            if ( !(($tmp = ($context["showCustomerSummary"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "summary";
            } else {
                yield "summary-total";
            }
            yield "\">
            ";
            // line 203
            yield from $this->unwrap()->yieldBlock('summary_summary_row_start', $context, $blocks);
            // line 204
            yield "            <td class=\"totals\" colspan=\"2\">
                ";
            // line 205
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
            yield "
            </td>
            ";
            // line 207
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["summaryColumns"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["summaryColumn"]) {
                // line 208
                yield "                ";
                if (($context["summaryColumn"] == "duration")) {
                    // line 209
                    yield "                    <td class=\"totals duration\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } elseif ((                // line 210
$context["summaryColumn"] == "internalRate")) {
                    // line 211
                    yield "                        <td class=\"totals cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalInternalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } elseif ((                // line 212
$context["summaryColumn"] == "rate")) {
                    // line 213
                    yield "                    <td class=\"totals cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["totalRate"] ?? null), ($context["customerCurrency"] ?? null)), "html", null, true);
                    yield "</td>
                ";
                } elseif (!CoreExtension::inFilter(                // line 214
$context["summaryColumn"], ["customer", "project"])) {
                    // line 215
                    yield "                    <td></td>
                ";
                }
                // line 217
                yield "            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['summaryColumn'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 218
            yield "            ";
            yield from $this->unwrap()->yieldBlock('summary_summary_row_end', $context, $blocks);
            // line 219
            yield "        </tr>
        ";
        }
        // line 221
        yield "        </tbody>
    </table>

    ";
        // line 224
        if ((($tmp = ($context["showPageBreak"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 225
            yield "        <pagebreak>
    ";
        }
        yield from [];
    }

    // line 75
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 76
        yield "        <h2 style=\"margin-bottom: 4px; padding-bottom: 0\">";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</h2>
        ";
        // line 77
        if (array_key_exists("query", $context)) {
            // line 78
            yield "        <p>
            ";
            // line 79
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.period"), "html", null, true);
            yield ":
            ";
            // line 80
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "begin", [], "any", false, false, false, 80)), "html", null, true);
            yield " - ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["query"] ?? null), "end", [], "any", false, false, false, 80)), "html", null, true);
            yield "
        </p>
        ";
        }
        // line 83
        yield "        <h3>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.summary"), "html", null, true);
        yield "</h3>
    ";
        yield from [];
    }

    // line 76
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.document_title"), "html", null, true);
        yield from [];
    }

    // line 88
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_head_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 98
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_head_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 126
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_customer_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 138
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_customer_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 148
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_project_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 177
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_project_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 186
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_customer_summary_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 198
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_customer_summary_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 203
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_summary_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 218
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_summary_summary_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 228
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 229
        yield "    ";
        yield from $this->unwrap()->yieldBlock('items_header', $context, $blocks);
        // line 232
        yield "
    ";
        // line 233
        $context["duration"] = 0;
        // line 234
        yield "    ";
        $context["rate"] = 0;
        // line 235
        yield "    ";
        $context["rateInternal"] = 0;
        // line 236
        yield "    ";
        $context["currency"] = false;
        // line 237
        yield "    <table class=\"items\">
        <thead>
        <tr>
            ";
        // line 240
        yield from $this->unwrap()->yieldBlock('items_head_row_start', $context, $blocks);
        // line 241
        yield "            <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</th>
            ";
        // line 242
        if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 243
            yield "                <th>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("user"), "html", null, true);
            yield "</th>
            ";
        }
        // line 245
        yield "            <th>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("description"), "html", null, true);
        yield "</th>
            ";
        // line 246
        if ((($tmp = ($context["showHourlyRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 247
            yield "                <th class=\"center\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("hourlyRate"), "html", null, true);
            yield "</th>
            ";
        }
        // line 249
        yield "            <th class=\"center\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
            ";
        // line 250
        if ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 251
            yield "                ";
            if ((($tmp = ($context["showInternalRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 252
                yield "                    <th class=\"center\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("internalRate"), "html", null, true);
                yield "</th>
                ";
            }
            // line 254
            yield "                <th class=\"center\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("rate"), "html", null, true);
            yield "</th>
            ";
        }
        // line 256
        yield "            ";
        yield from $this->unwrap()->yieldBlock('items_head_row_end', $context, $blocks);
        // line 257
        yield "        </tr>
        </thead>
        <tbody>
        ";
        // line 260
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 261
            yield "            <!-- CONTENT_PART -->
            ";
            // line 262
            $context["duration"] = (($context["duration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 262));
            // line 263
            yield "            ";
            $context["entryCurrency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 263), "customer", [], "any", false, false, false, 263), "currency", [], "any", false, false, false, 263);
            // line 264
            yield "            ";
            if ((($context["currency"] ?? null) === false)) {
                // line 265
                yield "                ";
                $context["currency"] = ($context["entryCurrency"] ?? null);
                // line 266
                yield "            ";
            }
            // line 267
            yield "            ";
            if ( !(($context["currency"] ?? null) === ($context["entryCurrency"] ?? null))) {
                // line 268
                yield "                ";
                $context["currency"] = null;
                // line 269
                yield "            ";
            }
            // line 270
            yield "            <tr class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::cycle(["odd", "even"], CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 270)), "html", null, true);
            yield "\">
                ";
            // line 271
            yield from $this->unwrap()->yieldBlock('items_entry_row_start', $context, $blocks);
            // line 272
            yield "                <td class=\"text-nowrap\">
                    ";
            // line 273
            yield from $this->unwrap()->yieldBlock('date_begin', $context, $blocks);
            // line 274
            yield "                    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 274)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 275
                yield "                        ";
                yield from $this->unwrap()->yieldBlock('date_end', $context, $blocks);
                // line 276
                yield "                    ";
            }
            // line 277
            yield "                </td>
                ";
            // line 278
            if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 279
                yield "                    <td>";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 279), "displayName", [], "any", false, false, false, 279), "html", null, true);
                yield "</td>
                ";
            }
            // line 281
            yield "                <td>
                    ";
            // line 282
            yield from $this->unwrap()->yieldBlock('description', $context, $blocks);
            // line 289
            yield "                </td>
                ";
            // line 290
            if ((($tmp = ($context["showHourlyRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 291
                yield "                    <td class=\"cost\">
                        ";
                // line 292
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 292)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 293
                    yield "                            -
                        ";
                } else {
                    // line 295
                    yield "                            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 295), ($context["entryCurrency"] ?? null)), "html", null, true);
                    yield "
                        ";
                }
                // line 297
                yield "                    </td>
                ";
            }
            // line 299
            yield "                <td class=\"duration\">
                    ";
            // line 300
            if ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 300) == 0)) {
                // line 301
                yield "                        -
                    ";
            } else {
                // line 303
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 303), ($context["decimal"] ?? null)), "html", null, true);
                yield "
                    ";
            }
            // line 305
            yield "                </td>
                ";
            // line 306
            if ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 307
                yield "                    ";
                // line 309
                yield "                    ";
                $context["rate"] = (($context["rate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 309));
                // line 310
                yield "                    ";
                $context["rateInternal"] = (($context["rateInternal"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 310));
                // line 311
                yield "                    ";
                $context["entryRate"] = $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 311), ($context["entryCurrency"] ?? null));
                // line 312
                yield "                    ";
                $context["entryRateInternal"] = $this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 312), ($context["entryCurrency"] ?? null));
                // line 313
                yield "                    ";
                if ((($tmp = ($context["showInternalRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 314
                    yield "                        <td class=\"cost\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["entryRateInternal"] ?? null), "html", null, true);
                    yield "</td>
                    ";
                }
                // line 316
                yield "                    <td class=\"cost\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["entryRate"] ?? null), "html", null, true);
                yield "</td>
                ";
            }
            // line 318
            yield "                ";
            yield from $this->unwrap()->yieldBlock('items_entry_row_end', $context, $blocks);
            // line 319
            yield "            </tr>
        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 321
        yield "        ";
        yield from $this->unwrap()->yieldBlock('items_summary', $context, $blocks);
        // line 342
        yield "        </tbody>
    </table>
";
        yield from [];
    }

    // line 229
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 230
        yield "        <h3>";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.full_list"), "html", null, true);
        yield "</h3>
    ";
        yield from [];
    }

    // line 240
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_head_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 256
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_head_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 271
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_entry_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 273
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_date_begin(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ( !(($tmp = ($context["showDateTimeShort"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 273)), "html", null, true);
        } else {
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "begin", [], "any", false, false, false, 273)), "html", null, true);
        }
        yield from [];
    }

    // line 275
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_date_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ( !(($tmp = ($context["showDateTimeShort"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "<br>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "end", [], "any", false, false, false, 275)), "html", null, true);
        }
        yield from [];
    }

    // line 282
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_description(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 283
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 283), "customer", [], "any", false, false, false, 283), "name", [], "any", false, false, false, 283), "html", null, true);
        yield " - ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 283), "name", [], "any", false, false, false, 283), "html", null, true);
        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 283))) {
            yield " - ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 283), "name", [], "any", false, false, false, 283), "html", null, true);
        }
        // line 284
        yield "                        ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 284))) {
            // line 285
            yield "                            <br>
                            <i>";
            // line 286
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 286));
            yield "</i>
                        ";
        }
        // line 288
        yield "                    ";
        yield from [];
    }

    // line 318
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_entry_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 321
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_summary(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 322
        yield "        <tr class=\"summary\">
            ";
        // line 323
        yield from $this->unwrap()->yieldBlock('items_summary_row_start', $context, $blocks);
        // line 324
        yield "            ";
        if ((($tmp = ($context["showUserColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 325
            yield "                <td colspan=\"3\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
            yield "</td>
            ";
        } else {
            // line 327
            yield "                <td colspan=\"2\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("sum.total"), "html", null, true);
            yield "</td>
            ";
        }
        // line 329
        yield "            ";
        if ((($tmp = ($context["showHourlyRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 330
            yield "                <td class=\"totals cost\"></td>
            ";
        }
        // line 332
        yield "            <td class=\"totals duration\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["duration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "</td>
            ";
        // line 333
        if ((($tmp = ($context["showRateColumn"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 334
            yield "                ";
            if ((($tmp = ($context["showInternalRate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 335
                yield "                    <td class=\"totals cost\">";
                if ( !(null === ($context["currency"] ?? null))) {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rateInternal"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                }
                yield "</td>
                ";
            }
            // line 337
            yield "                <td class=\"totals cost\">";
            if ( !(null === ($context["currency"] ?? null))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            }
            yield "</td>
            ";
        }
        // line 339
        yield "            ";
        yield from $this->unwrap()->yieldBlock('items_summary_row_end', $context, $blocks);
        // line 340
        yield "        </tr>
        ";
        yield from [];
    }

    // line 323
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_summary_row_start(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 339
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_items_summary_row_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 345
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/pdf-layout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1386 => 345,  1376 => 339,  1366 => 323,  1360 => 340,  1357 => 339,  1349 => 337,  1341 => 335,  1338 => 334,  1336 => 333,  1331 => 332,  1327 => 330,  1324 => 329,  1318 => 327,  1312 => 325,  1309 => 324,  1307 => 323,  1304 => 322,  1297 => 321,  1287 => 318,  1282 => 288,  1277 => 286,  1274 => 285,  1271 => 284,  1262 => 283,  1255 => 282,  1241 => 275,  1226 => 273,  1216 => 271,  1206 => 256,  1196 => 240,  1188 => 230,  1181 => 229,  1174 => 342,  1171 => 321,  1155 => 319,  1152 => 318,  1146 => 316,  1140 => 314,  1137 => 313,  1134 => 312,  1131 => 311,  1128 => 310,  1125 => 309,  1123 => 307,  1121 => 306,  1118 => 305,  1112 => 303,  1108 => 301,  1106 => 300,  1103 => 299,  1099 => 297,  1093 => 295,  1089 => 293,  1087 => 292,  1084 => 291,  1082 => 290,  1079 => 289,  1077 => 282,  1074 => 281,  1068 => 279,  1066 => 278,  1063 => 277,  1060 => 276,  1057 => 275,  1054 => 274,  1052 => 273,  1049 => 272,  1047 => 271,  1042 => 270,  1039 => 269,  1036 => 268,  1033 => 267,  1030 => 266,  1027 => 265,  1024 => 264,  1021 => 263,  1019 => 262,  1016 => 261,  999 => 260,  994 => 257,  991 => 256,  985 => 254,  979 => 252,  976 => 251,  974 => 250,  969 => 249,  963 => 247,  961 => 246,  956 => 245,  950 => 243,  948 => 242,  943 => 241,  941 => 240,  936 => 237,  933 => 236,  930 => 235,  927 => 234,  925 => 233,  922 => 232,  919 => 229,  912 => 228,  902 => 218,  892 => 203,  882 => 198,  872 => 186,  862 => 177,  852 => 148,  842 => 138,  832 => 126,  822 => 98,  812 => 88,  801 => 76,  793 => 83,  785 => 80,  781 => 79,  778 => 78,  776 => 77,  771 => 76,  764 => 75,  757 => 225,  755 => 224,  750 => 221,  746 => 219,  743 => 218,  736 => 217,  732 => 215,  730 => 214,  725 => 213,  723 => 212,  718 => 211,  716 => 210,  711 => 209,  708 => 208,  704 => 207,  699 => 205,  696 => 204,  694 => 203,  685 => 202,  682 => 201,  678 => 199,  675 => 198,  668 => 197,  664 => 195,  658 => 193,  656 => 192,  651 => 191,  649 => 190,  644 => 189,  641 => 188,  636 => 187,  634 => 186,  631 => 185,  628 => 184,  613 => 183,  610 => 182,  607 => 181,  604 => 180,  602 => 179,  599 => 178,  596 => 177,  589 => 176,  583 => 174,  581 => 173,  576 => 172,  574 => 171,  569 => 170,  567 => 169,  562 => 168,  559 => 167,  557 => 166,  554 => 165,  548 => 163,  546 => 162,  543 => 161,  541 => 160,  538 => 159,  532 => 157,  530 => 156,  527 => 155,  525 => 154,  520 => 153,  518 => 152,  513 => 151,  510 => 150,  505 => 149,  503 => 148,  498 => 147,  495 => 146,  492 => 145,  489 => 144,  486 => 143,  483 => 142,  480 => 141,  478 => 140,  475 => 139,  472 => 138,  465 => 137,  461 => 135,  455 => 133,  453 => 132,  448 => 131,  446 => 130,  441 => 129,  438 => 128,  433 => 127,  431 => 126,  428 => 125,  425 => 124,  422 => 123,  419 => 122,  416 => 121,  413 => 120,  410 => 119,  407 => 118,  404 => 117,  401 => 116,  398 => 115,  396 => 114,  393 => 113,  375 => 112,  372 => 111,  369 => 110,  366 => 109,  363 => 108,  360 => 107,  357 => 106,  354 => 105,  351 => 104,  348 => 103,  346 => 102,  341 => 99,  338 => 98,  331 => 97,  325 => 95,  319 => 93,  317 => 92,  312 => 91,  309 => 90,  304 => 89,  302 => 88,  297 => 85,  294 => 75,  287 => 74,  277 => 73,  266 => 66,  260 => 64,  252 => 62,  249 => 61,  247 => 60,  243 => 58,  236 => 56,  233 => 55,  231 => 54,  227 => 53,  220 => 48,  213 => 47,  205 => 42,  202 => 41,  195 => 40,  184 => 39,  177 => 346,  175 => 345,  173 => 228,  171 => 74,  169 => 73,  167 => 47,  163 => 45,  161 => 40,  157 => 39,  147 => 37,  143 => 35,  140 => 34,  137 => 33,  134 => 32,  132 => 31,  130 => 30,  126 => 28,  124 => 27,  120 => 25,  118 => 24,  114 => 22,  112 => 21,  110 => 20,  106 => 18,  104 => 17,  101 => 16,  99 => 15,  97 => 13,  95 => 12,  93 => 11,  91 => 10,  89 => 9,  87 => 8,  85 => 7,  83 => 6,  81 => 5,  79 => 4,  77 => 3,  75 => 2,  73 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/pdf-layout.html.twig", "/opt/kimai/templates/export/pdf-layout.html.twig");
    }
}
