<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* embeds/comments.html.twig */
class __TwigTemplate_02d26f7b5f23972b7cf1c4725f63d2d3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("embeds/comments.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["form" => ($context["form"] ?? null), "comments" => ($context["comments"] ?? null), "route_pin" => ((array_key_exists("route_pin", $context)) ? (Twig\Extension\CoreExtension::default(($context["route_pin"] ?? null), null)) : (null)), "route_delete" => ((array_key_exists("route_delete", $context)) ? (Twig\Extension\CoreExtension::default(($context["route_delete"] ?? null), null)) : (null)), "route_api_options" => ((array_key_exists("route_api_options", $context)) ? (Twig\Extension\CoreExtension::default(($context["route_api_options"] ?? null), null)) : (null)), "delete_by_user" => ((array_key_exists("delete_by_user", $context)) ? (Twig\Extension\CoreExtension::default(($context["delete_by_user"] ?? null), false)) : (false))]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/comments.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/comments.html.twig", "/opt/kimai/templates/embeds/comments.html.twig");
    }
}


/* embeds/comments.html.twig */
class __TwigTemplate_02d26f7b5f23972b7cf1c4725f63d2d3___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("comment"), "html", null, true);
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"comments_box\"";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "box-body-scrollable";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["comments"] ?? null)) > 0)) {
            yield " p-0";
        }
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "        ";
        $context["replacer"] = [];
        // line 8
        yield "        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 8), "preferences", [], "any", false, false, false, 8));
        foreach ($context['_seq'] as $context["_key"] => $context["pref"]) {
            // line 9
            yield "            ";
            $context["replacer"] = Twig\Extension\CoreExtension::merge(($context["replacer"] ?? null), [ (string)(("{{user." . CoreExtension::getAttribute($this->env, $this->source, $context["pref"], "name", [], "any", false, false, false, 9)) . "}}") => CoreExtension::getAttribute($this->env, $this->source, $context["pref"], "value", [], "any", false, false, false, 9)]);
            // line 10
            yield "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['pref'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 11
        yield "        ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["comments"] ?? null)) == 0)) {
            // line 12
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("error.no_comments_found"), "html", null, true);
            yield "
        ";
        } else {
            // line 14
            yield "            <div class=\"divide-y\">
                ";
            // line 15
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["comments"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["comment"]) {
                // line 16
                yield "                <div class=\"p-3\">
                    <div class=\"row\">
                        <div class=\"col-auto\">
                            ";
                // line 19
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 19, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "createdBy", [], "any", false, false, false, 19), false]);
                yield "
                        </div>
                        <div class=\"col\">
                            <div class=\"text-truncate\">
                                <strong>";
                // line 23
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_username", $context, 23, $this->getSourceContext())->macro_username(...[CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "createdBy", [], "any", false, false, false, 23)]);
                yield "</strong>
                            </div>
                            <div class=\"text-body-secondary\">";
                // line 25
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "createdAt", [], "any", false, false, false, 25)), "html", null, true);
                yield "</div>
                        </div>
                        <div class=\"col-auto align-self-center\">
                            ";
                // line 28
                if ( !(null === ($context["route_pin"] ?? null))) {
                    // line 29
                    yield "                                ";
                    if ( !(null === ($context["route_api_options"] ?? null))) {
                        // line 30
                        yield "                                    <a href=\"#\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route_pin"] ?? null), Twig\Extension\CoreExtension::merge(["comment" => CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 30)], ($context["route_api_options"] ?? null))), "html", null, true);
                        yield "\" class=\"btn btn-action pin-comment-link api-link\" data-event=\"kimai.commentUpdate\" data-method=\"PATCH\" data-msg-error=\"action.update.error\">
                                ";
                    } else {
                        // line 32
                        yield "                                    <a href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route_pin"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 32), "token" => $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("comment.pin")]), "html", null, true);
                        yield "\" class=\"btn btn-action pin-comment-link\">
                                ";
                    }
                    // line 34
                    yield "
                                ";
                    // line 35
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "pinned", [], "any", false, false, false, 35)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 36
                        yield "                                    <i class=\"text-primary ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("pin"), "html", null, true);
                        yield "\"></i>
                                ";
                    } else {
                        // line 38
                        yield "                                    ";
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("pin");
                        yield "
                                ";
                    }
                    // line 40
                    yield "
                                </a>
                            ";
                } elseif ((($tmp = CoreExtension::getAttribute($this->env, $this->source,                 // line 42
$context["comment"], "pinned", [], "any", false, false, false, 42)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 43
                    yield "                                ";
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("pin");
                    yield "
                            ";
                }
                // line 45
                yield "
                            ";
                // line 46
                if (( !(null === ($context["route_delete"] ?? null)) && ((!(($tmp = ($context["delete_by_user"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || ((($tmp = ($context["delete_by_user"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "createdBy", [], "any", false, false, false, 46), "id", [], "any", false, false, false, 46) == CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 46), "id", [], "any", false, false, false, 46)))))) {
                    // line 47
                    yield "                                ";
                    if ( !(null === ($context["route_api_options"] ?? null))) {
                        // line 48
                        yield "                                    <a href=\"#\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route_delete"] ?? null), Twig\Extension\CoreExtension::merge(["comment" => CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 48)], ($context["route_api_options"] ?? null))), "html", null, true);
                        yield "\" class=\"btn btn-action pin-comment-link api-link\" data-event=\"kimai.commentUpdate\" data-method=\"DELETE\" data-question=\"confirm.delete\" data-msg-error=\"action.delete.error\">
                                ";
                    } else {
                        // line 50
                        yield "                                    <a href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["route_delete"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "id", [], "any", false, false, false, 50), "token" => $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("comment.delete")]), "html", null, true);
                        yield "\" class=\"confirmation-link btn btn-action delete-comment-link\" data-question=\"confirm.delete\">
                                ";
                    }
                    // line 52
                    yield "                                ";
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("delete");
                    yield "
                                    </a>
                            ";
                }
                // line 55
                yield "                        </div>
                    </div>
                    <div class=\"row pt-2 direct-chat-text\">
                        ";
                // line 58
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentContent(Twig\Extension\CoreExtension::replace(CoreExtension::getAttribute($this->env, $this->source, $context["comment"], "message", [], "any", false, false, false, 58), ($context["replacer"] ?? null)));
                yield "
                    </div>
                </div>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['comment'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 62
            yield "            </div>
        ";
        }
        // line 64
        yield "    ";
        yield from [];
    }

    // line 65
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 66
        if ( !(null === ($context["form"] ?? null))) {
            // line 67
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
            yield "
            ";
            // line 68
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "message", [], "any", false, false, false, 68), 'widget', ["attr" => ["rows" => "3", "placeholder" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("placeholder.type_message"), "style" => "margin-bottom: 5px"]]);
            yield "
            <button type=\"submit\" class=\"btn btn-primary\">
                ";
            // line 70
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("comment", true);
            yield "
                ";
            // line 71
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("comment"), "html", null, true);
            yield "
            </button>
            ";
            // line 73
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
            yield "
            ";
            // line 74
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "embeds/comments.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  347 => 74,  343 => 73,  338 => 71,  334 => 70,  329 => 68,  325 => 67,  323 => 66,  316 => 65,  311 => 64,  307 => 62,  296 => 58,  291 => 55,  284 => 52,  278 => 50,  272 => 48,  269 => 47,  267 => 46,  264 => 45,  258 => 43,  256 => 42,  252 => 40,  246 => 38,  240 => 36,  238 => 35,  235 => 34,  229 => 32,  223 => 30,  220 => 29,  218 => 28,  212 => 25,  207 => 23,  200 => 19,  195 => 16,  191 => 15,  188 => 14,  182 => 12,  179 => 11,  172 => 10,  169 => 9,  164 => 8,  161 => 7,  154 => 6,  140 => 5,  129 => 4,  118 => 3,  113 => 1,  111 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "embeds/comments.html.twig", "/opt/kimai/templates/embeds/comments.html.twig");
    }
}
