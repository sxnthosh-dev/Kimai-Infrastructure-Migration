<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/index.html.twig */
class __TwigTemplate_187f40fb19a76c0c48dcfa3b6d7cca48 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'status' => [$this, 'block_status'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 5
        $context["totalDuration"] = 0;
        // line 6
        $context["totalRates"] = [];
        // line 8
        $context["showEmpty"] = false;
        // line 9
        if ((($tmp = ($context["searched"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 10
            yield "    ";
            $context["showEmpty"] = true;
            // line 11
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["models"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["model"]) {
                // line 12
                yield "        ";
                if ((($tmp = ($context["showEmpty"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 13
                    yield "            ";
                    $context["showEmpty"] = (Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 13)) || Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 13), "entries", [], "any", false, false, false, 13)));
                    // line 14
                    yield "        ";
                }
                // line 15
                yield "        ";
                $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 15), "timeWorked", [], "any", false, false, false, 15));
                // line 16
                yield "        ";
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 16), "currency", [], "any", false, false, false, 16);
                // line 17
                yield "        ";
                if ( !CoreExtension::getAttribute($this->env, $this->source, ($context["totalRates"] ?? null), ($context["customerCurrency"] ?? null), [], "array", true, true, false, 17)) {
                    // line 18
                    yield "            ";
                    $context["totalRates"] = Twig\Extension\CoreExtension::merge(($context["totalRates"] ?? null), [ (string)($context["customerCurrency"] ?? null) => 0.0]);
                    // line 19
                    yield "        ";
                }
                // line 20
                yield "        ";
                $context["totalRates"] = Twig\Extension\CoreExtension::merge(($context["totalRates"] ?? null), [ (string)($context["customerCurrency"] ?? null) => ((($_v0 = ($context["totalRates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = ($context["customerCurrency"] ?? null)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 20), "total", [], "any", false, false, false, 20))]);
                // line 21
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['model'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
        }
        // line 24
        $context["columns"] = ["date" => ["class" => "alwaysVisible w-min", "orderBy" => false], "project" => ["class" => "d-none d-md-table-cell", "orderBy" => false], "description" => ["class" => "d-none d-xl-table-cell", "orderBy" => false], "user" => ["class" => "d-none d-xl-table-cell w-min", "orderBy" => false], "unit_price" => ["class" => "d-none d-sm-table-cell text-end w-min", "orderBy" => false], "amount" => ["class" => "d-none d-sm-table-cell text-end w-min", "orderBy" => false], "duration" => ["class" => "text-end w-min", "orderBy" => false], "total_rate" => ["class" => "text-end alwaysVisible w-min", "orderBy" => false]];
        // line 35
        $context["tableName"] = "invoice_create";
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 38
        yield "    ";
        $macros["_v2"] = $this->load("macros/status.html.twig", 38)->unwrap();
        // line 39
        yield "    ";
        if ((($context["totalDuration"] ?? null) > 0)) {
            // line 40
            yield "        ";
            yield (string) $macros["_v2"]->getTemplateForMacro("macro_status_duration", $context, 40, $this->getSourceContext())->macro_status_duration(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null))]);
            yield "
    ";
        }
        // line 42
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["totalRates"] ?? null));
        foreach ($context['_seq'] as $context["totalCurrency"] => $context["totalRate"]) {
            // line 43
            yield "        ";
            yield (string) $macros["_v2"]->getTemplateForMacro("macro_status_money", $context, 43, $this->getSourceContext())->macro_status_money(...[$this->extensions['App\Twig\LocaleFormatExtensions']->money($context["totalRate"], $context["totalCurrency"])]);
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['totalCurrency'], $context['totalRate'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        yield from [];
    }

    // line 47
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 48
        yield "
    ";
        // line 49
        yield from $this->load("invoice/index.html.twig", 49, 1)->unwrap()->yield($context);
        // line 87
        yield "
    ";
        // line 88
        if ((($tmp = ($context["showEmpty"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 89
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 89, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
    ";
        }
        // line 91
        yield "
    ";
        // line 92
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["models"] ?? null)) > 0)) {
            // line 93
            yield "        ";
            yield from $this->load("invoice/index.html.twig", 93, 2)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
            // line 214
            yield "
    ";
        }
        // line 216
        yield "
";
        yield from [];
    }

    // line 219
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 220
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    ";
        // line 221
        $context["formId"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 221), "attr", [], "any", false, false, false, 221), "id", [], "any", false, false, false, 221);
        // line 222
        yield "    ";
        $context["formSelector"] = ("form#" . ($context["formId"] ?? null));
        // line 223
        yield "
    <script type=\"text/javascript\">
        function singleInvoice(link, preview)
        {
            const formName = \x27customer_\x27 + link.dataset[\x27customer\x27];
            const template = document.getElementById(formName + \x27_template\x27).value;
            const date = document.getElementById(formName + \x27_invoiceDate\x27).value;
            const formPlugin = kimai.getPlugin(\x27form\x27);
            const overwrites = {\x27customers[]\x27: link.dataset[\x27customer\x27], \x27template\x27: template, \x27invoiceDate\x27: date};
            const uri = formPlugin.convertFormDataToQueryString(document.getElementById(\x27";
        // line 232
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["formId"] ?? null), "html", null, true);
        yield "\x27), overwrites);

            if (!preview) {
                link.classList.toggle(\x27disabled\x27);
                link.href = \x27javascript: void(0)\x27;

                const form = document.createElement(\x27form\x27);
                form.method = \x27post\x27;
                form.action = link.dataset[\x27href\x27];

                const params = new URLSearchParams(uri);
                params.append(\x27_token\x27, \x27";
        // line 243
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("invoice.create"), "html", null, true);
        yield "\x27);

                for (const [name, value] of params) {
                    const field = document.createElement(\x27input\x27);
                    field.type = \x27hidden\x27;
                    field.name = name;
                    field.value = value;
                    form.appendChild(field);
                }

                document.body.appendChild(form);
                form.submit();

                return false;
            }

            link.href = link.dataset[\x27href\x27] + \x27?\x27 + uri;

            return true;
        }

        /** @type CustomEvent event */
        document.addEventListener(\x27kimai.initialized\x27, function(event) {
            KimaiReloadPageWidget.create(\x27kimai.systemConfigUpdate\x27, true);

            ";
        // line 268
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["models"] ?? null)) > 0)) {
            // line 269
            yield "            document.getElementById(\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "template", [], "any", false, false, false, 269), "vars", [], "any", false, false, false, 269), "id", [], "any", false, false, false, 269), "html", null, true);
            yield "\x27).addEventListener(\x27change\x27, function(event) {
                document.getElementById(\x27";
            // line 270
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 270), "attr", [], "any", false, false, false, 270), "id", [], "any", false, false, false, 270), "html", null, true);
            yield "\x27).submit();
            });
            ";
        }
        // line 273
        yield "        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  275 => 273,  269 => 270,  264 => 269,  262 => 268,  234 => 243,  220 => 232,  209 => 223,  206 => 222,  204 => 221,  199 => 220,  192 => 219,  186 => 216,  182 => 214,  179 => 93,  177 => 92,  174 => 91,  168 => 89,  166 => 88,  163 => 87,  161 => 49,  158 => 48,  151 => 47,  138 => 43,  133 => 42,  127 => 40,  124 => 39,  121 => 38,  114 => 37,  109 => 1,  107 => 35,  105 => 24,  97 => 21,  94 => 20,  91 => 19,  88 => 18,  85 => 17,  82 => 16,  79 => 15,  76 => 14,  73 => 13,  70 => 12,  65 => 11,  62 => 10,  60 => 9,  58 => 8,  56 => 6,  54 => 5,  52 => 3,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/index.html.twig", "/opt/kimai/templates/invoice/index.html.twig");
    }
}


/* invoice/index.html.twig */
class __TwigTemplate_187f40fb19a76c0c48dcfa3b6d7cca48___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_before' => [$this, 'block_box_before'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_after' => [$this, 'block_box_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 49
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 50
        $macros["search"] = $this->macros["search"] = $this->load("macros/search.html.twig", 50)->unwrap();
        // line 51
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 49
        $this->parent = $this->load("@theme/embeds/card.html.twig", 49);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 52
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.filter"), "html", null, true);
        yield from [];
    }

    // line 53
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield from [];
    }

    // line 54
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 55
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
            ";
        // line 56
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "searchTerm", [], "any", true, true, false, 56)) {
            // line 57
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "searchTerm", [], "any", false, false, false, 57), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_searchTerm"]]);
            yield "
            ";
        }
        // line 59
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "daterange", [], "any", false, false, false, 59), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_daterange"]]);
        yield "
            ";
        // line 60
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customers", [], "any", false, false, false, 60), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_customers"]]);
        yield "
            ";
        // line 61
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "projects", [], "any", false, false, false, 61), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_projects"]]);
        yield "
            ";
        // line 62
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activities", [], "any", true, true, false, 62)) {
            // line 63
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activities", [], "any", false, false, false, 63), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_activities"]]);
            yield "
            ";
        }
        // line 65
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", true, true, false, 65)) {
            // line 66
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", false, false, false, 66), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_tags"]]);
            yield "
            ";
        }
        // line 68
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", true, true, false, 68)) {
            // line 69
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", false, false, false, 69), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_users"]]);
            yield "
            ";
        }
        // line 71
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 71)) {
            // line 72
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 72), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_teams"]]);
            yield "
            ";
        }
        // line 74
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", true, true, false, 74)) {
            // line 75
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 75), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_exported"]]);
            yield "
            ";
        }
        // line 77
        yield "            <div class=\"d-none\">
            ";
        // line 78
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "template", [], "any", false, false, false, 78), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_template"]]);
        yield "
            ";
        // line 79
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceDate", [], "any", false, false, false, 79), 'row', ["row_attr" => ["class" => "mb-3 invoice_search_form_row_invoiceDate"]]);
        yield "
            </div>
        ";
        yield from [];
    }

    // line 82
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 83
        yield "            ";
        yield (string) $macros["search"]->getTemplateForMacro("macro_searchButton", $context, 83, $this->getSourceContext())->macro_searchButton(...[($context["form"] ?? null)]);
        yield "
        ";
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  484 => 85,  476 => 83,  469 => 82,  461 => 79,  457 => 78,  454 => 77,  448 => 75,  445 => 74,  439 => 72,  436 => 71,  430 => 69,  427 => 68,  421 => 66,  418 => 65,  412 => 63,  410 => 62,  406 => 61,  402 => 60,  397 => 59,  391 => 57,  389 => 56,  384 => 55,  377 => 54,  366 => 53,  355 => 52,  350 => 49,  348 => 51,  346 => 50,  339 => 49,  275 => 273,  269 => 270,  264 => 269,  262 => 268,  234 => 243,  220 => 232,  209 => 223,  206 => 222,  204 => 221,  199 => 220,  192 => 219,  186 => 216,  182 => 214,  179 => 93,  177 => 92,  174 => 91,  168 => 89,  166 => 88,  163 => 87,  161 => 49,  158 => 48,  151 => 47,  138 => 43,  133 => 42,  127 => 40,  124 => 39,  121 => 38,  114 => 37,  109 => 1,  107 => 35,  105 => 24,  97 => 21,  94 => 20,  91 => 19,  88 => 18,  85 => 17,  82 => 16,  79 => 15,  76 => 14,  73 => 13,  70 => 12,  65 => 11,  62 => 10,  60 => 9,  58 => 8,  56 => 6,  54 => 5,  52 => 3,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/index.html.twig", "/opt/kimai/templates/invoice/index.html.twig");
    }
}


/* invoice/index.html.twig */
class __TwigTemplate_187f40fb19a76c0c48dcfa3b6d7cca48___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 93
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 94
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 94)->unwrap();
        // line 95
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 95)->unwrap();
        // line 93
        $this->parent = $this->load("@theme/embeds/card.html.twig", 93);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 96
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 97
        yield "                ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("preview"), "html", null, true);
        yield "
            ";
        yield from [];
    }

    // line 99
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"invoice_customer_forms\"";
        yield from [];
    }

    // line 100
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 101
        yield "                <table class=\"table dataTable\">
                    <thead>
                        <tr>
                            <th class=\"d-sm-table-cell d-none\"></th>
                            <th>";
        // line 105
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                            <th class=\"w-min text-end d-sm-table-cell d-none\">";
        // line 106
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
                            <th class=\"w-min text-end d-sm-table-cell d-none\">";
        // line 107
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("total_rate"), "html", null, true);
        yield "</th>
                            <th class=\"w-min text-center actions alwaysVisible\"></th>
                        </tr>
                    </thead>
                    <tbody>
                        ";
        // line 112
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["models"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["model"]) {
            // line 113
            yield "                            ";
            $context["isDecimal"] = true;
            // line 114
            yield "                            ";
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, $context["model"], "currency", [], "any", false, false, false, 114);
            // line 115
            yield "                            ";
            $context["isEmptyModel"] = (Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 115)) || Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 115), "entries", [], "any", false, false, false, 115)));
            // line 116
            yield "                            ";
            $context["customerForm"] = (($_v3 = ($context["forms"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3[(($_v4 = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 116)) instanceof \Stringable ? (string) $_v4 : $_v4)] ?? null) : null);
            // line 117
            yield "                            <tr>
                                <td class=\"w-min d-sm-table-cell d-none\">
                                    ";
            // line 119
            if ( !(($tmp = ($context["isEmptyModel"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 120
                yield "                                        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 120, $this->getSourceContext())->macro_card_tool_button(...["collapse", ["onclick" => "this.parentElement.parentElement.nextElementSibling.classList.toggle(\x27d-none\x27);return false;"]]);
                yield "
                                    ";
            }
            // line 122
            yield "                                </td>
                                <td>
                                    ";
            // line 124
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 124))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 125
                yield "                                        <a class=\"text-reset\" href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 125), "id", [], "any", false, false, false, 125)]), "html", null, true);
                yield "\">";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 125, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 125)]);
                yield "</a>
                                    ";
            } else {
                // line 127
                yield "                                        ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 127, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 127)]);
                yield "
                                    ";
            }
            // line 129
            yield "                                </td>
                                <td class=\"w-min text-end d-sm-table-cell d-none\">
                                    ";
            // line 131
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 131), "timeWorked", [], "any", false, false, false, 131), ($context["isDecimal"] ?? null)), "html", null, true);
            yield "
                                </td>
                                <td class=\"w-min text-end d-sm-table-cell d-none\">
                                    <span title=\"";
            // line 134
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 134), "tax", [], "any", false, false, false, 134), ($context["currency"] ?? null)), "html", null, true);
            yield "\" data-toggle=\"tooltip\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 134), "total", [], "any", false, false, false, 134), ($context["currency"] ?? null)), "html", null, true);
            yield "</span>
                                </td>
                                <td class=\"w-min text-center actions alwaysVisible\">
                                    ";
            // line 137
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable([["class" => "d-inline-flex d-md-none"], ["icon" => false, "class" => "d-none d-md-inline-flex"]]);
            foreach ($context['_seq'] as $context["_key"] => $context["attrs"]) {
                // line 138
                yield "                                    ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_action_button", $context, 138, $this->getSourceContext())->macro_action_button(...["print", Twig\Extension\CoreExtension::merge(["url" => "#", "onclick" => "return singleInvoice(this, true)", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("preview"), "target" => "_blank", "attr" => ["data-customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 138), "id", [], "any", false, false, false, 138), "data-href" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_preview", ["customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 138), "id", [], "any", false, false, false, 138), "token" => $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("invoice.preview")])]], $context["attrs"])]);
                yield "
                                    ";
                // line 139
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_action_button", $context, 139, $this->getSourceContext())->macro_action_button(...["invoice", Twig\Extension\CoreExtension::merge(["url" => "#", "onclick" => "return singleInvoice(this, false)", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "attr" => ["data-customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 139), "id", [], "any", false, false, false, 139), "data-href" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice_create", ["customer" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "customer", [], "any", false, false, false, 139), "id", [], "any", false, false, false, 139)])]], $context["attrs"]), "primary"]);
                yield "
                                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['attrs'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 141
            yield "                                </td>
                            </tr>
                            <tr class=\"d-none\">
                                <td colspan=\"5\" class=\"p-2\">
                                    ";
            // line 145
            if ( !(($tmp = ($context["isEmptyModel"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 146
                yield "                                        ";
                $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["customerForm"] ?? null), ["form/horizontal.html.twig"], true);
                // line 147
                yield "                                        ";
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["customerForm"] ?? null), 'form_start');
                yield "
                                        ";
                // line 148
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["customerForm"] ?? null), 'rest');
                yield "
                                        ";
                // line 149
                yield (string)                 $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["customerForm"] ?? null), 'form_end');
                yield "
                                        ";
                // line 150
                $context["isDecimal"] = true;
                // line 151
                yield "                                        ";
                $context["entries"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["model"], "calculator", [], "any", false, false, false, 151), "entries", [], "any", false, false, false, 151);
                // line 152
                yield "                                        ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, $context["model"], "currency", [], "any", false, false, false, 152);
                // line 153
                yield "                                        ";
                $context["itemsAmount"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["entries"] ?? null));
                // line 154
                yield "                                        ";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 154, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), CoreExtension::getAttribute($this->env, $this->source, $context["model"], "query", [], "any", false, false, false, 154), ["boxClass" => ""]]);
                yield "
                                        ";
                // line 155
                if ((($tmp = ($context["limit_preview"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 156
                    yield "                                            ";
                    $context["entries"] = Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["entries"] ?? null), 0, 100);
                    // line 157
                    yield "                                        ";
                }
                // line 158
                yield "                                        ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 159
                    yield "                                            ";
                    $context["amount"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "amount", [], "any", false, false, false, 159);
                    // line 160
                    yield "                                            ";
                    $context["duration"] = $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 160), ($context["isDecimal"] ?? null));
                    // line 161
                    yield "                                            ";
                    $context["rate"] = 0;
                    // line 162
                    yield "                                            ";
                    if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 162))) {
                        // line 163
                        yield "                                                ";
                        $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 163);
                        // line 164
                        yield "                                            ";
                    } elseif ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 164))) {
                        // line 165
                        yield "                                                ";
                        $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 165);
                        // line 166
                        yield "                                            ";
                    }
                    // line 167
                    yield "                                            <tr>
                                                <td class=\"";
                    // line 168
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 168, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "date"]);
                    yield "\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 168)), "html", null, true);
                    yield "</td>
                                                <td class=\"";
                    // line 169
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 169, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "project"]);
                    yield "\">
                                                    ";
                    // line 170
                    if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 170))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 171
                        yield "                                                        <a class=\"text-reset\" href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("project_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 171), "id", [], "any", false, false, false, 171)]), "html", null, true);
                        yield "\">";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 171, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 171)]);
                        yield "</a>
                                                    ";
                    } else {
                        // line 173
                        yield "                                                        ";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 173, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 173)]);
                        yield "
                                                    ";
                    }
                    // line 175
                    yield "                                                    ";
                    if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 175))) {
                        // line 176
                        yield "                                                        <br>
                                                        <small>
                                                            ";
                        // line 178
                        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view", CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 178))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 179
                            yield "                                                                <a class=\"text-reset\" href=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activity_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 179), "id", [], "any", false, false, false, 179)]), "html", null, true);
                            yield "\">";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 179, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 179)]);
                            yield "</a>
                                                            ";
                        } else {
                            // line 181
                            yield "                                                                ";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 181, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 181)]);
                            yield "
                                                            ";
                        }
                        // line 183
                        yield "                                                        </small>
                                                    ";
                    }
                    // line 185
                    yield "                                                </td>
                                                <td class=\"";
                    // line 186
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 186, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "description"]);
                    yield " timesheet-description\">
                                                    ";
                    // line 187
                    if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 187))) {
                        // line 188
                        yield "                                                        ";
                        yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 188));
                        yield "
                                                    ";
                    }
                    // line 190
                    yield "                                                </td>
                                                <td class=\"";
                    // line 191
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 191, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "user"]);
                    yield "\">";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_user", $context, 191, $this->getSourceContext())->macro_label_user(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 191)]);
                    yield "</td>
                                                <td class=\"";
                    // line 192
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 192, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "unit_price"]);
                    yield "\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                                                <td class=\"";
                    // line 193
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 193, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "amount"]);
                    yield "\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["amount"] ?? null), "html", null, true);
                    yield "</td>
                                                <td class=\"";
                    // line 194
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 194, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "duration"]);
                    yield "\" data-duration=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 194), "html", null, true);
                    yield "\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["duration"] ?? null), "html", null, true);
                    yield "</td>
                                                <td class=\"";
                    // line 195
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 195, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "total_rate"]);
                    yield "\">";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 195), ($context["currency"] ?? null)), "html", null, true);
                    yield "</td>
                                            </tr>
                                        ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 198
                yield "                                        ";
                if (((($tmp = ($context["limit_preview"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["itemsAmount"] ?? null) > 100))) {
                    // line 199
                    yield "                                            <tr class=\"warning\">
                                                <td colspan=\"8\">&raquo; ";
                    // line 200
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("preview.skipped_rows", ["%rows%" => (($context["itemsAmount"] ?? null) - 100)]), "html", null, true);
                    yield "</td>
                                            </tr>
                                        ";
                }
                // line 203
                yield "                                        ";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 203, $this->getSourceContext())->macro_data_table_footer(...[($context["entries"] ?? null)]);
                yield "
                                    ";
            }
            // line 205
            yield "                                </td>
                            </tr>
                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['model'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 208
        yield "                    </tbody>
                </table>
                <div style=\"display: none\" id=\"create-token\" data-value=\"";
        // line 210
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("invoice.create"), "html", null, true);
        yield "\"></div>
                <div style=\"display: none\" id=\"preview-token\" data-value=\"";
        // line 211
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("invoice.preview"), "html", null, true);
        yield "\"></div>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  952 => 211,  948 => 210,  944 => 208,  927 => 205,  921 => 203,  915 => 200,  912 => 199,  909 => 198,  897 => 195,  889 => 194,  883 => 193,  877 => 192,  871 => 191,  868 => 190,  862 => 188,  860 => 187,  856 => 186,  853 => 185,  849 => 183,  843 => 181,  835 => 179,  833 => 178,  829 => 176,  826 => 175,  820 => 173,  812 => 171,  810 => 170,  806 => 169,  800 => 168,  797 => 167,  794 => 166,  791 => 165,  788 => 164,  785 => 163,  782 => 162,  779 => 161,  776 => 160,  773 => 159,  768 => 158,  765 => 157,  762 => 156,  760 => 155,  755 => 154,  752 => 153,  749 => 152,  746 => 151,  744 => 150,  740 => 149,  736 => 148,  731 => 147,  728 => 146,  726 => 145,  720 => 141,  711 => 139,  706 => 138,  702 => 137,  692 => 134,  686 => 131,  682 => 129,  676 => 127,  668 => 125,  666 => 124,  662 => 122,  656 => 120,  654 => 119,  650 => 117,  647 => 116,  644 => 115,  641 => 114,  638 => 113,  621 => 112,  613 => 107,  609 => 106,  605 => 105,  599 => 101,  592 => 100,  581 => 99,  573 => 97,  566 => 96,  561 => 93,  559 => 95,  557 => 94,  550 => 93,  484 => 85,  476 => 83,  469 => 82,  461 => 79,  457 => 78,  454 => 77,  448 => 75,  445 => 74,  439 => 72,  436 => 71,  430 => 69,  427 => 68,  421 => 66,  418 => 65,  412 => 63,  410 => 62,  406 => 61,  402 => 60,  397 => 59,  391 => 57,  389 => 56,  384 => 55,  377 => 54,  366 => 53,  355 => 52,  350 => 49,  348 => 51,  346 => 50,  339 => 49,  275 => 273,  269 => 270,  264 => 269,  262 => 268,  234 => 243,  220 => 232,  209 => 223,  206 => 222,  204 => 221,  199 => 220,  192 => 219,  186 => 216,  182 => 214,  179 => 93,  177 => 92,  174 => 91,  168 => 89,  166 => 88,  163 => 87,  161 => 49,  158 => 48,  151 => 47,  138 => 43,  133 => 42,  127 => 40,  124 => 39,  121 => 38,  114 => 37,  109 => 1,  107 => 35,  105 => 24,  97 => 21,  94 => 20,  91 => 19,  88 => 18,  85 => 17,  82 => 16,  79 => 15,  76 => 14,  73 => 13,  70 => 12,  65 => 11,  62 => 10,  60 => 9,  58 => 8,  56 => 6,  54 => 5,  52 => 3,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/index.html.twig", "/opt/kimai/templates/invoice/index.html.twig");
    }
}
