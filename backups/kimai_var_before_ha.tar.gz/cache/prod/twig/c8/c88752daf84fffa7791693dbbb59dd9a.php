<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/embeds/offcanvas.html.twig */
class __TwigTemplate_0bed81227d0d1b7cdad00c495708fe01 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'offcanvas_attributes' => [$this, 'block_offcanvas_attributes'],
            'offcanvas_before' => [$this, 'block_offcanvas_before'],
            'header' => [$this, 'block_header'],
            'offcanvas_header' => [$this, 'block_offcanvas_header'],
            'body' => [$this, 'block_body'],
            'offcanvas_body' => [$this, 'block_offcanvas_body'],
            'offcanvas_after' => [$this, 'block_offcanvas_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["_id"] = (((array_key_exists("id", $context) &&  !(null === $context["id"]))) ? ($context["id"]) : (("offcanvas-" . Twig\Extension\CoreExtension::random($this->env->getCharset()))));
        // line 2
        $context["_position"] = (((array_key_exists("position", $context) &&  !(null === $context["position"]))) ? ($context["position"]) : ("end"));
        // line 3
        $context["_title"] = ((        $this->unwrap()->hasBlock("offcanvas_title", $context, $blocks)) ? (        $this->unwrap()->renderBlock("offcanvas_title", $context, $blocks)) : (""));
        // line 4
        $context["_hidden"] = ((((array_key_exists("hidden", $context) &&  !(null === $context["hidden"]))) ? ($context["hidden"]) : (true)) === true);
        // line 5
        yield "
<div
        id=\"";
        // line 7
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
        yield "\"
        class=\"offcanvas offcanvas-";
        // line 8
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_position"] ?? null), "html", null, true);
        yield " ";
        yield (string) (( !(($tmp = ($context["_hidden"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("show") : (""));
        yield "\"
        tabindex=\"-1\" aria-modal=\"true\" role=\"dialog\"
        ";
        // line 10
        yield from $this->unwrap()->yieldBlock('offcanvas_attributes', $context, $blocks);
        // line 11
        yield ">
    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('offcanvas_before', $context, $blocks);
        // line 13
        yield "
    ";
        // line 14
        yield from $this->unwrap()->yieldBlock('header', $context, $blocks);
        // line 25
        yield "
    ";
        // line 26
        yield from $this->unwrap()->yieldBlock('body', $context, $blocks);
        // line 35
        yield "
    ";
        // line 36
        yield from $this->unwrap()->yieldBlock('offcanvas_after', $context, $blocks);
        // line 37
        yield "</div>
";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_offcanvas_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_offcanvas_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "        <div class=\"offcanvas-header\">
            ";
        // line 16
        yield from $this->unwrap()->yieldBlock('offcanvas_header', $context, $blocks);
        // line 23
        yield "        </div>
    ";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_offcanvas_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "                <h2 class=\"offcanvas-title\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
        yield "</h2>
                <button
                        type=\"button\" class=\"btn-close text-reset\"
                        data-bs-dismiss=\"offcanvas\" aria-label=\"";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Close", [], "TablerBundle"), "html", null, true);
        yield "\"
                ></button>
            ";
        yield from [];
    }

    // line 26
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 27
        yield "        <div class=\"offcanvas-body\">
            ";
        // line 28
        yield from $this->unwrap()->yieldBlock('offcanvas_body', $context, $blocks);
        // line 33
        yield "        </div>
    ";
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_offcanvas_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 29
        yield "                <button class=\"btn\" type=\"button\" data-bs-dismiss=\"offcanvas\">
                    ";
        // line 30
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Close", [], "TablerBundle"), "html", null, true);
        yield "
                </button>
            ";
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_offcanvas_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/embeds/offcanvas.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  197 => 36,  189 => 30,  186 => 29,  179 => 28,  173 => 33,  171 => 28,  168 => 27,  161 => 26,  153 => 20,  146 => 17,  139 => 16,  133 => 23,  131 => 16,  128 => 15,  121 => 14,  111 => 12,  101 => 10,  95 => 37,  93 => 36,  90 => 35,  88 => 26,  85 => 25,  83 => 14,  80 => 13,  78 => 12,  75 => 11,  73 => 10,  66 => 8,  62 => 7,  58 => 5,  56 => 4,  54 => 3,  52 => 2,  50 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/embeds/offcanvas.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/embeds/offcanvas.html.twig");
    }
}
