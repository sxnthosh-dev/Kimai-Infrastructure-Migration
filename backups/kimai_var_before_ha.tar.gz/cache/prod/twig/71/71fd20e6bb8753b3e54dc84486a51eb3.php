<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* activity/index.html.twig */
class __TwigTemplate_9321bec408e2f180f68c62d36bdd2c90 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["actions"] = $this->macros["actions"] = $this->load("activity/actions.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_activity_row_attr", $context, 5, $this->getSourceContext())->macro_activity_row_attr(...[($context["entry"] ?? null), ($context["now"] ?? null)]);
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 9
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_name", $context, 9, $this->getSourceContext())->macro_label_name(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 9), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9))]);
            yield "
    ";
        } elseif ((        // line 10
($context["column"] ?? null) == "project")) {
            // line 11
            yield "        ";
            // line 12
            yield "        ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 12)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 13
                yield "            ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 13, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 13)]);
                yield "
            ";
                // line 14
                if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 14), "customer", [], "any", false, false, false, 14)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 15
                    yield "                <br>
                <small>
                    ";
                    // line 17
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 17, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 17), "customer", [], "any", false, false, false, 17)]);
                    yield "
                </small>
            ";
                }
                // line 20
                yield "        ";
            }
            // line 21
            yield "    ";
        } elseif ((($context["column"] ?? null) == "comment")) {
            // line 22
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentOneLiner($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "comment", [], "any", false, false, false, 22), "html", null, true));
            yield "
    ";
        } elseif ((        // line 23
($context["column"] ?? null) == "number")) {
            // line 24
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "number", [], "any", false, false, false, 24), "html", null, true);
            yield "
    ";
        } elseif ((        // line 25
($context["column"] ?? null) == "budget")) {
            // line 26
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasBudget", [], "method", false, false, false, 26)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 27
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "budget", [], "any", false, false, false, 27), (((null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 27))) ? (($context["defaultCurrency"] ?? null)) : (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 27), "customer", [], "any", false, false, false, 27), "currency", [], "any", false, false, false, 27)))), "html", null, true);
                yield "
        ";
            } else {
                // line 29
                yield "            &ndash;
        ";
            }
            // line 31
            yield "    ";
        } elseif ((($context["column"] ?? null) == "timeBudget")) {
            // line 32
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasTimeBudget", [], "method", false, false, false, 32)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 33
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "timeBudget", [], "any", false, false, false, 33)), "html", null, true);
                yield "
        ";
            } else {
                // line 35
                yield "            &ndash;
        ";
            }
            // line 37
            yield "    ";
        } elseif ((($context["column"] ?? null) == "billable")) {
            // line 38
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 38, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "billable", [], "any", false, false, false, 38)]);
            yield "
    ";
        } elseif ((        // line 39
($context["column"] ?? null) == "team")) {
            // line 40
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 40, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "teams", [], "any", false, false, false, 40)]);
            yield "
    ";
        } elseif ((        // line 41
($context["column"] ?? null) == "visible")) {
            // line 42
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 42, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "visible", [], "any", false, false, false, 42)]);
            yield "
    ";
        } elseif ((        // line 43
($context["column"] ?? null) == "actions")) {
            // line 44
            yield "        ";
            yield (string) $macros["actions"]->getTemplateForMacro("macro_activity", $context, 44, $this->getSourceContext())->macro_activity(...[($context["entry"] ?? null), "index"]);
            yield "
    ";
        } elseif ((is_string($_v0 =         // line 45
($context["column"] ?? null)) && is_string($_v1 = "mf_") && str_starts_with($_v0, $_v1))) {
            // line 46
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_meta_field_value", $context, 46, $this->getSourceContext())->macro_meta_field_value(...[($context["entry"] ?? null), ($context["data"] ?? null)]);
            yield "
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  189 => 46,  187 => 45,  182 => 44,  180 => 43,  175 => 42,  173 => 41,  168 => 40,  166 => 39,  161 => 38,  158 => 37,  154 => 35,  148 => 33,  145 => 32,  142 => 31,  138 => 29,  132 => 27,  129 => 26,  127 => 25,  122 => 24,  120 => 23,  115 => 22,  112 => 21,  109 => 20,  103 => 17,  99 => 15,  97 => 14,  92 => 13,  89 => 12,  87 => 11,  85 => 10,  80 => 9,  77 => 8,  70 => 7,  58 => 5,  53 => 1,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/index.html.twig", "/opt/kimai/templates/activity/index.html.twig");
    }
}
