<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/progress_bar.html.twig */
class __TwigTemplate_eb219e564174ab83f9ea6c662ad1cc9e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 42
        yield "
";
        // line 166
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_progress_bars($items = [], $options = [], ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            $macros["_v0"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "
    ";
            // line 4
            $context["_height"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", true, true, false, 4) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 4)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 4)) : (""));
            // line 5
            yield "    ";
            $context["_separated"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "separated", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "separated", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "separated", [], "any", false, false, false, 5)) : (false)) === true);
            // line 6
            yield "    ";
            $context["_style"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", false, false, false, 6)) : (""));
            // line 7
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 7)) : (""));
            // line 8
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 8) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 8)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 8)) : ([]));
            // line 9
            yield "
    ";
            // line 10
            $context["progressBarClasses"] = ["progress-stacked"];
            // line 11
            yield "
    ";
            // line 12
            if ((($tmp = ($context["_separated"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 13
                yield "        ";
                // line 14
                yield "        ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), ["progress-separated"]);
                // line 15
                yield "    ";
            }
            // line 16
            yield "
    ";
            // line 18
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "backgroundColor", [], "any", true, true, false, 18)) {
                // line 19
                yield "        ";
                trigger_deprecation('', '', "Option \x27backgroundColor\x27 is deprecated, no replacement allowed. Use `extraClass` option instead!"." in \"@Tabler/components/progress_bar.html.twig\" at line 19.");
                // line 20
                yield "        ";
                $context["_extraClass"] = ((($context["_extraClass"] ?? null) . " ") . CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "backgroundColor", [], "any", false, false, false, 20));
                // line 21
                yield "    ";
            }
            // line 22
            yield "
    ";
            // line 23
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_extraClass"] ?? null))) {
                // line 24
                yield "        ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), [($context["_extraClass"] ?? null)]);
                // line 25
                yield "    ";
            }
            // line 26
            yield "
    ";
            // line 27
            $context["heightStyle"] = (( !Twig\Extension\CoreExtension::testEmpty(($context["_height"] ?? null))) ? ((("height: " . ($context["_height"] ?? null)) . ";")) : (""));
            // line 28
            yield "
    <div
        class=\"";
            // line 30
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["progressBarClasses"] ?? null), " "), "html", null, true);
            yield "\"
        style=\"";
            // line 31
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["heightStyle"] ?? null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_style"] ?? null), "html", null, true);
            yield "\"
        ";
            // line 32
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_attr_to_html", $context, 32, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 35
                yield "            ";
                yield (string) $this->getTemplateForMacro("macro_progress_bar", $context, 35, $this->getSourceContext())->macro_progress_bar(...[$context["item"], ["multiple" => true, "height" =>                 // line 37
($context["_height"] ?? null)]]);
                // line 38
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 40
            yield "    </div>";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 43
    public function macro_progress_bar($item = [], $options = [], ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "item" => $item,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 44
            $macros["_v1"] = $this->load("@Tabler/includes/utils.html.twig", 44)->unwrap();
            // line 45
            yield "
    ";
            // line 47
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "current", [], "any", true, true, false, 47)) {
                // line 48
                yield "        ";
                trigger_deprecation('', '', "Item \x27current\x27 value is deprecated. Use `value` instead!"." in \"@Tabler/components/progress_bar.html.twig\" at line 48.");
                // line 49
                yield "        ";
                $context["_value"] = CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "current", [], "any", false, false, false, 49);
                // line 50
                yield "    ";
            } else {
                // line 51
                yield "        ";
                $context["_value"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "value", [], "any", true, true, false, 51) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "value", [], "any", false, false, false, 51)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "value", [], "any", false, false, false, 51)) : (0));
                // line 52
                yield "    ";
            }
            // line 53
            yield "
    ";
            // line 54
            $context["_max"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "max", [], "any", true, true, false, 54) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "max", [], "any", false, false, false, 54)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "max", [], "any", false, false, false, 54)) : (0));
            // line 55
            yield "    ";
            $context["_min"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "min", [], "any", true, true, false, 55) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "min", [], "any", false, false, false, 55)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "min", [], "any", false, false, false, 55)) : (0));
            // line 56
            yield "    ";
            $context["_indeterminate"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "indeterminate", [], "any", true, true, false, 56) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "indeterminate", [], "any", false, false, false, 56)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "indeterminate", [], "any", false, false, false, 56)) : (((($context["_value"] ?? null) == ($context["_max"] ?? null)) && (($context["_min"] ?? null) == ($context["_max"] ?? null))))) === true);
            // line 57
            yield "    ";
            $context["percent"] = ((((($tmp = ($context["_indeterminate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || ((($context["_max"] ?? null) - ($context["_min"] ?? null)) == 0))) ? (0) : ((((($context["_value"] ?? null) - ($context["_min"] ?? null)) * 100) / (($context["_max"] ?? null) - ($context["_min"] ?? null)))));
            // line 58
            yield "    ";
            $context["_autoLabel"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "autoLabel", [], "any", true, true, false, 58) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "autoLabel", [], "any", false, false, false, 58)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "autoLabel", [], "any", false, false, false, 58)) : (false)) === true);
            // line 59
            yield "    ";
            $context["_label"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", true, true, false, 59) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", false, false, false, 59)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "label", [], "any", false, false, false, 59)) : (((((($tmp = ($context["_autoLabel"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["_indeterminate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) ? ((($context["percent"] ?? null) . "%")) : (""))));
            // line 60
            yield "    ";
            $context["_multiple"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "multiple", [], "any", true, true, false, 60) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "multiple", [], "any", false, false, false, 60)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "multiple", [], "any", false, false, false, 60)) : (false)) === true);
            // line 61
            yield "    ";
            $context["_itemStyle"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", true, true, false, 61) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", false, false, false, 61)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", false, false, false, 61)) : (""));
            // line 62
            yield "
    ";
            // line 63
            $context["_height"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", true, true, false, 63) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 63)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "height", [], "any", false, false, false, 63)) : (""));
            // line 64
            yield "    ";
            $context["_style"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", true, true, false, 64) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", false, false, false, 64)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "style", [], "any", false, false, false, 64)) : (""));
            // line 65
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 65) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 65)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 65)) : (""));
            // line 66
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 66) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 66)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 66)) : ([]));
            // line 67
            yield "
    ";
            // line 69
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "backgroundColor", [], "any", true, true, false, 69)) {
                // line 70
                yield "        ";
                trigger_deprecation('', '', "Option \x27backgroundColor\x27 is deprecated, no replacement allowed. Use `extraClass` option instead!"." in \"@Tabler/components/progress_bar.html.twig\" at line 70.");
                // line 71
                yield "        ";
                $context["_extraClass"] = ((($context["_extraClass"] ?? null) . " ") . CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "backgroundColor", [], "any", false, false, false, 71));
                // line 72
                yield "    ";
            }
            // line 73
            yield "
    ";
            // line 75
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "progressSize", [], "any", true, true, false, 75)) {
                // line 76
                yield "        ";
                trigger_deprecation('', '', "Option \x27progressSize\x27 is deprecated, no replacement allowed. Use `attr.style` option instead!"." in \"@Tabler/components/progress_bar.html.twig\" at line 76.");
                // line 77
                yield "        ";
                $context["_extraClass"] = ((($context["_extraClass"] ?? null) . " ") . CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "progressSize", [], "any", false, false, false, 77));
                // line 78
                yield "    ";
            }
            // line 79
            yield "
    ";
            // line 80
            $context["heightStyle"] = (( !Twig\Extension\CoreExtension::testEmpty(($context["_height"] ?? null))) ? ((("height: " . ($context["_height"] ?? null)) . ";")) : (""));
            // line 81
            yield "    ";
            $context["widthStyle"] = (("width: " . ($context["percent"] ?? null)) . "%;");
            // line 82
            yield "    ";
            $context["progressClasses"] = ["progress"];
            // line 83
            yield "
    ";
            // line 84
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_extraClass"] ?? null))) {
                // line 85
                yield "        ";
                $context["progressClasses"] = Twig\Extension\CoreExtension::merge(($context["progressClasses"] ?? null), [($context["_extraClass"] ?? null)]);
                // line 86
                yield "    ";
            }
            // line 87
            yield "
    ";
            // line 89
            yield "    <div
        class=\"";
            // line 90
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["progressClasses"] ?? null), " "), "html", null, true);
            yield "\"
        role=\"progressbar\"
        ";
            // line 92
            if ( !(($tmp = ($context["_indeterminate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 93
                yield "            aria-valuenow=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_value"] ?? null), "html", null, true);
                yield "\"
            aria-valuemin=\"";
                // line 94
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_min"] ?? null), "html", null, true);
                yield "\"
            aria-valuemax=\"";
                // line 95
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_max"] ?? null), "html", null, true);
                yield "\"
        ";
            }
            // line 97
            yield "        ";
            if ((($context["_label"] ?? null) != "")) {
                // line 98
                yield "            aria-label=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_label"] ?? null), "html", null, true);
                yield "\"
        ";
            }
            // line 100
            yield "        style=\"";
            if ((($tmp = ($context["_multiple"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widthStyle"] ?? null), "html", null, true);
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["heightStyle"] ?? null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_style"] ?? null), "html", null, true);
            yield "\"
        ";
            // line 101
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_attr_to_html", $context, 101, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        ";
            // line 104
            yield "        ";
            $context["_striped"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "striped", [], "any", true, true, false, 104) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "striped", [], "any", false, false, false, 104)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "striped", [], "any", false, false, false, 104)) : (false)) === true);
            // line 105
            yield "        ";
            $context["_animated"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "animated", [], "any", true, true, false, 105) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "animated", [], "any", false, false, false, 105)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "animated", [], "any", false, false, false, 105)) : (false)) === true);
            // line 106
            yield "        ";
            $context["_labelVisible"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "labelVisible", [], "any", true, true, false, 106) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "labelVisible", [], "any", false, false, false, 106)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "labelVisible", [], "any", false, false, false, 106)) : (true)) === true);
            // line 107
            yield "        ";
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "color", [], "any", true, true, false, 107) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "color", [], "any", false, false, false, 107)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "color", [], "any", false, false, false, 107)) : (""));
            // line 108
            yield "        ";
            $context["_itemStyle"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", true, true, false, 108) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", false, false, false, 108)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "style", [], "any", false, false, false, 108)) : (""));
            // line 109
            yield "        ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "extraClass", [], "any", true, true, false, 109) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "extraClass", [], "any", false, false, false, 109)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "extraClass", [], "any", false, false, false, 109)) : (""));
            // line 110
            yield "        ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "attr", [], "any", true, true, false, 110) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "attr", [], "any", false, false, false, 110)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["item"] ?? null), "attr", [], "any", false, false, false, 110)) : ([]));
            // line 111
            yield "
        ";
            // line 112
            $context["heightStyle"] = (((($tmp = ($context["_height"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ((("height: " . ($context["_height"] ?? null)) . ";")) : (""));
            // line 113
            yield "        ";
            $context["progressBarClasses"] = ["progress-bar"];
            // line 114
            yield "
        ";
            // line 115
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_color"] ?? null))) {
                // line 116
                yield "            ";
                // line 117
                yield "            ";
                if (((is_string($_v2 = ($context["_color"] ?? null)) && is_string($_v3 = "bg-") && str_starts_with($_v2, $_v3)) || (is_string($_v4 = ($context["_color"] ?? null)) && is_string($_v5 = "text-") && str_starts_with($_v4, $_v5)))) {
                    // line 118
                    yield "                ";
                    trigger_deprecation('', '', "Defining \x27color\x27 class directly is deprecated. Use only the color value instead!"." in \"@Tabler/components/progress_bar.html.twig\" at line 118.");
                    // line 119
                    yield "                ";
                    $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), [($context["_color"] ?? null)]);
                    // line 120
                    yield "            ";
                } else {
                    // line 121
                    yield "                ";
                    $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), [("bg-" . ($context["_color"] ?? null))]);
                    // line 122
                    yield "            ";
                }
                // line 123
                yield "        ";
            }
            // line 124
            yield "
        ";
            // line 125
            if ((($tmp = ($context["_indeterminate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 126
                yield "            ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), ["progress-bar-indeterminate"]);
                // line 127
                yield "        ";
            } else {
                // line 128
                yield "            ";
                if ((($tmp = ($context["_striped"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 129
                    yield "                ";
                    $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), ["progress-bar-striped"]);
                    // line 130
                    yield "            ";
                }
                // line 131
                yield "        ";
            }
            // line 132
            yield "
        ";
            // line 133
            if (((($tmp = ($context["_animated"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = ($context["_indeterminate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 134
                yield "            ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), ["progress-bar-animated"]);
                // line 135
                yield "        ";
            }
            // line 136
            yield "
        ";
            // line 137
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_extraClass"] ?? null))) {
                // line 138
                yield "            ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), [($context["_extraClass"] ?? null)]);
                // line 139
                yield "        ";
            }
            // line 140
            yield "
        <div
            class=\"";
            // line 142
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["progressBarClasses"] ?? null), " "), "html", null, true);
            yield "\"
            style=\"";
            // line 143
            if ( !(($tmp = ($context["_multiple"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["widthStyle"] ?? null), "html", null, true);
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["heightStyle"] ?? null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_itemStyle"] ?? null), "html", null, true);
            yield "\"
            ";
            // line 144
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_attr_to_html", $context, 144, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
        >";
            // line 146
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_label"] ?? null))) {
                // line 147
                $context["labelClasses"] = [];
                // line 148
                yield "
                ";
                // line 149
                if ( !(($tmp = ($context["_labelVisible"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 150
                    yield "                    ";
                    $context["labelClasses"] = Twig\Extension\CoreExtension::merge(($context["labelClasses"] ?? null), ["visually-hidden"]);
                    // line 151
                    yield "                ";
                }
                // line 152
                yield "
                ";
                // line 153
                if ( !Twig\Extension\CoreExtension::testEmpty(($context["_color"] ?? null))) {
                    // line 154
                    yield "                    ";
                    $context["labelClasses"] = Twig\Extension\CoreExtension::merge(($context["labelClasses"] ?? null), [("text-bg-" . ($context["_color"] ?? null))]);
                    // line 155
                    yield "                ";
                }
                // line 156
                yield "
                <span
                    ";
                // line 158
                if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["labelClasses"] ?? null)) > 0)) {
                    // line 159
                    yield "class=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["labelClasses"] ?? null), " "), "html", null, true);
                    yield "\"";
                }
                // line 161
                yield "                >";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_label"] ?? null), "html", null, true);
                yield "</span>";
            }
            // line 163
            yield "</div>
    </div>";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 167
    public function macro_progress_background($options = [], ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 168
            $macros["_v6"] = $this->load("@Tabler/includes/utils.html.twig", 168)->unwrap();
            // line 169
            yield "
    ";
            // line 170
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 170) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 170)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 170)) : ("primary-lt"));
            // line 171
            yield "    ";
            $context["_width"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "width", [], "any", true, true, false, 171) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "width", [], "any", false, false, false, 171)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "width", [], "any", false, false, false, 171)) : (0));
            // line 172
            yield "    ";
            $context["_text"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "text", [], "any", true, true, false, 172) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "text", [], "any", false, false, false, 172)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "text", [], "any", false, false, false, 172)) : (""));
            // line 173
            yield "    ";
            $context["_value"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "value", [], "any", true, true, false, 173)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "value", [], "any", false, false, false, 173), (($context["_width"] ?? null) . "%"))) : ((($context["_width"] ?? null) . "%")));
            // line 174
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 174) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 174)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 174)) : ([]));
            // line 175
            yield "
    ";
            // line 176
            $context["progressBarClasses"] = ["progress-bar"];
            // line 177
            yield "
    ";
            // line 178
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_color"] ?? null))) {
                // line 179
                yield "        ";
                $context["progressBarClasses"] = Twig\Extension\CoreExtension::merge(($context["progressBarClasses"] ?? null), [("bg-" . ($context["_color"] ?? null))]);
                // line 180
                yield "    ";
            }
            // line 181
            yield "
    <div
        class=\"progressbg\"
        ";
            // line 184
            yield (string) $macros["_v6"]->getTemplateForMacro("macro_attr_to_html", $context, 184, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        <div class=\"progress progressbg-progress\">
            <div class=\"";
            // line 187
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["progressBarClasses"] ?? null), " "), "html", null, true);
            yield "\" style=\"width: ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_width"] ?? null), "html", null, true);
            yield "%\"></div>
        </div>
        ";
            // line 189
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_text"] ?? null))) {
                // line 190
                yield "            <div class=\"progressbg-text\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_text"] ?? null), "html", null, true);
                yield "</div>
        ";
            }
            // line 192
            yield "        ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_value"] ?? null))) {
                // line 193
                yield "            <div class=\"progressbg-value\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_value"] ?? null), "html", null, true);
                yield "</div>
        ";
            }
            // line 195
            yield "    </div>";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/progress_bar.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  609 => 195,  603 => 193,  600 => 192,  594 => 190,  592 => 189,  585 => 187,  579 => 184,  574 => 181,  571 => 180,  568 => 179,  566 => 178,  563 => 177,  561 => 176,  558 => 175,  555 => 174,  552 => 173,  549 => 172,  546 => 171,  544 => 170,  541 => 169,  539 => 168,  527 => 167,  520 => 163,  515 => 161,  510 => 159,  508 => 158,  504 => 156,  501 => 155,  498 => 154,  496 => 153,  493 => 152,  490 => 151,  487 => 150,  485 => 149,  482 => 148,  480 => 147,  478 => 146,  474 => 144,  464 => 143,  460 => 142,  456 => 140,  453 => 139,  450 => 138,  448 => 137,  445 => 136,  442 => 135,  439 => 134,  437 => 133,  434 => 132,  431 => 131,  428 => 130,  425 => 129,  422 => 128,  419 => 127,  416 => 126,  414 => 125,  411 => 124,  408 => 123,  405 => 122,  402 => 121,  399 => 120,  396 => 119,  393 => 118,  390 => 117,  388 => 116,  386 => 115,  383 => 114,  380 => 113,  378 => 112,  375 => 111,  372 => 110,  369 => 109,  366 => 108,  363 => 107,  360 => 106,  357 => 105,  354 => 104,  349 => 101,  338 => 100,  332 => 98,  329 => 97,  324 => 95,  320 => 94,  315 => 93,  313 => 92,  308 => 90,  305 => 89,  302 => 87,  299 => 86,  296 => 85,  294 => 84,  291 => 83,  288 => 82,  285 => 81,  283 => 80,  280 => 79,  277 => 78,  274 => 77,  271 => 76,  268 => 75,  265 => 73,  262 => 72,  259 => 71,  256 => 70,  253 => 69,  250 => 67,  247 => 66,  244 => 65,  241 => 64,  239 => 63,  236 => 62,  233 => 61,  230 => 60,  227 => 59,  224 => 58,  221 => 57,  218 => 56,  215 => 55,  213 => 54,  210 => 53,  207 => 52,  204 => 51,  201 => 50,  198 => 49,  195 => 48,  192 => 47,  189 => 45,  187 => 44,  174 => 43,  168 => 40,  160 => 38,  158 => 37,  156 => 35,  152 => 34,  147 => 32,  141 => 31,  137 => 30,  133 => 28,  131 => 27,  128 => 26,  125 => 25,  122 => 24,  120 => 23,  117 => 22,  114 => 21,  111 => 20,  108 => 19,  105 => 18,  102 => 16,  99 => 15,  96 => 14,  94 => 13,  92 => 12,  89 => 11,  87 => 10,  84 => 9,  81 => 8,  78 => 7,  75 => 6,  72 => 5,  70 => 4,  67 => 3,  65 => 2,  52 => 1,  46 => 166,  43 => 42,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/progress_bar.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/progress_bar.html.twig");
    }
}
