<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* customer/details.html.twig */
class __TwigTemplate_c48db6d226899a55ec268d3aa2df8a16 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        $context["can_edit"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["customer"] ?? null));
        // line 6
        yield "
    ";
        // line 7
        yield from $this->load("customer/details.html.twig", 7, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        // line 156
        yield "
    ";
        // line 157
        yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller("App\\Controller\\CustomerController::projectsAction", ["customer" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 157), "page" => 1]));
        yield "

    ";
        // line 159
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 160
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/rates-table.html.twig", ["id" => "customer_rates_box", "entity" => ($context["customer"] ?? null), "create_url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_customer_rate_add", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 160)]), "delete_route" => "delete_customer_rate", "currency" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "currency", [], "any", false, false, false, 160), "edit_route" => "admin_customer_rate_edit"]);
            yield "
    ";
        }
        // line 162
        yield "
    ";
        // line 163
        if ( !(null === ($context["stats"] ?? null))) {
            // line 164
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/budgets.html.twig", ["entity" => ($context["customer"] ?? null), "stats" => ($context["stats"] ?? null), "currency" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "currency", [], "any", false, false, false, 164)]);
            yield "
    ";
        }
        // line 166
        yield "
    ";
        // line 167
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["boxes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["controller"]) {
            // line 168
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller($context["controller"], ["customer" => ($context["customer"] ?? null), "page" => 1]));
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['controller'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 170
        yield "
    ";
        // line 171
        if ( !(null === ($context["teams"] ?? null))) {
            // line 172
            yield "        ";
            $context["options"] = ["teams" => ($context["teams"] ?? null)];
            // line 173
            yield "        ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("permissions", ($context["customer"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 174
                yield "            ";
                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_team")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 175
                    yield "                ";
                    $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_create" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("customer_team_create", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 175)])]);
                    // line 176
                    yield "            ";
                }
                // line 177
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_customer_permissions", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 177)])]);
                // line 178
                yield "        ";
            }
            // line 179
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/teams.html.twig", ($context["options"] ?? null));
            yield "
    ";
        }
        // line 181
        yield "
    ";
        // line 182
        if ( !(null === ($context["comments"] ?? null))) {
            // line 183
            yield "        ";
            $context["options"] = ["form" => ($context["commentForm"] ?? null), "comments" => ($context["comments"] ?? null)];
            // line 184
            yield "        ";
            if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 185
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_pin" => "toggle_customer_comment_pin", "route_api_options" => ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 185)], "route_delete" => "delete_customer_comment"]);
                // line 186
                yield "        ";
            }
            // line 187
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/comments.html.twig", ($context["options"] ?? null));
            yield "
    ";
        }
        // line 189
        yield "
";
        yield from [];
    }

    // line 192
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 193
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.commentUpdate kimai.customerTeamUpdate kimai.customerUpdate kimai.teamUpdate kimai.projectTeamUpdate kimai.rateUpdate\x27);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  183 => 193,  176 => 192,  170 => 189,  164 => 187,  161 => 186,  158 => 185,  155 => 184,  152 => 183,  150 => 182,  147 => 181,  141 => 179,  138 => 178,  135 => 177,  132 => 176,  129 => 175,  126 => 174,  123 => 173,  120 => 172,  118 => 171,  115 => 170,  105 => 168,  101 => 167,  98 => 166,  92 => 164,  90 => 163,  87 => 162,  81 => 160,  79 => 159,  74 => 157,  71 => 156,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/details.html.twig", "/opt/kimai/templates/customer/details.html.twig");
    }
}


/* customer/details.html.twig */
class __TwigTemplate_c48db6d226899a55ec268d3aa2df8a16___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_title' => [$this, 'block_box_title'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 7
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 8)->unwrap();
        // line 7
        $this->parent = $this->load("@theme/embeds/card.html.twig", 7);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"customer_details_box\"";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "            ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_dot", $context, 11, $this->getSourceContext())->macro_label_dot(...[CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "name", [], "any", false, false, false, 11), CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "color", [], "any", false, false, false, 11)]);
        yield "
            ";
        // line 12
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "company", [], "any", false, false, false, 12))) {
            yield " &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "company", [], "any", false, false, false, 12), "html", null, true);
        }
        // line 13
        yield "        ";
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "            ";
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 16
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 16, $this->getSourceContext())->macro_card_tool_button(...["edit", ["class" => "modal-ajax-form open-edit", "title" => "edit", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_customer_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "id", [], "any", false, false, false, 16)])]]);
            yield "
            ";
        }
        // line 18
        yield "        ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "comment", [], "any", false, false, false, 20))) {
            // line 21
            yield "                <div class=\"comment p-3\">
                    ";
            // line 22
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentContent(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "comment", [], "any", false, false, false, 22), true);
            yield "
                </div>
            ";
        }
        // line 25
        yield "            <table class=\"table table-hover dataTable\">
                ";
        // line 26
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visible", [], "any", false, false, false, 26)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 27
            yield "                    <tr class=\"";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_class_customer_row", $context, 27, $this->getSourceContext())->macro_class_customer_row(...[($context["customer"] ?? null), ($context["now"] ?? null)]);
            yield "\">
                        <th>";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("visible"), "html", null, true);
            yield "</th>
                        <td>";
            // line 29
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 29, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visible", [], "any", false, false, false, 29)]);
            yield "</td>
                    </tr>
                ";
        }
        // line 32
        yield "                ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "billable", [], "any", false, false, false, 32)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 33
            yield "                    <tr>
                        <th>";
            // line 34
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 36
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 36, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "billable", [], "any", false, false, false, 36)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 40
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine1", [], "any", false, false, false, 40))) {
            // line 41
            yield "                    <tr>
                        <th>";
            // line 42
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address"), "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 44
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine1", [], "any", false, false, false, 44), "html", null, true);
            yield "<br>
                            ";
            // line 45
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine2", [], "any", false, false, false, 45))) {
                // line 46
                yield "                                ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine2", [], "any", false, false, false, 46), "html", null, true);
                yield "<br>
                            ";
            }
            // line 48
            yield "                            ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine3", [], "any", false, false, false, 48))) {
                // line 49
                yield "                                ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "addressLine3", [], "any", false, false, false, 49), "html", null, true);
                yield "<br>
                            ";
            }
            // line 51
            yield "                            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "postCode", [], "any", false, false, false, 51), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "city", [], "any", false, false, false, 51), "html", null, true);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 55
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "address", [], "any", false, false, false, 55))) {
            // line 56
            yield "                    <tr>
                        <th>";
            // line 57
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address"), "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 59
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 59, $this->getSourceContext())->macro_alert(...["info", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address_deprecated")]);
            yield "
                            <br>
                            <i>
                            ";
            // line 62
            yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "address", [], "any", false, false, false, 62), "html", null, true));
            yield "
                            </i>
                        </td>
                    </tr>
                ";
        }
        // line 67
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "country", [], "any", false, false, false, 67))) {
            // line 68
            yield "                    <tr>
                        <th>";
            // line 69
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("country"), "html", null, true);
            yield "</th>
                        <td>";
            // line 70
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "country", [], "any", false, false, false, 70)), "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        // line 73
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "contact", [], "any", false, false, false, 73))) {
            // line 74
            yield "                    <tr>
                        <th>";
            // line 75
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("contact"), "html", null, true);
            yield "</th>
                        <td>";
            // line 76
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "contact", [], "any", false, false, false, 76), "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        // line 79
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "phone", [], "any", false, false, false, 79))) {
            // line 80
            yield "                    <tr>
                        <th>";
            // line 81
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("phone"), "html", null, true);
            yield "</th>
                        <td><a href=\"tel:";
            // line 82
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "phone", [], "any", false, false, false, 82), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "phone", [], "any", false, false, false, 82), "html", null, true);
            yield "</a></td>
                    </tr>
                ";
        }
        // line 85
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "mobile", [], "any", false, false, false, 85))) {
            // line 86
            yield "                    <tr>
                        <th>";
            // line 87
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("mobile"), "html", null, true);
            yield "</th>
                        <td><a href=\"tel:";
            // line 88
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "mobile", [], "any", false, false, false, 88), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "mobile", [], "any", false, false, false, 88), "html", null, true);
            yield "</a></td>
                    </tr>
                ";
        }
        // line 91
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "email", [], "any", false, false, false, 91))) {
            // line 92
            yield "                    <tr>
                        <th>";
            // line 93
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("email"), "html", null, true);
            yield "</th>
                        <td><a href=\"mailto:";
            // line 94
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "email", [], "any", false, false, false, 94), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "email", [], "any", false, false, false, 94), "html", null, true);
            yield "</a></td>
                    </tr>
                ";
        }
        // line 97
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "homepage", [], "any", false, false, false, 97))) {
            // line 98
            yield "                    <tr>
                        <th>";
            // line 99
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("homepage"), "html", null, true);
            yield "</th>
                        <td><a href=\"";
            // line 100
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "homepage", [], "any", false, false, false, 100), "html", null, true);
            yield "\" target=\"_blank\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::replace(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "homepage", [], "any", false, false, false, 100), ["https://" => "", "http://" => ""]), "html", null, true);
            yield "</a></td>
                    </tr>
                ";
        }
        // line 103
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "fax", [], "any", false, false, false, 103))) {
            // line 104
            yield "                    <tr>
                        <th>";
            // line 105
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("fax"), "html", null, true);
            yield "</th>
                        <td>";
            // line 106
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "fax", [], "any", false, false, false, 106), "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        // line 109
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "timezone", [], "any", false, false, false, 109))) {
            // line 110
            yield "                    <tr>
                        <th>";
            // line 111
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timezone"), "html", null, true);
            yield "</th>
                        <td>";
            // line 112
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(($context["customer_now"] ?? null)), "html", null, true);
            yield " (";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "timezone", [], "any", false, false, false, 112), "html", null, true);
            yield ")</td>
                    </tr>
                ";
        }
        // line 115
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "language", [], "any", false, false, false, 115))) {
            // line 116
            yield "                    <tr>
                        <th>";
            // line 117
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("language"), "html", null, true);
            yield "</th>
                        <td>";
            // line 118
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getLocaleName(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "language", [], "any", false, false, false, 118)), "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        // line 121
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "currency", [], "any", false, false, false, 121))) {
            // line 122
            yield "                    <tr>
                        <th>";
            // line 123
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("currency"), "html", null, true);
            yield "</th>
                        <td>";
            // line 124
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "currency", [], "any", false, false, false, 124), "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        // line 127
        yield "                ";
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("details", ($context["customer"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 128
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "number", [], "any", false, false, false, 128))) {
                // line 129
                yield "                        <tr>
                            <th>";
                // line 130
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("number"), "html", null, true);
                yield "</th>
                            <td>";
                // line 131
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "number", [], "any", false, false, false, 131), "html", null, true);
                yield "</td>
                        </tr>
                    ";
            }
            // line 134
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "vatId", [], "any", false, false, false, 134))) {
                // line 135
                yield "                        <tr>
                            <th>";
                // line 136
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
                yield "</th>
                            <td>";
                // line 137
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "vatId", [], "any", false, false, false, 137), "html", null, true);
                yield "</td>
                        </tr>
                    ";
            }
            // line 140
            yield "                    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "invoiceEmail", [], "any", false, false, false, 140))) {
                // line 141
                yield "                        <tr>
                            <th>";
                // line 142
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice_email"), "html", null, true);
                yield "</th>
                            <td><a href=\"mailto:";
                // line 143
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "invoiceEmail", [], "any", false, false, false, 143), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "invoiceEmail", [], "any", false, false, false, 143), "html", null, true);
                yield "</a></td>
                        </tr>
                    ";
            }
            // line 146
            yield "                ";
        }
        // line 147
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["customer"] ?? null), "visibleMetaFields", [], "any", false, false, false, 147), function ($__field__) use ($context, $macros) { $context["field"] = $__field__; return CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "defined", [], "any", false, false, false, 147); }), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "order", [], "any", false, false, false, 147) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "order", [], "any", false, false, false, 147)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["metaField"]) {
            // line 148
            yield "                    <tr>
                        <th>";
            // line 149
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "label", [], "any", false, false, false, 149)), "html", null, true);
            yield "</th>
                        <td>";
            // line 150
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_form_type_value", $context, 150, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "type", [], "any", false, false, false, 150), CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "value", [], "any", false, false, false, 150), ($context["customer"] ?? null)]);
            yield "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['metaField'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 153
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  692 => 153,  682 => 150,  678 => 149,  675 => 148,  670 => 147,  667 => 146,  659 => 143,  655 => 142,  652 => 141,  649 => 140,  643 => 137,  639 => 136,  636 => 135,  633 => 134,  627 => 131,  623 => 130,  620 => 129,  617 => 128,  614 => 127,  608 => 124,  604 => 123,  601 => 122,  598 => 121,  592 => 118,  588 => 117,  585 => 116,  582 => 115,  574 => 112,  570 => 111,  567 => 110,  564 => 109,  558 => 106,  554 => 105,  551 => 104,  548 => 103,  540 => 100,  536 => 99,  533 => 98,  530 => 97,  522 => 94,  518 => 93,  515 => 92,  512 => 91,  504 => 88,  500 => 87,  497 => 86,  494 => 85,  486 => 82,  482 => 81,  479 => 80,  476 => 79,  470 => 76,  466 => 75,  463 => 74,  460 => 73,  454 => 70,  450 => 69,  447 => 68,  444 => 67,  436 => 62,  430 => 59,  425 => 57,  422 => 56,  419 => 55,  409 => 51,  403 => 49,  400 => 48,  394 => 46,  392 => 45,  388 => 44,  383 => 42,  380 => 41,  377 => 40,  370 => 36,  365 => 34,  362 => 33,  359 => 32,  353 => 29,  349 => 28,  344 => 27,  342 => 26,  339 => 25,  333 => 22,  330 => 21,  327 => 20,  320 => 19,  315 => 18,  309 => 16,  306 => 15,  299 => 14,  294 => 13,  289 => 12,  284 => 11,  277 => 10,  266 => 9,  261 => 7,  259 => 8,  252 => 7,  183 => 193,  176 => 192,  170 => 189,  164 => 187,  161 => 186,  158 => 185,  155 => 184,  152 => 183,  150 => 182,  147 => 181,  141 => 179,  138 => 178,  135 => 177,  132 => 176,  129 => 175,  126 => 174,  123 => 173,  120 => 172,  118 => 171,  115 => 170,  105 => 168,  101 => 167,  98 => 166,  92 => 164,  90 => 163,  87 => 162,  81 => 160,  79 => 159,  74 => 157,  71 => 156,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/details.html.twig", "/opt/kimai/templates/customer/details.html.twig");
    }
}
