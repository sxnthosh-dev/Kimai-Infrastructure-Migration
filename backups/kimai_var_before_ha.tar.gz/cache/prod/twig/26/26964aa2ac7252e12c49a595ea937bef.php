<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/timeline.html.twig */
class __TwigTemplate_cef93b617260fb793a7f233b401f837e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_timeline($items = null, $values = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "values" => $values,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $context["_isSimple"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "simple", [], "any", true, true, false, 2) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "simple", [], "any", false, false, false, 2)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["values"] ?? null), "simple", [], "any", false, false, false, 2)) : (false));
            // line 3
            yield "
    <ul class=\"timeline ";
            // line 4
            if ((($tmp = ($context["_isSimple"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "timeline-simple";
            }
            yield "\">
        ";
            // line 5
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 6
                yield "            <li class=\"timeline-event\">
                ";
                // line 7
                if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", true, true, false, 7)) {
                    // line 8
                    yield "                    <div class=\"timeline-event-icon ";
                    if (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "iconColor", [], "any", true, true, false, 8)) {
                        yield "bg-";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "iconColor", [], "any", false, false, false, 8), "html", null, true);
                        yield "-lt";
                    }
                    yield "\">
                        ";
                    // line 9
                    yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, false, 9), false);
                    yield "
                    </div>
                ";
                }
                // line 12
                yield "                ";
                if (((($tmp = ($context["_isSimple"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "time", [], "any", true, true, false, 12) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "time", [], "any", false, false, false, 12))))) {
                    // line 13
                    yield "                    <div class=\"card timeline-event-card\">
                        <div class=\"card-body\">
                            ";
                    // line 15
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "time", [], "any", true, true, false, 15) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "time", [], "any", false, false, false, 15)))) {
                        // line 16
                        yield "                            <div class=\"text-body-secondary float-end\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "time", [], "any", false, false, false, 16), "html", null, true);
                        yield "</div>
                            ";
                    }
                    // line 18
                    yield "                            ";
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 18)))) {
                        // line 19
                        yield "                                <h4>";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 19), "html", null, true);
                        yield "</h4>
                            ";
                    }
                    // line 21
                    yield "                            ";
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "text", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, false, 21)))) {
                        // line 22
                        yield "                                <p class=\"text-body-secondary\">";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["item"], "text", [], "any", false, false, false, 22), "html", null, true);
                        yield "</p>
                            ";
                    } elseif ((CoreExtension::getAttribute($this->env, $this->source,                     // line 23
$context["item"], "textHtml", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "textHtml", [], "any", false, false, false, 23)))) {
                        // line 24
                        yield "                                ";
                        yield (string) CoreExtension::getAttribute($this->env, $this->source, $context["item"], "textHtml", [], "any", false, false, false, 24);
                        yield "
                            ";
                    }
                    // line 26
                    yield "                        </div>
                    </div>
                ";
                }
                // line 29
                yield "            </li>
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 31
            yield "    </ul>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/timeline.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  148 => 31,  140 => 29,  135 => 26,  129 => 24,  127 => 23,  122 => 22,  119 => 21,  113 => 19,  110 => 18,  104 => 16,  102 => 15,  98 => 13,  95 => 12,  89 => 9,  80 => 8,  78 => 7,  75 => 6,  71 => 5,  65 => 4,  62 => 3,  59 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/timeline.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/timeline.html.twig");
    }
}
