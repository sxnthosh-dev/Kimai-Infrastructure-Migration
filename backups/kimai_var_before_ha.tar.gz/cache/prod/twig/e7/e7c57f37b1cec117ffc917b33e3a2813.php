<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @!Tabler/includes/logo.html.twig */
class __TwigTemplate_b27b6384908dafa031020ff42695b9d1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<a href=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_welcome"));
        yield "\">
    ";
        // line 2
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 2))) {
            // line 3
            yield "        <img
                class=\"navbar-brand-image\"
                src=\"";
            // line 5
            if (CoreExtension::inFilter("://", CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 5))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 5), "html", null, true);
            } else {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 5)), "html", null, true);
            }
            yield "\"
                width=\"110\" height=\"32\"
                alt=\"\"
        >
    ";
        } else {
            // line 10
            yield "        <i class=\"far fa-smile\" style=\"font-size: 32px\"></i>
    ";
        }
        // line 12
        yield "</a>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@!Tabler/includes/logo.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  70 => 12,  66 => 10,  54 => 5,  50 => 3,  48 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@!Tabler/includes/logo.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/logo.html.twig");
    }
}
