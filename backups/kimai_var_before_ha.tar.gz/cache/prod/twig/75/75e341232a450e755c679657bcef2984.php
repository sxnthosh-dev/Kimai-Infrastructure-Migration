<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-userteamprojects.html.twig */
class __TwigTemplate_78b54603b0d025fd03886e3bcd469d0e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["projectStats"] = ($context["data"] ?? null);
        // line 2
        $context["title"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", true, true, false, 2)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "title", [], "any", false, false, false, 2), "my_team_projects")) : ("my_team_projects"));
        // line 3
        yield "
";
        // line 4
        yield from $this->load("widget/widget-userteamprojects.html.twig", 4, 1)->unwrap()->yield(CoreExtension::merge($context, ["margin_bottom" => 0]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-userteamprojects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-userteamprojects.html.twig", "/opt/kimai/templates/widget/widget-userteamprojects.html.twig");
    }
}


/* widget/widget-userteamprojects.html.twig */
class __TwigTemplate_78b54603b0d025fd03886e3bcd469d0e___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 5)->unwrap();
        // line 6
        $macros["progress"] = $this->macros["progress"] = $this->load("macros/progressbar.html.twig", 6)->unwrap();
        // line 4
        $this->parent = $this->load("@theme/embeds/card.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "p-0 box-body-scrollable";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "        ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["title"] ?? null))) {
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
        }
        // line 10
        yield "    ";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        <table class=\"table table-hover dataTable\" role=\"grid\">
            <tbody>
            ";
        // line 14
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["projectStats"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "entity", [], "any", false, false, false, 14), "name", [], "any", false, false, false, 14) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "entity", [], "any", false, false, false, 14), "name", [], "any", false, false, false, 14)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 15
            yield "                ";
            $context["project"] = CoreExtension::getAttribute($this->env, $this->source, $context["row"], "entity", [], "any", false, false, false, 15);
            // line 16
            yield "                <tr";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("details", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " class=\"alternative-link open-edit\" data-href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("project_details", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 16)]), "html", null, true);
                yield "\"";
            }
            yield ">
                    <td>
                        ";
            // line 18
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 18, $this->getSourceContext())->macro_label_project(...[($context["project"] ?? null)]);
            yield "
                        <br>
                        <small>";
            // line 20
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 20, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 20)]);
            yield "</small>
                    </td>
                    <td style=\"width:50%\">
                        ";
            // line 23
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["row"], "hasBudget", [], "method", false, false, false, 23)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", CoreExtension::getAttribute($this->env, $this->source, $context["row"], "entity", [], "any", false, false, false, 23))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 24
                yield "                            ";
                yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_budget", $context, 24, $this->getSourceContext())->macro_progressbar_budget(...[$context["row"], CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["row"], "entity", [], "any", false, false, false, 24), "customer", [], "any", false, false, false, 24), "currency", [], "any", false, false, false, 24)]);
                yield "
                        ";
            } elseif (((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 25
$context["row"], "hasTimeBudget", [], "method", false, false, false, 25)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", CoreExtension::getAttribute($this->env, $this->source, $context["row"], "entity", [], "any", false, false, false, 25))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 26
                yield "                            ";
                yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_timebudget", $context, 26, $this->getSourceContext())->macro_progressbar_timebudget(...[$context["row"]]);
                yield "
                        ";
            }
            // line 28
            yield "                    </td>
                </tr>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['row'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 31
        yield "            </tbody>
        </table>
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-userteamprojects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  216 => 31,  207 => 28,  201 => 26,  199 => 25,  194 => 24,  192 => 23,  186 => 20,  181 => 18,  171 => 16,  168 => 15,  164 => 14,  160 => 12,  153 => 11,  148 => 10,  143 => 9,  136 => 8,  125 => 7,  120 => 4,  118 => 6,  116 => 5,  50 => 4,  47 => 3,  45 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-userteamprojects.html.twig", "/opt/kimai/templates/widget/widget-userteamprojects.html.twig");
    }
}
