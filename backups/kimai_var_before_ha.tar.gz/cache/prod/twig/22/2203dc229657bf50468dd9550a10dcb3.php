<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/templates.html.twig */
class __TwigTemplate_dc591417a6954a415173ada8b49a94cb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row' => [$this, 'block_datatable_row'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 4
        $macros["actions"] = $this->macros["actions"] = $this->load("invoice/actions.html.twig", 4)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    <tr class=\"modal-ajax-form open-edit\" data-href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_invoice_template_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 7)]), "html", null, true);
        yield "\">
        <td class=\"";
        // line 8
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 8, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "name"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 8), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 9
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 9, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "title"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "title", [], "any", false, false, false, 9), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 10
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 10, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "company"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "company", [], "any", false, false, false, 10), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 11
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 11, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "vat_id"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "vatId", [], "any", false, false, false, 11), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 12
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 12, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "tax_rate"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "vat", [], "any", false, false, false, 12), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 13
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 13, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "due_days"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "dueDays", [], "any", false, false, false, 13), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 14
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 14, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "address"]);
        yield "\">";
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "address", [], "any", false, false, false, 14), "html", null, true));
        yield "</td>
        <td class=\"";
        // line 15
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 15, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "contact"]);
        yield "\">";
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "contact", [], "any", false, false, false, 15), "html", null, true));
        yield "</td>
        <td class=\"";
        // line 16
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 16, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "calculator"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "calculator", [], "any", false, false, false, 16), [], "invoice-calculator"), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 17
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 17, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "renderer"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "renderer", [], "any", false, false, false, 17), [], "invoice-renderer"), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 18
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 18, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "language"]);
        yield "\">";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "language", [], "any", false, false, false, 18))) {
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getLocaleName(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "language", [], "any", false, false, false, 18)), "html", null, true);
        }
        yield "</td>
        <td class=\"";
        // line 19
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 19, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "actions"]);
        yield "\">";
        // line 20
        yield (string) $macros["actions"]->getTemplateForMacro("macro_invoice_template", $context, 20, $this->getSourceContext())->macro_invoice_template(...[($context["entry"] ?? null), "index"]);
        // line 21
        yield "</td>
    </tr>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/templates.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  144 => 21,  142 => 20,  139 => 19,  131 => 18,  125 => 17,  119 => 16,  113 => 15,  107 => 14,  101 => 13,  95 => 12,  89 => 11,  83 => 10,  77 => 9,  71 => 8,  66 => 7,  59 => 6,  54 => 1,  52 => 4,  50 => 3,  48 => 2,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/templates.html.twig", "/opt/kimai/templates/invoice/templates.html.twig");
    }
}
