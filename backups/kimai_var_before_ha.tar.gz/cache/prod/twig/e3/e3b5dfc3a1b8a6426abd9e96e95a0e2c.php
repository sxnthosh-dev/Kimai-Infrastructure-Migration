<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/index.html.twig */
class __TwigTemplate_968b1cbca049e157d478d4833d512567 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'status' => [$this, 'block_status'],
            'main_before' => [$this, 'block_main_before'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 5
        $context["totalDuration"] = 0;
        // line 6
        $context["totalRates"] = [];
        // line 8
        if ((( !(($context["too_many"] ?? null) === true) && (($tmp = ($context["preview_show"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) &&  !Twig\Extension\CoreExtension::testEmpty(($context["entries"] ?? null)))) {
            // line 9
            yield "    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["by_customer"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
                // line 10
                yield "        ";
                $context["totalDuration"] = (($context["totalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["row"], "duration", [], "any", false, false, false, 10));
                // line 11
                yield "        ";
                $context["customerCurrency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["row"], "customer", [], "any", false, false, false, 11), "currency", [], "any", false, false, false, 11);
                // line 12
                yield "        ";
                if ( !CoreExtension::getAttribute($this->env, $this->source, ($context["totalRates"] ?? null), ($context["customerCurrency"] ?? null), [], "array", true, true, false, 12)) {
                    // line 13
                    yield "            ";
                    $context["totalRates"] = Twig\Extension\CoreExtension::merge(($context["totalRates"] ?? null), [ (string)($context["customerCurrency"] ?? null) => 0.0]);
                    // line 14
                    yield "        ";
                }
                // line 15
                yield "        ";
                $context["totalRates"] = Twig\Extension\CoreExtension::merge(($context["totalRates"] ?? null), [ (string)($context["customerCurrency"] ?? null) => ((($_v0 = ($context["totalRates"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = ($context["customerCurrency"] ?? null)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["row"], "rate", [], "any", false, false, false, 15))]);
                // line 16
                yield "    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['row'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
        }
        // line 19
        $context["columns"] = ["avatar" => ["class" => "text-nowrap w-avatar d-none d-md-table-cell", "title" => false, "orderBy" => false], "date" => ["class" => "alwaysVisible text-nowrap", "orderBy" => false], "begin" => ["class" => "d-none", "orderBy" => false], "end" => ["class" => "d-none", "orderBy" => false], "user" => ["class" => "d-none", "orderBy" => false], "project" => ["class" => "d-none d-sm-table-cell", "orderBy" => false], "activity" => ["class" => "d-none", "orderBy" => false], "description" => ["class" => "d-none d-xl-table-cell timesheet-description", "orderBy" => false], "tags" => ["class" => "d-none d-xl-table-cell", "orderBy" => false], "duration" => ["class" => "text-end text-nowrap", "orderBy" => false]];
        // line 31
        if ((($tmp = ($context["show_rates"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 32
            yield "    ";
            $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["unit_price" => ["class" => "d-none text-nowrap text-end", "orderBy" => false], "internalRate" => ["class" => "text-end d-none text-nowrap", "orderBy" => false], "total_rate" => ["class" => "text-end text-nowrap", "orderBy" => false]]);
        }
        // line 38
        $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), ["actions" => ["class" => "actions alwaysVisible", "orderBy" => false]]);
        // line 42
        $context["tableName"] = "export";
        // line 43
        $context["editExported"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit_exported_timesheet");
        // line 44
        $context["showMarkAsExportedButton"] = false;
        // line 45
        $context["showToggleButton"] = false;
        // line 46
        if (( !Twig\Extension\CoreExtension::testEmpty(($context["entries"] ?? null)) && CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "markAsExported", [], "any", true, true, false, 46))) {
            // line 47
            yield "    ";
            $context["showMarkAsExportedButton"] = (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 47), "vars", [], "any", false, false, false, 47), "value", [], "any", false, false, false, 47) != Twig\Extension\CoreExtension::constant("App\\Repository\\Query\\TimesheetQuery::STATE_EXPORTED"));
            // line 48
            yield "    ";
            $context["showToggleButton"] = ((($tmp = ($context["preview_show"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 48), "vars", [], "any", false, false, false, 48), "value", [], "any", false, false, false, 48) != Twig\Extension\CoreExtension::constant("App\\Repository\\Query\\TimesheetQuery::STATE_ALL")));
        }
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 51
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 52
        yield "    ";
        $macros["_v2"] = $this->load("macros/status.html.twig", 52)->unwrap();
        // line 53
        yield "    ";
        if ((($context["totalDuration"] ?? null) > 0)) {
            // line 54
            yield "        ";
            yield (string) $macros["_v2"]->getTemplateForMacro("macro_status_duration", $context, 54, $this->getSourceContext())->macro_status_duration(...[$this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["totalDuration"] ?? null))]);
            yield "
    ";
        }
        // line 56
        yield "    ";
        if ((($tmp = ($context["show_rates"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 57
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["totalRates"] ?? null));
            foreach ($context['_seq'] as $context["totalCurrency"] => $context["totalRate"]) {
                // line 58
                yield "            ";
                yield (string) $macros["_v2"]->getTemplateForMacro("macro_status_money", $context, 58, $this->getSourceContext())->macro_status_money(...[$this->extensions['App\Twig\LocaleFormatExtensions']->money($context["totalRate"], $context["totalCurrency"])]);
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['totalCurrency'], $context['totalRate'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 60
            yield "    ";
        }
        yield from [];
    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 64
        yield "    ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_modal", $context, 64, $this->getSourceContext())->macro_data_table_column_modal(...[($context["tableName"] ?? null), ($context["columns"] ?? null)]);
        yield "
";
        yield from [];
    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "
    ";
        // line 69
        yield from $this->load("export/index.html.twig", 69, 1)->unwrap()->yield($context);
        // line 103
        yield "
    ";
        // line 104
        if ((($context["too_many"] ?? null) === true)) {
            // line 105
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_callout", $context, 105, $this->getSourceContext())->macro_callout(...["danger", "error.too_many_entries"]);
            yield "
    ";
        } elseif ((($tmp =         // line 106
($context["preview_show"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 107
            yield "        ";
            if (Twig\Extension\CoreExtension::testEmpty(($context["entries"] ?? null))) {
                // line 108
                yield "            ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 108, $this->getSourceContext())->macro_nothing_found(...[]);
                yield "
        ";
            } else {
                // line 110
                yield "            ";
                yield from $this->load("export/index.html.twig", 110, 2)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
                // line 212
                yield "
            ";
                // line 213
                $context["itemsAmount"] = Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["entries"] ?? null));
                // line 214
                yield "            ";
                if ((($tmp = ($context["preview_limit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 215
                    yield "                ";
                    $context["entries"] = Twig\Extension\CoreExtension::slice($this->env->getCharset(), ($context["entries"] ?? null), 0, ($context["preview_limit"] ?? null));
                    // line 216
                    yield "            ";
                }
                // line 217
                yield "
            ";
                // line 218
                yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 218, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), ($context["query"] ?? null)]);
                yield "
            ";
                // line 219
                $context["edit_route"] = (((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_other_timesheet")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("admin_timesheet_edit") : ("timesheet_edit"));
                // line 220
                yield "            ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 221
                    yield "                ";
                    $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 221), "customer", [], "any", false, false, false, 221), "currency", [], "any", false, false, false, 221);
                    // line 222
                    yield "                ";
                    if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 222))) {
                        // line 223
                        yield "                    ";
                        $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "fixedRate", [], "any", false, false, false, 223);
                        // line 224
                        yield "                ";
                    } else {
                        // line 225
                        yield "                    ";
                        $context["rate"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "hourlyRate", [], "any", false, false, false, 225);
                        // line 226
                        yield "                ";
                    }
                    // line 227
                    yield "                <tr";
                    if (((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "type", [], "any", false, false, false, 227) == "timesheet") && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", $context["entry"])) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                        // line 228
                        yield "                    class=\"modal-ajax-form open-edit\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["edit_route"] ?? null), ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "id", [], "any", false, false, false, 228)]), "html", null, true);
                        yield "\"";
                    }
                    yield ">
                    <td class=\"";
                    // line 229
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 229, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "avatar"]);
                    yield "\">
                        ";
                    // line 230
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 230, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 230)]);
                    yield "
                    </td>
                    <td class=\"";
                    // line 232
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 232, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "date"]);
                    yield "\">
                        ";
                    // line 233
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 233)), "html", null, true);
                    yield "
                    </td>
                    <td class=\"";
                    // line 235
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 235, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "begin"]);
                    yield "\">
                        ";
                    // line 236
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "begin", [], "any", false, false, false, 236)), "html", null, true);
                    yield "
                    </td>
                    <td class=\"";
                    // line 238
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 238, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "begin"]);
                    yield "\">
                        ";
                    // line 239
                    if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 239)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 240
                        yield "                            ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->time(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "end", [], "any", false, false, false, 240)), "html", null, true);
                        yield "
                        ";
                    } else {
                        // line 242
                        yield "                            &dash;
                        ";
                    }
                    // line 244
                    yield "                    </td>
                    <td class=\"";
                    // line 245
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 245, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "user"]);
                    yield "\">
                        ";
                    // line 246
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_user", $context, 246, $this->getSourceContext())->macro_label_user(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "user", [], "any", false, false, false, 246)]);
                    yield "
                    </td>
                    <td class=\"";
                    // line 248
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 248, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "project"]);
                    yield "\">
                        ";
                    // line 249
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 249, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 249)]);
                    yield "
                        <br>
                        <small>";
                    // line 251
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 251, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 251), "customer", [], "any", false, false, false, 251)]);
                    yield "</small>
                    </td>
                    <td class=\"";
                    // line 253
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 253, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "activity"]);
                    yield "\">
                        ";
                    // line 254
                    if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 254))) {
                        // line 255
                        yield "                            ";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 255, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "activity", [], "any", false, false, false, 255)]);
                        yield "
                        ";
                    }
                    // line 257
                    yield "                    </td>
                    <td class=\"";
                    // line 258
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 258, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "description"]);
                    yield "\">
                        ";
                    // line 259
                    yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->timesheetContent(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "description", [], "any", false, false, false, 259));
                    yield "
                    </td>
                    <td class=\"";
                    // line 261
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 261, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "tags"]);
                    yield "\">
                        ";
                    // line 262
                    if ((CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "type", [], "any", false, false, false, 262) == "timesheet")) {
                        // line 263
                        yield "                            ";
                        yield (string) $macros["widgets"]->getTemplateForMacro("macro_tag_list", $context, 263, $this->getSourceContext())->macro_tag_list(...[CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "tags", [], "any", false, false, false, 263)]);
                        yield "
                        ";
                    }
                    // line 265
                    yield "                    </td>
                    <td class=\"";
                    // line 266
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 266, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "duration"]);
                    yield "\" data-duration=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 266), "html", null, true);
                    yield "\">
                        ";
                    // line 267
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "duration", [], "any", false, false, false, 267)), "html", null, true);
                    yield "
                    </td>
                    ";
                    // line 269
                    if ((($tmp = ($context["show_rates"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 270
                        yield "                    <td class=\"";
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 270, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "unit_price"]);
                        yield "\">
                        ";
                        // line 271
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["rate"] ?? null), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                    </td>
                    <td class=\"";
                        // line 273
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 273, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "internalRate"]);
                        yield "\">
                        ";
                        // line 274
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "internalRate", [], "any", false, false, false, 274), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                    </td>
                    <td class=\"";
                        // line 276
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 276, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "total_rate"]);
                        yield "\">
                        ";
                        // line 277
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "rate", [], "any", false, false, false, 277), ($context["currency"] ?? null)), "html", null, true);
                        yield "
                    </td>
                    ";
                    }
                    // line 280
                    yield "                    <td class=\"";
                    yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 280, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), "actions"]);
                    yield "\">
                    ";
                    // line 281
                    if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit_export", $context["entry"])) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                        // line 282
                        yield "                        ";
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "exported", [], "any", false, false, false, 282)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 283
                            yield "                            ";
                            if ((($tmp = ($context["editExported"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                                // line 284
                                yield "                                <button type=\"button\" class=\"btn btn-default exportBtn\" data-toggle=\"button\" aria-pressed=\"true\"
                                        data-exported-text=\"";
                                // line 285
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.exported"), "html", null, true);
                                yield "\" data-clean-text=\"";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.not_exported"), "html", null, true);
                                yield "\" data-timesheet=\"";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "id", [], "any", false, false, false, 285), "html", null, true);
                                yield "\">
                                    ";
                                // line 286
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.exported"), "html", null, true);
                                yield "
                                </button>
                            ";
                            } else {
                                // line 289
                                yield "                                ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.exported"), "html", null, true);
                                yield "
                            ";
                            }
                            // line 291
                            yield "                        ";
                        } else {
                            // line 292
                            yield "                            <button type=\"button\" class=\"btn btn-default exportBtn\" data-toggle=\"button\" aria-pressed=\"false\"
                                    data-exported-text=\"";
                            // line 293
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.exported"), "html", null, true);
                            yield "\" data-clean-text=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.not_exported"), "html", null, true);
                            yield "\" data-timesheet=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "id", [], "any", false, false, false, 293), "html", null, true);
                            yield "\">
                                ";
                            // line 294
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.not_exported"), "html", null, true);
                            yield "
                            </button>
                        ";
                        }
                        // line 297
                        yield "                    ";
                    } else {
                        // line 298
                        yield "                        ";
                        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "exported", [], "any", false, false, false, 298)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 299
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.exported"), "html", null, true);
                            yield "
                        ";
                        } else {
                            // line 301
                            yield "                            ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("entryState.not_exported"), "html", null, true);
                            yield "
                        ";
                        }
                        // line 303
                        yield "                    ";
                    }
                    // line 304
                    yield "                    </td>
                </tr>
            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 307
                yield "            ";
                if (((($tmp = ($context["preview_limit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["itemsAmount"] ?? null) > ($context["preview_limit"] ?? null)))) {
                    // line 308
                    yield "                <tr class=\"warning\">
                    <td colspan=\"10\">&raquo; ";
                    // line 309
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("preview.skipped_rows", ["%rows%" => (($context["itemsAmount"] ?? null) - ($context["preview_limit"] ?? null))]), "html", null, true);
                    yield "</td>
                </tr>
            ";
                }
                // line 312
                yield "            ";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 312, $this->getSourceContext())->macro_data_table_footer(...[($context["entries"] ?? null)]);
                yield "
        ";
            }
            // line 314
            yield "    ";
        }
        // line 315
        yield "
";
        yield from [];
    }

    // line 318
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 319
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        KimaiReloadPageWidget.create(\x27kimai.exportTemplate\x27, true);

        function updateTimesheetExportState(node, id)
        {
            /** @type {KimaiAlert} */
            const ALERT = kimai.getPlugin(\x27alert\x27);
            /** @type {KimaiAPI} */
            const API = kimai.getPlugin(\x27api\x27);

            API.patch(
                \x27";
        // line 331
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export_timesheet", ["id" => 1]);
        yield "\x27.replace(\x271\x27, id),
                {},
                function(data) {
                    const table = node.closest(\x27table\x27)
                    const row = node.closest(\x27tr\x27);
                    row.remove();
                    const list = table.querySelectorAll(\x27tbody tr\x27);
                    if (list.length === 0) {
                        document.querySelector(\x27form#export-form button.performSearch\x27).click();
                    }
                }
            );
        }

        document.addEventListener(\x27kimai.initialized\x27, function() {
            document.addEventListener(\x27click\x27, function (event) {
                const node = event.target;
                if (node.matches(\x27.exportBtn\x27)) {
                    if (node.dataset[\x27timesheet\x27] !== undefined) {
                        const id = node.dataset[\x27timesheet\x27];
                        updateTimesheetExportState(node, id);
                    }
                }

                ";
        // line 359
        yield "                if (node.matches(\x27#export-buttons .startExportBtn\x27)) {
                    event.preventDefault();

                    /** @type {KimaiForm} */
                    const FORM = kimai.getPlugin(\x27form\x27);
                    const overwrites = {
                        \x27renderer\x27: node.dataset[\x27type\x27],
                        \x27_token\x27: document.getElementById(\x27export-token\x27).dataset[\x27value\x27],
                    };

                    const uri = FORM.convertFormDataToQueryString(document.getElementById(\x27export-form\x27), overwrites);

                    // remove the form of a previous export, it cannot be deleted right
                    // after submitting it, as that might cancel the pending request
                    const previous = document.getElementById(\x27export-post-form\x27);
                    if (previous !== null) {
                        previous.remove();
                    }

                    const form = document.createElement(\x27form\x27);
                    form.id = \x27export-post-form\x27;
                    form.method = \x27POST\x27;
                    form.action = \x27";
        // line 381
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export_data");
        yield "\x27;
                    form.target = \x27_blank\x27;

                    for (const [name, value] of new URLSearchParams(uri)) {
                        const field = document.createElement(\x27input\x27);
                        field.type = \x27hidden\x27;
                        field.name = name;
                        field.value = value;
                        form.appendChild(field);
                    }

                    document.body.appendChild(form);
                    form.submit();
                }
            }, false);

            ";
        // line 397
        if ((($tmp = ($context["showMarkAsExportedButton"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 398
            yield "                document.getElementById(\x27markAsExportedCheck\x27).addEventListener(\x27change\x27, function(event) {
                    document.getElementById(\x27markAsExported\x27).value = event.target.checked ? 1 : 0;
                });
            ";
        }
        // line 402
        yield "        });

        ";
        // line 404
        if ((($tmp = ($context["showToggleButton"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 405
            yield "            function confirmToggleState(doExport)
            {
                let ALERT = kimai.getPlugin(\x27alert\x27);
                let message = \x27";
            // line 408
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.clear_all"), "html", null, true);
            yield "\x27;

                if (doExport) {
                    message = \x27";
            // line 411
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.mark_all"), "html", null, true);
            yield "\x27;
                }

                ALERT.question(message, function(value) {
                    if (!value) {
                        return;
                    }

                    [].slice.call(document.querySelectorAll(\x27.exportBtn\x27)).map(function (element) {
                        element.click();
                    });

                    document.getElementById(\x27toggle-button\x27).classList.add(\x27d-none\x27);
                });
            }

            document.getElementById(\x27toggle-button\x27).addEventListener(\x27click\x27, function (event) {
                confirmToggleState(";
            // line 428
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 428), "vars", [], "any", false, false, false, 428), "value", [], "any", false, false, false, 428) == "5")) {
                yield "true";
            } else {
                yield "false";
            }
            yield ");
            }, false);
        ";
        }
        // line 431
        yield "    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  685 => 431,  675 => 428,  655 => 411,  649 => 408,  644 => 405,  642 => 404,  638 => 402,  632 => 398,  630 => 397,  611 => 381,  587 => 359,  560 => 331,  544 => 319,  537 => 318,  531 => 315,  528 => 314,  522 => 312,  516 => 309,  513 => 308,  510 => 307,  501 => 304,  498 => 303,  492 => 301,  486 => 299,  483 => 298,  480 => 297,  474 => 294,  466 => 293,  463 => 292,  460 => 291,  454 => 289,  448 => 286,  440 => 285,  437 => 284,  434 => 283,  431 => 282,  429 => 281,  424 => 280,  418 => 277,  414 => 276,  409 => 274,  405 => 273,  400 => 271,  395 => 270,  393 => 269,  388 => 267,  382 => 266,  379 => 265,  373 => 263,  371 => 262,  367 => 261,  362 => 259,  358 => 258,  355 => 257,  349 => 255,  347 => 254,  343 => 253,  338 => 251,  333 => 249,  329 => 248,  324 => 246,  320 => 245,  317 => 244,  313 => 242,  307 => 240,  305 => 239,  301 => 238,  296 => 236,  292 => 235,  287 => 233,  283 => 232,  278 => 230,  274 => 229,  267 => 228,  264 => 227,  261 => 226,  258 => 225,  255 => 224,  252 => 223,  249 => 222,  246 => 221,  241 => 220,  239 => 219,  235 => 218,  232 => 217,  229 => 216,  226 => 215,  223 => 214,  221 => 213,  218 => 212,  215 => 110,  209 => 108,  206 => 107,  204 => 106,  199 => 105,  197 => 104,  194 => 103,  192 => 69,  189 => 68,  182 => 67,  174 => 64,  167 => 63,  161 => 60,  151 => 58,  146 => 57,  143 => 56,  137 => 54,  134 => 53,  131 => 52,  124 => 51,  119 => 1,  115 => 48,  112 => 47,  110 => 46,  108 => 45,  106 => 44,  104 => 43,  102 => 42,  100 => 38,  96 => 32,  94 => 31,  92 => 19,  84 => 16,  81 => 15,  78 => 14,  75 => 13,  72 => 12,  69 => 11,  66 => 10,  61 => 9,  59 => 8,  57 => 6,  55 => 5,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/index.html.twig", "/opt/kimai/templates/export/index.html.twig");
    }
}


/* export/index.html.twig */
class __TwigTemplate_968b1cbca049e157d478d4833d512567___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_before' => [$this, 'block_box_before'],
            'box_body' => [$this, 'block_box_body'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_after' => [$this, 'block_box_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 69
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 70
        $macros["search"] = $this->macros["search"] = $this->load("macros/search.html.twig", 70)->unwrap();
        // line 71
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 69
        $this->parent = $this->load("@theme/embeds/card.html.twig", 69);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.filter"), "html", null, true);
        yield from [];
    }

    // line 73
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 75
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
            ";
        // line 76
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "searchTerm", [], "any", false, false, false, 76), 'row');
        yield "
            ";
        // line 77
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "daterange", [], "any", false, false, false, 77), 'row');
        yield "
            ";
        // line 78
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customers", [], "any", false, false, false, 78), 'row');
        yield "
            ";
        // line 79
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "projects", [], "any", false, false, false, 79), 'row');
        yield "
            ";
        // line 80
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "activities", [], "any", false, false, false, 80), 'row');
        yield "
            ";
        // line 81
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "tags", [], "any", false, false, false, 81), 'row');
        yield "
            ";
        // line 82
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", true, true, false, 82)) {
            // line 83
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "users", [], "any", false, false, false, 83), 'row');
            yield "
            ";
        }
        // line 85
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 85)) {
            // line 86
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 86), 'row');
            yield "
            ";
        }
        // line 88
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 88), 'row');
        yield "
            ";
        // line 89
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 89), 'row');
        yield "
            ";
        // line 90
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "state", [], "any", false, false, false, 90), 'row');
        yield "
            ";
        // line 91
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "markAsExported", [], "any", true, true, false, 91)) {
            // line 92
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "markAsExported", [], "any", false, false, false, 92), 'row');
            yield "
            ";
        }
        // line 94
        yield "        ";
        yield from [];
    }

    // line 95
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 96
        yield "            ";
        yield (string) $macros["search"]->getTemplateForMacro("macro_searchButton", $context, 96, $this->getSourceContext())->macro_searchButton(...[($context["form"] ?? null)]);
        yield "
        ";
        yield from [];
    }

    // line 98
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 99
        yield "            ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
            <div style=\"display: none\" id=\"export-token\" data-value=\"";
        // line 100
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("export.data"), "html", null, true);
        yield "\"></div>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  892 => 100,  887 => 99,  880 => 98,  872 => 96,  865 => 95,  860 => 94,  854 => 92,  852 => 91,  848 => 90,  844 => 89,  839 => 88,  833 => 86,  830 => 85,  824 => 83,  822 => 82,  818 => 81,  814 => 80,  810 => 79,  806 => 78,  802 => 77,  798 => 76,  793 => 75,  786 => 74,  775 => 73,  764 => 72,  759 => 69,  757 => 71,  755 => 70,  748 => 69,  685 => 431,  675 => 428,  655 => 411,  649 => 408,  644 => 405,  642 => 404,  638 => 402,  632 => 398,  630 => 397,  611 => 381,  587 => 359,  560 => 331,  544 => 319,  537 => 318,  531 => 315,  528 => 314,  522 => 312,  516 => 309,  513 => 308,  510 => 307,  501 => 304,  498 => 303,  492 => 301,  486 => 299,  483 => 298,  480 => 297,  474 => 294,  466 => 293,  463 => 292,  460 => 291,  454 => 289,  448 => 286,  440 => 285,  437 => 284,  434 => 283,  431 => 282,  429 => 281,  424 => 280,  418 => 277,  414 => 276,  409 => 274,  405 => 273,  400 => 271,  395 => 270,  393 => 269,  388 => 267,  382 => 266,  379 => 265,  373 => 263,  371 => 262,  367 => 261,  362 => 259,  358 => 258,  355 => 257,  349 => 255,  347 => 254,  343 => 253,  338 => 251,  333 => 249,  329 => 248,  324 => 246,  320 => 245,  317 => 244,  313 => 242,  307 => 240,  305 => 239,  301 => 238,  296 => 236,  292 => 235,  287 => 233,  283 => 232,  278 => 230,  274 => 229,  267 => 228,  264 => 227,  261 => 226,  258 => 225,  255 => 224,  252 => 223,  249 => 222,  246 => 221,  241 => 220,  239 => 219,  235 => 218,  232 => 217,  229 => 216,  226 => 215,  223 => 214,  221 => 213,  218 => 212,  215 => 110,  209 => 108,  206 => 107,  204 => 106,  199 => 105,  197 => 104,  194 => 103,  192 => 69,  189 => 68,  182 => 67,  174 => 64,  167 => 63,  161 => 60,  151 => 58,  146 => 57,  143 => 56,  137 => 54,  134 => 53,  131 => 52,  124 => 51,  119 => 1,  115 => 48,  112 => 47,  110 => 46,  108 => 45,  106 => 44,  104 => 43,  102 => 42,  100 => 38,  96 => 32,  94 => 31,  92 => 19,  84 => 16,  81 => 15,  78 => 14,  75 => 13,  72 => 12,  69 => 11,  66 => 10,  61 => 9,  59 => 8,  57 => 6,  55 => 5,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/index.html.twig", "/opt/kimai/templates/export/index.html.twig");
    }
}


/* export/index.html.twig */
class __TwigTemplate_968b1cbca049e157d478d4833d512567___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 110
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 111
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 111)->unwrap();
        // line 110
        $this->parent = $this->load("@theme/embeds/card.html.twig", 110);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 112
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 113
        yield "                    ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("preview"), "html", null, true);
        yield "
                ";
        yield from [];
    }

    // line 115
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"preview_export\"";
        yield from [];
    }

    // line 116
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 117
        yield "                    ";
        if ((($tmp = ($context["showMarkAsExportedButton"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 118
            yield "                    <div class=\"d-flex\">
                        <div class=\"form-check form-switch\">
                            <input type=\"checkbox\" id=\"markAsExportedCheck\" name=\"markAsExportedCheck\" class=\"form-check-input\" value=\"1\" ";
            // line 120
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "markAsExported", [], "any", false, false, false, 120), "vars", [], "any", false, false, false, 120), "value", [], "any", false, false, false, 120) == "1")) {
                yield " checked=\"checked\"";
            }
            yield ">
                            <label class=\"form-check-label\" for=\"markAsExportedCheck\">";
            // line 121
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("mark_as_exported"), "html", null, true);
            yield "</label>
                        </div>
                    </div>
                    ";
        }
        // line 125
        yield "                    <div class=\"d-flex\">
                        <div class=\"btn-group me-auto\" id=\"export-buttons\" role=\"group\">
                            ";
        // line 127
        $context["allowCreate"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_export_template");
        // line 128
        yield "                            ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["buttons"] ?? null));
        foreach ($context['_seq'] as $context["type"] => $context["group"]) {
            // line 129
            yield "                                ";
            if (($context["type"] == "html")) {
                // line 130
                yield "                                    ";
                $context["type"] = "print";
                // line 131
                yield "                                ";
            }
            // line 132
            yield "                                ";
            $context["btnTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["type"]);
            // line 133
            yield "                                ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), $context["group"]) == 1)) {
                // line 134
                yield "                                    ";
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["group"]);
                foreach ($context['_seq'] as $context["id"] => $context["cfg"]) {
                    // line 135
                    yield "                                        ";
                    $context["title"] = CoreExtension::getAttribute($this->env, $this->source, $context["cfg"], "title", [], "any", false, false, false, 135);
                    // line 136
                    yield "                                        <button type=\"button\" id=\"export-";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["id"], "html", null, true);
                    yield "-button\" class=\"btn btn-primary startExportBtn\" data-type=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["id"], "html", null, true);
                    yield "\">
                                            ";
                    // line 137
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["btnTitle"] ?? null), "html", null, true);
                    yield "
                                        </button>
                                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['id'], $context['cfg'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 140
                yield "                                ";
            } else {
                // line 141
                yield "                                    <div class=\"btn-group\">
                                        <button type=\"button\" class=\"btn btn-primary dropdown-toggle\" data-bs-toggle=\"dropdown\" aria-haspopup=\"true\" aria-expanded=\"false\">
                                            ";
                // line 143
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["btnTitle"] ?? null), "html", null, true);
                yield "
                                        </button>
                                        <div class=\"dropdown-menu\">
                                            ";
                // line 146
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable($context["group"]);
                foreach ($context['_seq'] as $context["id"] => $context["cfg"]) {
                    // line 147
                    yield "                                                ";
                    $context["btnTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["cfg"], "title", [], "any", false, false, false, 147));
                    // line 148
                    yield "                                                ";
                    if (($context["id"] == $context["type"])) {
                        // line 149
                        yield "                                                    ";
                        $context["btnTitle"] = $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("default");
                        // line 150
                        yield "                                                ";
                    }
                    // line 151
                    yield "                                                <a href=\"#\" class=\"dropdown-item startExportBtn\" data-type=\"";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["id"], "html", null, true);
                    yield "\">
                                                    ";
                    // line 152
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["btnTitle"] ?? null), "html", null, true);
                    yield "
                                                    ";
                    // line 153
                    if (((($tmp = ($context["allowCreate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["cfg"], "internal", [], "any", false, false, false, 153)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                        // line 154
                        yield "                                                        <span class=\"dropdown-action modal-ajax-form open-edit ps-2 ms-auto\" data-href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export_template_edit", ["exportTemplate" => $context["id"]]), "html", null, true);
                        yield "\">";
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("edit");
                        yield "</span>
                                                        <span class=\"dropdown-action api-link text-red dd-ts-trash text-danger ms-2\" href=\"";
                        // line 155
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_export_template", ["id" => $context["id"]]), "html", null, true);
                        yield "\" data-event=\"kimai.exportTemplate\" data-method=\"DELETE\" data-question=\"confirm.delete\" data-msg-error=\"action.delete.error\">";
                        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("delete");
                        yield "</span>
                                                    ";
                    }
                    // line 157
                    yield "                                                </a>
                                            ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['id'], $context['cfg'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 159
                yield "                                        </div>
                                    </div>
                                ";
            }
            // line 162
            yield "                            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['type'], $context['group'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 163
        yield "                            ";
        if ((($tmp = ($context["allowCreate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 164
            yield "                                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_action_button", $context, 164, $this->getSourceContext())->macro_action_button(...["create", ["url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export_template_create"), "class" => "btn modal-ajax-form open-edit", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create")]]);
            yield "
                            ";
        }
        // line 166
        yield "                        </div>
                        ";
        // line 167
        if ((($tmp = ($context["showToggleButton"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 168
            yield "                            <button id=\"toggle-button\" class=\"btn ms-auto d-none d-sm-inline-flex\">
                                ";
            // line 169
            if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "exported", [], "any", false, false, false, 169), "vars", [], "any", false, false, false, 169), "value", [], "any", false, false, false, 169) == "5")) {
                // line 170
                yield "                                    ";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("off", true);
                yield "
                                    ";
                // line 171
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("mark_as_exported"), "html", null, true);
                yield "
                                ";
            } elseif ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source,             // line 172
($context["form"] ?? null), "exported", [], "any", false, false, false, 172), "vars", [], "any", false, false, false, 172), "value", [], "any", false, false, false, 172) == "4")) {
                // line 173
                yield "                                    ";
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("on", true);
                yield "
                                    ";
                // line 174
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("mark_as_open"), "html", null, true);
                yield "
                                ";
            }
            // line 176
            yield "                            </button>
                        ";
        }
        // line 178
        yield "                    </div>
                ";
        yield from [];
    }

    // line 180
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 181
        yield "                    <table class=\"table table-hover dataTable\">
                        <thead>
                        <tr>
                            <th>";
        // line 184
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "</th>
                            <th class=\"w-min text-end d-none d-sm-table-cell\">";
        // line 185
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
                            ";
        // line 186
        if ((($tmp = ($context["show_rates"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 187
            yield "                            <th class=\"w-min text-end\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("total_rate"), "html", null, true);
            yield "</th>
                            ";
        }
        // line 189
        yield "                        </tr>
                        </thead>
                        <tbody>
                        ";
        // line 192
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["by_customer"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["row"]) {
            // line 193
            yield "                            ";
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["row"], "customer", [], "any", false, false, false, 193), "currency", [], "any", false, false, false, 193);
            // line 194
            yield "                            <tr>
                                <td>
                                    ";
            // line 196
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 196, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["row"], "customer", [], "any", false, false, false, 196)]);
            yield "
                                </td>
                                <td class=\"w-min text-end d-none d-sm-table-cell\">
                                    ";
            // line 199
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["row"], "duration", [], "any", false, false, false, 199)), "html", null, true);
            yield "
                                </td>
                                ";
            // line 201
            if ((($tmp = ($context["show_rates"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 202
                yield "                                <td class=\"w-min text-end\">
                                    ";
                // line 203
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["row"], "rate", [], "any", false, false, false, 203), ($context["currency"] ?? null)), "html", null, true);
                yield "
                                </td>
                                ";
            }
            // line 206
            yield "                            </tr>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['row'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 208
        yield "                        </tbody>
                    </table>
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1271 => 208,  1263 => 206,  1257 => 203,  1254 => 202,  1252 => 201,  1247 => 199,  1241 => 196,  1237 => 194,  1234 => 193,  1230 => 192,  1225 => 189,  1219 => 187,  1217 => 186,  1213 => 185,  1209 => 184,  1204 => 181,  1197 => 180,  1191 => 178,  1187 => 176,  1182 => 174,  1177 => 173,  1175 => 172,  1171 => 171,  1166 => 170,  1164 => 169,  1161 => 168,  1159 => 167,  1156 => 166,  1150 => 164,  1147 => 163,  1140 => 162,  1135 => 159,  1127 => 157,  1120 => 155,  1113 => 154,  1111 => 153,  1107 => 152,  1102 => 151,  1099 => 150,  1096 => 149,  1093 => 148,  1090 => 147,  1086 => 146,  1080 => 143,  1076 => 141,  1073 => 140,  1063 => 137,  1056 => 136,  1053 => 135,  1048 => 134,  1045 => 133,  1042 => 132,  1039 => 131,  1036 => 130,  1033 => 129,  1028 => 128,  1026 => 127,  1022 => 125,  1015 => 121,  1009 => 120,  1005 => 118,  1002 => 117,  995 => 116,  984 => 115,  976 => 113,  969 => 112,  964 => 110,  962 => 111,  955 => 110,  892 => 100,  887 => 99,  880 => 98,  872 => 96,  865 => 95,  860 => 94,  854 => 92,  852 => 91,  848 => 90,  844 => 89,  839 => 88,  833 => 86,  830 => 85,  824 => 83,  822 => 82,  818 => 81,  814 => 80,  810 => 79,  806 => 78,  802 => 77,  798 => 76,  793 => 75,  786 => 74,  775 => 73,  764 => 72,  759 => 69,  757 => 71,  755 => 70,  748 => 69,  685 => 431,  675 => 428,  655 => 411,  649 => 408,  644 => 405,  642 => 404,  638 => 402,  632 => 398,  630 => 397,  611 => 381,  587 => 359,  560 => 331,  544 => 319,  537 => 318,  531 => 315,  528 => 314,  522 => 312,  516 => 309,  513 => 308,  510 => 307,  501 => 304,  498 => 303,  492 => 301,  486 => 299,  483 => 298,  480 => 297,  474 => 294,  466 => 293,  463 => 292,  460 => 291,  454 => 289,  448 => 286,  440 => 285,  437 => 284,  434 => 283,  431 => 282,  429 => 281,  424 => 280,  418 => 277,  414 => 276,  409 => 274,  405 => 273,  400 => 271,  395 => 270,  393 => 269,  388 => 267,  382 => 266,  379 => 265,  373 => 263,  371 => 262,  367 => 261,  362 => 259,  358 => 258,  355 => 257,  349 => 255,  347 => 254,  343 => 253,  338 => 251,  333 => 249,  329 => 248,  324 => 246,  320 => 245,  317 => 244,  313 => 242,  307 => 240,  305 => 239,  301 => 238,  296 => 236,  292 => 235,  287 => 233,  283 => 232,  278 => 230,  274 => 229,  267 => 228,  264 => 227,  261 => 226,  258 => 225,  255 => 224,  252 => 223,  249 => 222,  246 => 221,  241 => 220,  239 => 219,  235 => 218,  232 => 217,  229 => 216,  226 => 215,  223 => 214,  221 => 213,  218 => 212,  215 => 110,  209 => 108,  206 => 107,  204 => 106,  199 => 105,  197 => 104,  194 => 103,  192 => 69,  189 => 68,  182 => 67,  174 => 64,  167 => 63,  161 => 60,  151 => 58,  146 => 57,  143 => 56,  137 => 54,  134 => 53,  131 => 52,  124 => 51,  119 => 1,  115 => 48,  112 => 47,  110 => 46,  108 => 45,  106 => 44,  104 => 43,  102 => 42,  100 => 38,  96 => 32,  94 => 31,  92 => 19,  84 => 16,  81 => 15,  78 => 14,  75 => 13,  72 => 12,  69 => 11,  66 => 10,  61 => 9,  59 => 8,  57 => 6,  55 => 5,  53 => 3,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/index.html.twig", "/opt/kimai/templates/export/index.html.twig");
    }
}
