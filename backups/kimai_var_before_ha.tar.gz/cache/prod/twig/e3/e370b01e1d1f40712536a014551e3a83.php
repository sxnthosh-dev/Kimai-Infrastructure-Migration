<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* calendar/drag-drop.html.twig */
class __TwigTemplate_6a712ffc22238433a3cf8e9ccbae5b5f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'dd_timesheet' => [$this, 'block_dd_timesheet'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->unwrap()->yieldBlock('dd_timesheet', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_dd_timesheet(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        yield "    ";
        $macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        yield "    ";
        $macros["calendar"] = $this->load("calendar/widgets.html.twig", 3)->unwrap();
        // line 4
        yield "    ";
        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 4))) {
            // line 5
            yield "        ";
            $context["title"] = $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 5, $this->getSourceContext())->macro_label_activity(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 5), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "activity", [], "any", false, false, false, 5), "color", [], "any", false, false, false, 5)]);
            // line 6
            yield "    ";
        } else {
            // line 7
            yield "        ";
            $context["title"] = $macros["widgets"]->getTemplateForMacro("macro_label_color", $context, 7, $this->getSourceContext())->macro_label_color(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "title", [], "any", false, false, false, 7), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 7)]);
            // line 8
            yield "    ";
        }
        // line 9
        yield "    ";
        yield (string) $macros["calendar"]->getTemplateForMacro("macro_dd_event", $context, 9, $this->getSourceContext())->macro_dd_event(...[($context["title"] ?? null), (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 9, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 9), "customer", [], "any", false, false, false, 9)])) : (null)), (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 9)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 9, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "project", [], "any", false, false, false, 9)])) : (null)), null]);
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "calendar/drag-drop.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  76 => 9,  73 => 8,  70 => 7,  67 => 6,  64 => 5,  61 => 4,  58 => 3,  55 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "calendar/drag-drop.html.twig", "/opt/kimai/templates/calendar/drag-drop.html.twig");
    }
}
