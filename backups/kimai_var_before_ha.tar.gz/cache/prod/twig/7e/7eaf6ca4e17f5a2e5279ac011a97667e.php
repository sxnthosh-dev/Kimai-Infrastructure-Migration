<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/accordion.html.twig */
class __TwigTemplate_f6c4952ed35a508d4ebc17b9ba1a470a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_accordion($items = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "
    ";
            // line 5
            yield "    ";
            $context["_id"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "id", [], "any", false, false, false, 5)) : ($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->uniqueId("accordion_")));
            // line 6
            yield "    ";
            $context["_raw"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "raw", [], "any", false, false, false, 6)) : (true));
            // line 7
            yield "    ";
            $context["_flush"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "flush", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "flush", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "flush", [], "any", false, false, false, 7)) : (false));
            // line 8
            yield "    ";
            $context["_always_open"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "alwaysOpen", [], "any", true, true, false, 8) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "alwaysOpen", [], "any", false, false, false, 8)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "alwaysOpen", [], "any", false, false, false, 8)) : (false));
            // line 9
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 9) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 9)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 9)) : (""));
            // line 10
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 10) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 10)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 10)) : ([]));
            // line 11
            yield "
    <div id=\"";
            // line 12
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
            yield "\" class=\"accordion ";
            if ((($context["_flush"] ?? null) == true)) {
                yield "accordion-flush";
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\" ";
            yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 12, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield ">
        ";
            // line 13
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 14
                yield "
            ";
                // line 16
                yield "            ";
                $context["_id_collapse"] = ((($context["_id"] ?? null) . "_collapse_") . CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 16));
                // line 17
                yield "            ";
                $context["_item_title"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", true, true, false, 17) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 17)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 17)) : (""));
                // line 18
                yield "            ";
                $context["_item_body"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "body", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "body", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "body", [], "any", false, false, false, 18)) : (""));
                // line 19
                yield "            ";
                $context["_item_body_classes"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyClasses", [], "any", true, true, false, 19) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyClasses", [], "any", false, false, false, 19)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyClasses", [], "any", false, false, false, 19)) : ("pt-0"));
                // line 20
                yield "            ";
                $context["_item_body_before"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyBefore", [], "any", true, true, false, 20) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyBefore", [], "any", false, false, false, 20)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyBefore", [], "any", false, false, false, 20)) : (""));
                // line 21
                yield "            ";
                $context["_item_body_after"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyAfter", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyAfter", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "bodyAfter", [], "any", false, false, false, 21)) : (""));
                // line 22
                yield "
            ";
                // line 24
                yield "            ";
                $context["_item_open"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, true, false, 24), "open", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 24), "open", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 24), "open", [], "any", false, false, false, 24)) : (false));
                // line 25
                yield "            ";
                $context["_item_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, true, false, 25), "extraClass", [], "any", true, true, false, 25) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 25), "extraClass", [], "any", false, false, false, 25)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 25), "extraClass", [], "any", false, false, false, 25)) : (""));
                // line 26
                yield "            ";
                $context["_item_title_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, true, false, 26), "titleExtraClass", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 26), "titleExtraClass", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 26), "titleExtraClass", [], "any", false, false, false, 26)) : (""));
                // line 27
                yield "            ";
                $context["_item_body_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, true, false, 27), "bodyExtraClass", [], "any", true, true, false, 27) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 27), "bodyExtraClass", [], "any", false, false, false, 27)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 27), "bodyExtraClass", [], "any", false, false, false, 27)) : (""));
                // line 28
                yield "            ";
                $context["_item_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, true, false, 28), "attr", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 28), "attr", [], "any", false, false, false, 28)))) ? (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["item"], "options", [], "any", false, false, false, 28), "attr", [], "any", false, false, false, 28)) : ([]));
                // line 29
                yield "
            <div class=\"accordion-item ";
                // line 30
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_extraClass"] ?? null), "html", null, true);
                yield "\" ";
                yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 30, $this->getSourceContext())->macro_attr_to_html(...[($context["_item_attr"] ?? null)]);
                yield ">
                <div class=\"accordion-header ";
                // line 31
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_title_extraClass"] ?? null), "html", null, true);
                yield "\" id=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                yield "-heading-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 31), "html", null, true);
                yield "\">
                    <button class=\"accordion-button ";
                // line 32
                if ( !(($tmp = ($context["_item_open"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "collapsed";
                }
                yield "\"
                            type=\"button\" data-bs-toggle=\"collapse\" data-bs-target=\"#";
                // line 33
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id_collapse"] ?? null), "html", null, true);
                yield "\"
                            aria-expanded=\"";
                // line 34
                if ((($tmp = ($context["_item_open"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "true";
                } else {
                    yield "false";
                }
                yield "\">
                        ";
                // line 35
                if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield (string) ($context["_item_title"] ?? null);
                } else {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_title"] ?? null), "html", null, true);
                }
                // line 36
                yield "                        <div class=\"accordion-button-toggle\">
                            <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" aria-hidden=\"true\" focusable=\"false\" class=\"icon icon-1\"><path d=\"M6 9l6 6l6 -6\"></path></svg>
                        </div>
                    </button>
                </div>

                <div id=\"";
                // line 42
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id_collapse"] ?? null), "html", null, true);
                yield "\" ";
                if ((($context["_always_open"] ?? null) == false)) {
                    yield "data-bs-parent=\"#";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_id"] ?? null), "html", null, true);
                    yield "\"";
                }
                // line 43
                yield "                     class=\"accordion-collapse collapse ";
                if ((($tmp = ($context["_item_open"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield "show";
                }
                yield " ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_body_extraClass"] ?? null), "html", null, true);
                yield "\">
                    ";
                // line 44
                if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield (string) ($context["_item_body_before"] ?? null);
                } else {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_body_before"] ?? null), "html", null, true);
                }
                // line 45
                yield "                    <div class=\"accordion-body ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_body_classes"] ?? null), "html", null, true);
                yield "\">
                        ";
                // line 46
                if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield (string) ($context["_item_body"] ?? null);
                } else {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_body"] ?? null), "html", null, true);
                }
                // line 47
                yield "                    </div>
                    ";
                // line 48
                if ((($tmp = ($context["_raw"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    yield (string) ($context["_item_body_after"] ?? null);
                } else {
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_item_body_after"] ?? null), "html", null, true);
                }
                // line 49
                yield "                </div>
            </div>

        ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 53
            yield "    </div>

";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/accordion.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  264 => 53,  246 => 49,  240 => 48,  237 => 47,  231 => 46,  226 => 45,  220 => 44,  211 => 43,  203 => 42,  195 => 36,  189 => 35,  181 => 34,  177 => 33,  171 => 32,  163 => 31,  157 => 30,  154 => 29,  151 => 28,  148 => 27,  145 => 26,  142 => 25,  139 => 24,  136 => 22,  133 => 21,  130 => 20,  127 => 19,  124 => 18,  121 => 17,  118 => 16,  115 => 14,  98 => 13,  86 => 12,  83 => 11,  80 => 10,  77 => 9,  74 => 8,  71 => 7,  68 => 6,  65 => 5,  62 => 3,  59 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/accordion.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/accordion.html.twig");
    }
}
