<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/logo.html.twig */
class __TwigTemplate_47deb5593e67bb4e33705a59410023e7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<a href=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_welcome"));
        yield "\" title=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("dashboard.title"), "html", null, true);
        yield "\">
    ";
        // line 2
        $context["logo"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.logo");
        // line 3
        yield "    ";
        $context["company"] = $this->extensions['App\Twig\Configuration']->get($this->env, "theme.branding.company");
        // line 4
        yield "    ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["company"] ?? null))) {
            // line 5
            yield "        <span>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["company"] ?? null), "html", null, true);
            yield "</span>
    ";
        } elseif ( !Twig\Extension\CoreExtension::testEmpty(        // line 6
($context["logo"] ?? null))) {
            // line 7
            yield "        <img src=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["logo"] ?? null), "html", null, true);
            yield "\" class=\"navbar-brand-image\" style=\"max-height:32px\" alt=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["company"] ?? null), "html", null, true);
            yield "\">
    ";
        } elseif ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source,         // line 8
($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 8))) {
            // line 9
            yield "        <img class=\"navbar-brand-image\" alt=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("company", $context)) ? (Twig\Extension\CoreExtension::default(($context["company"] ?? null), ((Twig\Extension\CoreExtension::constant("\\App\\Constants::SOFTWARE") . " ") . Twig\Extension\CoreExtension::constant("\\App\\Constants::VERSION")))) : (((Twig\Extension\CoreExtension::constant("\\App\\Constants::SOFTWARE") . " ") . Twig\Extension\CoreExtension::constant("\\App\\Constants::VERSION")))), "html", null, true);
            yield "\" width=\"110\" height=\"32\"
                src=\"";
            // line 10
            if (CoreExtension::inFilter("://", CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 10))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 10), "html", null, true);
            } else {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["tabler_bundle"] ?? null), "getLogoUrl", [], "method", false, false, false, 10)), "html", null, true);
            }
            yield "\">
    ";
        } else {
            // line 12
            yield "        <span>";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->generateTitle();
            yield "</span>
    ";
        }
        // line 14
        yield "</a>";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/logo.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  94 => 14,  88 => 12,  79 => 10,  74 => 9,  72 => 8,  65 => 7,  63 => 6,  58 => 5,  55 => 4,  52 => 3,  50 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/logo.html.twig", "/opt/kimai/templates/bundles/TablerBundle/includes/logo.html.twig");
    }
}
