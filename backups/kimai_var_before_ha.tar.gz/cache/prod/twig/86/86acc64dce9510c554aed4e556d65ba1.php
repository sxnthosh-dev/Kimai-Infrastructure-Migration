<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/project_list_data.html.twig */
class __TwigTemplate_1ca19c01d0892c90d15876fad5cbbbb4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main_before' => [$this, 'block_main_before'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 2)->unwrap();
        // line 4
        $context["showMoneyBudget"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_money", "project");
        // line 5
        $context["showTimeBudget"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget_time", "project");
        // line 7
        $context["availableColumns"] = ["name" => ["class" => "alwaysVisible"]];
        // line 10
        if ((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 11
            yield "    ";
            $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["timeBudget" => ["class" => "d-none d-md-table-cell", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("timeBudget")]]);
        }
        // line 15
        if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 16
            yield "    ";
            $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["budget" => ["class" => "d-none d-md-table-cell", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("budget")]]);
        }
        // line 20
        $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["lastRecord" => ["class" => "d-none d-sm-table-cell text-start hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("last_record"), "columnClass" => "w-min"], "today" => ["class" => "d-none text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationToday")], "week" => ["class" => "d-none text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationWeek")], "month" => ["class" => "d-none d-lg-table-cell text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationMonth")], "durationTotal" => ["class" => "text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal"), "columnClass" => "w-min"]]);
        // line 27
        if (((($tmp = ($context["showTimeBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_export")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 28
            yield "    ";
            $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["exported" => ["class" => "d-none d-xl-table-cell text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_exported"), "columnClass" => "w-min"]]);
        }
        // line 32
        if ((($tmp = ($context["showMoneyBudget"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 33
            yield "    ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("view_invoice")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 34
                yield "        ";
                $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["invoiced" => ["class" => "d-none d-xl-table-cell text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("not_invoiced"), "columnClass" => "w-min"]]);
                // line 37
                yield "    ";
            }
            // line 38
            yield "    ";
            $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["total" => ["class" => "d-none d-xl-table-cell text-end hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.amountTotal"), "columnClass" => "w-min"]]);
        }
        // line 42
        $context["availableColumns"] = Twig\Extension\CoreExtension::merge(($context["availableColumns"] ?? null), ["projectStart" => ["class" => "d-none text-start hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_start")], "projectEnd" => ["class" => "d-none text-start hw-min w-min", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project_end")], "comment" => ["class" => "d-none", "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("comment")], "actions" => ["class" => "actions alwaysVisible"]]);
        // line 48
        $context["tableName"] = ((array_key_exists("tableName", $context)) ? (Twig\Extension\CoreExtension::default(($context["tableName"] ?? null), "project_view_reporting")) : ("project_view_reporting"));
        // line 49
        $context["skipColumns"] = ((array_key_exists("skipColumns", $context)) ? (($context["skipColumns"] ?? null)) : ([]));
        // line 50
        $context["columns"] = [];
        // line 51
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["availableColumns"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["config"]) {
            // line 52
            yield "    ";
            if (!CoreExtension::inFilter($context["name"], ($context["skipColumns"] ?? null))) {
                // line 53
                yield "        ";
                $context["columns"] = Twig\Extension\CoreExtension::merge(($context["columns"] ?? null), [ (string)$context["name"] => $context["config"]]);
                // line 54
                yield "    ";
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['config'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 1
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 57
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 58
        yield "    ";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_modal", $context, 58, $this->getSourceContext())->macro_data_table_column_modal(...[($context["tableName"] ?? null), ($context["columns"] ?? null)]);
        yield "
";
        yield from [];
    }

    // line 61
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 62
        yield "
    ";
        // line 63
        $context["hasData"] = (Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["entries"] ?? null)) > 0);
        // line 64
        yield "
    ";
        // line 65
        yield from $this->load("reporting/project_list_data.html.twig", 65, 1)->unwrap()->yield($context);
        // line 140
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project_list_data.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  155 => 140,  153 => 65,  150 => 64,  148 => 63,  145 => 62,  138 => 61,  130 => 58,  123 => 57,  118 => 1,  110 => 54,  107 => 53,  104 => 52,  100 => 51,  98 => 50,  96 => 49,  94 => 48,  92 => 42,  88 => 38,  85 => 37,  82 => 34,  79 => 33,  77 => 32,  73 => 28,  71 => 27,  69 => 20,  65 => 16,  63 => 15,  59 => 11,  57 => 10,  55 => 7,  53 => 5,  51 => 4,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project_list_data.html.twig", "/opt/kimai/templates/reporting/project_list_data.html.twig");
    }
}


/* reporting/project_list_data.html.twig */
class __TwigTemplate_1ca19c01d0892c90d15876fad5cbbbb4___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 65
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 66
        $macros["progress"] = $this->macros["progress"] = $this->load("macros/progressbar.html.twig", 66)->unwrap();
        // line 67
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 67)->unwrap();
        // line 68
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 68)->unwrap();
        // line 69
        $macros["projectActions"] = $this->macros["projectActions"] = $this->load("project/actions.html.twig", 69)->unwrap();
        // line 65
        $this->parent = $this->load("@theme/embeds/card.html.twig", 65);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["tableName"] ?? null), "html", null, true);
        yield "-box ";
        if ((($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "p-0";
        }
        yield from [];
    }

    // line 71
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 72
        yield "            ";
        if ( !(($tmp = ($context["hasData"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 73
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_nothing_found", $context, 73, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
            ";
        } else {
            // line 75
            yield "                ";
            yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_header", $context, 75, $this->getSourceContext())->macro_datatable_header(...[($context["tableName"] ?? null), ($context["columns"] ?? null), null, ["boxClass" => ""]]);
            yield "

                ";
            // line 77
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["entries"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "customer", [], "any", false, false, false, 77), "name", [], "any", false, false, false, 77) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "customer", [], "any", false, false, false, 77), "name", [], "any", false, false, false, 77)); }));
            foreach ($context['_seq'] as $context["id"] => $context["mapping"]) {
                // line 78
                yield "                    <tr class=\"summary\">
                        <td colspan=\"";
                // line 79
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["columns"] ?? null)), "html", null, true);
                yield "\">";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 79, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "customer", [], "any", false, false, false, 79)]);
                yield "</td>
                    </tr>
                    ";
                // line 81
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, $context["mapping"], "projects", [], "any", false, false, false, 81), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "project", [], "any", false, false, false, 81), "name", [], "any", false, false, false, 81) <=> CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "project", [], "any", false, false, false, 81), "name", [], "any", false, false, false, 81)); }));
                foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
                    // line 82
                    yield "                        ";
                    $context["project"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 82);
                    // line 83
                    yield "                        ";
                    $context["budgetStats"] = CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "getBudgetStatisticModel", [], "method", false, false, false, 83);
                    // line 84
                    yield "                        ";
                    $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 84), "currency", [], "any", false, false, false, 84);
                    // line 85
                    yield "                        <tr ";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 85, $this->getSourceContext())->macro_project_row_attr(...[($context["project"] ?? null), ($context["now"] ?? null)]);
                    yield ">
                        ";
                    // line 86
                    $context['_parent'] = $context;
                    $context['_seq'] = CoreExtension::ensureTraversable(($context["columns"] ?? null));
                    foreach ($context['_seq'] as $context["name"] => $context["column_config"]) {
                        // line 87
                        yield "                            <td class=\"";
                        yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_column_class", $context, 87, $this->getSourceContext())->macro_data_table_column_class(...[($context["tableName"] ?? null), ($context["columns"] ?? null), $context["name"]]);
                        yield "\">
                            ";
                        // line 88
                        if (($context["name"] == "name")) {
                            // line 89
                            yield "                                ";
                            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 89, $this->getSourceContext())->macro_label_project(...[($context["project"] ?? null)]);
                            yield "
                            ";
                        } elseif ((                        // line 90
$context["name"] == "lastRecord")) {
                            // line 91
                            yield "                                ";
                            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "lastRecord", [], "any", false, false, false, 91))) {
                                // line 92
                                yield "                                    ";
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "lastRecord", [], "any", false, false, false, 92)), "html", null, true);
                                yield "
                                ";
                            } else {
                                // line 94
                                yield "                                    &ndash;
                                ";
                            }
                            // line 96
                            yield "                            ";
                        } elseif (($context["name"] == "today")) {
                            // line 97
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationDay", [], "any", false, false, false, 97)), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 98
$context["name"] == "week")) {
                            // line 99
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationWeek", [], "any", false, false, false, 99)), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 100
$context["name"] == "month")) {
                            // line 101
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationMonth", [], "any", false, false, false, 101)), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 102
$context["name"] == "durationTotal")) {
                            // line 103
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "durationTotal", [], "any", false, false, false, 103)), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 104
$context["name"] == "timeBudget")) {
                            // line 105
                            yield "                                ";
                            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStats"] ?? null), "hasTimeBudget", [], "method", false, false, false, 105)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                                // line 106
                                yield "                                    ";
                                yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_timebudget", $context, 106, $this->getSourceContext())->macro_progressbar_timebudget(...[($context["budgetStats"] ?? null)]);
                                yield "
                                ";
                            }
                            // line 108
                            yield "                            ";
                        } elseif (($context["name"] == "budget")) {
                            // line 109
                            yield "                                ";
                            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "hasBudget", [], "method", false, false, false, 109)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["project"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                                // line 110
                                yield "                                    ";
                                yield (string) $macros["progress"]->getTemplateForMacro("macro_progressbar_budget", $context, 110, $this->getSourceContext())->macro_progressbar_budget(...[($context["budgetStats"] ?? null), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 110), "currency", [], "any", false, false, false, 110)]);
                                yield "
                                ";
                            }
                            // line 112
                            yield "                            ";
                        } elseif (($context["name"] == "exported")) {
                            // line 113
                            yield "                                <a href=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export", ["customers[]" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 113), "id", [], "any", false, false, false, 113), "projects[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 113), "daterange" => "", "preview" => true]), "html", null, true);
                            yield "\">
                                    ";
                            // line 114
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "notExportedDuration", [], "any", false, false, false, 114)), "html", null, true);
                            yield "
                                </a>
                            ";
                        } elseif ((                        // line 116
$context["name"] == "invoiced")) {
                            // line 117
                            yield "                                <a href=\"";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("invoice", ["customers[]" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 117), "id", [], "any", false, false, false, 117), "projects[]" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 117), "daterange" => ""]), "html", null, true);
                            yield "\">
                                    ";
                            // line 118
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "notExportedRate", [], "any", false, false, false, 118), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                                </a>
                            ";
                        } elseif ((                        // line 120
$context["name"] == "total")) {
                            // line 121
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["budgetStats"] ?? null), "getBudgetSpent", [], "method", false, false, false, 121), ($context["currency"] ?? null)), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 122
$context["name"] == "projectStart")) {
                            // line 123
                            yield "                                ";
                            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 123))) {
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "start", [], "any", false, false, false, 123)), "html", null, true);
                            }
                            // line 124
                            yield "                            ";
                        } elseif (($context["name"] == "projectEnd")) {
                            // line 125
                            yield "                                ";
                            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 125))) {
                                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "end", [], "any", false, false, false, 125)), "html", null, true);
                            }
                            // line 126
                            yield "                            ";
                        } elseif (($context["name"] == "comment")) {
                            // line 127
                            yield "                                ";
                            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "comment", [], "any", false, false, false, 127), "html", null, true);
                            yield "
                            ";
                        } elseif ((                        // line 128
$context["name"] == "actions")) {
                            // line 129
                            yield "                                ";
                            yield (string) $macros["projectActions"]->getTemplateForMacro("macro_project", $context, 129, $this->getSourceContext())->macro_project(...[($context["project"] ?? null), "custom"]);
                            yield "
                            ";
                        }
                        // line 131
                        yield "                            </td>
                        ";
                    }
                    $_parent = $context['_parent'];
                    unset($context['_seq'], $context['name'], $context['column_config'], $context['_parent']);
                    $context = array_intersect_key($context, $_parent);
                    $context += $_parent;
                    // line 133
                    yield "                        </tr>
                    ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 135
                yield "                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['mapping'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 136
            yield "                ";
            yield (string) $macros["tables"]->getTemplateForMacro("macro_data_table_footer", $context, 136, $this->getSourceContext())->macro_data_table_footer(...[($context["entries"] ?? null)]);
            yield "
            ";
        }
        // line 138
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/project_list_data.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  479 => 138,  473 => 136,  466 => 135,  458 => 133,  450 => 131,  444 => 129,  442 => 128,  437 => 127,  434 => 126,  429 => 125,  426 => 124,  421 => 123,  419 => 122,  414 => 121,  412 => 120,  407 => 118,  402 => 117,  400 => 116,  395 => 114,  390 => 113,  387 => 112,  381 => 110,  378 => 109,  375 => 108,  369 => 106,  366 => 105,  364 => 104,  359 => 103,  357 => 102,  352 => 101,  350 => 100,  345 => 99,  343 => 98,  338 => 97,  335 => 96,  331 => 94,  325 => 92,  322 => 91,  320 => 90,  315 => 89,  313 => 88,  308 => 87,  304 => 86,  299 => 85,  296 => 84,  293 => 83,  290 => 82,  286 => 81,  279 => 79,  276 => 78,  272 => 77,  266 => 75,  260 => 73,  257 => 72,  250 => 71,  235 => 70,  230 => 65,  228 => 69,  226 => 68,  224 => 67,  222 => 66,  215 => 65,  155 => 140,  153 => 65,  150 => 64,  148 => 63,  145 => 62,  138 => 61,  130 => 58,  123 => 57,  118 => 1,  110 => 54,  107 => 53,  104 => 52,  100 => 51,  98 => 50,  96 => 49,  94 => 48,  92 => 42,  88 => 38,  85 => 37,  82 => 34,  79 => 33,  77 => 32,  73 => 28,  71 => 27,  69 => 20,  65 => 16,  63 => 15,  59 => 11,  57 => 10,  55 => 7,  53 => 5,  51 => 4,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/project_list_data.html.twig", "/opt/kimai/templates/reporting/project_list_data.html.twig");
    }
}
