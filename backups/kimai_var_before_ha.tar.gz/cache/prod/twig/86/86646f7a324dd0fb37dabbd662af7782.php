<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* activity/details.html.twig */
class __TwigTemplate_c91ba1d77400ea9efa659df749610250 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    ";
        $context["can_edit"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["activity"] ?? null));
        // line 6
        yield "    ";
        $context["currency"] = null;
        // line 7
        yield "    ";
        if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 7))) {
            // line 8
            yield "        ";
            $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 8), "customer", [], "any", false, false, false, 8), "currency", [], "any", false, false, false, 8);
            // line 9
            yield "    ";
        }
        // line 10
        yield "
    ";
        // line 11
        yield from $this->load("activity/details.html.twig", 11, 1)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        // line 90
        yield "
    ";
        // line 91
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 92
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/rates-table.html.twig", ["id" => "activity_rates_box", "entity" => ($context["activity"] ?? null), "create_url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_activity_rate_add", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "id", [], "any", false, false, false, 92)]), "delete_route" => "delete_activity_rate", "currency" => ($context["currency"] ?? null), "edit_route" => "admin_activity_rate_edit"]);
            yield "
    ";
        }
        // line 94
        yield "
    ";
        // line 95
        if ( !(null === ($context["stats"] ?? null))) {
            // line 96
            yield "        ";
            $context["currency"] = $this->extensions['App\Twig\Configuration']->get($this->env, "customerDefaultCurrency");
            // line 97
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 97))) {
                // line 98
                yield "            ";
                $context["currency"] = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 98), "customer", [], "any", false, false, false, 98), "currency", [], "any", false, false, false, 98);
                // line 99
                yield "        ";
            }
            // line 100
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/budgets.html.twig", ["entity" => ($context["activity"] ?? null), "stats" => ($context["stats"] ?? null), "currency" => ($context["currency"] ?? null)]);
            yield "
    ";
        }
        // line 102
        yield "
    ";
        // line 103
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["boxes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["controller"]) {
            // line 104
            yield "        ";
            yield (string) $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment(Symfony\Bridge\Twig\Extension\HttpKernelExtension::controller($context["controller"], ["activity" => ($context["activity"] ?? null), "page" => 1]));
            yield "
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['controller'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 106
        yield "
    ";
        // line 107
        if ( !(null === ($context["teams"] ?? null))) {
            // line 108
            yield "        ";
            $context["options"] = ["teams" => ($context["teams"] ?? null)];
            // line 109
            yield "        ";
            if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("permissions", ($context["activity"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 110
                yield "            ";
                if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_team")) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 111
                    yield "                ";
                    $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_create" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activity_team_create", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "id", [], "any", false, false, false, 111)])]);
                    // line 112
                    yield "            ";
                }
                // line 113
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["route_edit" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_activity_permissions", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "id", [], "any", false, false, false, 113)])]);
                // line 114
                yield "        ";
            }
            // line 115
            yield "        ";
            if (( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 115)) && ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 115), "teams", [], "any", false, false, false, 115)) > 0) || (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 115), "customer", [], "any", false, false, false, 115), "teams", [], "any", false, false, false, 115)) > 0)))) {
                // line 116
                yield "            ";
                $context["options"] = Twig\Extension\CoreExtension::merge(($context["options"] ?? null), ["empty_message" => "team.activity_visibility_inherited"]);
                // line 117
                yield "        ";
            }
            // line 118
            yield "        ";
            yield (string) Twig\Extension\CoreExtension::include($this->env, $context, "embeds/teams.html.twig", ($context["options"] ?? null));
            yield "
    ";
        }
        // line 120
        yield "
";
        yield from [];
    }

    // line 123
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 124
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.activityUpdate kimai.teamUpdate kimai.activityTeamUpdate kimai.projectTeamUpdate kimai.customerTeamUpdate kimai.customerUpdate kimai.projectUpdate kimai.rateUpdate\x27);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  188 => 124,  181 => 123,  175 => 120,  169 => 118,  166 => 117,  163 => 116,  160 => 115,  157 => 114,  154 => 113,  151 => 112,  148 => 111,  145 => 110,  142 => 109,  139 => 108,  137 => 107,  134 => 106,  124 => 104,  120 => 103,  117 => 102,  111 => 100,  108 => 99,  105 => 98,  102 => 97,  99 => 96,  97 => 95,  94 => 94,  88 => 92,  86 => 91,  83 => 90,  81 => 11,  78 => 10,  75 => 9,  72 => 8,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/details.html.twig", "/opt/kimai/templates/activity/details.html.twig");
    }
}


/* activity/details.html.twig */
class __TwigTemplate_c91ba1d77400ea9efa659df749610250___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_title' => [$this, 'block_box_title'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 11
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 12)->unwrap();
        // line 13
        $macros["customerActions"] = $this->macros["customerActions"] = $this->load("customer/actions.html.twig", 13)->unwrap();
        // line 14
        $macros["projectActions"] = $this->macros["projectActions"] = $this->load("project/actions.html.twig", 14)->unwrap();
        // line 11
        $this->parent = $this->load("@theme/embeds/card.html.twig", 11);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"activity_details_box\"";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "            ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_dot", $context, 17, $this->getSourceContext())->macro_label_dot(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "name", [], "any", false, false, false, 17), CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "color", [], "any", false, false, false, 17)]);
        yield "
        ";
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        if ((($tmp = ($context["can_edit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 21
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 21, $this->getSourceContext())->macro_card_tool_button(...["edit", ["class" => "modal-ajax-form open-edit", "title" => "edit", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_activity_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "id", [], "any", false, false, false, 21)])]]);
            yield "
            ";
        }
        // line 23
        yield "        ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "            ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "comment", [], "any", false, false, false, 25))) {
            // line 26
            yield "                <div class=\"comment p-3\">
                    ";
            // line 27
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentContent(CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "comment", [], "any", false, false, false, 27), true);
            yield "
                </div>
            ";
        }
        // line 30
        yield "            <table class=\"table table-hover dataTable\">
                ";
        // line 31
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "visible", [], "any", false, false, false, 31)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 32
            yield "                    <tr class=\"";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_class_activity_row", $context, 32, $this->getSourceContext())->macro_class_activity_row(...[($context["activity"] ?? null), ($context["now"] ?? null)]);
            yield "\">
                        <th>";
            // line 33
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("visible"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 35
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 35, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "visible", [], "any", false, false, false, 35)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 39
        yield "                ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "billable", [], "any", false, false, false, 39)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 40
            yield "                    <tr>
                        <th>";
            // line 41
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("billable"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 43
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 43, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "billable", [], "any", false, false, false, 43)]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 47
        yield "                ";
        if ( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "global", [], "any", false, false, false, 47)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 48
            yield "                    <tr ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_customer_row_attr", $context, 48, $this->getSourceContext())->macro_customer_row_attr(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 48), "customer", [], "any", false, false, false, 48), ($context["now"] ?? null)]);
            yield ">
                        <th>";
            // line 49
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 51
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 51, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 51), "customer", [], "any", false, false, false, 51)]);
            yield "
                        </td>
                        <td class=\"w-min\">
                            ";
            // line 54
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 54, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 54), "customer", [], "any", false, false, false, 54), "teams", [], "any", false, false, false, 54)]);
            yield "
                        </td>
                        <td class=\"actions\">
                            ";
            // line 57
            yield (string) $macros["customerActions"]->getTemplateForMacro("macro_customer", $context, 57, $this->getSourceContext())->macro_customer(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 57), "customer", [], "any", false, false, false, 57), "custom"]);
            yield "
                        </td>
                    </tr>
                    <tr ";
            // line 60
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_project_row_attr", $context, 60, $this->getSourceContext())->macro_project_row_attr(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 60), ($context["now"] ?? null)]);
            yield ">
                        <th>";
            // line 61
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 63
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_project", $context, 63, $this->getSourceContext())->macro_label_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 63)]);
            yield "
                        </td>
                        <td class=\"w-min\">
                            ";
            // line 66
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 66, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 66), "teams", [], "any", false, false, false, 66)]);
            yield "
                        </td>
                        <td class=\"actions\">
                            ";
            // line 69
            yield (string) $macros["projectActions"]->getTemplateForMacro("macro_project", $context, 69, $this->getSourceContext())->macro_project(...[CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "project", [], "any", false, false, false, 69), "custom"]);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 73
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "number", [], "any", false, false, false, 73))) {
            // line 74
            yield "                    <tr>
                        <th>";
            // line 75
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity_number"), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">
                            ";
            // line 77
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "number", [], "any", false, false, false, 77), "html", null, true);
            yield "
                        </td>
                    </tr>
                ";
        }
        // line 81
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["activity"] ?? null), "visibleMetaFields", [], "any", false, false, false, 81), function ($__field__) use ($context, $macros) { $context["field"] = $__field__; return CoreExtension::getAttribute($this->env, $this->source, ($context["field"] ?? null), "defined", [], "any", false, false, false, 81); }), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "order", [], "any", false, false, false, 81) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "order", [], "any", false, false, false, 81)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["metaField"]) {
            // line 82
            yield "                    <tr>
                        <th>";
            // line 83
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "label", [], "any", false, false, false, 83)), "html", null, true);
            yield "</th>
                        <td colspan=\"3\">";
            // line 84
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_form_type_value", $context, 84, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "type", [], "any", false, false, false, 84), CoreExtension::getAttribute($this->env, $this->source, $context["metaField"], "value", [], "any", false, false, false, 84), ($context["activity"] ?? null)]);
            yield "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['metaField'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 87
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/details.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  480 => 87,  470 => 84,  466 => 83,  463 => 82,  458 => 81,  451 => 77,  446 => 75,  443 => 74,  440 => 73,  433 => 69,  427 => 66,  421 => 63,  416 => 61,  412 => 60,  406 => 57,  400 => 54,  394 => 51,  389 => 49,  384 => 48,  381 => 47,  374 => 43,  369 => 41,  366 => 40,  363 => 39,  356 => 35,  351 => 33,  346 => 32,  344 => 31,  341 => 30,  335 => 27,  332 => 26,  329 => 25,  322 => 24,  317 => 23,  311 => 21,  308 => 20,  301 => 19,  293 => 17,  286 => 16,  275 => 15,  270 => 11,  268 => 14,  266 => 13,  264 => 12,  257 => 11,  188 => 124,  181 => 123,  175 => 120,  169 => 118,  166 => 117,  163 => 116,  160 => 115,  157 => 114,  154 => 113,  151 => 112,  148 => 111,  145 => 110,  142 => 109,  139 => 108,  137 => 107,  134 => 106,  124 => 104,  120 => 103,  117 => 102,  111 => 100,  108 => 99,  105 => 98,  102 => 97,  99 => 96,  97 => 95,  94 => 94,  88 => 92,  86 => 91,  83 => 90,  81 => 11,  78 => 10,  75 => 9,  72 => 8,  69 => 7,  66 => 6,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/details.html.twig", "/opt/kimai/templates/activity/details.html.twig");
    }
}
