<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/includes/navbar_search.html.twig */
class __TwigTemplate_d7008895f8a943256245ab6100a5d24c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<div class=\"my-2 my-md-0 flex-grow-1 flex-md-grow-0 order-first order-md-last\">
    <form action=\".\" method=\"get\">
        <div class=\"input-icon\">
            <span class=\"input-icon-addon\">
                <i class=\"fas fa-search\"></i>
            </span>
            <input type=\"text\" class=\"form-control\" placeholder=\"Search…\" aria-label=\"Search in website\">
        </div>
    </form>
</div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/includes/navbar_search.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/includes/navbar_search.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/includes/navbar_search.html.twig");
    }
}
