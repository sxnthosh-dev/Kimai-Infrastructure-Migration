<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/dropdown.html.twig */
class __TwigTemplate_79c9577cb89da3499a09053cc35ad255 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_dropdown($items = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "items" => $items,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["͜macros"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            $macros["_v0"] = $this->load("@Tabler/components/badge.html.twig", 3)->unwrap();
            // line 4
            yield "
    ";
            // line 6
            yield "    ";
            // line 7
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuArrowEnd", [], "any", true, true, false, 7)) {
                // line 8
                yield "        ";
                trigger_deprecation('', '', "Using `menuArrowEnd` option is deprecated, use `menuAlignmentEnd` instead."." in \"@Tabler/components/dropdown.html.twig\" at line 8.");
                // line 9
                yield "        ";
                $context["_menuAlignmentEnd"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuArrowEnd", [], "any", false, false, false, 9) === true);
                // line 10
                yield "    ";
            } else {
                // line 11
                yield "        ";
                $context["_menuAlignmentEnd"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuAlignmentEnd", [], "any", true, true, false, 11) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuAlignmentEnd", [], "any", false, false, false, 11)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuAlignmentEnd", [], "any", false, false, false, 11)) : (false)) === true);
                // line 12
                yield "    ";
            }
            // line 13
            yield "
    ";
            // line 14
            $context["_menuArrow"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuArrow", [], "any", true, true, false, 14) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuArrow", [], "any", false, false, false, 14)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "menuArrow", [], "any", false, false, false, 14)) : (false));
            // line 15
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 15) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 15)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 15)) : (""));
            // line 16
            yield "
    <div class=\"dropdown-menu ";
            // line 17
            if ((($tmp = ($context["_menuArrow"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "dropdown-menu-arrow";
            }
            yield " ";
            if ((($tmp = ($context["_menuAlignmentEnd"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "dropdown-menu-end";
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\">
        ";
            // line 18
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["items"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["item"]) {
                // line 19
                yield "
            ";
                // line 21
                yield "            ";
                $context["_type"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "type", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "type", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "type", [], "any", false, false, false, 21)) : ("link"));
                // line 22
                yield "            ";
                // line 23
                yield "            ";
                $context["_title"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 23)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "title", [], "any", false, false, false, 23)) : (""));
                // line 24
                yield "            ";
                $context["_icon"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "icon", [], "any", false, false, false, 24)) : (false));
                // line 25
                yield "            ";
                $context["_html"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "html", [], "any", true, true, false, 25) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "html", [], "any", false, false, false, 25)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "html", [], "any", false, false, false, 25)) : (false));
                // line 26
                yield "            ";
                $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "href", [], "any", false, false, false, 26)) : ("#"));
                // line 27
                yield "            ";
                $context["_badge"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "badge", [], "any", true, true, false, 27) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "badge", [], "any", false, false, false, 27)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "badge", [], "any", false, false, false, 27)) : ([]));
                // line 28
                yield "            ";
                // line 29
                yield "            ";
                $context["_active"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", true, true, false, 29) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 29)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "active", [], "any", false, false, false, 29)) : (false));
                // line 30
                yield "            ";
                $context["_disabled"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "disabled", [], "any", false, false, false, 30)) : (false));
                // line 31
                yield "            ";
                // line 32
                yield "            ";
                $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "extraClass", [], "any", true, true, false, 32) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "extraClass", [], "any", false, false, false, 32)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "extraClass", [], "any", false, false, false, 32)) : (""));
                // line 33
                yield "            ";
                $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "attr", [], "any", true, true, false, 33) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "attr", [], "any", false, false, false, 33)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "attr", [], "any", false, false, false, 33)) : ([]));
                // line 34
                yield "
            ";
                // line 35
                if ((CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "text", [], "any", true, true, false, 35) || CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "class", [], "any", true, true, false, 35))) {
                    // line 36
                    yield "                ";
                    $context["badge"] = $macros["_v0"]->getTemplateForMacro("macro_badge", $context, 36, $this->getSourceContext())->macro_badge(...[(((CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "text", [], "any", true, true, false, 36) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "text", [], "any", false, false, false, 36)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "text", [], "any", false, false, false, 36)) : ("")), ((((CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "class", [], "any", true, true, false, 36) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "class", [], "any", false, false, false, 36)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["_badge"] ?? null), "class", [], "any", false, false, false, 36)) : ("")) . " ms-auto")]);
                    // line 37
                    yield "            ";
                } else {
                    // line 38
                    yield "                ";
                    $context["badge"] = "";
                    // line 39
                    yield "            ";
                }
                // line 40
                yield "
            ";
                // line 41
                if (CoreExtension::inFilter(($context["_type"] ?? null), ["html", "divider", "header"])) {
                    // line 42
                    yield "                ";
                    if ((($context["_type"] ?? null) === "divider")) {
                        // line 43
                        yield "                    <div class=\"dropdown-divider ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
                        yield "\" ";
                        yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 43, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                        yield "></div>
                ";
                    } elseif ((                    // line 44
($context["_type"] ?? null) === "header")) {
                        // line 45
                        yield "                    <h6 class=\"dropdown-header ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
                        yield "\" ";
                        yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 45, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                        yield ">
                        ";
                        // line 46
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
                        yield "
                    </h6>
                ";
                    } else {
                        // line 49
                        yield "                    <div class=\"dropdown-item ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
                        yield "\" ";
                        yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 49, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                        yield ">
                        ";
                        // line 50
                        yield (string) ($context["_html"] ?? null);
                        yield "
                    </div>
                ";
                    }
                    // line 53
                    yield "            ";
                } elseif ((($context["_type"] ?? null) === "parent")) {
                    // line 54
                    yield "                ";
                    $context["_children"] = (((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "children", [], "any", true, true, false, 54) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 54)))) ? (CoreExtension::getAttribute($this->env, $this->source, $context["item"], "children", [], "any", false, false, false, 54)) : ([]));
                    // line 55
                    yield "                ";
                    if ( !CoreExtension::getAttribute($this->env, $this->source, $context["item"], "autoClose", [], "any", true, true, false, 55)) {
                        // line 56
                        yield "                    ";
                        $context["_autoClose"] = "outside";
                        // line 57
                        yield "                ";
                    } elseif ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "autoClose", [], "any", false, false, false, 57) === true)) {
                        // line 58
                        yield "                    ";
                        $context["_autoClose"] = "true";
                        // line 59
                        yield "                ";
                    } elseif ((CoreExtension::getAttribute($this->env, $this->source, $context["item"], "autoClose", [], "any", false, false, false, 59) === false)) {
                        // line 60
                        yield "                    ";
                        $context["_autoClose"] = "false";
                        // line 61
                        yield "                ";
                    } else {
                        // line 62
                        yield "                    ";
                        $context["_autoClose"] = CoreExtension::getAttribute($this->env, $this->source, $context["item"], "autoClose", [], "any", false, false, false, 62);
                        // line 63
                        yield "                ";
                    }
                    // line 64
                    yield "                <div class=\"dropend\">
                    <a class=\"dropdown-item dropdown-toggle\" data-bs-toggle=\"dropdown\" data-bs-auto-close=\"";
                    // line 65
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_autoClose"] ?? null), "html", null, true);
                    yield "\" role=\"button\">
                        ";
                    // line 66
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
                    yield "
                    </a>
                    ";
                    // line 68
                    yield (string) $this->getTemplateForMacro("macro_dropdown", $context, 68, $this->getSourceContext())->macro_dropdown(...[($context["_children"] ?? null)]);
                    yield "
                </div>
            ";
                } else {
                    // line 71
                    yield "                ";
                    $context["classes"] = ((("dropdown-item " . (((($tmp = ($context["_disabled"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("disabled ") : (""))) . (((($tmp = ($context["_active"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("active ") : (""))) . ($context["_extraClass"] ?? null));
                    // line 72
                    yield "                ";
                    if ((($context["_type"] ?? null) === "link")) {
                        // line 73
                        yield "                    <a class=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classes"] ?? null), "html", null, true);
                        yield "\" href=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
                        yield "\" ";
                        yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 73, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                        yield ">
                        ";
                        // line 74
                        if ((($tmp = ($context["_icon"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 75
                            yield "                            <span class=\"dropdown-item-icon\">
                                ";
                            // line 76
                            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(($context["_icon"] ?? null), true);
                            yield "
                            </span>
                        ";
                        } elseif ((($tmp =                         // line 78
($context["_html"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                            // line 79
                            yield "                            ";
                            yield (string) ($context["_html"] ?? null);
                            yield "
                        ";
                        }
                        // line 81
                        yield "                        ";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
                        yield "
                        ";
                        // line 82
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["badge"] ?? null), "html", null, true);
                        yield "
                    </a>
                ";
                    } elseif (CoreExtension::inFilter(                    // line 84
($context["_type"] ?? null), ["radio", "checkbox", "switch"])) {
                        // line 85
                        yield "                    <label class=\"";
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classes"] ?? null), "html", null, true);
                        yield " ";
                        if ((($context["_type"] ?? null) === "switch")) {
                            yield "form-switch";
                        }
                        yield "\" ";
                        yield (string) $macros["͜macros"]->getTemplateForMacro("macro_attr_to_html", $context, 85, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
                        yield ">
                        ";
                        // line 86
                        yield (string) ($context["_html"] ?? null);
                        yield "
                        ";
                        // line 87
                        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_title"] ?? null), "html", null, true);
                        yield "
                    </label>
                ";
                    }
                    // line 90
                    yield "            ";
                }
                // line 91
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['item'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 92
            yield "    </div>

";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/dropdown.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  341 => 92,  334 => 91,  331 => 90,  325 => 87,  321 => 86,  310 => 85,  308 => 84,  303 => 82,  298 => 81,  292 => 79,  290 => 78,  285 => 76,  282 => 75,  280 => 74,  271 => 73,  268 => 72,  265 => 71,  259 => 68,  254 => 66,  250 => 65,  247 => 64,  244 => 63,  241 => 62,  238 => 61,  235 => 60,  232 => 59,  229 => 58,  226 => 57,  223 => 56,  220 => 55,  217 => 54,  214 => 53,  208 => 50,  201 => 49,  195 => 46,  188 => 45,  186 => 44,  179 => 43,  176 => 42,  174 => 41,  171 => 40,  168 => 39,  165 => 38,  162 => 37,  159 => 36,  157 => 35,  154 => 34,  151 => 33,  148 => 32,  146 => 31,  143 => 30,  140 => 29,  138 => 28,  135 => 27,  132 => 26,  129 => 25,  126 => 24,  123 => 23,  121 => 22,  118 => 21,  115 => 19,  111 => 18,  99 => 17,  96 => 16,  93 => 15,  91 => 14,  88 => 13,  85 => 12,  82 => 11,  79 => 10,  76 => 9,  73 => 8,  70 => 7,  68 => 6,  65 => 4,  62 => 3,  59 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/dropdown.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/dropdown.html.twig");
    }
}
