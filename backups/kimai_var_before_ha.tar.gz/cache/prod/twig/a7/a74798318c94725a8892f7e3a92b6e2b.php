<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* customer/edit.html.twig */
class __TwigTemplate_690496c2fffba8298bcefcc9dc60a2ec extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => (((null === CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["customer"] ?? null), "id", [], "any", false, false, false, 6))) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"))), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_customer")];
        // line 10
        yield "    ";
        yield from $this->load("customer/edit.html.twig", 10, 3)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/edit.html.twig", "/opt/kimai/templates/customer/edit.html.twig");
    }
}


/* customer/edit.html.twig */
class __TwigTemplate_690496c2fffba8298bcefcc9dc60a2ec___3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 11)->unwrap();
        // line 10
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "            <div class=\"row\">
                <div class=\"col-md-9\">
                    ";
        // line 15
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 15), 'row');
        yield "
                </div>
                <div class=\"col-md-3\">
                    ";
        // line 18
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "color", [], "any", false, false, false, 18), 'row');
        yield "
                </div>
            </div>
            ";
        // line 21
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "comment", [], "any", false, false, false, 21), 'row');
        yield "
            <div class=\"row\">
                <div class=\"col-md-4\">
                    ";
        // line 24
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "number", [], "any", false, false, false, 24), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 27
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "language", [], "any", false, false, false, 27), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 30
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "currency", [], "any", false, false, false, 30), 'row');
        yield "
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    ";
        // line 35
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "contact", [], "any", false, false, false, 35), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 38
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "email", [], "any", false, false, false, 38), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 41
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "homepage", [], "any", false, false, false, 41), 'row');
        yield "
                </div>
            </div>
            <div class=\"row\">
                <div class=\"col-md-4\">
                    ";
        // line 46
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "mobile", [], "any", false, false, false, 46), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 49
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "phone", [], "any", false, false, false, 49), 'row');
        yield "
                </div>
                <div class=\"col-md-4\">
                    ";
        // line 52
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "fax", [], "any", false, false, false, 52), 'row');
        yield "
                </div>
            </div>
            ";
        // line 55
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", true, true, false, 55)) {
            // line 56
            yield "                <div class=\"row\">
                    ";
            // line 57
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", true, true, false, 57)) {
                // line 58
                yield "                        <div class=\"col-md-4\">
                            ";
                // line 59
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", false, false, false, 59), 'row');
                yield "
                        </div>
                    ";
            }
            // line 62
            yield "                    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", true, true, false, 62)) {
                // line 63
                yield "                        <div class=\"col-md-4\">
                            ";
                // line 64
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", false, false, false, 64), 'row');
                yield "
                        </div>
                    ";
            }
            // line 67
            yield "                    <div class=\"col-md-4\">
                        ";
            // line 68
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", false, false, false, 68), 'row');
            yield "
                    </div>
                </div>
            ";
        }
        // line 72
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 72)) {
            // line 73
            yield "            <div class=\"row\">
                <div class=\"col-12\">
                    ";
            // line 75
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 75), 'row');
            yield "
                </div>
            </div>
            ";
        }
        // line 79
        yield "            ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 79, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), null]);
        yield "
            ";
        // line 80
        yield from $this->load("customer/edit.html.twig", 80, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => "customer_address_settings"]));
        // line 131
        yield "            ";
        yield from $this->load("customer/edit.html.twig", 131, 2)->unwrap()->yield(CoreExtension::merge($context, ["id" => "customer_invoice_settings"]));
        // line 154
        yield "            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 156
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "visible", [], "any", false, false, false, 156), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 159
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 159), 'row');
        yield "
                </div>
            </div>
            ";
        // line 162
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  302 => 162,  296 => 159,  290 => 156,  286 => 154,  283 => 131,  281 => 80,  276 => 79,  269 => 75,  265 => 73,  262 => 72,  255 => 68,  252 => 67,  246 => 64,  243 => 63,  240 => 62,  234 => 59,  231 => 58,  229 => 57,  226 => 56,  224 => 55,  218 => 52,  212 => 49,  206 => 46,  198 => 41,  192 => 38,  186 => 35,  178 => 30,  172 => 27,  166 => 24,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/edit.html.twig", "/opt/kimai/templates/customer/edit.html.twig");
    }
}


/* customer/edit.html.twig */
class __TwigTemplate_690496c2fffba8298bcefcc9dc60a2ec___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 80
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 81
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 81)->unwrap();
        // line 82
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 82)->unwrap();
        // line 80
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 80);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 83
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address"), "html", null, true);
        yield from [];
    }

    // line 84
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 85
        yield "                    <div class=\"row\">
                        <div class=\"col-12\">
                            ";
        // line 87
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "company", [], "any", false, false, false, 87), 'row');
        yield "
                        </div>
                    </div>
                    ";
        // line 90
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "address", [], "any", true, true, false, 90)) {
            // line 91
            yield "                    <div class=\"row\">
                        <div class=\"col-12\">
                            ";
            // line 93
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "address", [], "any", false, false, false, 93), 'row');
            yield "
                        </div>
                    </div>
                    ";
        }
        // line 97
        yield "                    <div class=\"row\">
                        <div class=\"col-12\">
                            ";
        // line 99
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "addressLine1", [], "any", false, false, false, 99), 'row', ["attr" => ["placeholder" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address_row", ["%row%" => 1])]]);
        yield "
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-12\">
                            ";
        // line 104
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "addressLine2", [], "any", false, false, false, 104), 'row', ["attr" => ["placeholder" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address_row", ["%row%" => 2])]]);
        yield "
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-12\">
                            ";
        // line 109
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "addressLine3", [], "any", false, false, false, 109), 'row', ["attr" => ["placeholder" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address_row", ["%row%" => 3])]]);
        yield "
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-3\">
                            ";
        // line 114
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "postCode", [], "any", false, false, false, 114), 'row');
        yield "
                        </div>
                        <div class=\"col-md-9\">
                            ";
        // line 117
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "city", [], "any", false, false, false, 117), 'row');
        yield "
                        </div>
                    </div>
                    <div class=\"row\">
                        <div class=\"col-md-6\">
                            ";
        // line 122
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "country", [], "any", false, false, false, 122), 'row');
        yield "
                        </div>
                        <div class=\"col-md-6\">
                            ";
        // line 125
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timezone", [], "any", false, false, false, 125), 'row');
        yield "
                        </div>
                    </div>
                    ";
        // line 128
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 128, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), "address"]);
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  474 => 128,  468 => 125,  462 => 122,  454 => 117,  448 => 114,  440 => 109,  432 => 104,  424 => 99,  420 => 97,  413 => 93,  409 => 91,  407 => 90,  401 => 87,  397 => 85,  390 => 84,  379 => 83,  374 => 80,  372 => 82,  370 => 81,  363 => 80,  302 => 162,  296 => 159,  290 => 156,  286 => 154,  283 => 131,  281 => 80,  276 => 79,  269 => 75,  265 => 73,  262 => 72,  255 => 68,  252 => 67,  246 => 64,  243 => 63,  240 => 62,  234 => 59,  231 => 58,  229 => 57,  226 => 56,  224 => 55,  218 => 52,  212 => 49,  206 => 46,  198 => 41,  192 => 38,  186 => 35,  178 => 30,  172 => 27,  166 => 24,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/edit.html.twig", "/opt/kimai/templates/customer/edit.html.twig");
    }
}


/* customer/edit.html.twig */
class __TwigTemplate_690496c2fffba8298bcefcc9dc60a2ec___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 131
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 132
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 132)->unwrap();
        // line 133
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 133)->unwrap();
        // line 131
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 131);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoices"), "html", null, true);
        yield from [];
    }

    // line 135
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 136
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vatId", [], "any", true, true, false, 136)) {
            // line 137
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vatId", [], "any", false, false, false, 137), 'row');
            yield "
                    ";
        }
        // line 139
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceEmail", [], "any", true, true, false, 139)) {
            // line 140
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceEmail", [], "any", false, false, false, 140), 'row');
            yield "
                    ";
        }
        // line 142
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "buyerReference", [], "any", true, true, false, 142)) {
            // line 143
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "buyerReference", [], "any", false, false, false, 143), 'row');
            yield "
                    ";
        }
        // line 145
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceTemplate", [], "any", true, true, false, 145)) {
            // line 146
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceTemplate", [], "any", false, false, false, 146), 'row');
            yield "
                    ";
        }
        // line 148
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", true, true, false, 148)) {
            // line 149
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", false, false, false, 149), 'row');
            yield "
                    ";
        }
        // line 151
        yield "                    ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 151, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), "invoice"]);
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  614 => 151,  608 => 149,  605 => 148,  599 => 146,  596 => 145,  590 => 143,  587 => 142,  581 => 140,  578 => 139,  572 => 137,  569 => 136,  562 => 135,  551 => 134,  546 => 131,  544 => 133,  542 => 132,  535 => 131,  474 => 128,  468 => 125,  462 => 122,  454 => 117,  448 => 114,  440 => 109,  432 => 104,  424 => 99,  420 => 97,  413 => 93,  409 => 91,  407 => 90,  401 => 87,  397 => 85,  390 => 84,  379 => 83,  374 => 80,  372 => 82,  370 => 81,  363 => 80,  302 => 162,  296 => 159,  290 => 156,  286 => 154,  283 => 131,  281 => 80,  276 => 79,  269 => 75,  265 => 73,  262 => 72,  255 => 68,  252 => 67,  246 => 64,  243 => 63,  240 => 62,  234 => 59,  231 => 58,  229 => 57,  226 => 56,  224 => 55,  218 => 52,  212 => 49,  206 => 46,  198 => 41,  192 => 38,  186 => 35,  178 => 30,  172 => 27,  166 => 24,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/edit.html.twig", "/opt/kimai/templates/customer/edit.html.twig");
    }
}
