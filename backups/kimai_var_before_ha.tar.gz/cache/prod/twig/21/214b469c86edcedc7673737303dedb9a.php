<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/actions.html.twig */
class __TwigTemplate_ae5d2c09e06f6df92f2197616dd402a0 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_actions($actions = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "actions" => $actions,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            $macros["macro"] = $this->load("@Tabler/components/button.html.twig", 2)->unwrap();
            // line 3
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["actions"] ?? null)) >= 1)) {
                // line 4
                $context["class"] = "btn-sm";
                // line 5
                $context["translationDomain"] = "messages";
                // line 6
                if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "translationDomain", [], "any", true, true, false, 6)) {
                    // line 7
                    $context["translationDomain"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "translationDomain", [], "any", false, false, false, 7);
                }
                // line 9
                if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", true, true, false, 9)) {
                    // line 10
                    $context["class"] = CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "class", [], "any", false, false, false, 10);
                }
                // line 12
                $context["trash"] = null;
                // line 13
                $context["divider"] = false;
                // line 14
                yield "<div class=\"dropdown\">
            <a href=\"#\" class=\"link-secondary ";
                // line 15
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["class"] ?? null), "html", null, true);
                yield "\" data-bs-toggle=\"dropdown\" data-bs-auto-close=\"outside\" aria-expanded=\"false\" aria-label=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Actions", [], "TablerBundle"), "html", null, true);
                yield "\">
                <i class=\"";
                // line 16
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", true, true, false, 16)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", false, false, false, 16), "fas fa-ellipsis-h")) : ("fas fa-ellipsis-h")), "html", null, true);
                yield "\"></i>
            </a>
            <div class=\"dropdown-menu dropdown-menu-end\" data-popper-placement=\"bottom-end\">";
                // line 19
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(($context["actions"] ?? null));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["icon"] => $context["values"]) {
                    // line 20
                    if ((CoreExtension::inFilter("divider", $context["icon"]) && (null === $context["values"]))) {
                        // line 21
                        if (( !(($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "last", [], "any", false, false, false, 21)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($context["divider"] ?? null) === false))) {
                            // line 22
                            yield "<hr class=\"dropdown-divider\" />";
                        }
                        // line 24
                        $context["divider"] = true;
                    } else {
                        // line 26
                        if (is_iterable($context["values"])) {
                            // line 27
                            if ( !CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "array", true, true, false, 27)) {
                                // line 28
                                $context["values"] = Twig\Extension\CoreExtension::merge($context["values"], ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["icon"], [], ($context["translationDomain"] ?? null))]);
                            }
                        } else {
                            // line 31
                            $context["values"] = ["href" => $context["values"], "title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans($context["icon"], [], ($context["translationDomain"] ?? null))];
                        }
                        // line 33
                        if (($context["icon"] == "trash")) {
                            // line 34
                            $context["trash"] = $context["values"];
                        } else {
                            // line 36
                            if (CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", true, true, false, 36)) {
                                // line 37
                                if ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "any", true, true, false, 37) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "any", false, false, false, 37)))) {
                                    // line 38
                                    yield "<div class=\"dropend\">
                                        <a class=\"dropdown-item dropdown-toggle\" href=\"#\" data-bs-toggle=\"dropdown\" data-bs-auto-close=\"outside\" role=\"button\" aria-expanded=\"false\">
                                            ";
                                    // line 40
                                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "title", [], "any", false, false, false, 40)), "html", null, true);
                                    yield "
                                        </a>
                                        <div class=\"dropdown-menu\">";
                                    // line 43
                                    $context['_parent'] = $context;
                                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", false, false, false, 43));
                                    foreach ($context['_seq'] as $context["childIcon"] => $context["childValues"]) {
                                        // line 44
                                        yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 44, $this->getSourceContext())->macro_button(...[false, Twig\Extension\CoreExtension::merge($context["childValues"], ["icon" => false, "class" => ((CoreExtension::getAttribute($this->env, $this->source, $context["childValues"], "class", [], "any", true, true, false, 44)) ? ((CoreExtension::getAttribute($this->env, $this->source, $context["childValues"], "class", [], "any", false, false, false, 44) . " dropdown-item")) : ("dropdown-item"))]), false]);
                                    }
                                    $_parent = $context['_parent'];
                                    unset($context['_seq'], $context['childIcon'], $context['childValues'], $context['_parent']);
                                    $context = array_intersect_key($context, $_parent);
                                    $context += $_parent;
                                    // line 46
                                    yield "</div>
                                    </div>";
                                } else {
                                    // line 49
                                    if ((($context["divider"] ?? null) === false)) {
                                        yield "<hr class=\"dropdown-divider\" />";
                                    }
                                    // line 50
                                    $context['_parent'] = $context;
                                    $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["values"], "children", [], "any", false, false, false, 50));
                                    foreach ($context['_seq'] as $context["childIcon"] => $context["childValues"]) {
                                        // line 51
                                        yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 51, $this->getSourceContext())->macro_button(...[false, Twig\Extension\CoreExtension::merge($context["childValues"], ["icon" => false, "class" => ((CoreExtension::getAttribute($this->env, $this->source, $context["childValues"], "class", [], "any", true, true, false, 51)) ? ((CoreExtension::getAttribute($this->env, $this->source, $context["childValues"], "class", [], "any", false, false, false, 51) . " dropdown-item")) : ("dropdown-item"))]), false]);
                                    }
                                    $_parent = $context['_parent'];
                                    unset($context['_seq'], $context['childIcon'], $context['childValues'], $context['_parent']);
                                    $context = array_intersect_key($context, $_parent);
                                    $context += $_parent;
                                    // line 53
                                    yield "<hr class=\"dropdown-divider\" />";
                                }
                                // line 55
                                $context["divider"] = true;
                            } else {
                                // line 57
                                $context["divider"] = false;
                                // line 58
                                yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 58, $this->getSourceContext())->macro_button(...[false, Twig\Extension\CoreExtension::merge($context["values"], ["icon" => false, "class" => ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", true, true, false, 58)) ? ((CoreExtension::getAttribute($this->env, $this->source, $context["values"], "class", [], "any", false, false, false, 58) . " dropdown-item")) : ("dropdown-item"))]), false]);
                            }
                        }
                    }
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['icon'], $context['values'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 63
                if ( !(null === ($context["trash"] ?? null))) {
                    // line 64
                    if (((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["actions"] ?? null)) > 1) && (($context["divider"] ?? null) === false))) {
                        // line 65
                        yield "<hr class=\"dropdown-divider\" />";
                    }
                    // line 67
                    yield (string) $macros["macro"]->getTemplateForMacro("macro_button", $context, 67, $this->getSourceContext())->macro_button(...[false, Twig\Extension\CoreExtension::merge(($context["trash"] ?? null), ["class" => ((CoreExtension::getAttribute($this->env, $this->source, ($context["trash"] ?? null), "class", [], "any", true, true, false, 67)) ? ((CoreExtension::getAttribute($this->env, $this->source, ($context["trash"] ?? null), "class", [], "any", false, false, false, 67) . " text-danger dropdown-item")) : ("dropdown-item"))]), false]);
                }
                // line 69
                yield "</div>
        </div>";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/actions.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  217 => 69,  214 => 67,  211 => 65,  209 => 64,  207 => 63,  189 => 58,  187 => 57,  184 => 55,  181 => 53,  174 => 51,  170 => 50,  166 => 49,  162 => 46,  155 => 44,  151 => 43,  146 => 40,  142 => 38,  140 => 37,  138 => 36,  135 => 34,  133 => 33,  130 => 31,  126 => 28,  124 => 27,  122 => 26,  119 => 24,  116 => 22,  114 => 21,  112 => 20,  95 => 19,  90 => 16,  84 => 15,  81 => 14,  79 => 13,  77 => 12,  74 => 10,  72 => 9,  69 => 7,  67 => 6,  65 => 5,  63 => 4,  61 => 3,  59 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/actions.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/actions.html.twig");
    }
}
