<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/report_by_user.html.twig */
class __TwigTemplate_6aeb16d1ba714bffda7f66f7a855493b extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_content' => [$this, 'block_report_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/report_by_user_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/report_by_user_layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield from $this->load("reporting/report_by_user.html.twig", 4, 1)->unwrap()->yield(CoreExtension::merge($context, ["with_links" => true]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_by_user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_by_user.html.twig", "/opt/kimai/templates/reporting/report_by_user.html.twig");
    }
}


/* reporting/report_by_user.html.twig */
class __TwigTemplate_6aeb16d1ba714bffda7f66f7a855493b___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'period_name' => [$this, 'block_period_name'],
            'upper_left' => [$this, 'block_upper_left'],
            'column_classes_project' => [$this, 'block_column_classes_project'],
            'column_classes_activity' => [$this, 'block_column_classes_activity'],
            'column_classes_total' => [$this, 'block_column_classes_total'],
            'column_classes_customer_total' => [$this, 'block_column_classes_customer_total'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "reporting/report_by_user_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/report_by_user_data.html.twig", 4);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "            <th class=\"text-center text-nowrap";
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(($context["column"] ?? null))) {
            yield " weekend";
        }
        if ($this->env->getTest('today')->getCallable()(($context["column"] ?? null))) {
            yield " today";
        }
        yield "\">
                ";
        // line 7
        yield (string) $this->extensions['App\Twig\LocaleFormatExtensions']->dateWeekday(($context["column"] ?? null));
        yield "
            </th>
        ";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_upper_left(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "&nbsp;";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_project(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(CoreExtension::getAttribute($this->env, $this->source, ($context["column"] ?? null), "date", [], "any", false, false, false, 12))) {
            yield " weekend";
        }
        if ($this->env->getTest('today')->getCallable()(CoreExtension::getAttribute($this->env, $this->source, ($context["column"] ?? null), "date", [], "any", false, false, false, 12))) {
            yield " today";
        }
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(CoreExtension::getAttribute($this->env, $this->source, ($context["column"] ?? null), "date", [], "any", false, false, false, 15))) {
            yield " weekend";
        }
        if ($this->env->getTest('today')->getCallable()(CoreExtension::getAttribute($this->env, $this->source, ($context["column"] ?? null), "date", [], "any", false, false, false, 15))) {
            yield " today";
        }
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(($context["column"] ?? null))) {
            yield " weekend";
        }
        yield from [];
    }

    // line 20
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_column_classes_customer_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 21
        if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(($context["column"] ?? null))) {
            yield " weekend";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/report_by_user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  224 => 21,  217 => 20,  210 => 18,  203 => 17,  193 => 15,  186 => 14,  176 => 12,  169 => 11,  158 => 10,  150 => 7,  140 => 6,  133 => 5,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/report_by_user.html.twig", "/opt/kimai/templates/reporting/report_by_user.html.twig");
    }
}
