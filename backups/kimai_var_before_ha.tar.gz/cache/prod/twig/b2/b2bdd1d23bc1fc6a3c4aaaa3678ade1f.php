<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/index.html.twig */
class __TwigTemplate_2e99cd37c2a797dca5dff8c4ce31c524 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 4
        $macros["actions"] = $this->macros["actions"] = $this->load("user/actions.html.twig", 4)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_row_attr", $context, 6, $this->getSourceContext())->macro_user_row_attr(...[($context["entry"] ?? null)]);
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "    ";
        if ((($context["column"] ?? null) == "avatar")) {
            // line 10
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 10, $this->getSourceContext())->macro_user_avatar(...[($context["entry"] ?? null), false]);
            yield "
    ";
        } elseif ((        // line 11
($context["column"] ?? null) == "alias")) {
            // line 12
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "alias", [], "any", false, false, false, 12), "html", null, true);
            yield "
    ";
        } elseif ((        // line 13
($context["column"] ?? null) == "user")) {
            // line 14
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_username", $context, 14, $this->getSourceContext())->macro_username(...[($context["entry"] ?? null)]);
            yield "
    ";
        } elseif ((        // line 15
($context["column"] ?? null) == "username")) {
            // line 16
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "username", [], "any", false, false, false, 16), "html", null, true);
            yield "
    ";
        } elseif ((        // line 17
($context["column"] ?? null) == "account_number")) {
            // line 18
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "accountNumber", [], "any", false, false, false, 18), "html", null, true);
            yield "
    ";
        } elseif ((        // line 19
($context["column"] ?? null) == "title")) {
            // line 20
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "title", [], "any", false, false, false, 20), "html", null, true);
            yield "
    ";
        } elseif ((        // line 21
($context["column"] ?? null) == "email")) {
            // line 22
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "email", [], "any", false, false, false, 22), "html", null, true);
            yield "
    ";
        } elseif ((        // line 23
($context["column"] ?? null) == "lastLogin")) {
            // line 24
            yield "        ";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "lastLogin", [], "any", false, false, false, 24))) {
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "lastLogin", [], "any", false, false, false, 24)), "html", null, true);
            }
            // line 25
            yield "    ";
        } elseif ((($context["column"] ?? null) == "roles")) {
            // line 26
            yield "        ";
            $context["showUserRole"] = (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "roles", [], "any", false, false, false, 26)) == 1);
            // line 27
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "roles", [], "any", false, false, false, 27));
            foreach ($context['_seq'] as $context["_key"] => $context["role"]) {
                // line 28
                yield "            ";
                if (((($tmp = ($context["showUserRole"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) || ($context["role"] != "ROLE_USER"))) {
                    // line 29
                    yield "                ";
                    yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_role", $context, 29, $this->getSourceContext())->macro_label_role(...[$context["role"]]);
                    yield "
            ";
                }
                // line 31
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['role'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 32
            yield "    ";
        } elseif ((($context["column"] ?? null) == "team")) {
            // line 33
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 33, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "teams", [], "any", false, false, false, 33)]);
            yield "
    ";
        } elseif ((        // line 34
($context["column"] ?? null) == "active")) {
            // line 35
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 35, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "enabled", [], "any", false, false, false, 35)]);
            yield "
    ";
        } elseif ((        // line 36
($context["column"] ?? null) == "system_account")) {
            // line 37
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 37, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "systemAccount", [], "any", false, false, false, 37)]);
            yield "
    ";
        } elseif ((        // line 38
($context["column"] ?? null) == "actions")) {
            // line 39
            yield "        ";
            yield (string) $macros["actions"]->getTemplateForMacro("macro_user", $context, 39, $this->getSourceContext())->macro_user(...[($context["entry"] ?? null), "index"]);
            yield "
    ";
        } elseif ((is_string($_v0 =         // line 40
($context["column"] ?? null)) && is_string($_v1 = "mf_") && str_starts_with($_v0, $_v1))) {
            // line 41
            yield "        ";
            $context["metaField"] = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "preference", [CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "name", [], "any", false, false, false, 41)], "method", false, false, false, 41);
            // line 42
            yield "        ";
            if ((( !(null === ($context["metaField"] ?? null)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 42))) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 42)))) {
                // line 43
                yield "            ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_form_type_value", $context, 43, $this->getSourceContext())->macro_form_type_value(...[CoreExtension::getAttribute($this->env, $this->source, ($context["data"] ?? null), "type", [], "any", false, false, false, 43), CoreExtension::getAttribute($this->env, $this->source, ($context["metaField"] ?? null), "value", [], "any", false, false, false, 43), ($context["entry"] ?? null)]);
                yield "
        ";
            }
            // line 45
            yield "    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  206 => 45,  200 => 43,  197 => 42,  194 => 41,  192 => 40,  187 => 39,  185 => 38,  180 => 37,  178 => 36,  173 => 35,  171 => 34,  166 => 33,  163 => 32,  156 => 31,  150 => 29,  147 => 28,  142 => 27,  139 => 26,  136 => 25,  131 => 24,  129 => 23,  124 => 22,  122 => 21,  117 => 20,  115 => 19,  110 => 18,  108 => 17,  103 => 16,  101 => 15,  96 => 14,  94 => 13,  89 => 12,  87 => 11,  82 => 10,  79 => 9,  72 => 8,  60 => 6,  55 => 1,  53 => 4,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/index.html.twig", "/opt/kimai/templates/user/index.html.twig");
    }
}
