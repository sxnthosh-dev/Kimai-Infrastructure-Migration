<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/customer/monthly_projects.html.twig */
class __TwigTemplate_7262b0f5f49b61773037d3996fc1e2bb extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'report_form_layout' => [$this, 'block_report_form_layout'],
            'report' => [$this, 'block_report'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "reporting/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("reporting/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report_form_layout(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 4), 'widget');
        yield "
    ";
        // line 5
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 5), 'widget', ["label" => false, "placeholder" => "customer"]);
        yield "
    ";
        // line 6
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "sumType", [], "any", false, false, false, 6), 'widget');
        yield "
    ";
        // line 7
        $macros["_v0"] = $this->load("@theme/components/buttons.html.twig", 7)->unwrap();
        // line 8
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_submit_button", $context, 8, $this->getSourceContext())->macro_submit_button(...["download", ["attr" => ["formaction" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["export_route"] ?? null))], "icon" => "download", "combined" => false]]);
        yield "
";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_report(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "    ";
        yield from $this->load("reporting/customer/monthly_projects.html.twig", 12, 2)->unwrap()->yield($context);
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  90 => 12,  83 => 11,  75 => 8,  73 => 7,  69 => 6,  65 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects.html.twig");
    }
}


/* reporting/customer/monthly_projects.html.twig */
class __TwigTemplate_7262b0f5f49b61773037d3996fc1e2bb___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        $macros["_v1"] = $this->macros["_v1"] = $this->load("macros/widgets.html.twig", 13)->unwrap();
        // line 12
        $this->parent = $this->load("@theme/embeds/card.html.twig", 12);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " table-responsive ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["stats"] ?? null))) {
            yield "p-0";
        }
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "            ";
        if (Twig\Extension\CoreExtension::testEmpty(($context["stats"] ?? null))) {
            // line 17
            yield "                ";
            yield (string) $macros["_v1"]->getTemplateForMacro("macro_nothing_found", $context, 17, $this->getSourceContext())->macro_nothing_found(...[]);
            yield "
            ";
        } else {
            // line 19
            yield "                ";
            yield from $this->load("reporting/customer/monthly_projects.html.twig", 19, 1)->unwrap()->yield(CoreExtension::toArray(["stats" => ($context["stats"] ?? null), "dataType" => ($context["dataType"] ?? null), "decimal" => ($context["decimal"] ?? null)]));
            // line 22
            yield "            ";
        }
        // line 23
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  199 => 23,  196 => 22,  193 => 19,  187 => 17,  184 => 16,  177 => 15,  163 => 14,  158 => 12,  156 => 13,  90 => 12,  83 => 11,  75 => 8,  73 => 7,  69 => 6,  65 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects.html.twig");
    }
}


/* reporting/customer/monthly_projects.html.twig */
class __TwigTemplate_7262b0f5f49b61773037d3996fc1e2bb___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 19
        return "reporting/customer/monthly_projects_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        $context["rowspanStyle"] = "vertical-align: middle";
        // line 19
        $this->parent = $this->load("reporting/customer/monthly_projects_data.html.twig", 19);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  265 => 19,  263 => 20,  256 => 19,  199 => 23,  196 => 22,  193 => 19,  187 => 17,  184 => 16,  177 => 15,  163 => 14,  158 => 12,  156 => 13,  90 => 12,  83 => 11,  75 => 8,  73 => 7,  69 => 6,  65 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects.html.twig");
    }
}
