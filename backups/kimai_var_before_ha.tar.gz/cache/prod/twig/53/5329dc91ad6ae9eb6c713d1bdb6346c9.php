<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/delete.html.twig */
class __TwigTemplate_13a7c52e4d3e450ca165ee2e49427d63 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["params"] = ["%records%" => CoreExtension::getAttribute($this->env, $this->source,         // line 5
($context["stats"] ?? null), "counter", [], "any", false, false, false, 5), "%duration%" => $this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["stats"] ?? null), "duration", [], "any", false, false, false, 6))];
        // line 8
        yield "    ";
        yield (string) Twig\Extension\CoreExtension::include($this->env, $context, (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 8)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_delete_modal.html.twig") : ("default/_form_delete.html.twig")), ["message" => (($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete_warning.short_stats",         // line 9
($context["params"] ?? null)) . " ") . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("admin_entity.delete_confirm")), "form" =>         // line 10
($context["form"] ?? null), "delete_item_name" => CoreExtension::getAttribute($this->env, $this->source,         // line 11
($context["project"] ?? null), "name", [], "any", false, false, false, 11), "used" => (CoreExtension::getAttribute($this->env, $this->source,         // line 12
($context["stats"] ?? null), "counter", [], "any", false, false, false, 12) > 0), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_project")]);
        // line 14
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/delete.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  70 => 14,  68 => 12,  67 => 11,  66 => 10,  65 => 9,  63 => 8,  61 => 6,  60 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/delete.html.twig", "/opt/kimai/templates/project/delete.html.twig");
    }
}
