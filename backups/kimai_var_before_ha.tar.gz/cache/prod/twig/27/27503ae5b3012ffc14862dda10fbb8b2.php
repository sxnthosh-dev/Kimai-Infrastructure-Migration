<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/security/password_reset.html.twig */
class __TwigTemplate_5a614e4bf484a3223938bb8df5245bf1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'login_social_auth' => [$this, 'block_login_social_auth'],
            'login_box_msg' => [$this, 'block_login_box_msg'],
            'login_form' => [$this, 'block_login_form'],
            'login_actions' => [$this, 'block_login_actions'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@Tabler/security.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@Tabler/security.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_social_auth(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_box_msg(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Reset your password", [], "TablerBundle"), "html", null, true);
        yield "
";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_form(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "    <form class=\"card-body security-password-reset\" action=\"";
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_password_reset_sent"));
        yield "\" method=\"post\" autocomplete=\"off\">
        <div class=\"mb-3\">
            <label for=\"username\" class=\"form-label\">";
        // line 12
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Username or email address", [], "TablerBundle"), "html", null, true);
        yield "</label>
            <input autocomplete=\"username\" type=\"text\" id=\"username\" name=\"username\" required=\"required\" class=\"form-control\" placeholder=\"";
        // line 13
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Username or email address", [], "TablerBundle"), "html", null, true);
        yield "\">
        </div>
        <div class=\"form-footer\">
            ";
        // line 16
        $macros["_v0"] = $this->load("@Tabler/components/buttons.html.twig", 16)->unwrap();
        // line 17
        yield "            ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_submit_button", $context, 17, $this->getSourceContext())->macro_submit_button(...["mail", ["class" => "w-100", "title" => "Reset your password", "translation_domain" => "TablerBundle"], "primary"]);
        yield "
        </div>
        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 19
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("password_reset"), "html", null, true);
        yield "\"/>
    </form>
";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_login_actions(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "    <div class=\"text-center text-body-secondary mt-3\">
        <a href=\"";
        // line 25
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->getRouteByAlias("tabler_login"));
        yield "\">
            ";
        // line 26
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Back to login", [], "TablerBundle"), "html", null, true);
        yield "
        </a>
    </div>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/security/password_reset.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  133 => 26,  129 => 25,  126 => 24,  119 => 23,  111 => 19,  105 => 17,  103 => 16,  97 => 13,  93 => 12,  87 => 10,  80 => 9,  72 => 6,  65 => 5,  55 => 3,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/security/password_reset.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/security/password_reset.html.twig");
    }
}
