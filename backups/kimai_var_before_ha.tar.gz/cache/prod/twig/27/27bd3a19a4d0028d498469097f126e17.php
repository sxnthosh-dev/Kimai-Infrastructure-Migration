<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* export/template.html.twig */
class __TwigTemplate_070f93c990eb26c738e8b9694ea9a32e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "        ";
        $context["formOptions"] = ["title" => (((($tmp = CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["template"] ?? null), "isNew", [], "method", false, false, false, 6)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"))), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("export_template_create")];
        // line 10
        yield "        ";
        yield from $this->load("export/template.html.twig", 10, 1)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/template.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/template.html.twig", "/opt/kimai/templates/export/template.html.twig");
    }
}


/* export/template.html.twig */
class __TwigTemplate_070f93c990eb26c738e8b9694ea9a32e___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
            'form_after' => [$this, 'block_form_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "                <div class=\"row\">
                    <div class=\"col-md-9\">
                        ";
        // line 14
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 14), 'row');
        yield "
                    </div>
                    <div class=\"col-md-3\">
                        ";
        // line 17
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "renderer", [], "any", false, false, false, 17), 'row', ["attr" => ["onchange" => "changeExportTemplateType(this)"]]);
        yield "
                    </div>
                </div>
                ";
        // line 20
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "language", [], "any", false, false, false, 20), 'row');
        yield "
                ";
        // line 21
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "columns", [], "any", false, false, false, 21), 'row');
        yield "
                ";
        // line 22
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
            ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "                <script>
                    function changeExportTemplateType(typeElement)
                    {
                        typeElement.form.querySelectorAll(\x27[data-type]\x27).forEach(
                            element => {
                                if (element.dataset[\x27type\x27] !== undefined && element.dataset[\x27type\x27] === typeElement.value) {
                                    element.classList.remove(\x27d-none\x27);
                                } else {
                                    element.classList.add(\x27d-none\x27);
                                }
                            }
                        );
                    }
                    changeExportTemplateType(document.getElementById(\x27";
        // line 38
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "renderer", [], "any", false, false, false, 38), "vars", [], "any", false, false, false, 38), "id", [], "any", false, false, false, 38), "html", null, true);
        yield "\x27));
                </script>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "export/template.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  195 => 38,  180 => 25,  173 => 24,  166 => 22,  162 => 21,  158 => 20,  152 => 17,  146 => 14,  142 => 12,  135 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "export/template.html.twig", "/opt/kimai/templates/export/template.html.twig");
    }
}
