<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/avatar_image.html.twig */
class __TwigTemplate_b3ec5e0600a3b859ea25ee7585349a73 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_avatar_image($user = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "user" => $user,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            if (( !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 2)) && (($tmp = $this->extensions['App\Twig\Configuration']->get($this->env, "themeAllowAvatarUrls")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 3
                yield "        ";
                $context["avatar"] = $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "avatar", [], "any", false, false, false, 3), "avatars");
                // line 4
                yield "        <span class=\"avatar\" style=\"background-image:url(";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["avatar"] ?? null), "html", null, true);
                yield ")\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 4), "html", null, true);
                yield "\">&nbsp;</span>
    ";
            } else {
                // line 6
                yield "        ";
                $context["color"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "color", [], "any", false, false, false, 6), CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 6));
                // line 7
                yield "        <span class=\"avatar\" style=\"background-color: ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
                yield "; color: ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(($context["color"] ?? null)), "html", null, true);
                yield "\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 7), "html", null, true);
                yield "\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "initials", [], "any", false, false, false, 7), "html", null, true);
                yield "</span>
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/avatar_image.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  75 => 7,  72 => 6,  64 => 4,  61 => 3,  58 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/avatar_image.html.twig", "/opt/kimai/templates/bundles/TablerBundle/components/avatar_image.html.twig");
    }
}
