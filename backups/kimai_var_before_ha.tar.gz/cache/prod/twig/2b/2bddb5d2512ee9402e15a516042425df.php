<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/wizard.html.twig */
class __TwigTemplate_c0adc4e25910546f6d0707674b3052f6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_content' => [$this, 'block_page_content'],
            'container_size' => [$this, 'block_container_size'],
            'container_class' => [$this, 'block_container_class'],
            'container_attr' => [$this, 'block_container_attr'],
            'wizard_before' => [$this, 'block_wizard_before'],
            'wizard_logo' => [$this, 'block_wizard_logo'],
            'navbar_brand_classes' => [$this, 'block_navbar_brand_classes'],
            'navbar_brand_class' => [$this, 'block_navbar_brand_class'],
            'wizard_header_before' => [$this, 'block_wizard_header_before'],
            'wizard_header' => [$this, 'block_wizard_header'],
            'wizard_header_after' => [$this, 'block_wizard_header_after'],
            'card_class' => [$this, 'block_card_class'],
            'card_attr' => [$this, 'block_card_attr'],
            'wizard_content_before' => [$this, 'block_wizard_content_before'],
            'wizard_content' => [$this, 'block_wizard_content'],
            'wizard_content_after' => [$this, 'block_wizard_content_after'],
            'wizard_footer_before' => [$this, 'block_wizard_footer_before'],
            'wizard_footer' => [$this, 'block_wizard_footer'],
            'wizard_progress_bar' => [$this, 'block_wizard_progress_bar'],
            'wizard_previous_button' => [$this, 'block_wizard_previous_button'],
            'wizard_next_button' => [$this, 'block_wizard_next_button'],
            'wizard_footer_after' => [$this, 'block_wizard_footer_after'],
            'wizard_after' => [$this, 'block_wizard_after'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@Tabler/fullpage.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 3
        $macros["_v0"] = $this->macros["_v0"] = $this->load("@Tabler/components/progress_bar.html.twig", 3)->unwrap();
        // line 4
        $macros["_v1"] = $this->macros["_v1"] = $this->load("@Tabler/components/button.html.twig", 4)->unwrap();
        // line 5
        $macros["_v2"] = $this->macros["_v2"] = $this->load("@Tabler/components/buttons.html.twig", 5)->unwrap();
        // line 1
        $this->parent = $this->load("@Tabler/fullpage.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "
    <div
            class=\"container ";
        // line 10
        yield from $this->unwrap()->yieldBlock('container_size', $context, $blocks);
        yield " ";
        yield from $this->unwrap()->yieldBlock('container_class', $context, $blocks);
        yield "\"
            ";
        // line 11
        yield from $this->unwrap()->yieldBlock('container_attr', $context, $blocks);
        // line 12
        yield "    >
        ";
        // line 13
        yield from $this->unwrap()->yieldBlock('wizard_before', $context, $blocks);
        // line 14
        yield "
        ";
        // line 15
        yield from $this->unwrap()->yieldBlock('wizard_logo', $context, $blocks);
        // line 22
        yield "
        ";
        // line 23
        yield from $this->unwrap()->yieldBlock('wizard_header_before', $context, $blocks);
        // line 24
        yield "        ";
        yield from $this->unwrap()->yieldBlock('wizard_header', $context, $blocks);
        // line 25
        yield "        ";
        yield from $this->unwrap()->yieldBlock('wizard_header_after', $context, $blocks);
        // line 26
        yield "
        <div
                class=\"card ";
        // line 28
        yield from $this->unwrap()->yieldBlock('card_class', $context, $blocks);
        yield "\"
                ";
        // line 29
        yield from $this->unwrap()->yieldBlock('card_attr', $context, $blocks);
        // line 30
        yield "        >
            ";
        // line 31
        yield from $this->unwrap()->yieldBlock('wizard_content_before', $context, $blocks);
        // line 32
        yield "            ";
        yield from $this->unwrap()->yieldBlock('wizard_content', $context, $blocks);
        // line 33
        yield "            ";
        yield from $this->unwrap()->yieldBlock('wizard_content_after', $context, $blocks);
        // line 34
        yield "        </div>

        ";
        // line 36
        yield from $this->unwrap()->yieldBlock('wizard_footer_before', $context, $blocks);
        // line 37
        yield "        ";
        yield from $this->unwrap()->yieldBlock('wizard_footer', $context, $blocks);
        // line 57
        yield "        ";
        yield from $this->unwrap()->yieldBlock('wizard_footer_after', $context, $blocks);
        // line 58
        yield "
        ";
        // line 59
        yield from $this->unwrap()->yieldBlock('wizard_after', $context, $blocks);
        // line 60
        yield "    </div>

";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "container-narrow";
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "py-4";
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_container_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_logo(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "            <div class=\"text-center mb-4\">
                <h1 class=\"";
        // line 17
        yield from $this->unwrap()->yieldBlock('navbar_brand_classes', $context, $blocks);
        yield "\">
                    ";
        // line 18
        yield from $this->load("@Tabler/includes/logo.html.twig", 18)->unwrap()->yield($context);
        // line 19
        yield "                </h1>
            </div>
        ";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_classes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand ";
        yield from $this->unwrap()->yieldBlock('navbar_brand_class', $context, $blocks);
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_navbar_brand_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "navbar-brand-autodark";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_header_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_header(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_header_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 28
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "card-md";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_card_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_content_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_content_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_footer_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 38
        yield "            <div class=\"row align-items-center mt-3\">
                <div class=\"col-4\">
                    ";
        // line 40
        yield from $this->unwrap()->yieldBlock('wizard_progress_bar', $context, $blocks);
        // line 43
        yield "                </div>
                <div class=\"col\">
                    <div class=\"btn-list justify-content-end\">
                        ";
        // line 46
        yield from $this->unwrap()->yieldBlock('wizard_previous_button', $context, $blocks);
        // line 49
        yield "
                        ";
        // line 50
        yield from $this->unwrap()->yieldBlock('wizard_next_button', $context, $blocks);
        // line 53
        yield "                    </div>
                </div>
            </div>
        ";
        yield from [];
    }

    // line 40
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_progress_bar(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 41
        yield "                        ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_progress_bar", $context, 41, $this->getSourceContext())->macro_progress_bar(...[]);
        yield "
                    ";
        yield from [];
    }

    // line 46
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_previous_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 47
        yield "                            ";
        yield (string) $macros["_v1"]->getTemplateForMacro("macro_button", $context, 47, $this->getSourceContext())->macro_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Previous", [], "TablerBundle"), "combined" => true], "link"]);
        yield "
                        ";
        yield from [];
    }

    // line 50
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_next_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 51
        yield "                            ";
        yield (string) $macros["_v2"]->getTemplateForMacro("macro_submit_button", $context, 51, $this->getSourceContext())->macro_submit_button(...[false, ["title" => $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("Next", [], "TablerBundle"), "combined" => true], "primary"]);
        yield "
                        ";
        yield from [];
    }

    // line 57
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_footer_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/wizard.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  431 => 59,  421 => 57,  413 => 51,  406 => 50,  398 => 47,  391 => 46,  383 => 41,  376 => 40,  368 => 53,  366 => 50,  363 => 49,  361 => 46,  356 => 43,  354 => 40,  350 => 38,  343 => 37,  333 => 36,  323 => 33,  313 => 32,  303 => 31,  293 => 29,  282 => 28,  272 => 25,  262 => 24,  252 => 23,  230 => 17,  223 => 19,  221 => 18,  217 => 17,  214 => 16,  207 => 15,  197 => 13,  187 => 11,  166 => 10,  159 => 60,  157 => 59,  154 => 58,  151 => 57,  148 => 37,  146 => 36,  142 => 34,  139 => 33,  136 => 32,  134 => 31,  131 => 30,  129 => 29,  125 => 28,  121 => 26,  118 => 25,  115 => 24,  113 => 23,  110 => 22,  108 => 15,  105 => 14,  103 => 13,  100 => 12,  98 => 11,  92 => 10,  88 => 8,  81 => 7,  76 => 1,  74 => 5,  72 => 4,  70 => 3,  63 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/wizard.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/wizard.html.twig");
    }
}
