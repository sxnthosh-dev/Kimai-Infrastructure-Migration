<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'status' => [$this, 'block_status'],
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_status(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $macros["_v0"] = $this->load("macros/status.html.twig", 4)->unwrap();
        // line 5
        yield "    ";
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_status", $context, 5, $this->getSourceContext())->macro_status(...[Twig\Extension\CoreExtension::constant("App\\Constants::VERSION")]);
        yield "
    ";
        // line 6
        yield (string) $macros["_v0"]->getTemplateForMacro("macro_status", $context, 6, $this->getSourceContext())->macro_status(...[($context["environment"] ?? null), (((($context["environment"] ?? null) == "dev")) ? ("danger-lt") : ("success-lt"))]);
        yield "
";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "
    ";
        // line 11
        if (( !(null === ($context["release"] ?? null)) && is_iterable(($context["release"] ?? null)))) {
            // line 12
            yield "        ";
            yield from $this->load("doctor/index.html.twig", 12, 1)->unwrap()->yield(CoreExtension::merge($context, ["release" => ($context["release"] ?? null), "boxtype" => "warning"]));
            // line 21
            yield "    ";
        }
        // line 22
        yield "
    ";
        // line 23
        $context["permissionOpts"] = ["boxtype" => "success"];
        // line 24
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["directories"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 25
            yield "        ";
            if (($context["value"] === false)) {
                // line 26
                yield "            ";
                $context["permissionOpts"] = ["boxtype" => "danger", "open" => true];
                // line 27
                yield "        ";
            }
            // line 28
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 29
        yield "
    ";
        // line 30
        yield from $this->load("doctor/index.html.twig", 30, 2)->unwrap()->yield(CoreExtension::merge($context, ($context["permissionOpts"] ?? null)));
        // line 53
        yield "
    ";
        // line 54
        $context["extensionOpts"] = ["boxtype" => "success"];
        // line 55
        yield "    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["extensions"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 56
            yield "        ";
            if (($context["value"] === false)) {
                // line 57
                yield "            ";
                $context["extensionOpts"] = ["boxtype" => "danger", "open" => true];
                // line 58
                yield "        ";
            }
            // line 59
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 60
        yield "
    ";
        // line 61
        yield from $this->load("doctor/index.html.twig", 61, 3)->unwrap()->yield(CoreExtension::merge($context, ($context["extensionOpts"] ?? null)));
        // line 83
        yield "
    ";
        // line 84
        $context["logOpts"] = [];
        // line 85
        yield "    ";
        if ((($context["logSize"] ?? null) > 52428800)) {
            // line 86
            yield "        ";
            $context["logOpts"] = ["boxtype" => "danger", "open" => true];
            // line 87
            yield "    ";
        }
        // line 88
        yield "    ";
        yield from $this->load("doctor/index.html.twig", 88, 4)->unwrap()->yield(CoreExtension::merge($context, ($context["logOpts"] ?? null)));
        // line 117
        yield "
    ";
        // line 118
        yield from $this->load("doctor/index.html.twig", 118, 5)->unwrap()->yield($context);
        // line 133
        yield "
    ";
        // line 134
        yield from $this->load("doctor/index.html.twig", 134, 6)->unwrap()->yield($context);
        // line 168
        yield "
    ";
        // line 169
        $context["opcache_warning"] =  !(($tmp = (($_v1 = ($context["opcache"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["enabled"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp);
        // line 170
        yield "    ";
        $context["opcache_unknown"] = (($_v2 = ($context["opcache"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["unknown"] ?? null) : null);
        // line 171
        yield "    ";
        yield from $this->load("doctor/index.html.twig", 171, 7)->unwrap()->yield(CoreExtension::merge($context, ["open" => ($context["opcache_warning"] ?? null), "boxtype" => (((($tmp = ($context["opcache_warning"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ((((($tmp = ($context["opcache_unknown"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("warning") : ("danger"))) : ("success"))]));
        // line 241
        yield "
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 12
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 12);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 13
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Kimai ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["release"] ?? null), "version", [], "any", false, false, false, 13), "html", null, true);
        yield " available (released on ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["release"] ?? null), "date", [], "any", false, false, false, 13)), "html", null, true);
        yield ")";
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "                ";
        yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml(CoreExtension::getAttribute($this->env, $this->source, ($context["release"] ?? null), "content", [], "any", false, false, false, 15));
        yield "
                <p>
                    <a class=\"btn btn-primary\" href=\"";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["release"] ?? null), "url", [], "any", false, false, false, 17), "html", null, true);
        yield "\" target=_blank\">Read more</a>
                </p>
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 30
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 30);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "File permissions";
        yield from [];
    }

    // line 32
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 33
        yield "            <p>
                If you see a warning icon <i class=\"";
        // line 34
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("warning", false), "html", null, true);
        yield " text-red\"></i> in the list below, you should talk to your administrator.
                The path is either not readable or not writable and Kimai might not work as expected.
            </p>
            <table class=\"table\">
                ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["directories"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 39
            yield "                    <tr>
                        <th style=\"width:15%\">";
            // line 40
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 42
            if (($context["value"] === false)) {
                // line 43
                yield "                                <i class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("warning", false), "html", null, true);
                yield " text-red\"></i>
                            ";
            } else {
                // line 45
                yield "                                <i class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
                yield " text-green\"></i>
                            ";
            }
            // line 47
            yield "                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 50
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 61
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 61);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 62
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "PHP extensions";
        yield from [];
    }

    // line 63
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 64
        yield "            <p>
                If you see a warning icon <i class=\"";
        // line 65
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("warning", false), "html", null, true);
        yield " text-red\"></i> in the list below, you should talk to your administrator, as there is a missing PHP extension causing Kimai not to work as expected.
            </p>
            <table class=\"table\">
                ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["extensions"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 69
            yield "                    <tr>
                        <th style=\"width:15%\">";
            // line 70
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
            yield "</th>
                        <td>
                            ";
            // line 72
            if (($context["value"] === false)) {
                // line 73
                yield "                                <i class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("warning", false), "html", null, true);
                yield " text-red\"></i>
                            ";
            } else {
                // line 75
                yield "                                <i class=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("success", false), "html", null, true);
                yield " text-green\"></i>
                            ";
            }
            // line 77
            yield "                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 80
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  561 => 80,  552 => 77,  546 => 75,  540 => 73,  538 => 72,  533 => 70,  530 => 69,  526 => 68,  520 => 65,  517 => 64,  510 => 63,  499 => 62,  488 => 61,  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 88
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 89
        $macros["_v3"] = $this->macros["_v3"] = $this->load("@theme/components/button.html.twig", 89)->unwrap();
        // line 88
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 88);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 90
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Logfile (max. ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["logLines"] ?? null), "html", null, true);
        yield " last lines)";
        yield from [];
    }

    // line 91
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 92
        yield "            ";
        if ((($context["logSize"] ?? null) > 52428800)) {
            // line 93
            yield "                <p>Your logfile is larger than 50 MB, consider deleting it (it will be re-created automatically).</p>
            ";
        }
        // line 95
        yield "            <pre>";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::reverse($this->env->getCharset(), ($context["logs"] ?? null)));
        foreach ($context['_seq'] as $context["_key"] => $context["logLine"]) {
            // line 96
            $context["logLineClass"] = "";
            // line 97
            if (CoreExtension::inFilter(".CRITICAL", $context["logLine"])) {
                // line 98
                $context["logLineClass"] = "text-danger text-bold";
            } elseif (CoreExtension::inFilter(".WARNING",             // line 99
$context["logLine"])) {
                // line 100
                $context["logLineClass"] = "text-warning text-bold";
            } elseif (CoreExtension::inFilter(".ERROR",             // line 101
$context["logLine"])) {
                // line 102
                $context["logLineClass"] = "text-warning text-bold";
            } elseif (CoreExtension::inFilter(".DEBUG",             // line 103
$context["logLine"])) {
                // line 104
                $context["logLineClass"] = "text-body-secondary";
            }
            // line 106
            yield "<span class=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["logLineClass"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["logLine"], "html", null, true);
            yield "</span>";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['logLine'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 107
        yield "</pre>
            ";
        // line 108
        if ((($tmp = ($context["log_delete"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 109
            yield "                ";
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["log_delete_form"] ?? null), 'form_start');
            yield "
                    <button type=\"submit\" class=\"btn btn-danger confirmation-link\" data-question=\"confirm.delete\">
                        ";
            // line 111
            yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("delete", true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("delete"), "html", null, true);
            yield "
                    </button>
                ";
            // line 113
            yield (string)             $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["log_delete_form"] ?? null), 'form_end');
            yield "
            ";
        }
        // line 115
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  720 => 115,  715 => 113,  708 => 111,  702 => 109,  700 => 108,  697 => 107,  686 => 106,  683 => 104,  681 => 103,  679 => 102,  677 => 101,  675 => 100,  673 => 99,  671 => 98,  669 => 97,  667 => 96,  662 => 95,  658 => 93,  655 => 92,  648 => 91,  635 => 90,  630 => 88,  628 => 89,  621 => 88,  561 => 80,  552 => 77,  546 => 75,  540 => 73,  538 => 72,  533 => 70,  530 => 69,  526 => 68,  520 => 65,  517 => 64,  510 => 63,  499 => 62,  488 => 61,  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___5 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body_class' => [$this, 'block_body_class'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 118
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 119
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 119)->unwrap();
        // line 118
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 118);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 120
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "Composer";
        yield from [];
    }

    // line 121
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "p-0";
        yield from [];
    }

    // line 122
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 123
        yield "            <table class=\"table table-hover\">
                ";
        // line 124
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["composer"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 125
            yield "                    <tr>
                        <th class=\"text-nowrap w-min\">";
            // line 126
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
            yield "</th>
                        <td class=\"text-break\">";
            // line 127
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
            yield "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 130
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  847 => 130,  837 => 127,  833 => 126,  830 => 125,  826 => 124,  823 => 123,  816 => 122,  805 => 121,  794 => 120,  789 => 118,  787 => 119,  780 => 118,  720 => 115,  715 => 113,  708 => 111,  702 => 109,  700 => 108,  697 => 107,  686 => 106,  683 => 104,  681 => 103,  679 => 102,  677 => 101,  675 => 100,  673 => 99,  671 => 98,  669 => 97,  667 => 96,  662 => 95,  658 => 93,  655 => 92,  648 => 91,  635 => 90,  630 => 88,  628 => 89,  621 => 88,  561 => 80,  552 => 77,  546 => 75,  540 => 73,  538 => 72,  533 => 70,  530 => 69,  526 => 68,  520 => 65,  517 => 64,  510 => 63,  499 => 62,  488 => 61,  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body_class' => [$this, 'block_body_class'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 134
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 134);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 135
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "PHP";
        yield from [];
    }

    // line 136
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "p-0";
        yield from [];
    }

    // line 137
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 138
        yield "            <table class=\"table table-hover\">
                <tr>
                    <th class=\"text-nowrap w-min\">";
        // line 140
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("version"), "html", null, true);
        yield "</th>
                    <td>";
        // line 141
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::constant("PHP_VERSION"), "html", null, true);
        yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Modules</th>
                    <td class=\"text-break\">";
        // line 145
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::join(($context["modules"] ?? null), ", "), "html", null, true);
        yield "</td>
                </tr>
                ";
        // line 147
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["settings"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 148
            yield "                    <tr>
                        <th class=\"text-nowrap w-min\">";
            // line 149
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
            yield "</th>
                        <td class=\"text-break\">
                            ";
            // line 151
            if (Twig\Extension\CoreExtension::testEmpty($context["value"])) {
                // line 152
                yield "                                <i>unknown</i>
                            ";
            } else {
                // line 154
                yield "                                ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["value"], "html", null, true);
                yield "
                            ";
            }
            // line 156
            yield "                        </td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 159
        yield "                ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["info"] ?? null));
        foreach ($context['_seq'] as $context["name"] => $context["value"]) {
            // line 160
            yield "                    <tr>
                        <th class=\"text-nowrap w-min\">";
            // line 161
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($context["name"], "html", null, true);
            yield "</th>
                        <td class=\"text-break\">";
            // line 162
            yield (string) $context["value"];
            yield "</td>
                    </tr>
                ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['name'], $context['value'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 165
        yield "            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1023 => 165,  1013 => 162,  1009 => 161,  1006 => 160,  1001 => 159,  992 => 156,  986 => 154,  982 => 152,  980 => 151,  975 => 149,  972 => 148,  968 => 147,  963 => 145,  956 => 141,  952 => 140,  948 => 138,  941 => 137,  930 => 136,  919 => 135,  908 => 134,  847 => 130,  837 => 127,  833 => 126,  830 => 125,  826 => 124,  823 => 123,  816 => 122,  805 => 121,  794 => 120,  789 => 118,  787 => 119,  780 => 118,  720 => 115,  715 => 113,  708 => 111,  702 => 109,  700 => 108,  697 => 107,  686 => 106,  683 => 104,  681 => 103,  679 => 102,  677 => 101,  675 => 100,  673 => 99,  671 => 98,  669 => 97,  667 => 96,  662 => 95,  658 => 93,  655 => 92,  648 => 91,  635 => 90,  630 => 88,  628 => 89,  621 => 88,  561 => 80,  552 => 77,  546 => 75,  540 => 73,  538 => 72,  533 => 70,  530 => 69,  526 => 68,  520 => 65,  517 => 64,  510 => 63,  499 => 62,  488 => 61,  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}


/* doctor/index.html.twig */
class __TwigTemplate_f98b56f5b67fe5a733dd1636be11774c___7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body_class' => [$this, 'block_body_class'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 171
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 171);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 172
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "OPCache";
        yield from [];
    }

    // line 173
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "p-0";
        yield from [];
    }

    // line 174
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 175
        yield "            ";
        $macros["widgets"] = $this->load("macros/widgets.html.twig", 175)->unwrap();
        // line 176
        yield "            ";
        if ((($tmp = ($context["opcache_warning"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 177
            yield "                ";
            if ((($tmp = (($_v4 = ($context["opcache"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["unknown"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 178
                yield "                    ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 178, $this->getSourceContext())->macro_alert(...["warning", "Could not detect OPCache status. Using shared hosting? Talk to your hoster to find out if it is activated."]);
                yield "
                ";
            } else {
                // line 180
                yield "                    ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 180, $this->getSourceContext())->macro_alert(...["danger", "Could not detect an active OPCache. This will significantly impact the performance of Kimai."]);
                yield "
                ";
            }
            // line 182
            yield "            ";
        }
        // line 183
        yield "            ";
        if (is_iterable((($_v5 = ($context["opcache"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["status"] ?? null) : null))) {
            // line 184
            yield "            <table class=\"table table-hover\">
                <tr>
                    <th class=\"text-nowrap w-min\">Opcache Enabled</th>
                    <td class=\"text-break\">";
            // line 187
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 187, $this->getSourceContext())->macro_label_boolean(...[(($_v6 = ($context["opcache"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["enabled"] ?? null) : null)]);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Opcache Full</th>
                    <td class=\"text-break\">";
            // line 191
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 191, $this->getSourceContext())->macro_label_boolean(...[(($_v7 = (($_v8 = ($context["opcache"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["status"] ?? null) : null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["cache_full"] ?? null) : null)]);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Memory Used</th>
                    <td class=\"text-break\">";
            // line 195
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v9 = (($_v10 = (($_v11 = ($context["opcache"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["status"] ?? null) : null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["memory_usage"] ?? null) : null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["used_memory"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Memory Free</th>
                    <td class=\"text-break\">";
            // line 199
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v12 = (($_v13 = (($_v14 = ($context["opcache"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["status"] ?? null) : null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["memory_usage"] ?? null) : null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["free_memory"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Interned-Strings Used</th>
                    <td class=\"text-break\">";
            // line 203
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v15 = (($_v16 = (($_v17 = ($context["opcache"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["status"] ?? null) : null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["interned_strings_usage"] ?? null) : null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["used_memory"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Interned-Strings Free</th>
                    <td class=\"text-break\">";
            // line 207
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v18 = (($_v19 = (($_v20 = ($context["opcache"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20["status"] ?? null) : null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["interned_strings_usage"] ?? null) : null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["free_memory"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Cached Scripts</th>
                    <td class=\"text-break\">";
            // line 211
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v21 = (($_v22 = (($_v23 = ($context["opcache"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23["status"] ?? null) : null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22["opcache_statistics"] ?? null) : null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21["num_cached_scripts"] ?? null) : null), "html", null, true);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Cached Keys</th>
                    <td class=\"text-break\">";
            // line 215
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v24 = (($_v25 = (($_v26 = ($context["opcache"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26["status"] ?? null) : null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25["opcache_statistics"] ?? null) : null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24["num_cached_keys"] ?? null) : null), "html", null, true);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Max Keys</th>
                    <td class=\"text-break\">";
            // line 219
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v27 = (($_v28 = (($_v29 = ($context["opcache"] ?? null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29["status"] ?? null) : null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28["opcache_statistics"] ?? null) : null)) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27["max_cached_keys"] ?? null) : null), "html", null, true);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Hit Rate</th>
                    <td class=\"text-break\">";
            // line 223
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((($_v30 = (($_v31 = (($_v32 = ($context["opcache"] ?? null)) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["status"] ?? null) : null)) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["opcache_statistics"] ?? null) : null)) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30["opcache_hit_rate"] ?? null) : null), 2), "html", null, true);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Jit enabled</th>
                    <td class=\"text-break\">";
            // line 227
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 227, $this->getSourceContext())->macro_label_boolean(...[(($_v33 = (($_v34 = (($_v35 = ($context["opcache"] ?? null)) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["status"] ?? null) : null)) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["jit"] ?? null) : null)) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["enabled"] ?? null) : null)]);
            yield "</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Buffer Size</th>
                    <td class=\"text-break\">";
            // line 231
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v36 = (($_v37 = (($_v38 = ($context["opcache"] ?? null)) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["status"] ?? null) : null)) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["jit"] ?? null) : null)) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["buffer_size"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
                <tr>
                    <th class=\"text-nowrap w-min\">Buffer Free</th>
                    <td class=\"text-break\">";
            // line 235
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extension\CoreExtension']->formatNumber((((($_v39 = (($_v40 = (($_v41 = ($context["opcache"] ?? null)) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41["status"] ?? null) : null)) && is_array($_v40) || $_v40 instanceof ArrayAccess ? ($_v40["jit"] ?? null) : null)) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39["buffer_free"] ?? null) : null) / 1024) / 1024), 2), "html", null, true);
            yield " MB</td>
                </tr>
            </table>
            ";
        }
        // line 239
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "doctor/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1247 => 239,  1240 => 235,  1233 => 231,  1226 => 227,  1219 => 223,  1212 => 219,  1205 => 215,  1198 => 211,  1191 => 207,  1184 => 203,  1177 => 199,  1170 => 195,  1163 => 191,  1156 => 187,  1151 => 184,  1148 => 183,  1145 => 182,  1139 => 180,  1133 => 178,  1130 => 177,  1127 => 176,  1124 => 175,  1117 => 174,  1106 => 173,  1095 => 172,  1084 => 171,  1023 => 165,  1013 => 162,  1009 => 161,  1006 => 160,  1001 => 159,  992 => 156,  986 => 154,  982 => 152,  980 => 151,  975 => 149,  972 => 148,  968 => 147,  963 => 145,  956 => 141,  952 => 140,  948 => 138,  941 => 137,  930 => 136,  919 => 135,  908 => 134,  847 => 130,  837 => 127,  833 => 126,  830 => 125,  826 => 124,  823 => 123,  816 => 122,  805 => 121,  794 => 120,  789 => 118,  787 => 119,  780 => 118,  720 => 115,  715 => 113,  708 => 111,  702 => 109,  700 => 108,  697 => 107,  686 => 106,  683 => 104,  681 => 103,  679 => 102,  677 => 101,  675 => 100,  673 => 99,  671 => 98,  669 => 97,  667 => 96,  662 => 95,  658 => 93,  655 => 92,  648 => 91,  635 => 90,  630 => 88,  628 => 89,  621 => 88,  561 => 80,  552 => 77,  546 => 75,  540 => 73,  538 => 72,  533 => 70,  530 => 69,  526 => 68,  520 => 65,  517 => 64,  510 => 63,  499 => 62,  488 => 61,  428 => 50,  419 => 47,  413 => 45,  407 => 43,  405 => 42,  400 => 40,  397 => 39,  393 => 38,  386 => 34,  383 => 33,  376 => 32,  365 => 31,  354 => 30,  292 => 17,  286 => 15,  279 => 14,  264 => 13,  253 => 12,  193 => 241,  190 => 171,  187 => 170,  185 => 169,  182 => 168,  180 => 134,  177 => 133,  175 => 118,  172 => 117,  169 => 88,  166 => 87,  163 => 86,  160 => 85,  158 => 84,  155 => 83,  153 => 61,  150 => 60,  143 => 59,  140 => 58,  137 => 57,  134 => 56,  129 => 55,  127 => 54,  124 => 53,  122 => 30,  119 => 29,  112 => 28,  109 => 27,  106 => 26,  103 => 25,  98 => 24,  96 => 23,  93 => 22,  90 => 21,  87 => 12,  85 => 11,  82 => 10,  75 => 9,  68 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "doctor/index.html.twig", "/opt/kimai/templates/doctor/index.html.twig");
    }
}
