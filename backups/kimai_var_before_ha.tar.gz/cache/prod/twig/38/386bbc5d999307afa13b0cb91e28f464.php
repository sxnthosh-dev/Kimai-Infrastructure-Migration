<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/listing.html.twig */
class __TwigTemplate_32ec35814a8d3124a6ca0a6966061aff extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row' => [$this, 'block_datatable_row'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 4
        $macros["actions"] = $this->macros["actions"] = $this->load("invoice/actions.html.twig", 4)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        yield "    <tr class=\"modal-ajax-form open-edit";
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "canceled", [], "any", false, false, false, 7)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " text-body-secondary";
        }
        yield "\" data-href=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_invoice_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 7)]), "html", null, true);
        yield "\">
        <td class=\"";
        // line 8
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 8, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "avatar"]);
        yield "\">";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 8, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "user", [], "any", false, false, false, 8)]);
        yield "</td>
        <td class=\"";
        // line 9
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 9, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "date"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "createdAt", [], "any", false, false, false, 9)), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 10
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 10, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "user"]);
        yield "\">";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_user", $context, 10, $this->getSourceContext())->macro_label_user(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "user", [], "any", false, false, false, 10)]);
        yield "</td>
        <td class=\"";
        // line 11
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 11, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "customer"]);
        yield "\">";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_customer", $context, 11, $this->getSourceContext())->macro_label_customer(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "customer", [], "any", false, false, false, 11)]);
        yield "</td>
        <td class=\"";
        // line 12
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 12, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "comment"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "comment", [], "any", false, false, false, 12), "html", null, true);
        yield "</td>
        ";
        // line 13
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["metaColumns"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 14
            yield "            <td class=\"";
            yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 14, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), ("mf_" . CoreExtension::getAttribute($this->env, $this->source, $context["field"], "name", [], "any", false, false, false, 14))]);
            yield "\">
                ";
            // line 15
            yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_meta_column", $context, 15, $this->getSourceContext())->macro_datatable_meta_column(...[($context["entry"] ?? null), $context["field"]]);
            yield "
            </td>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 18
        yield "        <td class=\"";
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 18, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "invoice_number"]);
        yield "\">";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_label", $context, 18, $this->getSourceContext())->macro_label(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "invoiceNumber", [], "any", false, false, false, 18), "default"]);
        yield "</td>
        <td class=\"";
        // line 19
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 19, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "due_date"]);
        yield "\">";
        yield (string) $this->getTemplateForMacro("macro_invoice_due_date", $context, 19, $this->getSourceContext())->macro_invoice_due_date(...[($context["entry"] ?? null)]);
        yield "</td>
        <td class=\"";
        // line 20
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 20, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "payment_date"]);
        yield "\">
            ";
        // line 21
        if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "paymentDate", [], "any", false, false, false, 21)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "paid", [], "any", false, false, false, 21)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 22
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label", $context, 22, $this->getSourceContext())->macro_label(...[$this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "paymentDate", [], "any", false, false, false, 22)), "primary"]);
            yield "
            ";
        }
        // line 24
        yield "        </td>
        <td class=\"";
        // line 25
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 25, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "status"]);
        yield "\">";
        yield (string) $this->getTemplateForMacro("macro_invoice_status", $context, 25, $this->getSourceContext())->macro_invoice_status(...[($context["entry"] ?? null)]);
        yield "</td>
        <td class=\"";
        // line 26
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 26, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "subtotal"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "subtotal", [], "any", false, false, false, 26), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "currency", [], "any", false, false, false, 26)), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 27
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 27, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "tax"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "tax", [], "any", false, false, false, 27), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "currency", [], "any", false, false, false, 27)), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 28
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 28, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "total_rate"]);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "total", [], "any", false, false, false, 28), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "currency", [], "any", false, false, false, 28)), "html", null, true);
        yield "</td>
        <td class=\"";
        // line 29
        yield (string) $macros["tables"]->getTemplateForMacro("macro_class", $context, 29, $this->getSourceContext())->macro_class(...[($context["dataTable"] ?? null), "actions"]);
        yield "\">";
        yield (string) $macros["actions"]->getTemplateForMacro("macro_invoice", $context, 29, $this->getSourceContext())->macro_invoice(...[($context["entry"] ?? null), "index"]);
        yield "</td>
    </tr>
";
        yield from [];
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 34
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <div style=\"display: none\" id=\"status-token\" data-value=\"";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderCsrfToken("invoice.status"), "html", null, true);
        yield "\"></div>
    <script>
        function kimaiInvoiceStatus(link)
        {
            const form = document.createElement(\x27form\x27);
            form.method = \x27post\x27;
            form.action = link.dataset[\x27href\x27];

            const token = document.createElement(\x27input\x27);
            token.type = \x27hidden\x27;
            token.name = \x27_token\x27;
            token.value = document.getElementById(\x27status-token\x27).dataset[\x27value\x27];
            form.appendChild(token);

            document.body.appendChild(form);
            form.submit();

            return false;
        }

        ";
        // line 55
        if ( !(null === ($context["download"] ?? null))) {
            // line 56
            yield "        document.addEventListener(\x27kimai.initialized\x27, function() {
            location.href = \x27";
            // line 57
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_invoice_download", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["download"] ?? null), "id", [], "any", false, false, false, 57)]), "html", null, true);
            yield "\x27;
        });
        ";
        }
        // line 60
        yield "    </script>
";
        yield from [];
    }

    // line 63
    public function macro_invoice_status($invoice = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "invoice" => $invoice,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 64
            yield "    ";
            $macros["_v0"] = $this->load("macros/widgets.html.twig", 64)->unwrap();
            // line 65
            yield "    ";
            $context["overdue"] = CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "overdue", [], "any", false, false, false, 65);
            // line 66
            yield "    ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "new", [], "any", false, false, false, 66)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["overdue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 67
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 67, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.new"), "danger"]);
                yield "
    ";
            } elseif ((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 68
($context["invoice"] ?? null), "new", [], "any", false, false, false, 68)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 69
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 69, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.new"), "primary"]);
                yield "
    ";
            } elseif (((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 70
($context["invoice"] ?? null), "pending", [], "any", false, false, false, 70)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = ($context["overdue"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 71
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 71, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.pending"), "danger"]);
                yield "
    ";
            } elseif ((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 72
($context["invoice"] ?? null), "pending", [], "any", false, false, false, 72)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 73
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 73, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.pending"), "warning"]);
                yield "
    ";
            } elseif ((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 74
($context["invoice"] ?? null), "paid", [], "any", false, false, false, 74)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 75
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 75, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.paid"), "success"]);
                yield "
    ";
            } elseif ((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 76
($context["invoice"] ?? null), "canceled", [], "any", false, false, false, 76)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 77
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_label", $context, 77, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.canceled"), "gray"]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 81
    public function macro_invoice_due_date($invoice = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "invoice" => $invoice,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 82
            yield "    ";
            $macros["_v1"] = $this->load("macros/widgets.html.twig", 82)->unwrap();
            // line 83
            yield "    ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "canceled", [], "any", false, false, false, 83)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 84
                yield "        ";
                yield (string) $macros["_v1"]->getTemplateForMacro("macro_label", $context, 84, $this->getSourceContext())->macro_label(...[$this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.canceled"), "gray"]);
                yield "
    ";
            } elseif (((($tmp = CoreExtension::getAttribute($this->env, $this->source,             // line 85
($context["invoice"] ?? null), "overdue", [], "any", false, false, false, 85)) && $tmp instanceof Markup ? (string) $tmp : $tmp) &&  !(($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "paid", [], "any", false, false, false, 85)) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 86
                yield "        ";
                yield (string) $macros["_v1"]->getTemplateForMacro("macro_label", $context, 86, $this->getSourceContext())->macro_label(...[$this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "dueDate", [], "any", false, false, false, 86)), "danger"]);
                yield "
    ";
            } else {
                // line 88
                yield "        ";
                yield (string) $macros["_v1"]->getTemplateForMacro("macro_label", $context, 88, $this->getSourceContext())->macro_label(...[$this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "dueDate", [], "any", false, false, false, 88)), "primary"]);
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/listing.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  336 => 88,  330 => 86,  328 => 85,  323 => 84,  320 => 83,  317 => 82,  305 => 81,  295 => 77,  293 => 76,  288 => 75,  286 => 74,  281 => 73,  279 => 72,  274 => 71,  272 => 70,  267 => 69,  265 => 68,  260 => 67,  257 => 66,  254 => 65,  251 => 64,  239 => 63,  233 => 60,  227 => 57,  224 => 56,  222 => 55,  199 => 35,  194 => 34,  187 => 33,  177 => 29,  171 => 28,  165 => 27,  159 => 26,  153 => 25,  150 => 24,  144 => 22,  142 => 21,  138 => 20,  132 => 19,  125 => 18,  115 => 15,  110 => 14,  106 => 13,  100 => 12,  94 => 11,  88 => 10,  82 => 9,  76 => 8,  67 => 7,  60 => 6,  55 => 1,  53 => 4,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/listing.html.twig", "/opt/kimai/templates/invoice/listing.html.twig");
    }
}
