<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/user_list_period_data.html.twig */
class __TwigTemplate_8f402a4aa60d0288af7976420b7c2fb1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'period_name' => [$this, 'block_period_name'],
            'user_column_cell_attribute' => [$this, 'block_user_column_cell_attribute'],
            'user_total_cell_class' => [$this, 'block_user_total_cell_class'],
            'user_total_cell_attribute' => [$this, 'block_user_total_cell_attribute'],
            'total_rate_user' => [$this, 'block_total_rate_user'],
            'total_internal_rate_user' => [$this, 'block_total_internal_rate_user'],
            'total_duration_user' => [$this, 'block_total_duration_user'],
            'period_cell_class' => [$this, 'block_period_cell_class'],
            'period_cell_attribute' => [$this, 'block_period_cell_attribute'],
            'rate' => [$this, 'block_rate'],
            'internal_rate' => [$this, 'block_internal_rate'],
            'duration' => [$this, 'block_duration'],
            'total_period_cell_class' => [$this, 'block_total_period_cell_class'],
            'total_period_cell_attribute' => [$this, 'block_total_period_cell_attribute'],
            'total_rate' => [$this, 'block_total_rate'],
            'total_internal_rate' => [$this, 'block_total_internal_rate'],
            'total_duration' => [$this, 'block_total_duration'],
            'total_rate_period_cell_class' => [$this, 'block_total_rate_period_cell_class'],
            'total_rate_period_cell_attribute' => [$this, 'block_total_rate_period_cell_attribute'],
            'total_rate_period' => [$this, 'block_total_rate_period'],
            'total_internal_rate_period_cell_class' => [$this, 'block_total_internal_rate_period_cell_class'],
            'total_internal_rate_period_cell_attribute' => [$this, 'block_total_internal_rate_period_cell_attribute'],
            'total_internal_rate_period' => [$this, 'block_total_internal_rate_period'],
            'total_duration_period_cell_class' => [$this, 'block_total_duration_period_cell_class'],
            'total_duration_period_cell_attribute' => [$this, 'block_total_duration_period_cell_attribute'],
            'total_duration_period' => [$this, 'block_total_duration_period'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["with_avatar"] = ((array_key_exists("avatar", $context)) ? (($context["avatar"] ?? null)) : (true));
        // line 2
        $context["show_empty_rows"] = true;
        // line 3
        $context["absoluteDuration"] = 0;
        // line 4
        $context["absoluteInternalRate"] = 0;
        // line 5
        $context["absoluteRate"] = 0;
        // line 6
        $context["totalsDuration"] = [];
        // line 7
        $context["totalsInternalRate"] = [];
        // line 8
        $context["totalsRate"] = [];
        // line 9
        $context["showAccountNumber"] = ((array_key_exists("showAccountNumber", $context)) ? (($context["showAccountNumber"] ?? null)) : (false));
        // line 10
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 11
            yield "    ";
            $context["dataTypeTitle"] = "stats.amountTotal";
        } elseif ((        // line 12
($context["dataType"] ?? null) == "internalRate")) {
            // line 13
            yield "    ";
            $context["dataTypeTitle"] = "internalRate";
        } else {
            // line 15
            yield "    ";
            $context["dataTypeTitle"] = "stats.durationTotal";
        }
        // line 17
        yield "<table class=\"table table-hover dataTable\">
    <thead>
        <tr>
            ";
        // line 20
        if ((($tmp = ($context["with_avatar"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 21
            yield "            <th class=\"w-avatar\"></th>
            ";
        }
        // line 23
        yield "            <th>&nbsp;</th>
            ";
        // line 24
        if ((($tmp = ($context["showAccountNumber"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 25
            yield "            <th>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("account_number"), "html", null, true);
            yield "</th>
            ";
        }
        // line 27
        yield "            <th class=\"text-center reportDataTypeTitle\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
        yield "</th>
            ";
        // line 28
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["stats"] ?? null), 0, [], "any", false, false, false, 28), "getDateTimes", [], "method", false, false, false, 28));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["column"]) {
            // line 29
            yield "                ";
            yield from $this->unwrap()->yieldBlock('period_name', $context, $blocks);
            // line 30
            yield "                ";
            $context["columnKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate($context["column"]);
            // line 31
            yield "                ";
            $context["totalsDuration"] = Twig\Extension\CoreExtension::merge(($context["totalsDuration"] ?? null), [ (string)($context["columnKey"] ?? null) => 0]);
            // line 32
            yield "                ";
            $context["totalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["totalsInternalRate"] ?? null), [ (string)($context["columnKey"] ?? null) => 0]);
            // line 33
            yield "                ";
            $context["totalsRate"] = Twig\Extension\CoreExtension::merge(($context["totalsRate"] ?? null), [ (string)($context["columnKey"] ?? null) => 0]);
            // line 34
            yield "            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['column'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 35
        yield "        </tr>
    </thead>
    <tbody>
    ";
        // line 38
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["stats"] ?? null), function ($__row__) use ($context, $macros) { $context["row"] = $__row__; return  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["row"] ?? null), "user", [], "any", false, false, false, 38)); }), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "user", [], "any", false, false, false, 38), "displayName", [], "any", false, false, false, 38)) <=> Twig\Extension\CoreExtension::lower($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "user", [], "any", false, false, false, 38), "displayName", [], "any", false, false, false, 38))); }));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["userPeriod"]) {
            // line 39
            yield "        ";
            $context["usersTotalDuration"] = 0;
            // line 40
            yield "        ";
            $context["usersTotalInternalRate"] = 0;
            // line 41
            yield "        ";
            $context["usersTotalRate"] = 0;
            // line 42
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "data", [], "any", false, false, false, 42));
            foreach ($context['_seq'] as $context["_key"] => $context["period"]) {
                // line 43
                yield "            ";
                $context["usersTotalDuration"] = (($context["usersTotalDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalDuration", [], "any", false, false, false, 43));
                // line 44
                yield "            ";
                $context["absoluteDuration"] = (($context["absoluteDuration"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalDuration", [], "any", false, false, false, 44));
                // line 45
                yield "            ";
                $context["usersTotalInternalRate"] = (($context["usersTotalInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalInternalRate", [], "any", false, false, false, 45));
                // line 46
                yield "            ";
                $context["absoluteInternalRate"] = (($context["absoluteInternalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalInternalRate", [], "any", false, false, false, 46));
                // line 47
                yield "            ";
                $context["usersTotalRate"] = (($context["usersTotalRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalRate", [], "any", false, false, false, 47));
                // line 48
                yield "            ";
                $context["absoluteRate"] = (($context["absoluteRate"] ?? null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalRate", [], "any", false, false, false, 48));
                // line 49
                yield "            ";
                $context["reportDateKey"] = $this->extensions['App\Twig\Extensions']->formatReportDate(CoreExtension::getAttribute($this->env, $this->source, $context["period"], "date", [], "any", false, false, false, 49));
                // line 50
                yield "            ";
                $context["totalsDuration"] = Twig\Extension\CoreExtension::merge(($context["totalsDuration"] ?? null), [ (string)($context["reportDateKey"] ?? null) => ((($_v0 = ($context["totalsDuration"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = ($context["reportDateKey"] ?? null)) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalDuration", [], "any", false, false, false, 50))]);
                // line 51
                yield "            ";
                $context["totalsInternalRate"] = Twig\Extension\CoreExtension::merge(($context["totalsInternalRate"] ?? null), [ (string)($context["reportDateKey"] ?? null) => ((($_v2 = ($context["totalsInternalRate"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2[(($_v3 = ($context["reportDateKey"] ?? null)) instanceof \Stringable ? (string) $_v3 : $_v3)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalInternalRate", [], "any", false, false, false, 51))]);
                // line 52
                yield "            ";
                $context["totalsRate"] = Twig\Extension\CoreExtension::merge(($context["totalsRate"] ?? null), [ (string)($context["reportDateKey"] ?? null) => ((($_v4 = ($context["totalsRate"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4[(($_v5 = ($context["reportDateKey"] ?? null)) instanceof \Stringable ? (string) $_v5 : $_v5)] ?? null) : null) + CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalRate", [], "any", false, false, false, 52))]);
                // line 53
                yield "        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['period'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 54
            yield "        ";
            if ((((($tmp = ($context["show_empty_rows"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "user", [], "any", false, false, false, 54), "enabled", [], "any", false, false, false, 54)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) || (($context["usersTotalDuration"] ?? null) != 0))) {
                // line 55
                yield "        <tr class=\"user\">
            ";
                // line 56
                if ((($tmp = ($context["with_avatar"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 57
                    yield "                <td class=\"w-avatar\">
                    ";
                    // line 58
                    $macros["_v6"] = $this->macros["_v6"] = $this->load("macros/widgets.html.twig", 58)->unwrap();
                    // line 59
                    yield "                    ";
                    yield (string) $macros["_v6"]->getTemplateForMacro("macro_user_avatar", $context, 59, $this->getSourceContext())->macro_user_avatar(...[CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "user", [], "any", false, false, false, 59)]);
                    yield "
                </td>
            ";
                }
                // line 62
                yield "            <td class=\"text-nowrap\"";
                yield from $this->unwrap()->yieldBlock('user_column_cell_attribute', $context, $blocks);
                yield ">
                ";
                // line 63
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(App\Utils\StringHelper::sanitizeDDE(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "user", [], "any", false, false, false, 63), "displayName", [], "any", false, false, false, 63)), "html", null, true);
                yield "
            </td>
            ";
                // line 65
                if ((($tmp = ($context["showAccountNumber"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                    // line 66
                    yield "                <td>";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "user", [], "any", false, false, false, 66), "accountNumber", [], "any", false, false, false, 66), "html", null, true);
                    yield "</td>
            ";
                }
                // line 68
                yield "            <td class=\"text-nowrap text-center total";
                yield from $this->unwrap()->yieldBlock('user_total_cell_class', $context, $blocks);
                yield "\"";
                yield from $this->unwrap()->yieldBlock('user_total_cell_attribute', $context, $blocks);
                yield ">
                ";
                // line 69
                if ((($context["dataType"] ?? null) == "rate")) {
                    // line 70
                    yield "                    ";
                    yield from $this->unwrap()->yieldBlock('total_rate_user', $context, $blocks);
                    // line 71
                    yield "                ";
                } elseif ((($context["dataType"] ?? null) == "internalRate")) {
                    // line 72
                    yield "                    ";
                    yield from $this->unwrap()->yieldBlock('total_internal_rate_user', $context, $blocks);
                    // line 73
                    yield "                ";
                } else {
                    // line 74
                    yield "                    ";
                    yield from $this->unwrap()->yieldBlock('total_duration_user', $context, $blocks);
                    // line 75
                    yield "                ";
                }
                // line 76
                yield "            </td>
            ";
                // line 77
                $context['_parent'] = $context;
                $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["userPeriod"], "data", [], "any", false, false, false, 77));
                $context['loop'] = [
                  'parent' => $context['_parent'],
                  'index0' => 0,
                  'index'  => 1,
                  'first'  => true,
                ];
                if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                    $length = count($context['_seq']);
                    $context['loop']['revindex0'] = $length - 1;
                    $context['loop']['revindex'] = $length;
                    $context['loop']['length'] = $length;
                    $context['loop']['last'] = 1 === $length;
                }
                foreach ($context['_seq'] as $context["_key"] => $context["period"]) {
                    // line 78
                    yield "                <td class=\"text-nowrap text-center day-total";
                    yield from $this->unwrap()->yieldBlock('period_cell_class', $context, $blocks);
                    yield "\"";
                    yield from $this->unwrap()->yieldBlock('period_cell_attribute', $context, $blocks);
                    yield ">
                    ";
                    // line 79
                    if ((((CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalDuration", [], "any", false, false, false, 79) != 0) || (CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalRate", [], "any", false, false, false, 79) != 0)) || (CoreExtension::getAttribute($this->env, $this->source, $context["period"], "totalInternalRate", [], "any", false, false, false, 79) != 0))) {
                        // line 80
                        yield "                        ";
                        if ((($context["dataType"] ?? null) == "rate")) {
                            // line 81
                            yield "                            ";
                            yield from $this->unwrap()->yieldBlock('rate', $context, $blocks);
                            // line 82
                            yield "                        ";
                        } elseif ((($context["dataType"] ?? null) == "internalRate")) {
                            // line 83
                            yield "                            ";
                            yield from $this->unwrap()->yieldBlock('internal_rate', $context, $blocks);
                            // line 84
                            yield "                        ";
                        } else {
                            // line 85
                            yield "                            ";
                            yield from $this->unwrap()->yieldBlock('duration', $context, $blocks);
                            // line 86
                            yield "                        ";
                        }
                        // line 87
                        yield "                    ";
                    }
                    // line 88
                    yield "                </td>
            ";
                    ++$context['loop']['index0'];
                    ++$context['loop']['index'];
                    $context['loop']['first'] = false;
                    if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                        --$context['loop']['revindex0'];
                        --$context['loop']['revindex'];
                        $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                    }
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_key'], $context['period'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent);
                $context += $_parent;
                // line 90
                yield "        </tr>
        ";
            }
            // line 92
            yield "    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['userPeriod'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 93
        yield "    </tbody>
    <tfoot>
        <tr class=\"summary\">
            <td";
        // line 96
        if ((($tmp = ($context["with_avatar"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " colspan=\"2\"";
        }
        yield ">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["dataTypeTitle"] ?? null)), "html", null, true);
        yield "</td>
            ";
        // line 97
        if ((($tmp = ($context["showAccountNumber"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 98
            yield "                <td></td>
            ";
        }
        // line 100
        yield "            <td class=\"text-center text-nowrap";
        yield from $this->unwrap()->yieldBlock('total_period_cell_class', $context, $blocks);
        yield "\"";
        yield from $this->unwrap()->yieldBlock('total_period_cell_attribute', $context, $blocks);
        yield ">
                ";
        // line 101
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 102
            yield "                    ";
            yield from $this->unwrap()->yieldBlock('total_rate', $context, $blocks);
            // line 105
            yield "                ";
        } elseif ((($context["dataType"] ?? null) == "internalRate")) {
            // line 106
            yield "                    ";
            yield from $this->unwrap()->yieldBlock('total_internal_rate', $context, $blocks);
            // line 109
            yield "                ";
        } else {
            // line 110
            yield "                    ";
            yield from $this->unwrap()->yieldBlock('total_duration', $context, $blocks);
            // line 113
            yield "                ";
        }
        // line 114
        yield "            </td>
            ";
        // line 115
        if ((($context["dataType"] ?? null) == "rate")) {
            // line 116
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["totalsRate"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["id"] => $context["total"]) {
                // line 117
                yield "                    <td class=\"text-center text-nowrap";
                yield from $this->unwrap()->yieldBlock('total_rate_period_cell_class', $context, $blocks);
                yield "\"";
                yield from $this->unwrap()->yieldBlock('total_rate_period_cell_attribute', $context, $blocks);
                yield ">
                        ";
                // line 118
                yield from $this->unwrap()->yieldBlock('total_rate_period', $context, $blocks);
                // line 121
                yield "                    </td>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['total'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 123
            yield "            ";
        } elseif ((($context["dataType"] ?? null) == "internalRate")) {
            // line 124
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["totalsInternalRate"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["id"] => $context["total"]) {
                // line 125
                yield "                    <td class=\"text-center text-nowrap";
                yield from $this->unwrap()->yieldBlock('total_internal_rate_period_cell_class', $context, $blocks);
                yield "\"";
                yield from $this->unwrap()->yieldBlock('total_internal_rate_period_cell_attribute', $context, $blocks);
                yield ">
                        ";
                // line 126
                yield from $this->unwrap()->yieldBlock('total_internal_rate_period', $context, $blocks);
                // line 129
                yield "                    </td>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['total'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 131
            yield "            ";
        } else {
            // line 132
            yield "                ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["totalsDuration"] ?? null));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["id"] => $context["total"]) {
                // line 133
                yield "                    <td class=\"text-center text-nowrap";
                yield from $this->unwrap()->yieldBlock('total_duration_period_cell_class', $context, $blocks);
                yield "\"";
                yield from $this->unwrap()->yieldBlock('total_duration_period_cell_attribute', $context, $blocks);
                yield ">
                        ";
                // line 134
                yield from $this->unwrap()->yieldBlock('total_duration_period', $context, $blocks);
                // line 137
                yield "                    </td>
                ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['id'], $context['total'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 139
            yield "            ";
        }
        // line 140
        yield "        </tr>
    </tfoot>
</table>
";
        yield from [];
    }

    // line 29
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_name(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 62
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_column_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 68
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_total_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_total_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 70
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 74
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_user(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 78
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_period_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 81
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 83
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 85
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 100
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_period_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 102
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 103
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["absoluteRate"] ?? null)), "html", null, true);
        yield "
                    ";
        yield from [];
    }

    // line 106
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 107
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["absoluteInternalRate"] ?? null)), "html", null, true);
        yield "
                    ";
        yield from [];
    }

    // line 110
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 111
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["absoluteDuration"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "
                    ";
        yield from [];
    }

    // line 117
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_period_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 118
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_rate_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 119
        yield "                            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["total"] ?? null)), "html", null, true);
        yield "
                        ";
        yield from [];
    }

    // line 125
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_period_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 126
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_internal_rate_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 127
        yield "                            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["total"] ?? null)), "html", null, true);
        yield "
                        ";
        yield from [];
    }

    // line 133
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_period_cell_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_period_cell_attribute(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 134
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_total_duration_period(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 135
        yield "                            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["total"] ?? null), ($context["decimal"] ?? null)), "html", null, true);
        yield "
                        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/user_list_period_data.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  875 => 135,  868 => 134,  849 => 133,  841 => 127,  834 => 126,  815 => 125,  807 => 119,  800 => 118,  781 => 117,  773 => 111,  766 => 110,  758 => 107,  751 => 106,  743 => 103,  736 => 102,  717 => 100,  707 => 85,  697 => 83,  687 => 81,  668 => 78,  658 => 74,  648 => 72,  638 => 70,  619 => 68,  609 => 62,  599 => 29,  591 => 140,  588 => 139,  572 => 137,  570 => 134,  563 => 133,  545 => 132,  542 => 131,  526 => 129,  524 => 126,  517 => 125,  499 => 124,  496 => 123,  480 => 121,  478 => 118,  471 => 117,  453 => 116,  451 => 115,  448 => 114,  445 => 113,  442 => 110,  439 => 109,  436 => 106,  433 => 105,  430 => 102,  428 => 101,  421 => 100,  417 => 98,  415 => 97,  407 => 96,  402 => 93,  387 => 92,  383 => 90,  367 => 88,  364 => 87,  361 => 86,  358 => 85,  355 => 84,  352 => 83,  349 => 82,  346 => 81,  343 => 80,  341 => 79,  334 => 78,  317 => 77,  314 => 76,  311 => 75,  308 => 74,  305 => 73,  302 => 72,  299 => 71,  296 => 70,  294 => 69,  287 => 68,  281 => 66,  279 => 65,  274 => 63,  269 => 62,  262 => 59,  260 => 58,  257 => 57,  255 => 56,  252 => 55,  249 => 54,  242 => 53,  239 => 52,  236 => 51,  233 => 50,  230 => 49,  227 => 48,  224 => 47,  221 => 46,  218 => 45,  215 => 44,  212 => 43,  207 => 42,  204 => 41,  201 => 40,  198 => 39,  181 => 38,  176 => 35,  161 => 34,  158 => 33,  155 => 32,  152 => 31,  149 => 30,  146 => 29,  129 => 28,  124 => 27,  118 => 25,  116 => 24,  113 => 23,  109 => 21,  107 => 20,  102 => 17,  98 => 15,  94 => 13,  92 => 12,  89 => 11,  87 => 10,  85 => 9,  83 => 8,  81 => 7,  79 => 6,  77 => 5,  75 => 4,  73 => 3,  71 => 2,  69 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/user_list_period_data.html.twig", "/opt/kimai/templates/reporting/user_list_period_data.html.twig");
    }
}
