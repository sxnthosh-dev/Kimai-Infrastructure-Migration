<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* customer/index.html.twig */
class __TwigTemplate_d39965d0c464f704dc819c9e8fa61fd7 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["actions"] = $this->macros["actions"] = $this->load("customer/actions.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_customer_row_attr", $context, 5, $this->getSourceContext())->macro_customer_row_attr(...[($context["entry"] ?? null), ($context["now"] ?? null)]);
        yield from [];
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 8
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 9
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_name", $context, 9, $this->getSourceContext())->macro_label_name(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 9), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 9))]);
            yield "
    ";
        } elseif ((        // line 10
($context["column"] ?? null) == "comment")) {
            // line 11
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentOneLiner($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "comment", [], "any", false, false, false, 11), "html", null, true));
            yield "
    ";
        } elseif ((        // line 12
($context["column"] ?? null) == "number")) {
            // line 13
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "number", [], "any", false, false, false, 13), "html", null, true);
            yield "
    ";
        } elseif ((        // line 14
($context["column"] ?? null) == "company")) {
            // line 15
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "company", [], "any", false, false, false, 15), "html", null, true);
            yield "
    ";
        } elseif ((        // line 16
($context["column"] ?? null) == "vat_id")) {
            // line 17
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "vatId", [], "any", false, false, false, 17), "html", null, true);
            yield "
    ";
        } elseif ((        // line 18
($context["column"] ?? null) == "contact")) {
            // line 19
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "contact", [], "any", false, false, false, 19), "html", null, true);
            yield "
    ";
        } elseif ((        // line 20
($context["column"] ?? null) == "city")) {
            // line 21
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "postcode", [], "any", false, false, false, 21), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "city", [], "any", false, false, false, 21), "html", null, true);
            yield "
    ";
        } elseif ((        // line 22
($context["column"] ?? null) == "country")) {
            // line 23
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "country", [], "any", false, false, false, 23)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 24
($context["column"] ?? null) == "language")) {
            // line 25
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getLocaleName(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "language", [], "any", false, false, false, 25)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 26
($context["column"] ?? null) == "currency")) {
            // line 27
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Twig\Extra\Intl\IntlExtension']->getCurrencyName(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "currency", [], "any", false, false, false, 27)), "html", null, true);
            yield "
    ";
        } elseif ((        // line 28
($context["column"] ?? null) == "phone")) {
            // line 29
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "phone", [], "any", false, false, false, 29), "html", null, true);
            yield "
    ";
        } elseif ((        // line 30
($context["column"] ?? null) == "fax")) {
            // line 31
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "fax", [], "any", false, false, false, 31), "html", null, true);
            yield "
    ";
        } elseif ((        // line 32
($context["column"] ?? null) == "mobile")) {
            // line 33
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "mobile", [], "any", false, false, false, 33), "html", null, true);
            yield "
    ";
        } elseif ((        // line 34
($context["column"] ?? null) == "email")) {
            // line 35
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "email", [], "any", false, false, false, 35), "html", null, true);
            yield "
    ";
        } elseif ((        // line 36
($context["column"] ?? null) == "homepage")) {
            // line 37
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "homepage", [], "any", false, false, false, 37), "html", null, true);
            yield "
    ";
        } elseif ((        // line 38
($context["column"] ?? null) == "invoice_email")) {
            // line 39
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "invoiceEmail", [], "any", false, false, false, 39), "html", null, true);
            yield "
    ";
        } elseif ((        // line 40
($context["column"] ?? null) == "budget")) {
            // line 41
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasBudget", [], "method", false, false, false, 41)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("budget", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 42
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "budget", [], "any", false, false, false, 42), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "currency", [], "any", false, false, false, 42)), "html", null, true);
                yield "
        ";
            } else {
                // line 44
                yield "            &ndash;
        ";
            }
            // line 46
            yield "    ";
        } elseif ((($context["column"] ?? null) == "timeBudget")) {
            // line 47
            yield "        ";
            if (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hasTimeBudget", [], "method", false, false, false, 47)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("time", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
                // line 48
                yield "            ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "timeBudget", [], "any", false, false, false, 48)), "html", null, true);
                yield "
        ";
            } else {
                // line 50
                yield "            &ndash;
        ";
            }
            // line 52
            yield "    ";
        } elseif ((($context["column"] ?? null) == "billable")) {
            // line 53
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 53, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "billable", [], "any", false, false, false, 53)]);
            yield "
    ";
        } elseif ((        // line 54
($context["column"] ?? null) == "team")) {
            // line 55
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 55, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "teams", [], "any", false, false, false, 55)]);
            yield "
    ";
        } elseif ((        // line 56
($context["column"] ?? null) == "visible")) {
            // line 57
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 57, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "visible", [], "any", false, false, false, 57)]);
            yield "
    ";
        } elseif ((        // line 58
($context["column"] ?? null) == "actions")) {
            // line 59
            yield "        ";
            yield (string) $macros["actions"]->getTemplateForMacro("macro_customer", $context, 59, $this->getSourceContext())->macro_customer(...[($context["entry"] ?? null), "index"]);
            yield "
    ";
        } elseif ((is_string($_v0 =         // line 60
($context["column"] ?? null)) && is_string($_v1 = "mf_") && str_starts_with($_v0, $_v1))) {
            // line 61
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_meta_field_value", $context, 61, $this->getSourceContext())->macro_meta_field_value(...[($context["entry"] ?? null), ($context["data"] ?? null)]);
            yield "
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "customer/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  254 => 61,  252 => 60,  247 => 59,  245 => 58,  240 => 57,  238 => 56,  233 => 55,  231 => 54,  226 => 53,  223 => 52,  219 => 50,  213 => 48,  210 => 47,  207 => 46,  203 => 44,  197 => 42,  194 => 41,  192 => 40,  187 => 39,  185 => 38,  180 => 37,  178 => 36,  173 => 35,  171 => 34,  166 => 33,  164 => 32,  159 => 31,  157 => 30,  152 => 29,  150 => 28,  145 => 27,  143 => 26,  138 => 25,  136 => 24,  131 => 23,  129 => 22,  122 => 21,  120 => 20,  115 => 19,  113 => 18,  108 => 17,  106 => 16,  101 => 15,  99 => 14,  94 => 13,  92 => 12,  87 => 11,  85 => 10,  80 => 9,  77 => 8,  70 => 7,  58 => 5,  53 => 1,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "customer/index.html.twig", "/opt/kimai/templates/customer/index.html.twig");
    }
}
