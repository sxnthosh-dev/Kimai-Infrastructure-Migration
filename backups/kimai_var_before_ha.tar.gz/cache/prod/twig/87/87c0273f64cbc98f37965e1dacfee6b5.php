<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* widget/widget-more.html.twig */
class __TwigTemplate_6e004ab8d0084ab5c1abe197d21bbc30 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'widget_data' => [$this, 'block_widget_data'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["url"] = null;
        // line 2
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "route", [], "any", true, true, false, 2)) {
            // line 3
            yield "    ";
            $context["url"] = $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "route", [], "any", false, false, false, 3), ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "routeOptions", [], "any", true, true, false, 3)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "routeOptions", [], "any", false, false, false, 3), [])) : ([])));
        }
        // line 5
        $context["color"] = ((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 5), "green")) : ("green"));
        // line 6
        yield "
<div class=\"card card-sm\">
    <div class=\"card-body\">
        <div class=\"row align-items-center\">
            <div class=\"col-auto\">
                <span class=\"bg-";
        // line 11
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
        yield " text-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["color"] ?? null), "html", null, true);
        yield "-fg avatar\">
                    ";
        // line 12
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon(CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "icon", [], "any", false, false, false, 12), true);
        yield "
                </span>
            </div>
            <div class=\"col\">
                <div class=\"font-weight-medium\">
                    <a href=\"";
        // line 17
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["url"] ?? null), "html", null, true);
        yield "\" class=\"stretched-link text-reset\">
                        ";
        // line 18
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)), "html", null, true);
        yield "
                    </a>
                </div>
                <div class=\"text-body-secondary\">
                    ";
        // line 22
        if (is_iterable(($context["data"] ?? null))) {
            // line 23
            yield "                        ";
            yield "Invalid data";
            yield "
                    ";
        } else {
            // line 25
            yield "                        ";
            yield from $this->unwrap()->yieldBlock('widget_data', $context, $blocks);
            // line 28
            yield "                    ";
        }
        // line 29
        yield "                    <sup style=\"font-size: 20px\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((array_key_exists("unit", $context)) ? (Twig\Extension\CoreExtension::default(($context["unit"] ?? null), "")) : ("")), "html", null, true);
        yield "</sup>
                </div>
            </div>
        </div>
    </div>
</div>
";
        yield from [];
    }

    // line 25
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_widget_data(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 26
        yield "                            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["data"] ?? null), "html", null, true);
        yield "
                        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "widget/widget-more.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  120 => 26,  113 => 25,  100 => 29,  97 => 28,  94 => 25,  88 => 23,  86 => 22,  79 => 18,  75 => 17,  67 => 12,  61 => 11,  54 => 6,  52 => 5,  48 => 3,  46 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "widget/widget-more.html.twig", "/opt/kimai/templates/widget/widget-more.html.twig");
    }
}
