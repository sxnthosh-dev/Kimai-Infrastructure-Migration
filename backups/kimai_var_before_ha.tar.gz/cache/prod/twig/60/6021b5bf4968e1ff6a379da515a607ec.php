<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* wizard/profile.html.twig */
class __TwigTemplate_039492cb3f3de36289064f9e4963b33e extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'wizard_content' => [$this, 'block_wizard_content'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "wizard/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("wizard/layout.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_wizard_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    <div class=\"card-body text-center py-4 p-sm-6\">
        <h1 class=\"mt-2\">";
        // line 5
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("wizard.profile.title", [], "wizard"), "html", null, true);
        yield "</h1>
        <p class=\"text-body-secondary\">";
        // line 6
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("wizard.profile.description", [], "wizard"), "html", null, true);
        yield "</p>
    </div>
    <div class=\"hr-text hr-text-center hr-text-spaceless\">";
        // line 8
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("wizard.separator", [], "wizard"), "html", null, true);
        yield "</div>
    <div class=\"card-body\">
        <div class=\"mb-3\">
            ";
        // line 11
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        </div>
    </div>
";
        yield from [];
    }

    // line 16
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 17
        yield "    <script type=\"text/javascript\">
        window.addEventListener(\x27load\x27, function() {
            const skinChooser = document.getElementById(\x27form_skin\x27);
            if (skinChooser !== null) {
                skinChooser.addEventListener(\x27change\x27, () => {
                    document.querySelectorAll(\x27[data-bs-theme]\x27).forEach(
                        element => {
                            element.dataset[\x27bsTheme\x27] = (skinChooser.value === \x27default\x27 ? \x27light\x27 : \x27dark\x27);
                        }
                    );
                });
            }

            const localeChooser = document.getElementById(\x27form_language\x27);
            if (localeChooser !== null) {
                localeChooser.addEventListener(\x27change\x27, (ev) => {
                    document.getElementById(\x27form_reload\x27).value = \x271\x27;
                    ev.target.form.submit();
                });
            }
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "wizard/profile.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  94 => 17,  87 => 16,  78 => 11,  72 => 8,  67 => 6,  63 => 5,  60 => 4,  53 => 3,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "wizard/profile.html.twig", "/opt/kimai/templates/wizard/profile.html.twig");
    }
}
