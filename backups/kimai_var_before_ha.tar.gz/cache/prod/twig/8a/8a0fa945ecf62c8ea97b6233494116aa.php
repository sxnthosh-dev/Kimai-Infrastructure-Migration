<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* calendar/user.html.twig */
class __TwigTemplate_92b44afa4d98e93965e73f7cc9afed8d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
            'stylesheets' => [$this, 'block_stylesheets'],
            'head' => [$this, 'block_head'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("base.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    <div class=\"row\">
        ";
        // line 6
        $context["hasTwoColumns"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "dragDropAmount", [], "any", false, false, false, 6) > 0) &&  !Twig\Extension\CoreExtension::testEmpty(($context["dragAndDrop"] ?? null))) && (Twig\Extension\CoreExtension::length($this->env->getCharset(), Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["dragAndDrop"] ?? null), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "entries", [], "any", false, false, false, 6)) > 0); })) > 0)) ||  !(null === ($context["form"] ?? null)));
        // line 7
        yield "        ";
        if ((($tmp = ($context["hasTwoColumns"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 8
            yield "        <div class=\"col-md-4 col-lg-3 d-none d-md-block order-last\">
            ";
            // line 9
            if ( !(null === ($context["form"] ?? null))) {
                // line 10
                yield "                ";
                yield from $this->load("calendar/user.html.twig", 10, 1)->unwrap()->yield($context);
                // line 30
                yield "            ";
            }
            // line 31
            yield "            ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::filter($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["dragAndDrop"] ?? null), function ($__s__) use ($context, $macros) { $context["s"] = $__s__; return (Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["s"] ?? null), "entries", [], "any", false, false, false, 31)) > 0); }));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
                // line 32
                yield "                ";
                yield from $this->load("calendar/user.html.twig", 32, 2)->unwrap()->yield($context);
                // line 53
                yield "            ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 54
            yield "        </div>
        ";
        }
        // line 56
        yield "
        <div class=\"col-xs-12 ";
        // line 57
        if ((($tmp = ($context["hasTwoColumns"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "col-md-8 col-lg-9 col-print-12";
        }
        yield "\">
            ";
        // line 58
        yield from $this->load("calendar/user.html.twig", 58, 3)->unwrap()->yield(CoreExtension::merge($context, ["fullsize" => true]));
        // line 63
        yield "        </div>
    </div>
";
        yield from [];
    }

    // line 67
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_stylesheets(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 68
        yield "    ";
        yield from $this->yieldParentBlock("stylesheets", $context, $blocks);
        yield "
    ";
        // line 69
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackLinkTags("calendar");
        yield "
";
        yield from [];
    }

    // line 72
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_head(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 73
        yield "    ";
        yield from $this->yieldParentBlock("head", $context, $blocks);
        yield "
    ";
        // line 74
        yield (string) $this->extensions['Symfony\WebpackEncoreBundle\Twig\EntryFilesTwigExtension']->renderWebpackScriptTags("calendar");
        yield "
";
        yield from [];
    }

    // line 77
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 78
        yield "    ";
        $context["calendarSelector"] = "timesheet_calendar";
        // line 79
        yield "    ";
        $context["createParams"] = "";
        // line 80
        yield "    ";
        $context["createRoute"] = "timesheet_create";
        // line 81
        yield "    ";
        $context["editRoute"] = "timesheet_edit";
        // line 82
        yield "    ";
        $context["canCreate"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_own_timesheet");
        // line 83
        yield "    ";
        $context["canEdit"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit_own_timesheet");
        // line 84
        yield "    ";
        $context["canEditExported"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit_exported_timesheet");
        // line 85
        yield "    ";
        $context["isForeignEdit"] = false;
        // line 86
        yield "    ";
        if ((($context["user"] ?? null) != CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 86))) {
            // line 87
            yield "        ";
            $context["isForeignEdit"] = true;
            // line 88
            yield "        ";
            $context["createParams"] = (("user=" . CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 88)) . "&");
            // line 89
            yield "        ";
            $context["createRoute"] = "admin_timesheet_create";
            // line 90
            yield "        ";
            $context["editRoute"] = "admin_timesheet_edit";
            // line 91
            yield "        ";
            $context["canCreate"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_other_timesheet");
            // line 92
            yield "        ";
            $context["canEdit"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit_other_timesheet");
            // line 93
            yield "    ";
        }
        // line 94
        yield "
    ";
        // line 95
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script>
        ";
        // line 98
        yield "        var calendar = null;

        const reloader = function() { calendar.reloadEvents(); };
        document.addEventListener(\x27kimai.timesheetUpdate\x27, reloader);
        document.addEventListener(\x27kimai.timesheetDelete\x27, reloader);

        document.addEventListener(\x27kimai.calendar.changeDate\x27, function(event) {
            var queryParams = new URLSearchParams(window.location.search);

            const dateSelect = document.getElementById(\x27date\x27);
            if (dateSelect !== null) {
                dateSelect.value = event.detail.date;
                queryParams.set(\x27date\x27, event.detail.date);
            }
            const viewSelect = document.getElementById(\x27view\x27);
            if (viewSelect !== null) {
                viewSelect.value = event.detail.view;
                queryParams.set(\x27view\x27, event.detail.view);
            }

            history.replaceState(null, null, \"?\" + queryParams.toString());
        });

        document.addEventListener(\x27kimai.initialized\x27, function(event) {
            const kimai = event.detail.kimai;

            let calendarOptions = {
                initialDate: \x27";
        // line 125
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->formatReportDate(($context["initial_date"] ?? null)), "html", null, true);
        yield "\x27,
                dragdrop: {
                    container: \x27.external-events\x27,
                    items: \x27.external-event\x27,
                },
                initialView: \x27";
        // line 130
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["initial_view"] ?? null), "html", null, true);
        yield "\x27,
                translations: {
                    customer: \x27";
        // line 132
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("customer"), "html", null, true);
        yield "\x27,
                    project: \x27";
        // line 133
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
        yield "\x27,
                    activity: \x27";
        // line 134
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
        yield "\x27,
                },
                permissions: {
                    edit: ";
        // line 137
        if ((($tmp = ($context["canEdit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    edit_exported: ";
        // line 138
        if ((($tmp = ($context["canEditExported"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    create: ";
        // line 139
        if ((($tmp = ($context["canCreate"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    edit_begin: ";
        // line 140
        if ((($tmp = ($context["can_edit_begin"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    edit_end: ";
        // line 141
        if ((($tmp = ($context["can_edit_end"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    edit_duration: ";
        // line 142
        if ((($tmp = ($context["can_edit_duration"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                    punch: ";
        // line 143
        if ((($tmp = ($context["is_punch_mode"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield "true";
        } else {
            yield "false";
        }
        yield ",
                },
                icons: {
                    next: \x27";
        // line 146
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("right", true), "html", null, true);
        yield "\x27,
                    previous: \x27";
        // line 147
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("left", true), "html", null, true);
        yield "\x27,
                    nextYear: \x27";
        // line 148
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("right2", true), "html", null, true);
        yield "\x27,
                    previousYear: \x27";
        // line 149
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("left2", true), "html", null, true);
        yield "\x27,
                },
                ";
        // line 151
        if ( !(null === ($context["google"] ?? null))) {
            // line 152
            yield "                googleCalendarApiKey: \x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["google"] ?? null), "apiKey", [], "any", false, false, false, 152), "html", null, true);
            yield "\x27,
                ";
        }
        // line 154
        yield "                patterns: {
                    title: \x27";
        // line 155
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "entryTitlePattern", [], "any", false, false, false, 155), "html", null, true);
        yield "\x27,
                },
                defaultStartTime: ";
        // line 157
        if ((null === ($context["defaultStartTime"] ?? null))) {
            yield "null";
        } else {
            yield "\x27";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["defaultStartTime"] ?? null), "html", null, true);
            yield "\x27";
        }
        yield ",
                now: \x27";
        // line 158
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateFormat(($context["now"] ?? null), "c"), "html", null, true);
        yield "\x27,
                ";
        // line 160
        yield "                timezone: \x27";
        yield (string) (((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 160), "timezone", [], "any", false, false, false, 160) == "UTC")) ? ("GMT") : ($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 160), "timezone", [], "any", false, false, false, 160), "html", null, true)));
        yield "\x27,
                eventSources: [
                    {
                        id: \x27kimaiUserTimeSource\x27,
                        type: \x27timesheet\x27,
                        url: \x27";
        // line 165
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("get_timesheets", ["user" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 165), "size" => Twig\Extension\CoreExtension::constant("\\App\\API\\BaseApiController::MAX_PAGE_SIZE"), "full" => "true", "begin" => "__FROM__", "end" => "__TO__"]);
        yield "\x27,
                        options: {
                            color: \x27";
        // line 167
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Configuration']->get($this->env, "theme.calendar.background_color"), "html", null, true);
        yield "\x27,
                        },
                    }
                    ";
        // line 170
        if ( !(null === ($context["google"] ?? null))) {
            // line 171
            yield "                    ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, ($context["google"] ?? null), "sources", [], "any", false, false, false, 171));
            $context['loop'] = [
              'parent' => $context['_parent'],
              'index0' => 0,
              'index'  => 1,
              'first'  => true,
            ];
            if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
                $length = count($context['_seq']);
                $context['loop']['revindex0'] = $length - 1;
                $context['loop']['revindex'] = $length;
                $context['loop']['length'] = $length;
                $context['loop']['last'] = 1 === $length;
            }
            foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
                // line 172
                yield "                    ,
                    {
                        id: \x27googleCompanyCalendar";
                // line 174
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 174), "html", null, true);
                yield "\x27,
                        type: \x27";
                // line 175
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "typeName", [], "any", false, false, false, 175), "html", null, true);
                yield "\x27,
                        options: {
                            googleCalendarId: \x27";
                // line 177
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "uri", [], "any", false, false, false, 177), "html", null, true);
                yield "\x27,
                            name: \x27";
                // line 178
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "id", [], "any", false, false, false, 178), "html", null, true);
                yield "\x27,
                            color: \x27";
                // line 179
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "color", [], "any", false, false, false, 179), "html", null, true);
                yield "\x27,
                            textColor: \x27";
                // line 180
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "color", [], "any", false, false, false, 180)), "html", null, true);
                yield "\x27,
                        }
                    }
                    ";
                ++$context['loop']['index0'];
                ++$context['loop']['index'];
                $context['loop']['first'] = false;
                if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                    --$context['loop']['revindex0'];
                    --$context['loop']['revindex'];
                    $context['loop']['last'] = 0 === $context['loop']['revindex0'];
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 184
            yield "                    ";
        }
        // line 185
        yield "                    ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["sources"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["source"]) {
            // line 186
            yield "                    ,
                    {
                        id: \x27";
            // line 188
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "id", [], "any", false, false, false, 188), "html", null, true);
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index", [], "any", false, false, false, 188), "html", null, true);
            yield "\x27,
                        type: \x27";
            // line 189
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "typeName", [], "any", false, false, false, 189), "html", null, true);
            yield "\x27,
                        url: \x27";
            // line 190
            yield (string) CoreExtension::getAttribute($this->env, $this->source, $context["source"], "uri", [], "any", false, false, false, 190);
            yield "\x27,
                        options: {...";
            // line 191
            yield (string) json_encode(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "options", [], "any", false, false, false, 191));
            yield ", ...{
                            color: \x27";
            // line 192
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "color", [], "any", false, false, false, 192), "html", null, true);
            yield "\x27,
                            textColor: \x27";
            // line 193
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->calculateFontContrastColor(CoreExtension::getAttribute($this->env, $this->source, $context["source"], "color", [], "any", false, false, false, 193)), "html", null, true);
            yield "\x27,
                        }}
                    }
                    ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['source'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 197
        yield "                ],
                url: {
                    update: (timesheetId) => {
                        return \x27";
        // line 200
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("patch_timesheet", ["id" => 1]);
        yield "\x27.replace(\x271\x27, timesheetId);
                    },
                    create: (start, end) => {
                        let createUrl = \x27";
        // line 203
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["createRoute"] ?? null));
        yield "\x27 + \x27?";
        yield (string) ($context["createParams"] ?? null);
        yield "\x27;
                        if (end !== undefined) {
                            createUrl += \x27from=\x27 + start + \x27&to=\x27 + end;
                        } else {
                            createUrl += \x27begin=\x27 + start;
                        }
                        return createUrl;
                    },
                    edit: (timesheetId) => {
                        return \x27";
        // line 212
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(($context["editRoute"] ?? null), ["id" => "-XX-"]);
        yield "\x27.replace(\x27-XX-\x27, timesheetId);
                    },
                    actions: (timesheetId) => {
                        return \x27";
        // line 215
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("get_timesheet_actions", ["id" => 1, "view" => "calendar", "locale" => CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "request", [], "any", false, false, false, 215), "locale", [], "any", false, false, false, 215)]), "html", null, true);
        yield "\x27.replace(\x271\x27, timesheetId);
                    },
                },
                preparePayloadForUpdate: (data) => {
                    ";
        // line 219
        if ((($tmp = ($context["isForeignEdit"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 220
            yield "                    data.user = ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "id", [], "any", false, false, false, 220), "html", null, true);
            yield ";
                    ";
        }
        // line 222
        yield "
                    return data;
                },
            };

            calendar = new KimaiCalendar(
                kimai,
                document.getElementById(\x27";
        // line 229
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["calendarSelector"] ?? null), "html", null, true);
        yield "\x27),
                Object.assign({}, calendarOptions, ";
        // line 230
        yield (string) json_encode(($context["config"] ?? null));
        yield ")
            );
            calendar.render();

            document.querySelector(\x27.fc-today-button\x27).classList.remove(\x27btn-icon\x27);
            document.querySelector(\x27.fc-header-toolbar\x27).classList.toggle(\x27row\x27);
            document.querySelector(\x27.fc-header-toolbar\x27).classList.add(\x27p-3\x27);
            const toolbar = document.querySelectorAll(\x27.fc-header-toolbar .fc-toolbar-chunk\x27);
            toolbar[0].parentElement.classList.add(\x27p-3\x27);
            toolbar[0].classList.add(\x27col-md-4\x27, \x27col-6\x27, \x27mb-1\x27, \x27text-start\x27, \x27order-xs-1\x27);
            toolbar[1].classList.add(\x27col-md-4\x27, \x27col-12\x27, \x27mb-1\x27, \x27text-center\x27, \x27order-3\x27);
            toolbar[2].classList.add(\x27col-md-4\x27, \x27col-6\x27, \x27mb-1\x27, \x27text-end\x27, \x27order-md-4\x27, \x27order-xs-2\x27);

            KimaiReloadPageWidget.create(\x27kimai.systemConfigUpdate\x27, true);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "calendar/user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  612 => 230,  608 => 229,  599 => 222,  593 => 220,  591 => 219,  584 => 215,  578 => 212,  564 => 203,  558 => 200,  553 => 197,  534 => 193,  530 => 192,  526 => 191,  522 => 190,  518 => 189,  513 => 188,  509 => 186,  491 => 185,  488 => 184,  469 => 180,  465 => 179,  461 => 178,  457 => 177,  452 => 175,  448 => 174,  444 => 172,  426 => 171,  424 => 170,  418 => 167,  413 => 165,  404 => 160,  400 => 158,  390 => 157,  385 => 155,  382 => 154,  376 => 152,  374 => 151,  369 => 149,  365 => 148,  361 => 147,  357 => 146,  347 => 143,  339 => 142,  331 => 141,  323 => 140,  315 => 139,  307 => 138,  299 => 137,  293 => 134,  289 => 133,  285 => 132,  280 => 130,  272 => 125,  243 => 98,  238 => 95,  235 => 94,  232 => 93,  229 => 92,  226 => 91,  223 => 90,  220 => 89,  217 => 88,  214 => 87,  211 => 86,  208 => 85,  205 => 84,  202 => 83,  199 => 82,  196 => 81,  193 => 80,  190 => 79,  187 => 78,  180 => 77,  173 => 74,  168 => 73,  161 => 72,  154 => 69,  149 => 68,  142 => 67,  135 => 63,  133 => 58,  127 => 57,  124 => 56,  120 => 54,  105 => 53,  102 => 32,  84 => 31,  81 => 30,  78 => 10,  76 => 9,  73 => 8,  70 => 7,  68 => 6,  65 => 5,  58 => 4,  53 => 1,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "calendar/user.html.twig", "/opt/kimai/templates/calendar/user.html.twig");
    }
}


/* calendar/user.html.twig */
class __TwigTemplate_92b44afa4d98e93965e73f7cc9afed8d___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 10
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 10);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "                        ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["id" => "calendar-form"]]);
        yield "
                        ";
        // line 13
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", true, true, false, 13)) {
            // line 14
            yield "                            ";
            $context["user_class"] = "";
            // line 15
            yield "                            ";
            if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 15), "vars", [], "any", false, false, false, 15), "choices", [], "any", false, false, false, 15)) < 2)) {
                // line 16
                yield "                                ";
                $context["user_class"] = "d-none";
                // line 17
                yield "                            ";
            }
            // line 18
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "user", [], "any", false, false, false, 18), 'row', ["row_attr" => ["class" => ($context["user_class"] ?? null)]]);
            yield "
                        ";
        }
        // line 20
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", true, true, false, 20)) {
            // line 21
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "date", [], "any", false, false, false, 21), 'row', ["row_attr" => ["class" => "d-none"]]);
            yield "
                        ";
        }
        // line 23
        yield "                        ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "view", [], "any", true, true, false, 23)) {
            // line 24
            yield "                            ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "view", [], "any", false, false, false, 24), 'row', ["row_attr" => ["class" => "d-none"]]);
            yield "
                        ";
        }
        // line 26
        yield "                        ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
                        ";
        // line 27
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
                    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "calendar/user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  753 => 27,  748 => 26,  742 => 24,  739 => 23,  733 => 21,  730 => 20,  724 => 18,  721 => 17,  718 => 16,  715 => 15,  712 => 14,  710 => 13,  705 => 12,  698 => 11,  687 => 10,  612 => 230,  608 => 229,  599 => 222,  593 => 220,  591 => 219,  584 => 215,  578 => 212,  564 => 203,  558 => 200,  553 => 197,  534 => 193,  530 => 192,  526 => 191,  522 => 190,  518 => 189,  513 => 188,  509 => 186,  491 => 185,  488 => 184,  469 => 180,  465 => 179,  461 => 178,  457 => 177,  452 => 175,  448 => 174,  444 => 172,  426 => 171,  424 => 170,  418 => 167,  413 => 165,  404 => 160,  400 => 158,  390 => 157,  385 => 155,  382 => 154,  376 => 152,  374 => 151,  369 => 149,  365 => 148,  361 => 147,  357 => 146,  347 => 143,  339 => 142,  331 => 141,  323 => 140,  315 => 139,  307 => 138,  299 => 137,  293 => 134,  289 => 133,  285 => 132,  280 => 130,  272 => 125,  243 => 98,  238 => 95,  235 => 94,  232 => 93,  229 => 92,  226 => 91,  223 => 90,  220 => 89,  217 => 88,  214 => 87,  211 => 86,  208 => 85,  205 => 84,  202 => 83,  199 => 82,  196 => 81,  193 => 80,  190 => 79,  187 => 78,  180 => 77,  173 => 74,  168 => 73,  161 => 72,  154 => 69,  149 => 68,  142 => 67,  135 => 63,  133 => 58,  127 => 57,  124 => 56,  120 => 54,  105 => 53,  102 => 32,  84 => 31,  81 => 30,  78 => 10,  76 => 9,  73 => 8,  70 => 7,  68 => 6,  65 => 5,  58 => 4,  53 => 1,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "calendar/user.html.twig", "/opt/kimai/templates/calendar/user.html.twig");
    }
}


/* calendar/user.html.twig */
class __TwigTemplate_92b44afa4d98e93965e73f7cc9afed8d___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 32
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 32);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 33
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "title", [], "any", false, false, false, 33), [], CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "translationDomain", [], "any", false, false, false, 33)), "html", null, true);
        yield from [];
    }

    // line 34
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "drag-and-drop-source p-0";
        yield from [];
    }

    // line 35
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 36
        yield "                        <div class=\"list-group list-group-flush external-events\" data-method=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "method", [], "any", false, false, false, 36), "html", null, true);
        yield "\" data-route=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "route", [], "any", false, false, false, 36), CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "routeParams", [], "any", false, false, false, 36)), "html", null, true);
        yield "\" data-route-replacer=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "routeReplacer", [], "any", false, false, false, 36)), "html_attr");
        yield "\">
                            ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::slice($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "entries", [], "any", false, false, false, 37), 0, CoreExtension::getAttribute($this->env, $this->source, ($context["config"] ?? null), "dragDropAmount", [], "any", false, false, false, 37)));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["_key"] => $context["entry"]) {
            // line 38
            yield "                                <div class=\"p-2 ps-3 lh-lg list-group-item external-event draggable\" data-entry=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(json_encode(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "data", [], "any", false, false, false, 38)), "html_attr");
            yield "\"";
            if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 38))) {
                yield " data-toggle=\"tooltip\" title=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "project", [], "any", false, false, false, 38), "customer", [], "any", false, false, false, 38), "name", [], "any", false, false, false, 38), "html", null, true);
                yield "\"";
            }
            yield ">
                                    <div class=\"row align-items-center\">
                                        <div class=\"col text-truncate\">
                                            ";
            // line 41
            if ((( !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "blockInclude", [], "any", false, false, false, 41)) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "blockName", [], "any", false, false, false, 41))) &&             $this->load(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "blockInclude", [], "any", false, false, false, 41), 41)->unwrap()->hasBlock(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "blockName", [], "any", false, false, false, 41), $context))) {
                // line 42
                yield "                                                ";
                yield from                 $this->load(CoreExtension::getAttribute($this->env, $this->source, ($context["source"] ?? null), "blockInclude", [], "any", false, false, false, 42), 42)->unwrap()->yieldBlock(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "blockName", [], "any", false, false, false, 42), $context);
                yield "
                                            ";
            } else {
                // line 44
                yield "                                                <span class=\"d-block text-body-secondary text-truncate\">";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["entry"], "title", [], "any", false, false, false, 44), "html", null, true);
                yield "</span>
                                            ";
            }
            // line 46
            yield "                                        </div>
                                    </div>
                                </div>
                            ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['entry'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 50
        yield "                        </div>
                    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "calendar/user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  926 => 50,  908 => 46,  902 => 44,  896 => 42,  894 => 41,  881 => 38,  864 => 37,  855 => 36,  848 => 35,  837 => 34,  826 => 33,  815 => 32,  753 => 27,  748 => 26,  742 => 24,  739 => 23,  733 => 21,  730 => 20,  724 => 18,  721 => 17,  718 => 16,  715 => 15,  712 => 14,  710 => 13,  705 => 12,  698 => 11,  687 => 10,  612 => 230,  608 => 229,  599 => 222,  593 => 220,  591 => 219,  584 => 215,  578 => 212,  564 => 203,  558 => 200,  553 => 197,  534 => 193,  530 => 192,  526 => 191,  522 => 190,  518 => 189,  513 => 188,  509 => 186,  491 => 185,  488 => 184,  469 => 180,  465 => 179,  461 => 178,  457 => 177,  452 => 175,  448 => 174,  444 => 172,  426 => 171,  424 => 170,  418 => 167,  413 => 165,  404 => 160,  400 => 158,  390 => 157,  385 => 155,  382 => 154,  376 => 152,  374 => 151,  369 => 149,  365 => 148,  361 => 147,  357 => 146,  347 => 143,  339 => 142,  331 => 141,  323 => 140,  315 => 139,  307 => 138,  299 => 137,  293 => 134,  289 => 133,  285 => 132,  280 => 130,  272 => 125,  243 => 98,  238 => 95,  235 => 94,  232 => 93,  229 => 92,  226 => 91,  223 => 90,  220 => 89,  217 => 88,  214 => 87,  211 => 86,  208 => 85,  205 => 84,  202 => 83,  199 => 82,  196 => 81,  193 => 80,  190 => 79,  187 => 78,  180 => 77,  173 => 74,  168 => 73,  161 => 72,  154 => 69,  149 => 68,  142 => 67,  135 => 63,  133 => 58,  127 => 57,  124 => 56,  120 => 54,  105 => 53,  102 => 32,  84 => 31,  81 => 30,  78 => 10,  76 => 9,  73 => 8,  70 => 7,  68 => 6,  65 => 5,  58 => 4,  53 => 1,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "calendar/user.html.twig", "/opt/kimai/templates/calendar/user.html.twig");
    }
}


/* calendar/user.html.twig */
class __TwigTemplate_92b44afa4d98e93965e73f7cc9afed8d___3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 58
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("@theme/embeds/card.html.twig", 58);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 59
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 60
        yield "                    <div id=\"timesheet_calendar\"></div>
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "calendar/user.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  1003 => 60,  996 => 59,  985 => 58,  926 => 50,  908 => 46,  902 => 44,  896 => 42,  894 => 41,  881 => 38,  864 => 37,  855 => 36,  848 => 35,  837 => 34,  826 => 33,  815 => 32,  753 => 27,  748 => 26,  742 => 24,  739 => 23,  733 => 21,  730 => 20,  724 => 18,  721 => 17,  718 => 16,  715 => 15,  712 => 14,  710 => 13,  705 => 12,  698 => 11,  687 => 10,  612 => 230,  608 => 229,  599 => 222,  593 => 220,  591 => 219,  584 => 215,  578 => 212,  564 => 203,  558 => 200,  553 => 197,  534 => 193,  530 => 192,  526 => 191,  522 => 190,  518 => 189,  513 => 188,  509 => 186,  491 => 185,  488 => 184,  469 => 180,  465 => 179,  461 => 178,  457 => 177,  452 => 175,  448 => 174,  444 => 172,  426 => 171,  424 => 170,  418 => 167,  413 => 165,  404 => 160,  400 => 158,  390 => 157,  385 => 155,  382 => 154,  376 => 152,  374 => 151,  369 => 149,  365 => 148,  361 => 147,  357 => 146,  347 => 143,  339 => 142,  331 => 141,  323 => 140,  315 => 139,  307 => 138,  299 => 137,  293 => 134,  289 => 133,  285 => 132,  280 => 130,  272 => 125,  243 => 98,  238 => 95,  235 => 94,  232 => 93,  229 => 92,  226 => 91,  223 => 90,  220 => 89,  217 => 88,  214 => 87,  211 => 86,  208 => 85,  205 => 84,  202 => 83,  199 => 82,  196 => 81,  193 => 80,  190 => 79,  187 => 78,  180 => 77,  173 => 74,  168 => 73,  161 => 72,  154 => 69,  149 => 68,  142 => 67,  135 => 63,  133 => 58,  127 => 57,  124 => 56,  120 => 54,  105 => 53,  102 => 32,  84 => 31,  81 => 30,  78 => 10,  76 => 9,  73 => 8,  70 => 7,  68 => 6,  65 => 5,  58 => 4,  53 => 1,  51 => 2,  44 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "calendar/user.html.twig", "/opt/kimai/templates/calendar/user.html.twig");
    }
}
