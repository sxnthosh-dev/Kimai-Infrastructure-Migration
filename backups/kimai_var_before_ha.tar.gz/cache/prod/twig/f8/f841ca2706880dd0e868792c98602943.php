<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* help/index.html.twig */
class __TwigTemplate_17f8d40dc53b23d8ba4b07b05a5d3b7c extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_column_attr' => [$this, 'block_datatable_column_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "rtl", [], "any", false, false, false, 5)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " dir=\"rtl\"";
        }
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 9
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 10
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 10), "html", null, true);
            yield "
    ";
        } elseif ((        // line 11
($context["column"] ?? null) == "description")) {
            // line 12
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "description", [], "any", false, false, false, 12), "html", null, true);
            yield "
    ";
        } elseif ((        // line 13
($context["column"] ?? null) == "language")) {
            // line 14
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "language", [], "any", false, false, false, 14), "html", null, true);
            yield "
    ";
        } elseif ((        // line 15
($context["column"] ?? null) == "date")) {
            // line 16
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "date", [], "any", false, false, false, 16), "html", null, true);
            yield "
    ";
        } elseif ((        // line 17
($context["column"] ?? null) == "time")) {
            // line 18
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "time", [], "any", false, false, false, 18), "html", null, true);
            yield "
    ";
        } elseif ((        // line 19
($context["column"] ?? null) == "duration")) {
            // line 20
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "duration", [], "any", false, false, false, 20), "html", null, true);
            yield "
    ";
        } elseif ((        // line 21
($context["column"] ?? null) == "decimal")) {
            // line 22
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "decimal", [], "any", false, false, false, 22), "html", null, true);
            yield "
    ";
        } elseif ((        // line 23
($context["column"] ?? null) == "money")) {
            // line 24
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "money", [], "any", false, false, false, 24), "html", null, true);
            yield "
    ";
        } elseif ((        // line 25
($context["column"] ?? null) == "time_format")) {
            // line 26
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "time_format", [], "any", false, false, false, 26), "html", null, true);
            yield "
    ";
        } elseif ((        // line 27
($context["column"] ?? null) == "date_format")) {
            // line 28
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "date_format", [], "any", false, false, false, 28), "html", null, true);
            yield "
    ";
        } elseif ((        // line 29
($context["column"] ?? null) == "hour_24")) {
            // line 30
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 30, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "hour_24", [], "any", false, false, false, 30)]);
            yield "
    ";
        } elseif ((        // line 31
($context["column"] ?? null) == "rtl")) {
            // line 32
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_boolean", $context, 32, $this->getSourceContext())->macro_label_boolean(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "rtl", [], "any", false, false, false, 32)]);
            yield "
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "help/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  157 => 32,  155 => 31,  150 => 30,  148 => 29,  143 => 28,  141 => 27,  136 => 26,  134 => 25,  129 => 24,  127 => 23,  122 => 22,  120 => 21,  115 => 20,  113 => 19,  108 => 18,  106 => 17,  101 => 16,  99 => 15,  94 => 14,  92 => 13,  87 => 12,  85 => 11,  80 => 10,  77 => 9,  70 => 8,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "help/index.html.twig", "/opt/kimai/templates/help/index.html.twig");
    }
}
