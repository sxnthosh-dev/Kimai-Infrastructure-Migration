<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/template_edit.html.twig */
class __TwigTemplate_4a23a5f83a1fa7b4941f386472f0cc43 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => ((CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["template"] ?? null), "name", [], "any", true, true, false, 6)) ? (Twig\Extension\CoreExtension::default(CoreExtension::getAttribute($this->env, $this->source, ($context["template"] ?? null), "name", [], "any", false, false, false, 6), $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create"))) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create"))), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_invoice_template")];
        // line 10
        yield "
    ";
        // line 11
        yield from $this->load("invoice/template_edit.html.twig", 11, 1)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        // line 78
        yield "    
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/template_edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  71 => 78,  69 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/template_edit.html.twig", "/opt/kimai/templates/invoice/template_edit.html.twig");
    }
}


/* invoice/template_edit.html.twig */
class __TwigTemplate_4a23a5f83a1fa7b4941f386472f0cc43___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 11
        return $this->load(($context["formEditTemplate"] ?? null), 11);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 13), 'row');
        yield "
            <fieldset class=\"form-fieldset pb-0\">
                <div class=\"row\">
                    <div class=\"col-12\">
                        ";
        // line 17
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "title", [], "any", false, false, false, 17), 'row');
        yield "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        ";
        // line 22
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 22), 'row');
        yield "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-12\">
                        ";
        // line 27
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "paymentTerms", [], "any", false, false, false, 27), 'row');
        yield "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        ";
        // line 32
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "contact", [], "any", false, false, false, 32), 'row');
        yield "
                    </div>
                    <div class=\"col-md-6\">
                        ";
        // line 35
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "paymentDetails", [], "any", false, false, false, 35), 'row');
        yield "
                    </div>
                </div>
            </fieldset>
            <fieldset class=\"form-fieldset pb-0\">
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        ";
        // line 42
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "dueDays", [], "any", false, false, false, 42), 'row');
        yield "
                    </div>
                    <div class=\"col-md-6\">
                        ";
        // line 45
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vat", [], "any", false, false, false, 45), 'row');
        yield "
                    </div>
                </div>
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        ";
        // line 50
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "language", [], "any", false, false, false, 50), 'row');
        yield "
                    </div>
                    <div class=\"col-md-6\">
                        ";
        // line 53
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "numberGenerator", [], "any", false, false, false, 53), 'row');
        yield "
                    </div>
                </div>
            </fieldset>
            <fieldset class=\"form-fieldset pb-0\">
                <div class=\"row\">
                    <div class=\"col-md-6\">
                        ";
        // line 60
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "renderer", [], "any", false, false, false, 60), 'row', ["help_html" => true, "help" => (("<a href=\"https://github.com/kimai/invoice-templates\" target=\"_blank\">" . $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("download_invoice_renderer", [], "invoice-renderer")) . "</a>")]);
        yield "
                    </div>
                    <div class=\"col-md-6\">
                        ";
        // line 63
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "calculator", [], "any", false, false, false, 63), 'row');
        yield "
                    </div>
                </div>
            </fieldset>
            ";
        // line 67
        if ((CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", true, true, false, 67) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 67)))) {
            // line 68
            yield "            <fieldset class=\"form-fieldset pb-0\">
                <div class=\"row\">
                    <div class=\"col\">
                        ";
            // line 71
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "metaFields", [], "any", false, false, false, 71), 'row');
            yield "
                    </div>
                </div>
            </fieldset>
            ";
        }
        // line 76
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/template_edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  253 => 76,  245 => 71,  240 => 68,  238 => 67,  231 => 63,  225 => 60,  215 => 53,  209 => 50,  201 => 45,  195 => 42,  185 => 35,  179 => 32,  171 => 27,  163 => 22,  155 => 17,  147 => 13,  140 => 12,  130 => 11,  71 => 78,  69 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/template_edit.html.twig", "/opt/kimai/templates/invoice/template_edit.html.twig");
    }
}
