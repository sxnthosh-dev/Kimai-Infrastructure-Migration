<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* team/index.html.twig */
class __TwigTemplate_3d949833132d07fabe973407e1dfc7d3 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        if ((($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("edit", ($context["entry"] ?? null))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " class=\"open-edit alternative-link\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_team_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 6)]), "html", null, true);
            yield "\"";
        }
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 11
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_name", $context, 11, $this->getSourceContext())->macro_label_name(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 11), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 11), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 11))]);
            yield "
    ";
        } elseif ((        // line 12
($context["column"] ?? null) == "avatar")) {
            // line 13
            yield "        ";
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "members", [], "any", false, false, false, 13), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "teamlead", [], "any", false, false, false, 13) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "teamlead", [], "any", false, false, false, 13)); }));
            foreach ($context['_seq'] as $context["_key"] => $context["member"]) {
                // line 14
                yield "            ";
                $context["user"] = CoreExtension::getAttribute($this->env, $this->source, $context["member"], "user", [], "any", false, false, false, 14);
                // line 15
                yield "            ";
                $context["tooltip"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["member"], "teamlead", [], "any", false, false, false, 15)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ((($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("teamlead") . ": ") . CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "displayName", [], "any", false, false, false, 15))) : (null));
                // line 16
                yield "            ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_user_avatar", $context, 16, $this->getSourceContext())->macro_user_avatar(...[($context["user"] ?? null), ($context["tooltip"] ?? null), "avatar-rounded", (((($tmp = CoreExtension::getAttribute($this->env, $this->source, $context["member"], "teamlead", [], "any", false, false, false, 16)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("info") : (null))]);
                yield "
        ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['member'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 18
            yield "    ";
        } elseif ((($context["column"] ?? null) == "amount")) {
            // line 19
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counted", $context, 19, $this->getSourceContext())->macro_badge_counted(...[Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "members", [], "any", false, false, false, 19))]);
            yield "
    ";
        } elseif ((        // line 20
($context["column"] ?? null) == "actions")) {
            // line 21
            yield "        ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 21), "team", "index", ["team" => ($context["entry"] ?? null)]);
            // line 22
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 22, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 22)]);
            yield "
    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "team/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  125 => 22,  122 => 21,  120 => 20,  115 => 19,  112 => 18,  102 => 16,  99 => 15,  96 => 14,  91 => 13,  89 => 12,  84 => 11,  81 => 10,  74 => 9,  65 => 6,  58 => 5,  53 => 1,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "team/index.html.twig", "/opt/kimai/templates/team/index.html.twig");
    }
}
