<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* activity/edit.html.twig */
class __TwigTemplate_4da08a9796ef5e530a554bcd27349b4a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'main' => [$this, 'block_main'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return $this->load((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 1)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("form.html.twig") : ("base.html.twig")), 1);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "    ";
        $context["formEditTemplate"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "modalRequest", [], "any", false, false, false, 4)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("default/_form_modal.html.twig") : ("default/_form.html.twig"));
        // line 5
        yield "    ";
        $context["formOptions"] = ["title" => (((null === CoreExtension::getAttribute($this->env, $this->source,         // line 6
($context["activity"] ?? null), "id", [], "any", false, false, false, 6))) ? ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create-activity")) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("edit"))), "form" =>         // line 7
($context["form"] ?? null), "back" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_activity")];
        // line 10
        yield "    ";
        yield from $this->load("activity/edit.html.twig", 10, 2)->unwrap()->yield(CoreExtension::merge($context, ($context["formOptions"] ?? null)));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/edit.html.twig", "/opt/kimai/templates/activity/edit.html.twig");
    }
}


/* activity/edit.html.twig */
class __TwigTemplate_4da08a9796ef5e530a554bcd27349b4a___2 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return $this->load(($context["formEditTemplate"] ?? null), 10);
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 11)->unwrap();
        // line 10
        yield from $this->getParent($context)->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "            <div class=\"row\">
                <div class=\"col-md-9\">
                    ";
        // line 15
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "name", [], "any", false, false, false, 15), 'row');
        yield "
                </div>
                <div class=\"col-md-3\">
                    ";
        // line 18
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "color", [], "any", false, false, false, 18), 'row');
        yield "
                </div>
            </div>
            ";
        // line 21
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "comment", [], "any", false, false, false, 21), 'row');
        yield "
            ";
        // line 22
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", true, true, false, 22)) {
            // line 23
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "customer", [], "any", false, false, false, 23), 'row');
            yield "
            ";
        }
        // line 25
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", true, true, false, 25)) {
            // line 26
            yield "                ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "project", [], "any", false, false, false, 26), 'row');
            yield "
            ";
        }
        // line 28
        yield "            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "number", [], "any", false, false, false, 28), 'row');
        yield "
            ";
        // line 29
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", true, true, false, 29)) {
            // line 30
            yield "                <div class=\"row\">
                    ";
            // line 31
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", true, true, false, 31)) {
                // line 32
                yield "                        <div class=\"col-md-4\">
                            ";
                // line 33
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budget", [], "any", false, false, false, 33), 'row');
                yield "
                        </div>
                    ";
            }
            // line 36
            yield "                    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", true, true, false, 36)) {
                // line 37
                yield "                        <div class=\"col-md-4\">
                            ";
                // line 38
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "timeBudget", [], "any", false, false, false, 38), 'row');
                yield "
                        </div>
                    ";
            }
            // line 41
            yield "                    <div class=\"col-md-4\">
                        ";
            // line 42
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "budgetType", [], "any", false, false, false, 42), 'row');
            yield "
                    </div>
                </div>
            ";
        }
        // line 46
        yield "            ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", true, true, false, 46)) {
            // line 47
            yield "                <div class=\"row\">
                    <div class=\"col-12\">
                        ";
            // line 49
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "teams", [], "any", false, false, false, 49), 'row');
            yield "
                    </div>
                </div>
            ";
        }
        // line 53
        yield "            ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 53, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), null]);
        yield "
            ";
        // line 54
        yield from $this->load("activity/edit.html.twig", 54, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => "activity_invoice_settings"]));
        // line 65
        yield "            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 67
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "visible", [], "any", false, false, false, 67), 'row');
        yield "
                </div>
                <div class=\"col-md-6\">
                    ";
        // line 70
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "billable", [], "any", false, false, false, 70), 'row');
        yield "
                </div>
            </div>
            ";
        // line 73
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  261 => 73,  255 => 70,  249 => 67,  245 => 65,  243 => 54,  238 => 53,  231 => 49,  227 => 47,  224 => 46,  217 => 42,  214 => 41,  208 => 38,  205 => 37,  202 => 36,  196 => 33,  193 => 32,  191 => 31,  188 => 30,  186 => 29,  181 => 28,  175 => 26,  172 => 25,  166 => 23,  164 => 22,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/edit.html.twig", "/opt/kimai/templates/activity/edit.html.twig");
    }
}


/* activity/edit.html.twig */
class __TwigTemplate_4da08a9796ef5e530a554bcd27349b4a___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 54
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 55
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 55)->unwrap();
        // line 56
        $macros["form_helper"] = $this->macros["form_helper"] = $this->load("macros/form_helper.html.twig", 56)->unwrap();
        // line 54
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 54);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 57
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoices"), "html", null, true);
        yield from [];
    }

    // line 58
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 59
        yield "                    ";
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", true, true, false, 59)) {
            // line 60
            yield "                        ";
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "invoiceText", [], "any", false, false, false, 60), 'row');
            yield "
                    ";
        }
        // line 62
        yield "                    ";
        yield (string) $macros["form_helper"]->getTemplateForMacro("macro_metafields", $context, 62, $this->getSourceContext())->macro_metafields(...[($context["form"] ?? null), "invoice"]);
        yield "
                ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "activity/edit.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  365 => 62,  359 => 60,  356 => 59,  349 => 58,  338 => 57,  333 => 54,  331 => 56,  329 => 55,  322 => 54,  261 => 73,  255 => 70,  249 => 67,  245 => 65,  243 => 54,  238 => 53,  231 => 49,  227 => 47,  224 => 46,  217 => 42,  214 => 41,  208 => 38,  205 => 37,  202 => 36,  196 => 33,  193 => 32,  191 => 31,  188 => 30,  186 => 29,  181 => 28,  175 => 26,  172 => 25,  166 => 23,  164 => 22,  160 => 21,  154 => 18,  148 => 15,  144 => 13,  137 => 12,  133 => 10,  131 => 11,  66 => 10,  64 => 7,  63 => 6,  61 => 5,  58 => 4,  51 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "activity/edit.html.twig", "/opt/kimai/templates/activity/edit.html.twig");
    }
}
