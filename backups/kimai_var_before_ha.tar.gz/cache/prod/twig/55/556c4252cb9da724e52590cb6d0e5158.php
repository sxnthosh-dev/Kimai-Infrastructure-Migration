<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* reporting/customer/monthly_projects_export.html.twig */
class __TwigTemplate_baab673cef301d0e1519fa6b7dd3b53f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield from $this->load("reporting/customer/monthly_projects_export.html.twig", 1, 1)->unwrap()->yield(CoreExtension::toArray(["decimal" => true, "stats" => ($context["stats"] ?? null), "dataType" => ($context["dataType"] ?? null)]));
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects_export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects_export.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects_export.html.twig");
    }
}


/* reporting/customer/monthly_projects_export.html.twig */
class __TwigTemplate_baab673cef301d0e1519fa6b7dd3b53f___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'user_activity' => [$this, 'block_user_activity'],
            'project_activity' => [$this, 'block_project_activity'],
            'project_total' => [$this, 'block_project_total'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        return "reporting/customer/monthly_projects_data.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $context["rowspanStyle"] = "vertical-align:center";
        // line 1
        $this->parent = $this->load("reporting/customer/monthly_projects_data.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_user_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "        ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 5
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
        ";
        } else {
            // line 7
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), true), "html", null, true);
            yield "
        ";
        }
        // line 9
        yield "    ";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_project_activity(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "        ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 12
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
        ";
        } else {
            // line 14
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), true), "html", null, true);
            yield "
        ";
        }
        // line 16
        yield "    ";
        yield from [];
    }

    // line 17
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_project_total(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 18
        yield "        ";
        if (((($context["dataType"] ?? null) == "rate") || (($context["dataType"] ?? null) == "internalRate"))) {
            // line 19
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money(($context["value"] ?? null), ($context["currency"] ?? null)), "html", null, true);
            yield "
        ";
        } else {
            // line 21
            yield "            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->duration(($context["value"] ?? null), true), "html", null, true);
            yield "
        ";
        }
        // line 23
        yield "    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "reporting/customer/monthly_projects_export.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  192 => 23,  186 => 21,  180 => 19,  177 => 18,  170 => 17,  165 => 16,  159 => 14,  153 => 12,  150 => 11,  143 => 10,  138 => 9,  132 => 7,  126 => 5,  123 => 4,  116 => 3,  111 => 1,  109 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "reporting/customer/monthly_projects_export.html.twig", "/opt/kimai/templates/reporting/customer/monthly_projects_export.html.twig");
    }
}
