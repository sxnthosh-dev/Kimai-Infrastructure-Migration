<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/status.html.twig */
class __TwigTemplate_93ce2fe613a06670bafbce176e36475f extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_status($text = null, $options = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "text" => $text,
            "options" => $options,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            $macros["_v0"] = $this->load("@Tabler/components/status_dot.html.twig", 3)->unwrap();
            // line 4
            yield "
    ";
            // line 5
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 5) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 5)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 5)) : ("primary"));
            // line 6
            yield "    ";
            $context["_animated"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", true, true, false, 6) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", false, false, false, 6)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "animated", [], "any", false, false, false, 6)) : (true)) === true);
            // line 7
            yield "    ";
            $context["_lite"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "lite", [], "any", true, true, false, 7) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "lite", [], "any", false, false, false, 7)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "lite", [], "any", false, false, false, 7)) : (false)) === true);
            // line 8
            yield "    ";
            if (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "with_dot", [], "any", true, true, false, 8)) {
                // line 9
                yield "        ";
                trigger_deprecation('', '', "with_dot option is deprecated, use withDot option instead!"." in \"@Tabler/components/status.html.twig\" at line 9.");
                // line 10
                yield "        ";
                $context["_withDot"] = (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "with_dot", [], "any", false, false, false, 10) === true);
                // line 11
                yield "    ";
            } else {
                // line 12
                yield "        ";
                $context["_withDot"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "withDot", [], "any", true, true, false, 12) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "withDot", [], "any", false, false, false, 12)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "withDot", [], "any", false, false, false, 12)) : (false)) === true);
                // line 13
                yield "    ";
            }
            // line 14
            yield "
    ";
            // line 15
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 15) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 15)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 15)) : (""));
            // line 16
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 16) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 16)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 16)) : ([]));
            // line 17
            yield "
    <span
        class=\"status bg-";
            // line 19
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_color"] ?? null), "html", null, true);
            yield " ";
            if ( !(($tmp = ($context["_lite"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield " text-";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_color"] ?? null), "html", null, true);
                yield "-fg";
            }
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_extraClass"] ?? null), "html", null, true);
            yield "\"
        ";
            // line 20
            yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 20, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        ";
            // line 22
            if ((($tmp = ($context["_withDot"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 23
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_status_dot", $context, 23, $this->getSourceContext())->macro_status_dot(...[["color" => ($context["_color"] ?? null), "animated" => ($context["_animated"] ?? null)]]);
                yield "
        ";
            }
            // line 25
            yield "        ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["text"] ?? null), "html", null, true);
            yield "
    </span>
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  131 => 25,  125 => 23,  123 => 22,  118 => 20,  106 => 19,  102 => 17,  99 => 16,  97 => 15,  94 => 14,  91 => 13,  88 => 12,  85 => 11,  82 => 10,  79 => 9,  76 => 8,  73 => 7,  70 => 6,  68 => 5,  65 => 4,  62 => 3,  59 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/status.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/status.html.twig");
    }
}
