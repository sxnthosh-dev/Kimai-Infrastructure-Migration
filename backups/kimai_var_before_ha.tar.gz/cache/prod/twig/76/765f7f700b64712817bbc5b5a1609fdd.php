<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* macros/status.html.twig */
class __TwigTemplate_414e3caec23dcce74e2f63a1e3870cb4 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "
";
        // line 9
        yield "
";
        // line 13
        yield "
";
        yield from [];
    }

    // line 1
    public function macro_status($title = null, $color = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "title" => $title,
            "color" => $color,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["_v0"] = $this->load("@theme/components/status.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            yield (string) $macros["_v0"]->getTemplateForMacro("macro_status", $context, 3, $this->getSourceContext())->macro_status(...[($context["title"] ?? null), ["color" => ((array_key_exists("color", $context)) ? (Twig\Extension\CoreExtension::default(($context["color"] ?? null), "primary-lt")) : ("primary-lt")), "lite" => true]]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 6
    public function macro_status_duration($duration = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "duration" => $duration,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 7
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_status", $context, 7, $this->getSourceContext())->macro_status(...[($context["duration"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 10
    public function macro_status_money($money = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "money" => $money,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 11
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_status", $context, 11, $this->getSourceContext())->macro_status(...[($context["money"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    // line 14
    public function macro_status_count($counter = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "counter" => $counter,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 15
            yield "    ";
            yield (string) $this->getTemplateForMacro("macro_status", $context, 15, $this->getSourceContext())->macro_status(...[($context["counter"] ?? null)]);
            yield "
";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "macros/status.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  134 => 15,  122 => 14,  113 => 11,  101 => 10,  92 => 7,  80 => 6,  71 => 3,  68 => 2,  55 => 1,  49 => 13,  46 => 9,  43 => 5,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "macros/status.html.twig", "/opt/kimai/templates/macros/status.html.twig");
    }
}
