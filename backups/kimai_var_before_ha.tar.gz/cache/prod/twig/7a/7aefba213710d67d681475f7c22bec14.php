<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/api-token.html.twig */
class __TwigTemplate_e7b8156e14fb2f7d8ee9a1cb77c6b32a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_body' => [$this, 'block_form_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 1
        $this->parent = $this->load("user/form.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "    <div class=\"card-body\">

        <div class=\"row mb-3\">
            <div class=\"col-12 col-md-6\">
                <p>
                    ";
        // line 10
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("api_password.intro"), "html", null, true);
        yield "
                </p>
                <p>
                    <strong>URL</strong>: ";
        // line 13
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["api_url"] ?? null), "html", null, true);
        yield "
                </p>
            </div>

            <div class=\"col-12 col-md-6 text-md-end\">
                <a class=\"btn action-create modal-ajax-form\" href=\"";
        // line 18
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("user_profile_access_token", ["username" => CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "userIdentifier", [], "any", false, false, false, 18)]), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("create", true);
        yield " ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("create"), "html", null, true);
        yield "</a>
                <a class=\"btn\" target=\"_blank\" href=\"";
        // line 19
        yield (string) $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("api.swagger_ui");
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("documentation", true);
        yield " Swagger Docs</a>
                <a class=\"btn\" target=\"_blank\" href=\"";
        // line 20
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->documentationLink("rest-api.html"), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("help", true);
        yield " ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("help"), "html", null, true);
        yield "</a>
            </div>
        </div>

        ";
        // line 24
        if ( !(null === ($context["created_token"] ?? null))) {
            // line 25
            yield "            <div class=\"card mb-4\">
                <div class=\"ribbon bg-red\">";
            // line 26
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("status.new"), "html", null, true);
            yield "</div>
                <div class=\"card-body\">
                    <h3 class=\"card-title\">";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["created_token"] ?? null), "name", [], "any", false, false, false, 28), "html", null, true);
            yield "</h3>
                    <p class=\"text-secondary\"></p>
                    <p>";
            // line 30
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("api_token_hidden"), "html", null, true);
            yield "</p>
                    <div class=\"codeblock\">
                        <div class=\"codeblock-copy\" style=\"position: absolute; right: 30px; padding-top: 5px\">
                            <button class=\"btn btn-icon btn-dark\" onclick=\"navigator.clipboard.writeText(\x27";
            // line 33
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["created_token"] ?? null), "token", [], "any", false, false, false, 33), "html", null, true);
            yield "\x27);\"><svg xmlns=\"http://www.w3.org/2000/svg\" class=\"icon icon-tabler icon-tabler-clipboard icon\" width=\"24\" height=\"24\" viewBox=\"0 0 24 24\" stroke-width=\"2\" stroke=\"currentColor\" fill=\"none\" stroke-linecap=\"round\" stroke-linejoin=\"round\"><path d=\"M9 5h-2a2 2 0 0 0 -2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2 -2v-12a2 2 0 0 0 -2 -2h-2\"></path><path d=\"M9 3m0 2a2 2 0 0 1 2 -2h2a2 2 0 0 1 2 2v0a2 2 0 0 1 -2 2h-2a2 2 0 0 1 -2 -2z\"></path></svg></button>
                        </div>
                        <pre><code>";
            // line 35
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, ($context["created_token"] ?? null), "token", [], "any", false, false, false, 35), "html", null, true);
            yield "</code></pre>
                    </div>
                    ";
            // line 37
            if ( !(null === ($context["qr_code_payload"] ?? null))) {
                // line 38
                yield "                        <p class=\"mt-3 mb-1\">
                            <img style=\"max-width: 200px; max-height: 200px;\" alt=\"API QR code\" src=\"";
                // line 39
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('App\Twig\Runtime\QrCodeExtension')->qrCodeDataUriFunction(($context["qr_code_payload"] ?? null)), "html", null, true);
                yield "\" />
                        </p>
                        <p class=\"text-secondary\">
                            <i class=\"";
                // line 42
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->icon("info", false), "html", null, true);
                yield "\"></i>
                            ";
                // line 43
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("api_token_qr_hint"), "html", null, true);
                yield "
                        </p>
                    ";
            }
            // line 46
            yield "                </div>
            </div>
        ";
        }
        // line 49
        yield "
        ";
        // line 50
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["access_tokens"] ?? null)) > 0)) {
            // line 51
            yield "            <table class=\"table table-vcenter\">
                <thead>
                <tr>
                    <th>";
            // line 54
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("name"), "html", null, true);
            yield "</th>
                    <th>";
            // line 55
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("last_usage"), "html", null, true);
            yield "</th>
                    <th>";
            // line 56
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("expires"), "html", null, true);
            yield "</th>
                    <th class=\"w-min actions\"></th>
                </tr>
                </thead>
                <tbody>
                ";
            // line 61
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["access_tokens"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["token"]) {
                // line 62
                yield "                    <tr>
                        <td>";
                // line 63
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["token"], "name", [], "any", false, false, false, 63), "html", null, true);
                yield "</td>
                        <td>
                            ";
                // line 65
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["token"], "lastUsage", [], "any", false, false, false, 65))) {
                    // line 66
                    yield "                                ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateTime(CoreExtension::getAttribute($this->env, $this->source, $context["token"], "lastUsage", [], "any", false, false, false, 66)), "html", null, true);
                    yield "
                            ";
                }
                // line 68
                yield "                        </td>
                        <td>
                            ";
                // line 70
                if ( !(null === CoreExtension::getAttribute($this->env, $this->source, $context["token"], "expiresAt", [], "any", false, false, false, 70))) {
                    // line 71
                    yield "                                ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->dateShort(CoreExtension::getAttribute($this->env, $this->source, $context["token"], "expiresAt", [], "any", false, false, false, 71)), "html", null, true);
                    yield "
                            ";
                }
                // line 73
                yield "                        </td>
                        <td>
                            ";
                // line 75
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_action_button", $context, 75, $this->getSourceContext())->macro_action_button(...["trash", ["url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("delete_api_token", ["id" => CoreExtension::getAttribute($this->env, $this->source, $context["token"], "id", [], "any", false, false, false, 75)]), "class" => "api-link", "attr" => ["data-question" => "confirm.delete", "data-event" => "kimai.accessToken", "data-method" => "DELETE", "data-question" => "confirm.delete", "data-msg-error" => "action.delete.error"]]]);
                // line 81
                yield "
                        </td>
                    </tr>
                ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['token'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 85
            yield "                </tbody>
            </table>
        ";
        }
        // line 88
        yield "
        ";
        // line 89
        yield from $this->load("user/api-token.html.twig", 89, 1)->unwrap()->yield(CoreExtension::merge($context, ["id" => "activity_invoice_settings"]));
        // line 101
        yield "
    </div>
";
        yield from [];
    }

    // line 105
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 106
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script type=\"text/javascript\">
        document.addEventListener(\x27kimai.initialized\x27, function() {
            KimaiReloadPageWidget.create(\x27kimai.accessToken\x27);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/api-token.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  264 => 106,  257 => 105,  250 => 101,  248 => 89,  245 => 88,  240 => 85,  230 => 81,  228 => 75,  224 => 73,  218 => 71,  216 => 70,  212 => 68,  206 => 66,  204 => 65,  199 => 63,  196 => 62,  192 => 61,  184 => 56,  180 => 55,  176 => 54,  171 => 51,  169 => 50,  166 => 49,  161 => 46,  155 => 43,  151 => 42,  145 => 39,  142 => 38,  140 => 37,  135 => 35,  130 => 33,  124 => 30,  119 => 28,  114 => 26,  111 => 25,  109 => 24,  98 => 20,  92 => 19,  84 => 18,  76 => 13,  70 => 10,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/api-token.html.twig", "/opt/kimai/templates/user/api-token.html.twig");
    }
}


/* user/api-token.html.twig */
class __TwigTemplate_e7b8156e14fb2f7d8ee9a1cb77c6b32a___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'box_class' => [$this, 'block_box_class'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 89
        return "@theme/embeds/collapsible.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 90
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 90)->unwrap();
        // line 89
        $this->parent = $this->load("@theme/embeds/collapsible.html.twig", 89);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 91
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("password"), "html", null, true);
        yield from [];
    }

    // line 92
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "mt-3";
        yield from [];
    }

    // line 93
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 94
        yield "            ";
        yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 94, $this->getSourceContext())->macro_alert(...["danger", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("api_password_deprecated")]);
        yield "
            ";
        // line 95
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start');
        yield "
                ";
        // line 96
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'widget');
        yield "
                <input type=\"submit\" value=\"";
        // line 97
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
        yield "\" class=\"btn btn-primary\" />
            ";
        // line 98
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
            ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/api-token.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  392 => 98,  388 => 97,  384 => 96,  380 => 95,  375 => 94,  368 => 93,  357 => 92,  346 => 91,  341 => 89,  339 => 90,  332 => 89,  264 => 106,  257 => 105,  250 => 101,  248 => 89,  245 => 88,  240 => 85,  230 => 81,  228 => 75,  224 => 73,  218 => 71,  216 => 70,  212 => 68,  206 => 66,  204 => 65,  199 => 63,  196 => 62,  192 => 61,  184 => 56,  180 => 55,  176 => 54,  171 => 51,  169 => 50,  166 => 49,  161 => 46,  155 => 43,  151 => 42,  145 => 39,  142 => 38,  140 => 37,  135 => 35,  130 => 33,  124 => 30,  119 => 28,  114 => 26,  111 => 25,  109 => 24,  98 => 20,  92 => 19,  84 => 18,  76 => 13,  70 => 10,  63 => 5,  56 => 4,  51 => 1,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/api-token.html.twig", "/opt/kimai/templates/user/api-token.html.twig");
    }
}
