<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* user/contract.html.twig */
class __TwigTemplate_cfca523c1f51be18df4f9f347c25d9da extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'form_content' => [$this, 'block_form_content'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "user/form.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("user/form.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_content(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 4
        yield "
    <script>
        function toggleWorkingContractModeForm(value)
        {
            document.querySelectorAll(\x27.work_contract_mode\x27).forEach(function (element) {
                element.classList.add(\x27d-none\x27);
            });

            // Show the element with the class \x27work_contract_mode_\x27 + value
            var elementToShow = document.querySelector(\x27.work_contract_mode_\x27 + value);
            if (elementToShow) {
                elementToShow.classList.remove(\x27d-none\x27);
            }
        }
    </script>

    ";
        // line 20
        $this->env->getRuntime("Symfony\\Component\\Form\\FormRenderer")->setTheme(($context["form"] ?? null), ["form/horizontal.html.twig"], true);
        // line 21
        yield "
    ";
        // line 22
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 22), 'row');
        yield "

    ";
        // line 24
        if (CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "workContractMode", [], "any", true, true, false, 24)) {
            // line 25
            yield "        <fieldset class=\"form-fieldset form-fieldset-light border-0 pb-0\">
            <legend>";
            // line 26
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("work_times_should"), "html", null, true);
            yield "</legend>
            ";
            // line 27
            yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "workContractMode", [], "any", false, false, false, 27), 'row', ["attr" => ["onchange" => "toggleWorkingContractModeForm(this.value)"]]);
            yield "
        </fieldset>
    ";
        }
        // line 30
        yield "
    ";
        // line 31
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 31), "workContractModes", [], "any", false, false, false, 31));
        foreach ($context['_seq'] as $context["_key"] => $context["mode"]) {
            // line 32
            yield "        <fieldset class=\"form-fieldset form-fieldset-light  border-0 work_contract_mode work_contract_mode_";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["mode"], "getId", [], "method", false, false, false, 32), "html", null, true);
            yield " ";
            if ((CoreExtension::getAttribute($this->env, $this->source, ($context["user"] ?? null), "getWorkContractMode", [], "method", false, false, false, 32) != CoreExtension::getAttribute($this->env, $this->source, $context["mode"], "getId", [], "method", false, false, false, 32))) {
                yield "d-none";
            }
            yield "\">
            ";
            // line 33
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(CoreExtension::getAttribute($this->env, $this->source, $context["mode"], "getFormFields", [], "method", false, false, false, 33));
            foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
                // line 34
                yield "                ";
                yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock((($_v0 = CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 34)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0[(($_v1 = $context["field"]) instanceof \Stringable ? (string) $_v1 : $_v1)] ?? null) : null), 'row');
                yield "
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 36
            yield "        </fieldset>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['mode'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 38
        yield "
    <fieldset class=\"form-fieldset form-fieldset-light\">";
        // line 40
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        // line 41
        yield "</fieldset>

";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "user/contract.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  145 => 41,  143 => 40,  140 => 38,  132 => 36,  122 => 34,  118 => 33,  109 => 32,  105 => 31,  102 => 30,  96 => 27,  92 => 26,  89 => 25,  87 => 24,  82 => 22,  79 => 21,  77 => 20,  59 => 4,  52 => 3,  41 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "user/contract.html.twig", "/opt/kimai/templates/user/contract.html.twig");
    }
}
