<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/callout.html.twig */
class __TwigTemplate_1683f6bcf66dd723401577975a27c6c6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_callout($type = null, $description = null, $title = null, $icon = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "type" => $type,
            "description" => $description,
            "title" => $title,
            "icon" => $icon,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 2
            yield "    ";
            $macros["_v0"] = $this->load("@Tabler/components/alert.html.twig", 2)->unwrap();
            // line 3
            yield "    ";
            if (is_iterable(($context["type"] ?? null))) {
                // line 4
                yield "        ";
                $context["type"] = Twig\Extension\CoreExtension::merge(["dismissible" => false, "important" => true], ($context["type"] ?? null));
                // line 5
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 5, $this->getSourceContext())->macro_alert(...[($context["type"] ?? null)]);
                yield "
    ";
            } else {
                // line 7
                yield "        ";
                trigger_deprecation('', '', "Passing multiple parameters to \x27callout()\x27 Tabler macro is deprecated, use options object syntax."." in \"@Tabler/components/callout.html.twig\" at line 7.");
                // line 8
                yield "        ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_alert", $context, 8, $this->getSourceContext())->macro_alert(...[["type" =>                 // line 9
($context["type"] ?? null), "description" => (((null ===                 // line 10
($context["description"] ?? null))) ? (null) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["description"] ?? null)))), "title" => (((null ===                 // line 11
($context["title"] ?? null))) ? (null) : ($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(($context["title"] ?? null)))), "icon" =>                 // line 12
($context["icon"] ?? null), "dismissible" => false, "important" => true]]);
                // line 15
                yield "
    ";
            }
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/callout.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  86 => 15,  84 => 12,  83 => 11,  82 => 10,  81 => 9,  79 => 8,  76 => 7,  70 => 5,  67 => 4,  64 => 3,  61 => 2,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/callout.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/callout.html.twig");
    }
}
