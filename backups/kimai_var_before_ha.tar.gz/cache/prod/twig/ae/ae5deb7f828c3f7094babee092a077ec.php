<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* quick-entry/index.html.twig */
class __TwigTemplate_6347f843787f0f86462cdd2146c0d08d extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'page_class' => [$this, 'block_page_class'],
            'main' => [$this, 'block_main'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "page_setup.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        $this->parent = $this->load("page_setup.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_page_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "quick-entry-page";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_main(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 6
        yield "    ";
        yield from $this->load("quick-entry/index.html.twig", 6, 1)->unwrap()->yield($context);
        yield from [];
    }

    // line 69
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_javascripts(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 70
        yield "    ";
        yield from $this->yieldParentBlock("javascripts", $context, $blocks);
        yield "
    <script>
        document.addEventListener(\x27kimai.initialized\x27, function(event) {
            const kimai = event.detail.kimai;
            const DATES = kimai.getPlugin(\x27date\x27);
            /** @type {KimaiFormSelect} FORM_SELECT */
            const FORM_SELECT = kimai.getPlugin(\x27form-select\x27);


            if (window.matchMedia(\"(max-width: 1360px)\").matches) {
                document.querySelector(\x27form[name=quick_entry_form] div.maybe-table-responsive\x27).classList.replace(\x27maybe-table-responsive\x27, \x27table-responsive\x27);
            }

            const recalculateTotals = () => {
                const allFields = document.getElementsByClassName(\x27duration-input\x27);
                let totalsPerDay = {0: 0, 1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 0};
                let fullTotals = 0;
                for (let durationInput of allFields) {
                    // turn a string like \"quick_entry_form_rows_16_timesheets_3_duration\" into \"3\"
                    // we can safely use -1 because there are only 0 (monday) to 6 (sunday) indexes
                    let id = durationInput.id.replace(/_duration/, \x27\x27).slice(-1);
                    totalsPerDay[id] += DATES.getSecondsFromDurationString(durationInput.value);
                }
                for (const [id, total] of Object.entries(totalsPerDay)) {
                    document.getElementById(\x27qe-totals-day-\x27 + id).innerText = DATES.formatSeconds(total);
                    fullTotals += total;
                }
                document.getElementById(\x27qe-totals-week\x27).innerText = DATES.formatSeconds(fullTotals);

                const allRows = document.getElementsByClassName(\x27qe-entry-week-row\x27);
                for (let qeWeekRow of allRows) {
                    let qeWeekRowFields = qeWeekRow.getElementsByClassName(\x27duration-input\x27);
                    let totalsRow = 0;
                    for (let durationInput of qeWeekRowFields) {
                        totalsRow += DATES.getSecondsFromDurationString(durationInput.value);
                    }
                    qeWeekRow.getElementsByClassName(\x27qe-totals-row\x27)[0].innerText = DATES.formatSeconds(totalsRow);
                }
            };
            recalculateTotals();

            document.getElementById(\x27quick-entries-form\x27).addEventListener(\x27click\x27, recalculateTotals);
            document.getElementById(\x27quick-entries-form\x27).addEventListener(\x27change\x27, recalculateTotals);

            ";
        // line 114
        if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 114), "rows", [], "any", false, false, false, 114), "vars", [], "any", false, false, false, 114), "allow_add", [], "any", false, false, false, 114)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 115
            yield "            const addFormToCollection = function(e) {
                const collectionHolder = document.getElementById(e.currentTarget.dataset.collectionHolder);
                const collectionPrototype = document.getElementById(e.currentTarget.dataset.collectionPrototype);

                const fakeNode = document.createElement(\x27table\x27);
                fakeNode.innerHTML = collectionPrototype
                    .dataset
                    .prototype
                    .replace(
                        /__name__/g,
                        collectionHolder.dataset.index
                    );

                let node = fakeNode.children[0];
                if (node.nodeName.toUpperCase() === \x27TBODY\x27) {
                    node = node.children[0];
                }

                collectionHolder.appendChild(node);

                [].slice.call(node.querySelectorAll(\x27.selectpicker\x27)).map((element) => {
                    FORM_SELECT.activateSelectPickerByElement(element);
                });

                collectionHolder.dataset.index++;
                recalculateTotals();
            };

            document.querySelectorAll(\x27.add-item-link\x27).forEach(btn => btn.addEventListener(\"click\", addFormToCollection));
            ";
        }
        // line 145
        yield "        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "quick-entry/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  167 => 145,  135 => 115,  133 => 114,  85 => 70,  78 => 69,  72 => 6,  65 => 5,  54 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "quick-entry/index.html.twig", "/opt/kimai/templates/quick-entry/index.html.twig");
    }
}


/* quick-entry/index.html.twig */
class __TwigTemplate_6347f843787f0f86462cdd2146c0d08d___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_class' => [$this, 'block_box_class'],
            'box_before' => [$this, 'block_box_before'],
            'box_after' => [$this, 'block_box_after'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 6
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 7)->unwrap();
        // line 6
        $this->parent = $this->load("@theme/embeds/card.html.twig", 6);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "id=\"quick_entry_box\"";
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "mt-2";
        yield from [];
    }

    // line 10
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 11
        yield "            ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ["attr" => ["id" => "quick-entries-form", "class" => "form-dataTable quick-entries"]]);
        yield "
            ";
        // line 12
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "_token", [], "any", false, false, false, 12), 'widget');
        yield "
            ";
        // line 13
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
        ";
        yield from [];
    }

    // line 15
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 16
        yield "            ";
        if ((($tmp = ($context["locked"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 17
            yield "                ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_alert", $context, 17, $this->getSourceContext())->macro_alert(...["warning", $this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("The chosen date is already locked.", [], "validators")]);
            yield "
            ";
        } else {
            // line 19
            yield "                <input type=\"submit\" value=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.save"), "html", null, true);
            yield "\" class=\"btn btn-primary\" />
                ";
            // line 20
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "children", [], "any", false, false, false, 20), "rows", [], "any", false, false, false, 20), "vars", [], "any", false, false, false, 20), "allow_add", [], "any", false, false, false, 20)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 21
                yield "                    <button type=\"button\" class=\"btn btn-success add-item-link\" data-collection-prototype=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "rows", [], "any", false, false, false, 21), "vars", [], "any", false, false, false, 21), "id", [], "any", false, false, false, 21), "html", null, true);
                yield "\" data-collection-holder=\"ts-collection\">
                        ";
                // line 22
                yield (string) $this->env->getRuntime('KevinPapst\TablerBundle\Twig\RuntimeExtension')->createIcon("create", true);
                yield "
                        ";
                // line 23
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.add"), "html", null, true);
                yield "
                    </button>
                ";
            }
            // line 26
            yield "            ";
        }
        // line 27
        yield "            ";
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield "
        ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "p-0 maybe-table-responsive";
        yield from [];
    }

    // line 31
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 32
        yield "            <table class=\"table dataTable\">
                <thead class=\"sticky-top\">
                    <tr>
                        <th>";
        // line 35
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("project"), "html", null, true);
        yield "</th>
                        <th>";
        // line 36
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activity"), "html", null, true);
        yield "</th>
                        ";
        // line 37
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(Twig\Extension\CoreExtension::sort($this->env, $this->env->hasExtension(\Twig\Extension\SandboxExtension::class) && $this->env->getExtension(\Twig\Extension\SandboxExtension::class)->isSandboxed($this->source), ($context["metaColumns"] ?? null), function ($__a__, $__b__) use ($context, $macros) { $context["a"] = $__a__; $context["b"] = $__b__; return (CoreExtension::getAttribute($this->env, $this->source, ($context["a"] ?? null), "order", [], "any", false, false, false, 37) <=> CoreExtension::getAttribute($this->env, $this->source, ($context["b"] ?? null), "order", [], "any", false, false, false, 37)); }));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 38
            yield "                            <th style=\"min-width: 70px\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["field"], "label", [], "any", false, false, false, 38), "html", null, true);
            yield "</th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 40
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["days"] ?? null));
        foreach ($context['_seq'] as $context["id"] => $context["week"]) {
            // line 41
            yield "                        <th class=\"text-center";
            if ($this->extensions['App\Twig\LocaleFormatExtensions']->isWeekend(CoreExtension::getAttribute($this->env, $this->source, $context["week"], "day", [], "any", false, false, false, 41))) {
                yield " weekend";
            }
            if ($this->env->getTest('today')->getCallable()(CoreExtension::getAttribute($this->env, $this->source, $context["week"], "day", [], "any", false, false, false, 41))) {
                yield " today";
            }
            yield "\">
                            ";
            // line 42
            yield (string) $this->extensions['App\Twig\LocaleFormatExtensions']->dateWeekday(CoreExtension::getAttribute($this->env, $this->source, $context["week"], "day", [], "any", false, false, false, 42));
            yield "
                        </th>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['week'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 45
        yield "                        <th class=\"summary\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("duration"), "html", null, true);
        yield "</th>
                    </tr>
                </thead>
                <tbody id=\"ts-collection\" data-index=\"";
        // line 48
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(Twig\Extension\CoreExtension::length($this->env->getCharset(), CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "rows", [], "any", false, false, false, 48), "children", [], "any", false, false, false, 48)), "html", null, true);
        yield "\">
                    ";
        // line 49
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "rows", [], "any", false, false, false, 49), 'widget');
        yield "
                </tbody>
                <tfoot>
                    <tr class=\"summary\">
                        <td>";
        // line 53
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("stats.durationTotal"), "html", null, true);
        yield "</td>
                        <td></td>
                        ";
        // line 55
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["metaColumns"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            // line 56
            yield "                            <td></td>
                        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['field'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 58
        yield "                        ";
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["days"] ?? null));
        $context['loop'] = [
          'parent' => $context['_parent'],
          'index0' => 0,
          'index'  => 1,
          'first'  => true,
        ];
        if (is_array($context['_seq']) || (is_object($context['_seq']) && $context['_seq'] instanceof \Countable)) {
            $length = count($context['_seq']);
            $context['loop']['revindex0'] = $length - 1;
            $context['loop']['revindex'] = $length;
            $context['loop']['length'] = $length;
            $context['loop']['last'] = 1 === $length;
        }
        foreach ($context['_seq'] as $context["id"] => $context["week"]) {
            // line 59
            yield "                            <td class=\"text-center total\" id=\"qe-totals-day-";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["loop"], "index0", [], "any", false, false, false, 59), "html", null, true);
            yield "\"></td>
                        ";
            ++$context['loop']['index0'];
            ++$context['loop']['index'];
            $context['loop']['first'] = false;
            if (isset($context['loop']['revindex0'], $context['loop']['revindex'])) {
                --$context['loop']['revindex0'];
                --$context['loop']['revindex'];
                $context['loop']['last'] = 0 === $context['loop']['revindex0'];
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['id'], $context['week'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 61
        yield "                        <td class=\"text-center total\" id=\"qe-totals-week\"></td>
                    </tr>
                </tfoot>
            </table>
        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "quick-entry/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  481 => 61,  463 => 59,  445 => 58,  437 => 56,  433 => 55,  428 => 53,  421 => 49,  417 => 48,  410 => 45,  400 => 42,  390 => 41,  385 => 40,  375 => 38,  371 => 37,  367 => 36,  363 => 35,  358 => 32,  351 => 31,  340 => 30,  332 => 27,  329 => 26,  323 => 23,  319 => 22,  314 => 21,  312 => 20,  307 => 19,  301 => 17,  298 => 16,  291 => 15,  284 => 13,  280 => 12,  275 => 11,  268 => 10,  257 => 9,  246 => 8,  241 => 6,  239 => 7,  232 => 6,  167 => 145,  135 => 115,  133 => 114,  85 => 70,  78 => 69,  72 => 6,  65 => 5,  54 => 3,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "quick-entry/index.html.twig", "/opt/kimai/templates/quick-entry/index.html.twig");
    }
}
