<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* tags/index.html.twig */
class __TwigTemplate_9d9423283cbd0034c38821362e2547f6 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'datatable_row_attr' => [$this, 'block_datatable_row_attr'],
            'datatable_column_value' => [$this, 'block_datatable_column_value'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "datatable.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 2)->unwrap();
        // line 3
        $macros["tables"] = $this->macros["tables"] = $this->load("macros/datatables.html.twig", 3)->unwrap();
        // line 5
        $context["manageAllowed"] = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("manage_tag");
        // line 1
        $this->parent = $this->load("datatable.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 7
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_row_attr(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ((($tmp = ($context["manageAllowed"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            yield " class=\"modal-ajax-form open-edit ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_class_tag_row", $context, 7, $this->getSourceContext())->macro_class_tag_row(...[($context["entry"] ?? null)]);
            yield "\" data-href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("tags_edit", ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 7)]), "html", null, true);
            yield "\" ";
        }
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_datatable_column_value(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 10
        yield "    ";
        if ((($context["column"] ?? null) == "name")) {
            // line 11
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_name", $context, 11, $this->getSourceContext())->macro_label_name(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 11), $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->colorize(CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "color", [], "any", false, false, false, 11), CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "name", [], "any", false, false, false, 11))]);
            yield "
    ";
        } elseif ((        // line 12
($context["column"] ?? null) == "amount")) {
            // line 13
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_counted", $context, 13, $this->getSourceContext())->macro_badge_counted(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "amount", [], "any", false, false, false, 13)]);
            yield "
    ";
        } elseif ((        // line 14
($context["column"] ?? null) == "visible")) {
            // line 15
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 15, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "visible", [], "any", false, false, false, 15)]);
            yield "
    ";
        } elseif ((        // line 16
($context["column"] ?? null) == "actions")) {
            // line 17
            yield "        ";
            $context["event"] = $this->env->getRuntime('App\Twig\Runtime\ThemeExtension')->actions(CoreExtension::getAttribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 17), "tag", "index", ["tag" => ($context["entry"] ?? null)]);
            // line 18
            yield "        ";
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_table_actions", $context, 18, $this->getSourceContext())->macro_table_actions(...[CoreExtension::getAttribute($this->env, $this->source, ($context["event"] ?? null), "actions", [], "any", false, false, false, 18)]);
            yield "
    ";
        } elseif ((        // line 19
($context["column"] ?? null) == "id")) {
            // line 20
            yield "        ";
            if ((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["dataTable"] ?? null), "hasBatchForm", [], "method", false, false, false, 20)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 21
                yield "            ";
                yield (string) $macros["tables"]->getTemplateForMacro("macro_datatable_multiupdate_row", $context, 21, $this->getSourceContext())->macro_datatable_multiupdate_row(...[CoreExtension::getAttribute($this->env, $this->source, ($context["entry"] ?? null), "id", [], "any", false, false, false, 21)]);
                yield "
        ";
            }
            // line 23
            yield "    ";
        }
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "tags/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  127 => 23,  121 => 21,  118 => 20,  116 => 19,  111 => 18,  108 => 17,  106 => 16,  101 => 15,  99 => 14,  94 => 13,  92 => 12,  87 => 11,  84 => 10,  77 => 9,  60 => 7,  55 => 1,  53 => 5,  51 => 3,  49 => 2,  42 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "tags/index.html.twig", "/opt/kimai/templates/tags/index.html.twig");
    }
}
