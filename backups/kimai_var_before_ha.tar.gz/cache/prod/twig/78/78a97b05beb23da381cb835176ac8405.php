<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @NelmioApiDoc/Scalar/index.html.twig */
class __TwigTemplate_f1595dfd1e2647398d68e7e41f01eed9 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'meta' => [$this, 'block_meta'],
            'title' => [$this, 'block_title'],
            'swagger_ui' => [$this, 'block_swagger_ui'],
            'swagger_initialization' => [$this, 'block_swagger_initialization'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html>
<head>
    ";
        // line 4
        yield from $this->unwrap()->yieldBlock('meta', $context, $blocks);
        // line 8
        yield "    <title>";
        yield from $this->unwrap()->yieldBlock('title', $context, $blocks);
        yield "</title>
</head>
<body>
    ";
        // line 11
        yield from $this->unwrap()->yieldBlock('swagger_ui', $context, $blocks);
        // line 14
        yield "    ";
        yield from $this->unwrap()->yieldBlock('swagger_initialization', $context, $blocks);
        // line 22
        yield "</body>
</html>
";
        yield from [];
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_meta(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 5
        yield "        <meta charset=\"UTF-8\">
        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    ";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["swagger_data"] ?? null), "spec", [], "any", false, false, false, 8), "info", [], "any", false, false, false, 8), "title", [], "any", false, false, false, 8), "html", null, true);
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_swagger_ui(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        yield "        <script id=\"api-reference\" type=\"application/json\">";
        yield (string) json_encode(CoreExtension::getAttribute($this->env, $this->source, ($context["swagger_data"] ?? null), "spec", [], "any", false, false, false, 12), 65);
        yield "</script>
    ";
        yield from [];
    }

    // line 14
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_swagger_initialization(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 15
        yield "        ";
        if ( !Twig\Extension\CoreExtension::testEmpty(($context["scalar_config"] ?? null))) {
            // line 16
            yield "        <script>
            document.getElementById(\x27api-reference\x27).dataset.configuration = JSON.stringify(";
            // line 17
            yield (string) json_encode(($context["scalar_config"] ?? null), 65);
            yield ");
        </script>
        ";
        }
        // line 20
        yield "        ";
        yield (string) $this->extensions['Nelmio\ApiDocBundle\Render\Html\GetNelmioAsset']->__invoke(($context["assets_mode"] ?? null), "scalar/scalar.standalone.js");
        yield "
    ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@NelmioApiDoc/Scalar/index.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  132 => 20,  126 => 17,  123 => 16,  120 => 15,  113 => 14,  105 => 12,  98 => 11,  87 => 8,  80 => 5,  73 => 4,  66 => 22,  63 => 14,  61 => 11,  54 => 8,  52 => 4,  47 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@NelmioApiDoc/Scalar/index.html.twig", "/opt/kimai/vendor/nelmio/api-doc-bundle/templates/Scalar/index.html.twig");
    }
}
