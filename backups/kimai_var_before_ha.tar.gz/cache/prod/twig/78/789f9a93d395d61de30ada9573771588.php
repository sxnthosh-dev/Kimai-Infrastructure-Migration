<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* project/embed_activities.html.twig */
class __TwigTemplate_f525faad681a93a497f163204e034407 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "    ";
        yield from $this->load("project/embed_activities.html.twig", 1, 1)->unwrap()->yield(CoreExtension::merge($context, ["project" => ($context["project"] ?? null), "activities" => ($context["activities"] ?? null), "page" => ($context["page"] ?? null), "id" => "activity_list_box"]));
        // line 48
        yield "    <script type=\"text/javascript\">
        ";
        // line 49
        $context["eventName"] = (((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["kimai_context"] ?? null), "javascriptRequest", [], "any", false, false, false, 49)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) ? ("kimai.reloadPage") : ("kimai.initialized"));
        // line 50
        yield "        document.addEventListener(\x27";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["eventName"] ?? null), "html", null, true);
        yield "\x27, function() {
            KimaiPaginatedBoxWidget.create(\x27#activity_list_box\x27);
        });
    </script>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/embed_activities.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  51 => 50,  49 => 49,  46 => 48,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/embed_activities.html.twig", "/opt/kimai/templates/project/embed_activities.html.twig");
    }
}


/* project/embed_activities.html.twig */
class __TwigTemplate_f525faad681a93a497f163204e034407___1 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'box_title' => [$this, 'block_box_title'],
            'box_attributes' => [$this, 'block_box_attributes'],
            'box_tools' => [$this, 'block_box_tools'],
            'box_footer' => [$this, 'block_box_footer'],
            'box_body_class' => [$this, 'block_box_body_class'],
            'box_body' => [$this, 'block_box_body'],
        ];
    }

    protected function doGetParent(array $context): bool|string|Template|TemplateWrapper
    {
        // line 1
        return "@theme/embeds/card.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 2
        $macros["actions"] = $this->macros["actions"] = $this->load("activity/actions.html.twig", 2)->unwrap();
        // line 3
        $macros["widgets"] = $this->macros["widgets"] = $this->load("macros/widgets.html.twig", 3)->unwrap();
        // line 1
        $this->parent = $this->load("@theme/embeds/card.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
    }

    // line 4
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("activities"), "html", null, true);
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_attributes(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield " data-reload=\"kimai.activityUpdate kimai.activityDelete\" ";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_tools(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 7
        if ((((($tmp = CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "visible", [], "any", false, false, false, 7)) && $tmp instanceof Markup ? (string) $tmp : $tmp) && (($tmp = CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "customer", [], "any", false, false, false, 7), "visible", [], "any", false, false, false, 7)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) && (($tmp = $this->extensions['Symfony\Bridge\Twig\Extension\SecurityExtension']->isGranted("create_activity")) && $tmp instanceof Markup ? (string) $tmp : $tmp))) {
            // line 8
            yield (string) $macros["widgets"]->getTemplateForMacro("macro_card_tool_button", $context, 8, $this->getSourceContext())->macro_card_tool_button(...["create", ["class" => "modal-ajax-form open-edit", "title" => "create", "url" => $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("admin_activity_create_with_project", ["project" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 8)])]]);
        }
        yield from [];
    }

    // line 11
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 12
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["activities"] ?? null)) > 0)) {
            // line 13
            yield "<div class=\"d-flex\">
                    ";
            // line 14
            yield (string) $this->extensions['App\Twig\PaginationExtension']->renderPagination(($context["activities"] ?? null), ["css_container_class" => "pagination ms-auto m-0", "routeName" => "project_activities", "routeParams" => ["id" => CoreExtension::getAttribute($this->env, $this->source, ($context["project"] ?? null), "id", [], "any", false, false, false, 14)]]);
            yield "
                </div>";
        }
        yield from [];
    }

    // line 18
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["activities"] ?? null)) > 0)) {
            yield "p-0";
        }
        yield from [];
    }

    // line 19
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_box_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 20
        yield "            ";
        if ((Twig\Extension\CoreExtension::length($this->env->getCharset(), ($context["activities"] ?? null)) == 0)) {
            // line 21
            yield "                <div class=\"comment\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("error.no_entries_found"), "html", null, true);
            yield "</div>
            ";
        } else {
            // line 23
            yield "                <table class=\"table table-hover dataTable\">
                    <thead>
                        <tr>
                            <th>";
            // line 26
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("name"), "html", null, true);
            yield "</th>
                            <th class=\"d-none d-md-table-cell\">";
            // line 27
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("comment"), "html", null, true);
            yield "</th>
                            <th class=\"d-none d-sm-table-cell w-min text-center\">";
            // line 28
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("visible"), "html", null, true);
            yield "</th>
                            <th class=\"d-none d-sm-table-cell w-min text-center\">";
            // line 29
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("team"), "html", null, true);
            yield "</th>
                            <th class=\"actions\"></th>
                        </tr>
                    </thead>
                    <tbody>
                    ";
            // line 34
            $context['_parent'] = $context;
            $context['_seq'] = CoreExtension::ensureTraversable(($context["activities"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["activity"]) {
                // line 35
                yield "                        <tr ";
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_activity_row_attr", $context, 35, $this->getSourceContext())->macro_activity_row_attr(...[$context["activity"], ($context["now"] ?? null)]);
                yield ">
                            <td>";
                // line 36
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_activity", $context, 36, $this->getSourceContext())->macro_label_activity(...[$context["activity"]]);
                yield "</td>
                            <td class=\"d-none d-md-table-cell\">";
                // line 37
                yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->commentOneLiner($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "comment", [], "any", false, false, false, 37), "html", null, true), false);
                yield "</td>
                            <td class=\"d-none d-sm-table-cell w-min text-center\">";
                // line 38
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_label_visible", $context, 38, $this->getSourceContext())->macro_label_visible(...[CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "visible", [], "any", false, false, false, 38)]);
                yield "</td>
                            <td class=\"d-none d-sm-table-cell w-min text-center\">";
                // line 39
                yield (string) $macros["widgets"]->getTemplateForMacro("macro_badge_team_access", $context, 39, $this->getSourceContext())->macro_badge_team_access(...[CoreExtension::getAttribute($this->env, $this->source, $context["activity"], "teams", [], "any", false, false, false, 39)]);
                yield "</td>
                            <td class=\"actions\">";
                // line 40
                yield (string) $macros["actions"]->getTemplateForMacro("macro_activity", $context, 40, $this->getSourceContext())->macro_activity(...[$context["activity"], "project_details", true]);
                yield "</td>
                        </tr>
                    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_key'], $context['activity'], $context['_parent']);
            $context = array_intersect_key($context, $_parent);
            $context += $_parent;
            // line 43
            yield "                    </tbody>
                </table>
            ";
        }
        // line 46
        yield "        ";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "project/embed_activities.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  287 => 46,  282 => 43,  272 => 40,  268 => 39,  264 => 38,  260 => 37,  256 => 36,  251 => 35,  247 => 34,  239 => 29,  235 => 28,  231 => 27,  227 => 26,  222 => 23,  216 => 21,  213 => 20,  206 => 19,  193 => 18,  185 => 14,  182 => 13,  180 => 12,  173 => 11,  167 => 8,  165 => 7,  158 => 6,  147 => 5,  136 => 4,  131 => 1,  129 => 3,  127 => 2,  120 => 1,  51 => 50,  49 => 49,  46 => 48,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "project/embed_activities.html.twig", "/opt/kimai/templates/project/embed_activities.html.twig");
    }
}
