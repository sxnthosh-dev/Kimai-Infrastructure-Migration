<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* invoice/renderer/service-date.pdf.twig */
class __TwigTemplate_befc7b4cc8bd208bcf9fd72cbcea7c3a extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        yield "<!DOCTYPE html>
<html lang=\"";
        // line 2
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v0 = ($context["invoice"] ?? null)) && is_array($_v0) || $_v0 instanceof ArrayAccess ? ($_v0["invoice.language"] ?? null) : null), "html", null, true);
        yield "\">
<head>
    <meta charset=\"utf-8\">
    <title>";
        // line 5
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v1 = ($context["invoice"] ?? null)) && is_array($_v1) || $_v1 instanceof ArrayAccess ? ($_v1["invoice.number"] ?? null) : null), "html", null, true);
        yield "-";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(CoreExtension::getAttribute($this->env, $this->source, $this->extensions['Twig\Extra\String\StringExtension']->createUnicodeString(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 5)) ? (Twig\Extension\CoreExtension::default((($_v2 = ($context["invoice"] ?? null)) && is_array($_v2) || $_v2 instanceof ArrayAccess ? ($_v2["customer.company"] ?? null) : null), (($_v3 = ($context["invoice"] ?? null)) && is_array($_v3) || $_v3 instanceof ArrayAccess ? ($_v3["customer.name"] ?? null) : null))) : ((($_v4 = ($context["invoice"] ?? null)) && is_array($_v4) || $_v4 instanceof ArrayAccess ? ($_v4["customer.name"] ?? null) : null)))), "snake", [], "any", false, false, false, 5), "html", null, true);
        yield "</title>
    <style>
        ";
        // line 7
        yield (string) $this->env->getRuntime('App\Twig\Runtime\EncoreExtension')->getEncoreEntryCssSource("invoice-pdf");
        yield "
    </style>
</head>
<body>
<!--mpdf
<htmlpageheader name=\"header\">
    <table class=\"header\">
        <tr>
            <td class=\"text-small\">
                ";
        // line 16
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v5 = ($context["invoice"] ?? null)) && is_array($_v5) || $_v5 instanceof ArrayAccess ? ($_v5["template.company"] ?? null) : null), "html", null, true);
        yield " &ndash; ";
        yield (string) $this->extensions['App\Twig\Extensions']->replaceNewline($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v6 = ($context["invoice"] ?? null)) && is_array($_v6) || $_v6 instanceof ArrayAccess ? ($_v6["template.address"] ?? null) : null), "html", null, true), " – ");
        yield "
                ";
        // line 17
        if ( !(null === (($_v7 = ($context["invoice"] ?? null)) && is_array($_v7) || $_v7 instanceof ArrayAccess ? ($_v7["template.country"] ?? null) : null))) {
            // line 18
            yield "                    ";
            $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v8 = ($context["invoice"] ?? null)) && is_array($_v8) || $_v8 instanceof ArrayAccess ? ($_v8["template.country"] ?? null) : null), (($_v9 = ($context["invoice"] ?? null)) && is_array($_v9) || $_v9 instanceof ArrayAccess ? ($_v9["invoice.language"] ?? null) : null));
            // line 19
            yield "                    ";
            if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v10 = ($context["invoice"] ?? null)) && is_array($_v10) || $_v10 instanceof ArrayAccess ? ($_v10["template.address"] ?? null) : null))) {
                // line 20
                yield "                        – ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
                yield "
                    ";
            }
            // line 22
            yield "                ";
        }
        // line 23
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v11 = ($context["invoice"] ?? null)) && is_array($_v11) || $_v11 instanceof ArrayAccess ? ($_v11["template.vat_id"] ?? null) : null))) {
            // line 24
            yield "                    &ndash; ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v12 = ($context["invoice"] ?? null)) && is_array($_v12) || $_v12 instanceof ArrayAccess ? ($_v12["template.vat_id"] ?? null) : null), "html", null, true);
            yield "
                ";
        }
        // line 26
        yield "            </td>
            <td class=\"text-small text-right\">
                ";
        // line 28
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("export.page_of", ["%page%" => "{PAGENO}", "%pages%" => "{nb}"]), "html", null, true);
        yield "
            </td>
        </tr>
    </table>
</htmlpageheader>
<sethtmlpageheader name=\"header\" page=\"ALL\" value=\"on\" show-this-page=\"1\" />
<htmlpagefooter name=\"footer\">
    <table class=\"footer text-small\">
        <tr>
            <td style=\"width: 33%\">
                <strong>";
        // line 38
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("address"), "html", null, true);
        yield "</strong>
                <br>
                ";
        // line 40
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v13 = ($context["invoice"] ?? null)) && is_array($_v13) || $_v13 instanceof ArrayAccess ? ($_v13["template.company"] ?? null) : null), "html", null, true);
        yield "<br>
                ";
        // line 41
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v14 = ($context["invoice"] ?? null)) && is_array($_v14) || $_v14 instanceof ArrayAccess ? ($_v14["template.address"] ?? null) : null), "html", null, true));
        yield "
                ";
        // line 42
        if ( !(null === (($_v15 = ($context["invoice"] ?? null)) && is_array($_v15) || $_v15 instanceof ArrayAccess ? ($_v15["template.country"] ?? null) : null))) {
            // line 43
            yield "                    ";
            $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v16 = ($context["invoice"] ?? null)) && is_array($_v16) || $_v16 instanceof ArrayAccess ? ($_v16["template.country"] ?? null) : null), (($_v17 = ($context["invoice"] ?? null)) && is_array($_v17) || $_v17 instanceof ArrayAccess ? ($_v17["invoice.language"] ?? null) : null));
            // line 44
            yield "                    ";
            if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v18 = ($context["invoice"] ?? null)) && is_array($_v18) || $_v18 instanceof ArrayAccess ? ($_v18["template.address"] ?? null) : null))) {
                // line 45
                yield "                        <br> ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
                yield "
                    ";
            }
            // line 47
            yield "                ";
        }
        // line 48
        yield "            </td>
            <td class=\"text-center\">
                <strong>";
        // line 50
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice_bank_account"), "html", null, true);
        yield "</strong>
                <br>
                ";
        // line 52
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v19 = ($context["invoice"] ?? null)) && is_array($_v19) || $_v19 instanceof ArrayAccess ? ($_v19["template.payment_details"] ?? null) : null), "html", null, true));
        yield "
            </td>
            <td class=\"text-right\" style=\"width: 33%\">
                <strong>";
        // line 55
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("contact"), "html", null, true);
        yield "</strong>
                <br>
                ";
        // line 57
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v20 = ($context["invoice"] ?? null)) && is_array($_v20) || $_v20 instanceof ArrayAccess ? ($_v20["template.contact"] ?? null) : null), "html", null, true));
        yield "
            </td>
        </tr>
    </table>
</htmlpagefooter>
<sethtmlpagefooter page=\"ALL\" value=\"on\" name=\"footer\" show-this-page=\"1\" />
mpdf-->
    <table class=\"addresses\">
        <tr>
            <td>
                <strong>";
        // line 67
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(((CoreExtension::getAttribute($this->env, $this->source, ($context["invoice"] ?? null), "customer.company", [], "array", true, true, false, 67)) ? (Twig\Extension\CoreExtension::default((($_v21 = ($context["invoice"] ?? null)) && is_array($_v21) || $_v21 instanceof ArrayAccess ? ($_v21["customer.company"] ?? null) : null), (($_v22 = ($context["invoice"] ?? null)) && is_array($_v22) || $_v22 instanceof ArrayAccess ? ($_v22["customer.name"] ?? null) : null))) : ((($_v23 = ($context["invoice"] ?? null)) && is_array($_v23) || $_v23 instanceof ArrayAccess ? ($_v23["customer.name"] ?? null) : null))), "html", null, true);
        yield "</strong><br>
                ";
        // line 68
        yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v24 = ($context["invoice"] ?? null)) && is_array($_v24) || $_v24 instanceof ArrayAccess ? ($_v24["customer.address"] ?? null) : null), "html", null, true));
        yield "
                ";
        // line 69
        $context["country"] = $this->extensions['Twig\Extra\Intl\IntlExtension']->getCountryName((($_v25 = ($context["invoice"] ?? null)) && is_array($_v25) || $_v25 instanceof ArrayAccess ? ($_v25["customer.country"] ?? null) : null), (($_v26 = ($context["invoice"] ?? null)) && is_array($_v26) || $_v26 instanceof ArrayAccess ? ($_v26["invoice.language"] ?? null) : null));
        // line 70
        yield "                ";
        if (!CoreExtension::inFilter(($context["country"] ?? null), (($_v27 = ($context["invoice"] ?? null)) && is_array($_v27) || $_v27 instanceof ArrayAccess ? ($_v27["customer.address"] ?? null) : null))) {
            // line 71
            yield "                    <br> ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["country"] ?? null), "html", null, true);
            yield "
                ";
        }
        // line 73
        yield "                ";
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v28 = ($context["invoice"] ?? null)) && is_array($_v28) || $_v28 instanceof ArrayAccess ? ($_v28["customer.vat_id"] ?? null) : null))) {
            // line 74
            yield "                    <br>";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("vat_id"), "html", null, true);
            yield ": ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v29 = ($context["invoice"] ?? null)) && is_array($_v29) || $_v29 instanceof ArrayAccess ? ($_v29["customer.vat_id"] ?? null) : null), "html", null, true);
            yield "
                ";
        }
        // line 76
        yield "            </td>
            <td class=\"text-right\">
                ";
        // line 78
        $context["classLeft"] = "text-left";
        // line 79
        yield "                ";
        $context["classRight"] = "text-right text-nowrap padding-left";
        // line 80
        yield "                <table style=\"width: 270px\">
                    <tr>
                        <td class=\"";
        // line 82
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("date"), "html", null, true);
        yield "</td>
                        <td class=\"";
        // line 83
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v30 = ($context["invoice"] ?? null)) && is_array($_v30) || $_v30 instanceof ArrayAccess ? ($_v30["invoice.date"] ?? null) : null), "html", null, true);
        yield "</td>
                    </tr>
                    <tr>
                        <td class=\"";
        // line 86
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.service_date"), "html", null, true);
        yield "</td>
                        <td class=\"";
        // line 87
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
        yield "\">
                            ";
        // line 88
        if ((((($_v31 = ($context["invoice"] ?? null)) && is_array($_v31) || $_v31 instanceof ArrayAccess ? ($_v31["invoice.first_month"] ?? null) : null) != (($_v32 = ($context["invoice"] ?? null)) && is_array($_v32) || $_v32 instanceof ArrayAccess ? ($_v32["invoice.last_month"] ?? null) : null)) || ((($_v33 = ($context["invoice"] ?? null)) && is_array($_v33) || $_v33 instanceof ArrayAccess ? ($_v33["invoice.first_year"] ?? null) : null) != (($_v34 = ($context["invoice"] ?? null)) && is_array($_v34) || $_v34 instanceof ArrayAccess ? ($_v34["invoice.last_year"] ?? null) : null)))) {
            // line 89
            yield "                            ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v35 = ($context["invoice"] ?? null)) && is_array($_v35) || $_v35 instanceof ArrayAccess ? ($_v35["invoice.first_month"] ?? null) : null), "html", null, true);
            yield " ";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v36 = ($context["invoice"] ?? null)) && is_array($_v36) || $_v36 instanceof ArrayAccess ? ($_v36["invoice.first_year"] ?? null) : null), "html", null, true);
            yield "
                            &ndash;
                            ";
        }
        // line 92
        yield "                            ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v37 = ($context["invoice"] ?? null)) && is_array($_v37) || $_v37 instanceof ArrayAccess ? ($_v37["invoice.last_month"] ?? null) : null), "html", null, true);
        yield " ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v38 = ($context["invoice"] ?? null)) && is_array($_v38) || $_v38 instanceof ArrayAccess ? ($_v38["invoice.last_year"] ?? null) : null), "html", null, true);
        yield "
                        </td>
                    </tr>
                    <tr>
                        <td class=\"";
        // line 96
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.number"), "html", null, true);
        yield "</td>
                        <td class=\"";
        // line 97
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v39 = ($context["invoice"] ?? null)) && is_array($_v39) || $_v39 instanceof ArrayAccess ? ($_v39["invoice.number"] ?? null) : null), "html", null, true);
        yield "</td>
                    </tr>
                    <tr>
                        <td class=\"";
        // line 100
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.due_days"), "html", null, true);
        yield "</td>
                        <td class=\"";
        // line 101
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
        yield "\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v40 = ($context["invoice"] ?? null)) && is_array($_v40) || $_v40 instanceof ArrayAccess ? ($_v40["invoice.due_date"] ?? null) : null), "html", null, true);
        yield "</td>
                    </tr>
                    ";
        // line 103
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v41 = ($context["invoice"] ?? null)) && is_array($_v41) || $_v41 instanceof ArrayAccess ? ($_v41["customer.number"] ?? null) : null))) {
            // line 104
            yield "                        <tr>
                            <td class=\"";
            // line 105
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("number"), "html", null, true);
            yield "</td>
                            <td class=\"";
            // line 106
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v42 = ($context["invoice"] ?? null)) && is_array($_v42) || $_v42 instanceof ArrayAccess ? ($_v42["customer.number"] ?? null) : null), "html", null, true);
            yield "</td>
                        </tr>
                    ";
        }
        // line 109
        yield "                    ";
        if ((((($_v43 = ($context["invoice"] ?? null)) && is_array($_v43) || $_v43 instanceof ArrayAccess ? ($_v43["project.counter"] ?? null) : null) == 1) &&  !Twig\Extension\CoreExtension::testEmpty((($_v44 = ($context["invoice"] ?? null)) && is_array($_v44) || $_v44 instanceof ArrayAccess ? ($_v44["project.order_number"] ?? null) : null)))) {
            // line 110
            yield "                        <tr>
                            <td class=\"";
            // line 111
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classLeft"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("orderNumber"), "html", null, true);
            yield "</td>
                            <td class=\"";
            // line 112
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classRight"] ?? null), "html", null, true);
            yield "\">";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v45 = ($context["invoice"] ?? null)) && is_array($_v45) || $_v45 instanceof ArrayAccess ? ($_v45["project.order_number"] ?? null) : null), "html", null, true);
            yield "</td>
                        </tr>
                    ";
        }
        // line 115
        yield "                </table>
            </td>
        </tr>
    </table>

    <h2 style=\"margin-top: 60px; margin-bottom: 20px;\">";
        // line 120
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v46 = ($context["invoice"] ?? null)) && is_array($_v46) || $_v46 instanceof ArrayAccess ? ($_v46["template.title"] ?? null) : null), "html", null, true);
        yield "</h2>

    ";
        // line 122
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v47 = ($context["invoice"] ?? null)) && is_array($_v47) || $_v47 instanceof ArrayAccess ? ($_v47["customer.invoice_text"] ?? null) : null))) {
            // line 123
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v48 = ($context["invoice"] ?? null)) && is_array($_v48) || $_v48 instanceof ArrayAccess ? ($_v48["customer.invoice_text"] ?? null) : null));
            yield "
    ";
        }
        // line 125
        yield "
    ";
        // line 126
        if ((((($_v49 = ($context["invoice"] ?? null)) && is_array($_v49) || $_v49 instanceof ArrayAccess ? ($_v49["project.counter"] ?? null) : null) == 1) &&  !Twig\Extension\CoreExtension::testEmpty((($_v50 = ($context["invoice"] ?? null)) && is_array($_v50) || $_v50 instanceof ArrayAccess ? ($_v50["project.invoice_text"] ?? null) : null)))) {
            // line 127
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v51 = ($context["invoice"] ?? null)) && is_array($_v51) || $_v51 instanceof ArrayAccess ? ($_v51["project.invoice_text"] ?? null) : null));
            yield "
    ";
        }
        // line 129
        yield "
    <table class=\"items\">
        <thead>
            <tr>
                <th class=\"first\">";
        // line 133
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("description"), "html", null, true);
        yield "</th>
                <th class=\"text-right\">";
        // line 134
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("unit_price"), "html", null, true);
        yield "</th>
                <th class=\"text-right\">";
        // line 135
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("amount"), "html", null, true);
        yield "</th>
                <th class=\"last text-right\">";
        // line 136
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("total_rate"), "html", null, true);
        yield "</th>
            </tr>
        </thead>
        <tbody>
        ";
        // line 140
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable(($context["entries"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["invoiceLineItem"]) {
            // line 141
            yield "            <!-- CONTENT_PART -->
            <tr>
                <td class=\"first\">
                    ";
            // line 144
            if ( !Twig\Extension\CoreExtension::testEmpty((($_v52 = $context["invoiceLineItem"]) && is_array($_v52) || $_v52 instanceof ArrayAccess ? ($_v52["entry.description"] ?? null) : null))) {
                // line 145
                yield "                        ";
                yield (string) Twig\Extension\CoreExtension::nl2br($this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v53 = $context["invoiceLineItem"]) && is_array($_v53) || $_v53 instanceof ArrayAccess ? ($_v53["entry.description"] ?? null) : null), "html", null, true));
                yield "
                    ";
            } else {
                // line 147
                yield "                        ";
                if (CoreExtension::getAttribute($this->env, $this->source, $context["invoiceLineItem"], "entry.activity", [], "array", true, true, false, 147)) {
                    // line 148
                    yield "                            ";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v54 = $context["invoiceLineItem"]) && is_array($_v54) || $_v54 instanceof ArrayAccess ? ($_v54["entry.activity"] ?? null) : null), "html", null, true);
                    yield " /
                        ";
                }
                // line 150
                yield "                        ";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v55 = $context["invoiceLineItem"]) && is_array($_v55) || $_v55 instanceof ArrayAccess ? ($_v55["entry.project"] ?? null) : null), "html", null, true);
                yield "
                    ";
            }
            // line 152
            yield "                </td>
                <td class=\"text-right text-nowrap\">";
            // line 153
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v56 = $context["invoiceLineItem"]) && is_array($_v56) || $_v56 instanceof ArrayAccess ? ($_v56["entry.rate"] ?? null) : null), "html", null, true);
            yield "</td>
                <td class=\"text-right text-nowrap\">";
            // line 154
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v57 = $context["invoiceLineItem"]) && is_array($_v57) || $_v57 instanceof ArrayAccess ? ($_v57["entry.amount"] ?? null) : null), "html", null, true);
            yield "</td>
                <td class=\"last text-right text-nowrap\">";
            // line 155
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v58 = $context["invoiceLineItem"]) && is_array($_v58) || $_v58 instanceof ArrayAccess ? ($_v58["entry.total"] ?? null) : null), "html", null, true);
            yield "</td>
            </tr>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['invoiceLineItem'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 158
        yield "        </tbody>
        <tfoot>
            <tr>
                <td colspan=\"3\" class=\"text-right\">
                    ";
        // line 162
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.subtotal"), "html", null, true);
        yield "
                </td>
                <td class=\"last text-right\">";
        // line 164
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v59 = ($context["invoice"] ?? null)) && is_array($_v59) || $_v59 instanceof ArrayAccess ? ($_v59["invoice.subtotal"] ?? null) : null), "html", null, true);
        yield "</td>
            </tr>
            ";
        // line 166
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v60 = ($context["invoice"] ?? null)) && is_array($_v60) || $_v60 instanceof ArrayAccess ? ($_v60["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 167
            yield "                ";
            if ((($tmp = (($_v61 = $context["taxRow"]) && is_array($_v61) || $_v61 instanceof ArrayAccess ? ($_v61["show"] ?? null) : null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 168
                yield "                    <tr>
                        <td colspan=\"3\" class=\"text-right\">
                            ";
                // line 170
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v62 = $context["taxRow"]) && is_array($_v62) || $_v62 instanceof ArrayAccess ? ($_v62["name"] ?? null) : null)), "html", null, true);
                yield " (";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v63 = $context["taxRow"]) && is_array($_v63) || $_v63 instanceof ArrayAccess ? ($_v63["rate"] ?? null) : null), "html", null, true);
                yield "%)
                            ";
                // line 171
                if ( !(null === (($_v64 = $context["taxRow"]) && is_array($_v64) || $_v64 instanceof ArrayAccess ? ($_v64["note"] ?? null) : null))) {
                    // line 172
                    yield "                                <sup>[";
                    yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v65 = $context["taxRow"]) && is_array($_v65) || $_v65 instanceof ArrayAccess ? ($_v65["counter"] ?? null) : null), "html", null, true);
                    yield "]</sup>
                            ";
                }
                // line 174
                yield "                        </td>
                        <td class=\"last text-right\">";
                // line 175
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\LocaleFormatExtensions']->money((($_v66 = $context["taxRow"]) && is_array($_v66) || $_v66 instanceof ArrayAccess ? ($_v66["amount"] ?? null) : null), (($_v67 = $context["taxRow"]) && is_array($_v67) || $_v67 instanceof ArrayAccess ? ($_v67["currency"] ?? null) : null)), "html", null, true);
                yield "</td>
                    </tr>
                ";
            }
            // line 178
            yield "            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 179
        yield "            <tr>
                <td colspan=\"3\" class=\"text-right text-nowrap\">
                    <strong>";
        // line 181
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("invoice.total"), "html", null, true);
        yield "</strong>
                </td>
                <td class=\"last text-right\">
                    <strong>";
        // line 184
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v68 = ($context["invoice"] ?? null)) && is_array($_v68) || $_v68 instanceof ArrayAccess ? ($_v68["invoice.total"] ?? null) : null), "html", null, true);
        yield "</strong>
                </td>
            </tr>
        </tfoot>
    </table>

    ";
        // line 190
        $context['_parent'] = $context;
        $context['_seq'] = CoreExtension::ensureTraversable((($_v69 = ($context["invoice"] ?? null)) && is_array($_v69) || $_v69 instanceof ArrayAccess ? ($_v69["invoice.tax_rows"] ?? null) : null));
        foreach ($context['_seq'] as $context["_key"] => $context["taxRow"]) {
            // line 191
            yield "        ";
            if ( !(null === (($_v70 = $context["taxRow"]) && is_array($_v70) || $_v70 instanceof ArrayAccess ? ($_v70["note"] ?? null) : null))) {
                // line 192
                yield "            <p>
                <sup>[";
                // line 193
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((($_v71 = $context["taxRow"]) && is_array($_v71) || $_v71 instanceof ArrayAccess ? ($_v71["counter"] ?? null) : null), "html", null, true);
                yield "]</sup>
                ";
                // line 194
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans((($_v72 = $context["taxRow"]) && is_array($_v72) || $_v72 instanceof ArrayAccess ? ($_v72["note"] ?? null) : null)), "html", null, true);
                yield "
            </p>
        ";
            }
            // line 197
            yield "    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_key'], $context['taxRow'], $context['_parent']);
        $context = array_intersect_key($context, $_parent);
        $context += $_parent;
        // line 198
        yield "
    ";
        // line 199
        if ( !Twig\Extension\CoreExtension::testEmpty((($_v73 = ($context["invoice"] ?? null)) && is_array($_v73) || $_v73 instanceof ArrayAccess ? ($_v73["template.payment_terms"] ?? null) : null))) {
            // line 200
            yield "        ";
            yield (string) $this->env->getRuntime('App\Twig\Runtime\MarkdownExtension')->markdownToHtml((($_v74 = ($context["invoice"] ?? null)) && is_array($_v74) || $_v74 instanceof ArrayAccess ? ($_v74["template.payment_terms"] ?? null) : null));
            yield "
    ";
        }
        // line 202
        yield "</body>
</html>
";
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "invoice/renderer/service-date.pdf.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  562 => 202,  556 => 200,  554 => 199,  551 => 198,  544 => 197,  538 => 194,  534 => 193,  531 => 192,  528 => 191,  524 => 190,  515 => 184,  509 => 181,  505 => 179,  498 => 178,  492 => 175,  489 => 174,  483 => 172,  481 => 171,  475 => 170,  471 => 168,  468 => 167,  464 => 166,  459 => 164,  454 => 162,  448 => 158,  438 => 155,  434 => 154,  430 => 153,  427 => 152,  421 => 150,  415 => 148,  412 => 147,  406 => 145,  404 => 144,  399 => 141,  395 => 140,  388 => 136,  384 => 135,  380 => 134,  376 => 133,  370 => 129,  364 => 127,  362 => 126,  359 => 125,  353 => 123,  351 => 122,  346 => 120,  339 => 115,  331 => 112,  325 => 111,  322 => 110,  319 => 109,  311 => 106,  305 => 105,  302 => 104,  300 => 103,  293 => 101,  287 => 100,  279 => 97,  273 => 96,  263 => 92,  254 => 89,  252 => 88,  248 => 87,  242 => 86,  234 => 83,  228 => 82,  224 => 80,  221 => 79,  219 => 78,  215 => 76,  207 => 74,  204 => 73,  198 => 71,  195 => 70,  193 => 69,  189 => 68,  185 => 67,  172 => 57,  167 => 55,  161 => 52,  156 => 50,  152 => 48,  149 => 47,  143 => 45,  140 => 44,  137 => 43,  135 => 42,  131 => 41,  127 => 40,  122 => 38,  109 => 28,  105 => 26,  97 => 24,  94 => 23,  91 => 22,  85 => 20,  82 => 19,  79 => 18,  77 => 17,  71 => 16,  59 => 7,  52 => 5,  46 => 2,  43 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "invoice/renderer/service-date.pdf.twig", "/opt/kimai/templates/invoice/renderer/service-date.pdf.twig");
    }
}
