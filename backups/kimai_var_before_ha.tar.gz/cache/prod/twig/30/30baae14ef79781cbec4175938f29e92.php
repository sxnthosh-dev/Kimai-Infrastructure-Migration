<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* default/_form_modal.html.twig */
class __TwigTemplate_a267eaf99861deecfb7b6f086c8de595 extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'modal_class' => [$this, 'block_modal_class'],
            'modal_id' => [$this, 'block_modal_id'],
            'modal_size' => [$this, 'block_modal_size'],
            'form_before' => [$this, 'block_form_before'],
            'modal_before' => [$this, 'block_modal_before'],
            'modal_title' => [$this, 'block_modal_title'],
            'modal_body' => [$this, 'block_modal_body'],
            'form_body_outer' => [$this, 'block_form_body_outer'],
            'form_body_pre' => [$this, 'block_form_body_pre'],
            'form_body' => [$this, 'block_form_body'],
            'form_body_post' => [$this, 'block_form_body_post'],
            'modal_footer' => [$this, 'block_modal_footer'],
            'submit_button' => [$this, 'block_submit_button'],
            'modal_end' => [$this, 'block_modal_end'],
            'form_after' => [$this, 'block_form_after'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 1
        $context["bodyClasses"] = "modal-body";
        // line 2
        if ((($tmp = (((array_key_exists("fullsize", $context) &&  !(null === $context["fullsize"]))) ? ($context["fullsize"]) : (false))) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
            // line 3
            yield "    ";
            $context["bodyClasses"] = (($context["bodyClasses"] ?? null) . " p-0");
        }
        // line 5
        yield "<div class=\"modal ";
        yield from $this->unwrap()->yieldBlock('modal_class', $context, $blocks);
        yield "\" id=\"";
        yield from $this->unwrap()->yieldBlock('modal_id', $context, $blocks);
        yield "\" tabindex=\"-1\" role=\"dialog\" aria-labelledby=\"";
        yield from         $this->unwrap()->yieldBlock("modal_id", $context, $blocks);
        yield "_label\">
    <div class=\"modal-dialog ";
        // line 6
        yield from $this->unwrap()->yieldBlock('modal_size', $context, $blocks);
        yield "\" role=\"document\">
        <div class=\"modal-content\">
            ";
        // line 8
        yield from $this->unwrap()->yieldBlock('form_before', $context, $blocks);
        // line 9
        yield "            ";
        yield from $this->unwrap()->yieldBlock('modal_before', $context, $blocks);
        // line 10
        yield "            <div class=\"modal-header\">
                <h5 class=\"modal-title\" id=\"";
        // line 11
        yield from         $this->unwrap()->yieldBlock("modal_id", $context, $blocks);
        yield "_label\">
                    ";
        // line 12
        yield from $this->unwrap()->yieldBlock('modal_title', $context, $blocks);
        // line 18
        yield "                </h5>
                <button type=\"button\" class=\"btn-close\" data-bs-dismiss=\"modal\" aria-label=\"";
        // line 19
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
        yield "\"></button>
            </div>
            <div class=\"";
        // line 21
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["bodyClasses"] ?? null), "html", null, true);
        yield "\">
                ";
        // line 22
        yield from $this->unwrap()->yieldBlock('modal_body', $context, $blocks);
        // line 34
        yield "            </div>
            <div class=\"modal-footer\">
                ";
        // line 36
        yield from $this->unwrap()->yieldBlock('modal_footer', $context, $blocks);
        // line 42
        yield "            </div>
            ";
        // line 43
        yield from $this->unwrap()->yieldBlock('modal_end', $context, $blocks);
        // line 44
        yield "            ";
        yield from $this->unwrap()->yieldBlock('form_after', $context, $blocks);
        // line 45
        yield "        </div>
    </div>
</div>
";
        yield from [];
    }

    // line 5
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_class(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_id(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "form_modal";
        yield from [];
    }

    // line 6
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_size(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield "modal-lg";
        yield from [];
    }

    // line 8
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 9
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_before(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_start', ((array_key_exists("formStartOptions", $context)) ? (Twig\Extension\CoreExtension::default(($context["formStartOptions"] ?? null), [])) : ([])));
        yield from [];
    }

    // line 12
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_title(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 13
        yield "                        ";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["title"] ?? null), "html", null, true);
        yield "
                        ";
        // line 14
        if ((CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, true, false, 14), "docu_chapter", [], "any", true, true, false, 14) &&  !Twig\Extension\CoreExtension::testEmpty(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 14), "docu_chapter", [], "any", false, false, false, 14)))) {
            // line 15
            yield "                            <a class=\"form-help\" href=\"";
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['App\Twig\Extensions']->documentationLink(CoreExtension::getAttribute($this->env, $this->source, CoreExtension::getAttribute($this->env, $this->source, ($context["form"] ?? null), "vars", [], "any", false, false, false, 15), "docu_chapter", [], "any", false, false, false, 15), "form"), "html", null, true);
            yield "\" target=\"_blank\">?</a>
                        ";
        }
        // line 17
        yield "                    ";
        yield from [];
    }

    // line 22
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 23
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('form_body_outer', $context, $blocks);
        // line 33
        yield "                ";
        yield from [];
    }

    // line 23
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_outer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 24
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('form_body_pre', $context, $blocks);
        // line 27
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('form_body', $context, $blocks);
        // line 30
        yield "                        ";
        yield from $this->unwrap()->yieldBlock('form_body_post', $context, $blocks);
        // line 32
        yield "                    ";
        yield from [];
    }

    // line 24
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_pre(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 25
        yield "                            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'errors');
        yield "
                        ";
        yield from [];
    }

    // line 27
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 28
        yield "                            ";
        yield (string) $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->searchAndRenderBlock(($context["form"] ?? null), 'rest');
        yield "
                        ";
        yield from [];
    }

    // line 30
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_body_post(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 31
        yield "                        ";
        yield from [];
    }

    // line 36
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_footer(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 37
        yield "                    ";
        yield from $this->unwrap()->yieldBlock('submit_button', $context, $blocks);
        // line 40
        yield "                    <button type=\"button\" class=\"btn btn-cancel\" data-bs-dismiss=\"modal\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans("action.close"), "html", null, true);
        yield "</button>
                ";
        yield from [];
    }

    // line 37
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_submit_button(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        // line 38
        yield "                        <button type=\"submit\" class=\"btn btn-primary pull-left modal-form-save\" data-loading-text=\"";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((array_key_exists("submit_button", $context)) ? (Twig\Extension\CoreExtension::default(($context["submit_button"] ?? null), "action.save")) : ("action.save"))), "html", null, true);
        yield "…\" id=\"";
        yield from         $this->unwrap()->yieldBlock("modal_id", $context, $blocks);
        yield "_save\" data-hotkey=\"ctrl+Enter\">";
        yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\TranslationExtension']->trans(((array_key_exists("submit_button", $context)) ? (Twig\Extension\CoreExtension::default(($context["submit_button"] ?? null), "action.save")) : ("action.save"))), "html", null, true);
        yield "</button>
                    ";
        yield from [];
    }

    // line 43
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_modal_end(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield (string)         $this->env->getRuntime('Symfony\Component\Form\FormRenderer')->renderBlock(($context["form"] ?? null), 'form_end');
        yield from [];
    }

    // line 44
    /**
     * @return iterable<null|scalar|\Stringable>
     */
    public function block_form_after(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "default/_form_modal.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  333 => 44,  322 => 43,  310 => 38,  303 => 37,  295 => 40,  292 => 37,  285 => 36,  280 => 31,  273 => 30,  265 => 28,  258 => 27,  250 => 25,  243 => 24,  238 => 32,  235 => 30,  232 => 27,  229 => 24,  222 => 23,  217 => 33,  214 => 23,  207 => 22,  202 => 17,  196 => 15,  194 => 14,  189 => 13,  182 => 12,  171 => 9,  161 => 8,  150 => 6,  130 => 5,  122 => 45,  119 => 44,  117 => 43,  114 => 42,  112 => 36,  108 => 34,  106 => 22,  102 => 21,  97 => 19,  94 => 18,  92 => 12,  88 => 11,  85 => 10,  82 => 9,  80 => 8,  75 => 6,  66 => 5,  62 => 3,  60 => 2,  58 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "default/_form_modal.html.twig", "/opt/kimai/templates/default/_form_modal.html.twig");
    }
}
