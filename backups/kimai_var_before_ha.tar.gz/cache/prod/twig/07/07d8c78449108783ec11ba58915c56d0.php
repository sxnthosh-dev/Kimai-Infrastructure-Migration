<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Sandbox\SecurityNotAllowedTestError;
use Twig\Source;
use Twig\Template;
use Twig\TemplateWrapper;

/* @Tabler/components/avatar.html.twig */
class __TwigTemplate_d72ee9270ff3fe8bd310698ffbefb3ff extends Template
{
    private Source $source;
    /**
     * @var array<string, Template>
     */
    private array $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = []): iterable
    {
        $macros = $this->macros;
        yield from [];
    }

    // line 1
    public function macro_avatar($options_or_user = null, $size = null, ...$varargs): string|Markup
    {
        $macros = $this->macros;
        $context = [
            "options_or_user" => $options_or_user,
            "size" => $size,
            "varargs" => $varargs,
        ] + $this->env->getGlobals();

        $blocks = [];

        return ('' === $tmp = \Twig\Extension\CoreExtension::captureOutput((function () use (&$context, $macros, $blocks) {
            // line 3
            yield "    ";
            // line 4
            yield "    ";
            $macros["utils"] = $this->load("@Tabler/includes/utils.html.twig", 4)->unwrap();
            // line 5
            yield "
    ";
            // line 7
            yield "    ";
            if (is_iterable(($context["options_or_user"] ?? null))) {
                // line 8
                yield "        ";
                $context["options"] = ($context["options_or_user"] ?? null);
                // line 9
                yield "    ";
            } else {
                // line 10
                yield "        ";
                trigger_deprecation('', '', "Passing multiple parameters to \x27avatar()\x27 Tabler macro is deprecated, use options object syntax."." in \"@Tabler/components/avatar.html.twig\" at line 10.");
                // line 11
                yield "        ";
                $macros["macro"] = $this->load("@Tabler/components/avatar_image.html.twig", 11)->unwrap();
                // line 12
                yield "        ";
                $context["options"] = ["content" => $macros["macro"]->getTemplateForMacro("macro_avatar_image", $context, 13, $this->getSourceContext())->macro_avatar_image(...[                // line 13
($context["options_or_user"] ?? null)]), "size" =>                 // line 14
($context["size"] ?? null)];
                // line 16
                yield "    ";
            }
            // line 17
            yield "
    ";
            // line 18
            $context["_content"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", true, true, false, 18) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", false, false, false, 18)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "content", [], "any", false, false, false, 18)) : (""));
            // line 19
            yield "    ";
            $context["_imageUrl"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "imageUrl", [], "any", true, true, false, 19) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "imageUrl", [], "any", false, false, false, 19)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "imageUrl", [], "any", false, false, false, 19)) : (""));
            // line 20
            yield "    ";
            $context["_color"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", true, true, false, 20) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 20)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "color", [], "any", false, false, false, 20)) : (""));
            // line 21
            yield "    ";
            $context["_size"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", true, true, false, 21) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", false, false, false, 21)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "size", [], "any", false, false, false, 21)) : (""));
            // line 22
            yield "    ";
            $context["_badge"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "badge", [], "any", true, true, false, 22) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "badge", [], "any", false, false, false, 22)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "badge", [], "any", false, false, false, 22)) : ([]));
            // line 23
            yield "    ";
            $context["_brand"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "brand", [], "any", true, true, false, 23) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "brand", [], "any", false, false, false, 23)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "brand", [], "any", false, false, false, 23)) : (false)) === true);
            // line 24
            yield "    ";
            $context["_upload"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "upload", [], "any", true, true, false, 24) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "upload", [], "any", false, false, false, 24)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "upload", [], "any", false, false, false, 24)) : (false)) === true);
            // line 25
            yield "    ";
            // line 26
            yield "    ";
            $context["_rounded"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "rounded", [], "any", true, true, false, 26) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "rounded", [], "any", false, false, false, 26)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "rounded", [], "any", false, false, false, 26)) : (false));
            // line 27
            yield "    ";
            $context["_circle"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "circle", [], "any", true, true, false, 27) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "circle", [], "any", false, false, false, 27)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "circle", [], "any", false, false, false, 27)) : (false)) === true);
            // line 28
            yield "    ";
            $context["_link"] = ((((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "link", [], "any", true, true, false, 28) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "link", [], "any", false, false, false, 28)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "link", [], "any", false, false, false, 28)) : (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", true, true, false, 28))) === true);
            // line 29
            yield "    ";
            $context["_href"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", true, true, false, 29) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", false, false, false, 29)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "href", [], "any", false, false, false, 29)) : (""));
            // line 30
            yield "    ";
            $context["_extraClass"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", true, true, false, 30) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 30)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "extraClass", [], "any", false, false, false, 30)) : (""));
            // line 31
            yield "    ";
            $context["_attr"] = (((CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", true, true, false, 31) &&  !(null === CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 31)))) ? (CoreExtension::getAttribute($this->env, $this->source, ($context["options"] ?? null), "attr", [], "any", false, false, false, 31)) : ([]));
            // line 32
            yield "
    ";
            // line 33
            $context["classes"] = ["avatar"];
            // line 34
            yield "
    ";
            // line 36
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_color"] ?? null))) {
                // line 37
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("bg-" . ($context["_color"] ?? null))]);
                // line 38
                yield "    ";
            }
            // line 39
            yield "
    ";
            // line 41
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_size"] ?? null))) {
                // line 42
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("avatar-" . ($context["_size"] ?? null))]);
                // line 43
                yield "    ";
            }
            // line 44
            yield "
    ";
            // line 46
            yield "    ";
            if ((($context["_brand"] ?? null) === true)) {
                // line 47
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["avatar-brand"]);
                // line 48
                yield "    ";
            }
            // line 49
            yield "
    ";
            // line 51
            yield "    ";
            if ((($context["_upload"] ?? null) === true)) {
                // line 52
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["avatar-upload"]);
                // line 53
                yield "    ";
            }
            // line 54
            yield "
    ";
            // line 56
            yield "    ";
            if ( !(($context["_rounded"] ?? null) === false)) {
                // line 57
                yield "        ";
                if ((($context["_rounded"] ?? null) === true)) {
                    // line 58
                    yield "            ";
                    $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["rounded"]);
                    // line 59
                    yield "        ";
                } else {
                    // line 60
                    yield "            ";
                    $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [("rounded-" . ($context["_rounded"] ?? null))]);
                    // line 61
                    yield "        ";
                }
                // line 62
                yield "    ";
            }
            // line 63
            yield "
    ";
            // line 65
            yield "    ";
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_circle"] ?? null))) {
                // line 66
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), ["rounded-circle"]);
                // line 67
                yield "    ";
            }
            // line 68
            yield "
    ";
            // line 69
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_extraClass"] ?? null))) {
                // line 70
                yield "        ";
                $context["classes"] = Twig\Extension\CoreExtension::merge(($context["classes"] ?? null), [($context["_extraClass"] ?? null)]);
                // line 71
                yield "    ";
            }
            // line 72
            yield "
    ";
            // line 73
            $context["classesStr"] = Twig\Extension\CoreExtension::join(($context["classes"] ?? null), " ");
            // line 74
            yield "
    ";
            // line 75
            if ((($tmp = ($context["_link"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                // line 76
                yield "        ";
                $context["type"] = "a";
                // line 77
                yield "    ";
            } else {
                // line 78
                yield "        ";
                $context["type"] = "span";
                // line 79
                yield "    ";
            }
            // line 80
            yield "
    <";
            // line 81
            yield (string) ($context["type"] ?? null);
            yield "
        class=\"";
            // line 82
            yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["classesStr"] ?? null), "html", null, true);
            yield "\"
        ";
            // line 83
            if ((($tmp = ($context["_imageUrl"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "style=\"background-image: url(";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_imageUrl"] ?? null), "html", null, true);
                yield ")\"";
            }
            // line 84
            yield "        ";
            if ((($tmp = ($context["_href"] ?? null)) && $tmp instanceof Markup ? (string) $tmp : $tmp)) {
                yield "href=\"";
                yield (string) $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape(($context["_href"] ?? null), "html", null, true);
                yield "\"";
            }
            // line 85
            yield "        ";
            yield (string) $macros["utils"]->getTemplateForMacro("macro_attr_to_html", $context, 85, $this->getSourceContext())->macro_attr_to_html(...[($context["_attr"] ?? null)]);
            yield "
    >
        ";
            // line 87
            yield (string) ($context["_content"] ?? null);
            yield "

        ";
            // line 89
            if ( !Twig\Extension\CoreExtension::testEmpty(($context["_badge"] ?? null))) {
                // line 90
                $macros["_v0"] = $this->load("@Tabler/components/badge.html.twig", 90)->unwrap();
                // line 91
                yield "            ";
                yield (string) $macros["_v0"]->getTemplateForMacro("macro_badge", $context, 91, $this->getSourceContext())->macro_badge(...[($context["_badge"] ?? null)]);
            }
            // line 93
            yield "    </";
            yield (string) ($context["type"] ?? null);
            yield ">";
            yield from [];
        })())) ? '' : new Markup($tmp, $this->env->getCharset());
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName(): string
    {
        return "@Tabler/components/avatar.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable(): bool
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo(): array
    {
        return array (  298 => 93,  294 => 91,  292 => 90,  290 => 89,  285 => 87,  279 => 85,  272 => 84,  266 => 83,  262 => 82,  258 => 81,  255 => 80,  252 => 79,  249 => 78,  246 => 77,  243 => 76,  241 => 75,  238 => 74,  236 => 73,  233 => 72,  230 => 71,  227 => 70,  225 => 69,  222 => 68,  219 => 67,  216 => 66,  213 => 65,  210 => 63,  207 => 62,  204 => 61,  201 => 60,  198 => 59,  195 => 58,  192 => 57,  189 => 56,  186 => 54,  183 => 53,  180 => 52,  177 => 51,  174 => 49,  171 => 48,  168 => 47,  165 => 46,  162 => 44,  159 => 43,  156 => 42,  153 => 41,  150 => 39,  147 => 38,  144 => 37,  141 => 36,  138 => 34,  136 => 33,  133 => 32,  130 => 31,  127 => 30,  124 => 29,  121 => 28,  118 => 27,  115 => 26,  113 => 25,  110 => 24,  107 => 23,  104 => 22,  101 => 21,  98 => 20,  95 => 19,  93 => 18,  90 => 17,  87 => 16,  85 => 14,  84 => 13,  82 => 12,  79 => 11,  76 => 10,  73 => 9,  70 => 8,  67 => 7,  64 => 5,  61 => 4,  59 => 3,  46 => 1,);
    }

    public function getSourceContext(): Source
    {
        return new Source("", "@Tabler/components/avatar.html.twig", "/opt/kimai/vendor/kevinpapst/tabler-bundle/templates/components/avatar.html.twig");
    }
}
